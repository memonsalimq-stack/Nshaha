.class public Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;
.super Ljava/lang/Object;
.source "Il2CppBinary.java"


# static fields
.field private static final MR_FIELD_COUNT:I = 0xe

.field private static final MR_FIELD_OFFSETS:I = 0xb

.field private static final MR_FIELD_OFFSETS_COUNT:I = 0xa

.field private static final MR_TYPES:I = 0x7

.field private static final MR_TYPES_COUNT:I = 0x6

.field private static final MR_TYPE_SIZES:I = 0xd

.field private static final MR_TYPE_SIZES_COUNT:I = 0xc


# instance fields
.field private final bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

.field private codeGenModulesVA:J

.field private countMatches:I

.field private final elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

.field private fieldOffsetsArePointers:Z

.field private fieldOffsetsVA:J

.field private final metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

.field private metadataRegistrationVA:J

.field private final notes:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private final pointerSize:I

.field private registrationOffset:J

.field private typeSizesVA:J

.field private typesCount:I

.field private typesVA:J


# direct methods
.method public constructor <init>(Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;)V
    .locals 9

    .prologue
    .line 47
    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v5, v1

    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    move-object v5, v1

    const/4 v6, -0x1

    int-to-long v6, v6

    iput-wide v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->metadataRegistrationVA:J

    move-object v5, v1

    const/4 v6, -0x1

    int-to-long v6, v6

    iput-wide v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->registrationOffset:J

    move-object v5, v1

    const/4 v6, -0x1

    int-to-long v6, v6

    iput-wide v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->codeGenModulesVA:J

    move-object v5, v1

    new-instance v6, Ljava/util/ArrayList;

    move-object v8, v6

    move-object v6, v8

    move-object v7, v8

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    iput-object v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->notes:Ljava/util/List;

    .line 48
    move-object v5, v1

    move-object v6, v2

    iput-object v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    .line 49
    move-object v5, v1

    move-object v6, v2

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->stream()Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-result-object v6

    iput-object v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    .line 50
    move-object v5, v1

    move-object v6, v3

    iput-object v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    .line 51
    move-object v5, v1

    move-object v6, v2

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->pointerSize()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    .line 53
    move-object v5, v1

    invoke-direct {v5}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->findMetadataRegistration()V

    .line 54
    move-object v5, v1

    invoke-direct {v5}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->findCodeGenModules()V

    .line 55
    move-object v5, v1

    invoke-direct {v5}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->detectFieldOffsetMode()V

    return-void
.end method

.method private arrayOfValidPointers(JI)Z
    .locals 21

    .prologue
    .line 251
    move-object/from16 v3, p0

    move-wide/from16 v4, p1

    move/from16 v6, p3

    move-object v12, v3

    iget-object v12, v12, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-wide v13, v4

    invoke-virtual {v12, v13, v14}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapVirtualAddress(J)J

    move-result-wide v12

    move-wide v8, v12

    .line 252
    move-wide v12, v8

    const/4 v14, 0x0

    int-to-long v14, v14

    cmp-long v12, v12, v14

    if-ltz v12, :cond_0

    move-wide v12, v8

    move v14, v6

    int-to-long v14, v14

    move-object/from16 v16, v3

    move-object/from16 v0, v16

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move/from16 v16, v0

    move/from16 v0, v16

    int-to-long v0, v0

    move-wide/from16 v16, v0

    mul-long v14, v14, v16

    add-long/2addr v12, v14

    move-object v14, v3

    iget-object v14, v14, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    invoke-virtual {v14}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->size()I

    move-result v14

    int-to-long v14, v14

    cmp-long v12, v12, v14

    if-lez v12, :cond_1

    .line 253
    :cond_0
    const/4 v12, 0x0

    move v3, v12

    .line 260
    :goto_0
    return v3

    .line 255
    :cond_1
    const/4 v12, 0x0

    move v10, v12

    :goto_1
    move v12, v10

    move v13, v6

    if-lt v12, v13, :cond_2

    .line 260
    const/4 v12, 0x1

    move v3, v12

    goto :goto_0

    .line 256
    :cond_2
    move-object v12, v3

    iget-object v12, v12, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object v13, v3

    move-wide v14, v8

    move/from16 v16, v10

    move/from16 v0, v16

    int-to-long v0, v0

    move-wide/from16 v16, v0

    move-object/from16 v18, v3

    move-object/from16 v0, v18

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move/from16 v18, v0

    move/from16 v0, v18

    int-to-long v0, v0

    move-wide/from16 v18, v0

    mul-long v16, v16, v18

    add-long v14, v14, v16

    invoke-direct {v13, v14, v15}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->readPtr(J)J

    move-result-wide v13

    invoke-virtual {v12, v13, v14}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->isValidPointer(J)Z

    move-result v12

    if-nez v12, :cond_3

    .line 257
    const/4 v12, 0x0

    move v3, v12

    goto :goto_0

    .line 255
    :cond_3
    add-int/lit8 v10, v10, 0x1

    goto :goto_1
.end method

.method private detectFieldOffsetMode()V
    .locals 21
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 268
    move-object/from16 v3, p0

    move-object v13, v3

    iget-object v13, v13, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object v14, v3

    iget-wide v14, v14, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->fieldOffsetsVA:J

    invoke-virtual {v13, v14, v15}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapVirtualAddress(J)J

    move-result-wide v13

    move-wide v5, v13

    .line 269
    move-wide v13, v5

    const/4 v15, 0x0

    int-to-long v15, v15

    cmp-long v13, v13, v15

    if-gez v13, :cond_0

    .line 270
    new-instance v13, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;

    move-object/from16 v20, v13

    move-object/from16 v13, v20

    move-object/from16 v14, v20

    const-string v15, "fieldOffsets \u0443\u043a\u0430\u0437\u044b\u0432\u0430\u0435\u0442 \u0432 \u043d\u0435\u043e\u0442\u043e\u0431\u0440\u0430\u0436\u0451\u043d\u043d\u0443\u044e \u043e\u0431\u043b\u0430\u0441\u0442\u044c"

    invoke-direct {v14, v15}, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;-><init>(Ljava/lang/String;)V

    throw v13

    .line 272
    :cond_0
    move-object v13, v3

    iget-object v13, v13, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    invoke-virtual {v13}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->types()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    move-result-object v13

    array-length v13, v13

    const/16 v14, 0x40

    invoke-static {v13, v14}, Ljava/lang/Math;->min(II)I

    move-result v13

    move v7, v13

    .line 273
    const/4 v13, 0x0

    move v8, v13

    .line 274
    const/4 v13, 0x0

    move v9, v13

    :goto_0
    move v13, v9

    move v14, v7

    if-lt v13, v14, :cond_2

    .line 280
    move-object v13, v3

    move v14, v8

    move v15, v7

    const/16 v16, 0x3

    mul-int/lit8 v15, v15, 0x3

    const/16 v16, 0x4

    div-int/lit8 v15, v15, 0x4

    if-ge v14, v15, :cond_5

    const/4 v14, 0x0

    :goto_1
    iput-boolean v14, v13, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->fieldOffsetsArePointers:Z

    .line 281
    move-object v13, v3

    iget-boolean v13, v13, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->fieldOffsetsArePointers:Z

    if-nez v13, :cond_1

    .line 282
    move-object v13, v3

    iget-object v13, v13, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->notes:Ljava/util/List;

    const-string v14, "fieldOffsets \u2014 \u043f\u043b\u043e\u0441\u043a\u0438\u0439 \u043c\u0430\u0441\u0441\u0438\u0432 int (\u0441\u0442\u0430\u0440\u044b\u0439 \u0444\u043e\u0440\u043c\u0430\u0442)"

    invoke-interface {v13, v14}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v13

    :cond_1
    return-void

    .line 275
    :cond_2
    move-object v13, v3

    move-wide v14, v5

    move/from16 v16, v9

    move/from16 v0, v16

    int-to-long v0, v0

    move-wide/from16 v16, v0

    move-object/from16 v18, v3

    move-object/from16 v0, v18

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move/from16 v18, v0

    move/from16 v0, v18

    int-to-long v0, v0

    move-wide/from16 v18, v0

    mul-long v16, v16, v18

    add-long v14, v14, v16

    invoke-direct {v13, v14, v15}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->readPtr(J)J

    move-result-wide v13

    move-wide v10, v13

    .line 276
    move-wide v13, v10

    const/4 v15, 0x0

    int-to-long v15, v15

    cmp-long v13, v13, v15

    if-eqz v13, :cond_3

    move-object v13, v3

    iget-object v13, v13, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-wide v14, v10

    invoke-virtual {v13, v14, v15}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->isValidPointer(J)Z

    move-result v13

    if-eqz v13, :cond_4

    .line 277
    :cond_3
    add-int/lit8 v8, v8, 0x1

    .line 274
    :cond_4
    add-int/lit8 v9, v9, 0x1

    goto :goto_0

    .line 280
    :cond_5
    const/4 v14, 0x1

    goto :goto_1
.end method

.method private field(JI)J
    .locals 13

    .prologue
    .line 115
    move-object v0, p0

    move-wide v1, p1

    move/from16 v3, p3

    move-object v5, v0

    move-wide v6, v1

    move v8, v3

    int-to-long v8, v8

    move-object v10, v0

    iget v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    int-to-long v10, v10

    mul-long/2addr v8, v10

    add-long/2addr v6, v8

    invoke-direct {v5, v6, v7}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->readPtr(J)J

    move-result-wide v5

    move-wide v0, v5

    return-wide v0
.end method

.method private findCodeGenModules()V
    .locals 29
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 177
    move-object/from16 v4, p0

    move-object/from16 v22, v4

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object/from16 v22, v0

    invoke-virtual/range {v22 .. v22}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->images()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;

    move-result-object v22

    move-object/from16 v0, v22

    array-length v0, v0

    move/from16 v22, v0

    move/from16 v6, v22

    .line 178
    move/from16 v22, v6

    const/16 v23, 0x0

    move/from16 v0, v22

    move/from16 v1, v23

    if-gt v0, v1, :cond_0

    .line 179
    move-object/from16 v22, v4

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->notes:Ljava/util/List;

    move-object/from16 v22, v0

    const-string v23, "\u0441\u0431\u043e\u0440\u043e\u043a \u043d\u0435\u0442 \u2014 \u043f\u043e\u0438\u0441\u043a codeGenModules \u043f\u0440\u043e\u043f\u0443\u0449\u0435\u043d"

    invoke-interface/range {v22 .. v23}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v22

    .line 220
    :goto_0
    return-void

    .line 183
    :cond_0
    move/from16 v22, v6

    move/from16 v0, v22

    new-array v0, v0, [Ljava/lang/String;

    move-object/from16 v22, v0

    move-object/from16 v7, v22

    .line 184
    const/16 v22, 0x0

    move/from16 v8, v22

    :goto_1
    move/from16 v22, v8

    move/from16 v23, v6

    move/from16 v0, v22

    move/from16 v1, v23

    if-lt v0, v1, :cond_2

    .line 188
    const/16 v22, 0x0

    move/from16 v8, v22

    .line 189
    move-object/from16 v22, v4

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v22, v0

    invoke-virtual/range {v22 .. v22}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->segments()Ljava/util/List;

    move-result-object v22

    move-object/from16 v9, v22

    .line 190
    const/16 v22, 0x0

    move/from16 v10, v22

    :goto_2
    move/from16 v22, v10

    move-object/from16 v23, v9

    invoke-interface/range {v23 .. v23}, Ljava/util/List;->size()I

    move-result v23

    move/from16 v0, v22

    move/from16 v1, v23

    if-lt v0, v1, :cond_3

    .line 217
    move-object/from16 v22, v4

    move-object/from16 v0, v22

    iget-wide v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->codeGenModulesVA:J

    move-wide/from16 v22, v0

    const/16 v24, 0x0

    move/from16 v0, v24

    int-to-long v0, v0

    move-wide/from16 v24, v0

    cmp-long v22, v22, v24

    if-gez v22, :cond_a

    .line 218
    move-object/from16 v22, v4

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->notes:Ljava/util/List;

    move-object/from16 v22, v0

    const-string v23, "codeGenModules \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d \u2014 \u0430\u0434\u0440\u0435\u0441\u0430 \u043c\u0435\u0442\u043e\u0434\u043e\u0432 \u0431\u0443\u0434\u0443\u0442 \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u043d\u044b"

    invoke-interface/range {v22 .. v23}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v22

    .line 220
    :cond_1
    :goto_3
    goto :goto_0

    .line 185
    :cond_2
    move-object/from16 v22, v7

    move/from16 v23, v8

    move-object/from16 v24, v4

    move-object/from16 v0, v24

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object/from16 v24, v0

    move-object/from16 v25, v4

    move-object/from16 v0, v25

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object/from16 v25, v0

    invoke-virtual/range {v25 .. v25}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->images()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;

    move-result-object v25

    move/from16 v26, v8

    aget-object v25, v25, v26

    move-object/from16 v0, v25

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;->nameIndex:I

    move/from16 v25, v0

    invoke-virtual/range {v24 .. v25}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->getString(I)Ljava/lang/String;

    move-result-object v24

    aput-object v24, v22, v23

    .line 184
    add-int/lit8 v8, v8, 0x1

    goto :goto_1

    .line 191
    :cond_3
    move-object/from16 v22, v9

    move/from16 v23, v10

    invoke-interface/range {v22 .. v23}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v22

    check-cast v22, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile$Segment;

    move-object/from16 v11, v22

    .line 192
    move-object/from16 v22, v11

    move-object/from16 v0, v22

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile$Segment;->type:I

    move/from16 v22, v0

    const/16 v23, 0x1

    move/from16 v0, v22

    move/from16 v1, v23

    if-eq v0, v1, :cond_5

    .line 190
    :cond_4
    add-int/lit8 v10, v10, 0x1

    goto :goto_2

    .line 195
    :cond_5
    move-object/from16 v22, v11

    move-object/from16 v0, v22

    iget-wide v0, v0, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile$Segment;->offset:J

    move-wide/from16 v22, v0

    move-object/from16 v24, v4

    move-object/from16 v0, v24

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move/from16 v24, v0

    move/from16 v0, v24

    int-to-long v0, v0

    move-wide/from16 v24, v0

    add-long v22, v22, v24

    const/16 v24, 0x1

    move/from16 v0, v24

    int-to-long v0, v0

    move-wide/from16 v24, v0

    sub-long v22, v22, v24

    move-object/from16 v24, v4

    move-object/from16 v0, v24

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move/from16 v24, v0

    move/from16 v0, v24

    int-to-long v0, v0

    move-wide/from16 v24, v0

    div-long v22, v22, v24

    move-object/from16 v24, v4

    move-object/from16 v0, v24

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move/from16 v24, v0

    move/from16 v0, v24

    int-to-long v0, v0

    move-wide/from16 v24, v0

    mul-long v22, v22, v24

    move-wide/from16 v12, v22

    .line 196
    move-object/from16 v22, v4

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object/from16 v22, v0

    invoke-virtual/range {v22 .. v22}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->size()I

    move-result v22

    move/from16 v0, v22

    int-to-long v0, v0

    move-wide/from16 v22, v0

    move-object/from16 v24, v11

    move-object/from16 v0, v24

    iget-wide v0, v0, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile$Segment;->offset:J

    move-wide/from16 v24, v0

    move-object/from16 v26, v11

    move-object/from16 v0, v26

    iget-wide v0, v0, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile$Segment;->fileSize:J

    move-wide/from16 v26, v0

    add-long v24, v24, v26

    invoke-static/range {v22 .. v25}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v22

    const-wide/16 v24, 0x2

    move-object/from16 v26, v4

    move-object/from16 v0, v26

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move/from16 v26, v0

    move/from16 v0, v26

    int-to-long v0, v0

    move-wide/from16 v26, v0

    mul-long v24, v24, v26

    sub-long v22, v22, v24

    move-wide/from16 v14, v22

    .line 198
    move-wide/from16 v22, v12

    move-wide/from16 v16, v22

    :goto_4
    move-wide/from16 v22, v16

    move-wide/from16 v24, v14

    cmp-long v22, v22, v24

    if-gtz v22, :cond_4

    .line 199
    move-object/from16 v22, v4

    move-wide/from16 v23, v16

    invoke-direct/range {v22 .. v24}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->readPtr(J)J

    move-result-wide v22

    move/from16 v24, v6

    move/from16 v0, v24

    int-to-long v0, v0

    move-wide/from16 v24, v0

    cmp-long v22, v22, v24

    if-eqz v22, :cond_7

    .line 198
    :cond_6
    :goto_5
    move-wide/from16 v22, v16

    move-object/from16 v24, v4

    move-object/from16 v0, v24

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move/from16 v24, v0

    move/from16 v0, v24

    int-to-long v0, v0

    move-wide/from16 v24, v0

    add-long v22, v22, v24

    move-wide/from16 v16, v22

    goto :goto_4

    .line 202
    :cond_7
    move-object/from16 v22, v4

    move-wide/from16 v23, v16

    move-object/from16 v25, v4

    move-object/from16 v0, v25

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move/from16 v25, v0

    move/from16 v0, v25

    int-to-long v0, v0

    move-wide/from16 v25, v0

    add-long v23, v23, v25

    invoke-direct/range {v22 .. v24}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->readPtr(J)J

    move-result-wide v22

    move-wide/from16 v18, v22

    .line 203
    move-object/from16 v22, v4

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v22, v0

    move-wide/from16 v23, v18

    invoke-virtual/range {v22 .. v24}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->isValidPointer(J)Z

    move-result v22

    if-eqz v22, :cond_8

    move-object/from16 v22, v4

    move-wide/from16 v23, v18

    move/from16 v25, v6

    invoke-direct/range {v22 .. v25}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->arrayOfValidPointers(JI)Z

    move-result v22

    if-nez v22, :cond_9

    .line 204
    :cond_8
    goto :goto_5

    .line 206
    :cond_9
    move-object/from16 v22, v4

    move-wide/from16 v23, v18

    move-object/from16 v25, v7

    invoke-direct/range {v22 .. v25}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->scoreModuleNames(J[Ljava/lang/String;)I

    move-result v22

    move/from16 v20, v22

    .line 207
    move/from16 v22, v20

    move/from16 v23, v8

    move/from16 v0, v22

    move/from16 v1, v23

    if-le v0, v1, :cond_6

    .line 208
    move/from16 v22, v20

    move/from16 v8, v22

    .line 209
    move-object/from16 v22, v4

    move-wide/from16 v23, v18

    move-wide/from16 v0, v23

    move-object/from16 v2, v22

    iput-wide v0, v2, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->codeGenModulesVA:J

    .line 210
    move/from16 v22, v20

    const/16 v23, 0x64

    move/from16 v0, v22

    move/from16 v1, v23

    if-ne v0, v1, :cond_6

    .line 211
    goto/16 :goto_0

    .line 219
    :cond_a
    move/from16 v22, v8

    const/16 v23, 0x64

    move/from16 v0, v22

    move/from16 v1, v23

    if-ge v0, v1, :cond_1

    .line 220
    move-object/from16 v22, v4

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->notes:Ljava/util/List;

    move-object/from16 v22, v0

    new-instance v23, Ljava/lang/StringBuffer;

    move-object/from16 v28, v23

    move-object/from16 v23, v28

    move-object/from16 v24, v28

    invoke-direct/range {v24 .. v24}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v24, Ljava/lang/StringBuffer;

    move-object/from16 v28, v24

    move-object/from16 v24, v28

    move-object/from16 v25, v28

    invoke-direct/range {v25 .. v25}, Ljava/lang/StringBuffer;-><init>()V

    const-string v25, "codeGenModules \u043d\u0430\u0439\u0434\u0435\u043d \u0441 \u0441\u043e\u0432\u043f\u0430\u0434\u0435\u043d\u0438\u0435\u043c \u0438\u043c\u0451\u043d "

    invoke-virtual/range {v24 .. v25}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v24

    move/from16 v25, v8

    invoke-virtual/range {v24 .. v25}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v24

    invoke-virtual/range {v24 .. v24}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v24

    invoke-virtual/range {v23 .. v24}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v23

    const-string v24, "% \u2014 \u0447\u0430\u0441\u0442\u044c \u0430\u0434\u0440\u0435\u0441\u043e\u0432 \u043c\u043e\u0436\u0435\u0442 \u0431\u044b\u0442\u044c \u043d\u0435\u0432\u0435\u0440\u043d\u043e\u0439"

    invoke-virtual/range {v23 .. v24}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v23

    invoke-virtual/range {v23 .. v23}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v23

    invoke-interface/range {v22 .. v23}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v22

    goto/16 :goto_3
.end method

.method private findMetadataRegistration()V
    .locals 32
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 121
    move-object/from16 v4, p0

    move-object/from16 v22, v4

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object/from16 v22, v0

    invoke-virtual/range {v22 .. v22}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->types()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    move-result-object v22

    move-object/from16 v0, v22

    array-length v0, v0

    move/from16 v22, v0

    move/from16 v6, v22

    .line 122
    const/16 v22, 0xe

    move-object/from16 v23, v4

    move-object/from16 v0, v23

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move/from16 v23, v0

    mul-int v22, v22, v23

    move/from16 v7, v22

    .line 124
    move-object/from16 v22, v4

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v22, v0

    invoke-virtual/range {v22 .. v22}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->segments()Ljava/util/List;

    move-result-object v22

    move-object/from16 v8, v22

    .line 125
    const/16 v22, 0x0

    move/from16 v9, v22

    :goto_0
    move/from16 v22, v9

    move-object/from16 v23, v8

    invoke-interface/range {v23 .. v23}, Ljava/util/List;->size()I

    move-result v23

    move/from16 v0, v22

    move/from16 v1, v23

    if-lt v0, v1, :cond_0

    .line 158
    new-instance v22, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;

    move-object/from16 v31, v22

    move-object/from16 v22, v31

    move-object/from16 v23, v31

    new-instance v24, Ljava/lang/StringBuffer;

    move-object/from16 v31, v24

    move-object/from16 v24, v31

    move-object/from16 v25, v31

    invoke-direct/range {v25 .. v25}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v25, Ljava/lang/StringBuffer;

    move-object/from16 v31, v25

    move-object/from16 v25, v31

    move-object/from16 v26, v31

    invoke-direct/range {v26 .. v26}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v26, Ljava/lang/StringBuffer;

    move-object/from16 v31, v26

    move-object/from16 v26, v31

    move-object/from16 v27, v31

    invoke-direct/range {v27 .. v27}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v27, Ljava/lang/StringBuffer;

    move-object/from16 v31, v27

    move-object/from16 v27, v31

    move-object/from16 v28, v31

    invoke-direct/range {v28 .. v28}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v28, Ljava/lang/StringBuffer;

    move-object/from16 v31, v28

    move-object/from16 v28, v31

    move-object/from16 v29, v31

    invoke-direct/range {v29 .. v29}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v29, Ljava/lang/StringBuffer;

    move-object/from16 v31, v29

    move-object/from16 v29, v31

    move-object/from16 v30, v31

    invoke-direct/range {v30 .. v30}, Ljava/lang/StringBuffer;-><init>()V

    const-string v30, "MetadataRegistration \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d."

    invoke-virtual/range {v29 .. v30}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v29

    const-string v30, " \u0421\u043e\u0432\u043f\u0430\u0434\u0435\u043d\u0438\u0439 \u043f\u043e \u0447\u0438\u0441\u043b\u0443 \u043a\u043b\u0430\u0441\u0441\u043e\u0432 ("

    invoke-virtual/range {v29 .. v30}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v29

    invoke-virtual/range {v29 .. v29}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v29

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v28

    move/from16 v29, v6

    invoke-virtual/range {v28 .. v29}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v28

    invoke-virtual/range {v28 .. v28}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v28

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v27

    const-string v28, "): "

    invoke-virtual/range {v27 .. v28}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v27

    invoke-virtual/range {v27 .. v27}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v27

    invoke-virtual/range {v26 .. v27}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v26

    move-object/from16 v27, v4

    move-object/from16 v0, v27

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->countMatches:I

    move/from16 v27, v0

    invoke-virtual/range {v26 .. v27}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v26

    invoke-virtual/range {v26 .. v26}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v26

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v25

    const-string v26, ", \u0438\u0437 \u043d\u0438\u0445 \u0441 \u0432\u0430\u043b\u0438\u0434\u043d\u044b\u043c\u0438 \u0443\u043a\u0430\u0437\u0430\u0442\u0435\u043b\u044f\u043c\u0438: 0."

    invoke-virtual/range {v25 .. v26}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v25

    invoke-virtual/range {v25 .. v25}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v25

    invoke-virtual/range {v24 .. v25}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v24

    move-object/from16 v25, v4

    move-object/from16 v0, v25

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->countMatches:I

    move/from16 v25, v0

    const/16 v26, 0x0

    move/from16 v0, v25

    move/from16 v1, v26

    if-le v0, v1, :cond_7

    const-string v25, " \u0421\u0447\u0451\u0442\u0447\u0438\u043a\u0438 \u043d\u0430\u0448\u043b\u0438\u0441\u044c, \u0430 \u0443\u043a\u0430\u0437\u0430\u0442\u0435\u043b\u0438 \u043f\u0443\u0441\u0442\u044b\u0435 \u2014 \u0437\u043d\u0430\u0447\u0438\u0442, \u0440\u0435\u043b\u043e\u043a\u0430\u0446\u0438\u0438 \u043d\u0435 \u043f\u0440\u0438\u043c\u0435\u043d\u0438\u043b\u0438\u0441\u044c."

    :goto_1
    invoke-virtual/range {v24 .. v25}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v24

    invoke-virtual/range {v24 .. v24}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v24

    invoke-direct/range {v23 .. v24}, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;-><init>(Ljava/lang/String;)V

    throw v22

    .line 126
    :cond_0
    move-object/from16 v22, v8

    move/from16 v23, v9

    invoke-interface/range {v22 .. v23}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v22

    check-cast v22, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile$Segment;

    move-object/from16 v10, v22

    .line 127
    move-object/from16 v22, v10

    move-object/from16 v0, v22

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile$Segment;->type:I

    move/from16 v22, v0

    const/16 v23, 0x1

    move/from16 v0, v22

    move/from16 v1, v23

    if-eq v0, v1, :cond_2

    .line 125
    :cond_1
    add-int/lit8 v9, v9, 0x1

    goto/16 :goto_0

    .line 130
    :cond_2
    move-object/from16 v22, v10

    move-object/from16 v0, v22

    iget-wide v0, v0, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile$Segment;->offset:J

    move-wide/from16 v22, v0

    move-wide/from16 v11, v22

    .line 131
    move-object/from16 v22, v4

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object/from16 v22, v0

    invoke-virtual/range {v22 .. v22}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->size()I

    move-result v22

    move/from16 v0, v22

    int-to-long v0, v0

    move-wide/from16 v22, v0

    move-object/from16 v24, v10

    move-object/from16 v0, v24

    iget-wide v0, v0, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile$Segment;->offset:J

    move-wide/from16 v24, v0

    move-object/from16 v26, v10

    move-object/from16 v0, v26

    iget-wide v0, v0, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile$Segment;->fileSize:J

    move-wide/from16 v26, v0

    add-long v24, v24, v26

    invoke-static/range {v22 .. v25}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v22

    move/from16 v24, v7

    move/from16 v0, v24

    int-to-long v0, v0

    move-wide/from16 v24, v0

    sub-long v22, v22, v24

    move-wide/from16 v13, v22

    .line 133
    move-wide/from16 v22, v11

    move-object/from16 v24, v4

    move-object/from16 v0, v24

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move/from16 v24, v0

    move/from16 v0, v24

    int-to-long v0, v0

    move-wide/from16 v24, v0

    add-long v22, v22, v24

    const/16 v24, 0x1

    move/from16 v0, v24

    int-to-long v0, v0

    move-wide/from16 v24, v0

    sub-long v22, v22, v24

    move-object/from16 v24, v4

    move-object/from16 v0, v24

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move/from16 v24, v0

    move/from16 v0, v24

    int-to-long v0, v0

    move-wide/from16 v24, v0

    div-long v22, v22, v24

    move-object/from16 v24, v4

    move-object/from16 v0, v24

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move/from16 v24, v0

    move/from16 v0, v24

    int-to-long v0, v0

    move-wide/from16 v24, v0

    mul-long v22, v22, v24

    move-wide/from16 v11, v22

    .line 135
    move-wide/from16 v22, v11

    move-wide/from16 v15, v22

    :goto_2
    move-wide/from16 v22, v15

    move-wide/from16 v24, v13

    cmp-long v22, v22, v24

    if-gtz v22, :cond_1

    .line 136
    move-object/from16 v22, v4

    move-wide/from16 v23, v15

    const/16 v25, 0xa

    invoke-direct/range {v22 .. v25}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->field(JI)J

    move-result-wide v22

    move/from16 v24, v6

    move/from16 v0, v24

    int-to-long v0, v0

    move-wide/from16 v24, v0

    cmp-long v22, v22, v24

    if-eqz v22, :cond_3

    .line 135
    :goto_3
    move-wide/from16 v22, v15

    move-object/from16 v24, v4

    move-object/from16 v0, v24

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move/from16 v24, v0

    move/from16 v0, v24

    int-to-long v0, v0

    move-wide/from16 v24, v0

    add-long v22, v22, v24

    move-wide/from16 v15, v22

    goto :goto_2

    .line 139
    :cond_3
    move-object/from16 v22, v4

    move-wide/from16 v23, v15

    const/16 v25, 0xc

    invoke-direct/range {v22 .. v25}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->field(JI)J

    move-result-wide v22

    move/from16 v24, v6

    move/from16 v0, v24

    int-to-long v0, v0

    move-wide/from16 v24, v0

    cmp-long v22, v22, v24

    if-eqz v22, :cond_4

    .line 140
    goto :goto_3

    .line 142
    :cond_4
    move-object/from16 v22, v4

    move-wide/from16 v23, v15

    const/16 v25, 0xb

    invoke-direct/range {v22 .. v25}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->field(JI)J

    move-result-wide v22

    move-wide/from16 v17, v22

    .line 143
    move-object/from16 v22, v4

    move-wide/from16 v23, v15

    const/16 v25, 0xd

    invoke-direct/range {v22 .. v25}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->field(JI)J

    move-result-wide v22

    move-wide/from16 v19, v22

    .line 144
    move-object/from16 v22, v4

    move-object/from16 v31, v22

    move-object/from16 v22, v31

    move-object/from16 v23, v31

    move-object/from16 v0, v23

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->countMatches:I

    move/from16 v23, v0

    const/16 v24, 0x1

    add-int/lit8 v23, v23, 0x1

    move/from16 v0, v23

    move-object/from16 v1, v22

    iput v0, v1, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->countMatches:I

    .line 146
    move-object/from16 v22, v4

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v22, v0

    move-wide/from16 v23, v17

    invoke-virtual/range {v22 .. v24}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->isValidPointer(J)Z

    move-result v22

    if-eqz v22, :cond_5

    move-object/from16 v22, v4

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v22, v0

    move-wide/from16 v23, v19

    invoke-virtual/range {v22 .. v24}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->isValidPointer(J)Z

    move-result v22

    if-nez v22, :cond_6

    .line 147
    :cond_5
    goto :goto_3

    .line 150
    :cond_6
    move-object/from16 v22, v4

    move-object/from16 v23, v4

    move-object/from16 v0, v23

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v23, v0

    move-wide/from16 v24, v15

    invoke-virtual/range {v23 .. v25}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapFileOffset(J)J

    move-result-wide v23

    move-wide/from16 v0, v23

    move-object/from16 v2, v22

    iput-wide v0, v2, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->metadataRegistrationVA:J

    .line 151
    move-object/from16 v22, v4

    move-wide/from16 v23, v15

    move-wide/from16 v0, v23

    move-object/from16 v2, v22

    iput-wide v0, v2, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->registrationOffset:J

    .line 152
    move-object/from16 v22, v4

    move-wide/from16 v23, v17

    move-wide/from16 v0, v23

    move-object/from16 v2, v22

    iput-wide v0, v2, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->fieldOffsetsVA:J

    .line 153
    move-object/from16 v22, v4

    move-wide/from16 v23, v19

    move-wide/from16 v0, v23

    move-object/from16 v2, v22

    iput-wide v0, v2, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->typeSizesVA:J

    .line 154
    return-void

    .line 158
    :cond_7
    const-string v25, " \u0411\u0438\u0431\u043b\u0438\u043e\u0442\u0435\u043a\u0430 \u043c\u043e\u0436\u0435\u0442 \u0431\u044b\u0442\u044c \u0443\u043f\u0430\u043a\u043e\u0432\u0430\u043d\u0430, \u0438\u043b\u0438 .so \u043d\u0435 \u043e\u0442 \u044d\u0442\u0438\u0445 \u043c\u0435\u0442\u0430\u0434\u0430\u043d\u043d\u044b\u0445."

    goto/16 :goto_1
.end method

.method private isExecutable(J)Z
    .locals 15

    .prologue
    .line 435
    move-object v1, p0

    move-wide/from16 v2, p1

    const/4 v8, 0x0

    move v5, v8

    :goto_0
    move v8, v5

    move-object v9, v1

    iget-object v9, v9, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    invoke-virtual {v9}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->segments()Ljava/util/List;

    move-result-object v9

    invoke-interface {v9}, Ljava/util/List;->size()I

    move-result v9

    if-lt v8, v9, :cond_0

    .line 444
    const/4 v8, 0x0

    move v1, v8

    :goto_1
    return v1

    .line 436
    :cond_0
    move-object v8, v1

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    invoke-virtual {v8}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->segments()Ljava/util/List;

    move-result-object v8

    move v9, v5

    invoke-interface {v8, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile$Segment;

    move-object v6, v8

    .line 437
    move-object v8, v6

    iget v8, v8, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile$Segment;->type:I

    const/4 v9, 0x1

    if-ne v8, v9, :cond_1

    move-object v8, v6

    iget v8, v8, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile$Segment;->flags:I

    const/4 v9, 0x1

    and-int/lit8 v8, v8, 0x1

    const/4 v9, 0x0

    if-ne v8, v9, :cond_2

    .line 435
    :cond_1
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    .line 440
    :cond_2
    move-wide v8, v2

    move-object v10, v6

    iget-wide v10, v10, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile$Segment;->virtualAddress:J

    cmp-long v8, v8, v10

    if-ltz v8, :cond_1

    move-wide v8, v2

    move-object v10, v6

    iget-wide v10, v10, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile$Segment;->virtualAddress:J

    move-object v12, v6

    iget-wide v12, v12, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile$Segment;->memorySize:J

    add-long/2addr v10, v12

    cmp-long v8, v8, v10

    if-gez v8, :cond_1

    .line 441
    const/4 v8, 0x1

    move v1, v8

    goto :goto_1
.end method

.method private moduleVA(I)J
    .locals 13

    .prologue
    .line 336
    move-object v0, p0

    move v1, p1

    move-object v6, v0

    iget-wide v6, v6, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->codeGenModulesVA:J

    const/4 v8, 0x0

    int-to-long v8, v8

    cmp-long v6, v6, v8

    if-gez v6, :cond_0

    .line 337
    const/4 v6, -0x1

    int-to-long v6, v6

    move-wide v0, v6

    .line 343
    :goto_0
    return-wide v0

    .line 339
    :cond_0
    move-object v6, v0

    iget-object v6, v6, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object v7, v0

    iget-wide v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->codeGenModulesVA:J

    invoke-virtual {v6, v7, v8}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapVirtualAddress(J)J

    move-result-wide v6

    move-wide v3, v6

    .line 340
    move-wide v6, v3

    const/4 v8, 0x0

    int-to-long v8, v8

    cmp-long v6, v6, v8

    if-gez v6, :cond_1

    .line 341
    const/4 v6, -0x1

    int-to-long v6, v6

    move-wide v0, v6

    goto :goto_0

    .line 343
    :cond_1
    move-object v6, v0

    move-wide v7, v3

    move v9, v1

    int-to-long v9, v9

    move-object v11, v0

    iget v11, v11, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    int-to-long v11, v11

    mul-long/2addr v9, v11

    add-long/2addr v7, v9

    invoke-direct {v6, v7, v8}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->readPtr(J)J

    move-result-wide v6

    move-wide v0, v6

    goto :goto_0
.end method

.method private readPtr(J)J
    .locals 7

    .prologue
    .line 110
    move-object v0, p0

    move-wide v1, p1

    move-object v4, v0

    iget-object v4, v4, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-wide v5, v1

    long-to-int v5, v5

    invoke-virtual {v4, v5}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readPointerAt(I)J

    move-result-wide v4

    move-wide v0, v4

    return-wide v0
.end method

.method private scoreModuleNames(J[Ljava/lang/String;)I
    .locals 29

    .prologue
    .line 227
    move-object/from16 v3, p0

    move-wide/from16 v4, p1

    move-object/from16 v6, p3

    move-object/from16 v21, v3

    move-object/from16 v0, v21

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v21, v0

    move-wide/from16 v22, v4

    invoke-virtual/range {v21 .. v23}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapVirtualAddress(J)J

    move-result-wide v21

    move-wide/from16 v8, v21

    .line 228
    move-wide/from16 v21, v8

    const/16 v23, 0x0

    move/from16 v0, v23

    int-to-long v0, v0

    move-wide/from16 v23, v0

    cmp-long v21, v21, v23

    if-gez v21, :cond_0

    .line 229
    const/16 v21, 0x0

    move/from16 v3, v21

    .line 247
    :goto_0
    return v3

    .line 231
    :cond_0
    const/16 v21, 0x0

    move/from16 v10, v21

    .line 232
    const/16 v21, 0x0

    move/from16 v11, v21

    :goto_1
    move/from16 v21, v11

    move-object/from16 v22, v6

    move-object/from16 v0, v22

    array-length v0, v0

    move/from16 v22, v0

    move/from16 v0, v21

    move/from16 v1, v22

    if-lt v0, v1, :cond_1

    .line 247
    move/from16 v21, v10

    const/16 v22, 0x64

    mul-int/lit8 v21, v21, 0x64

    move-object/from16 v22, v6

    move-object/from16 v0, v22

    array-length v0, v0

    move/from16 v22, v0

    div-int v21, v21, v22

    move/from16 v3, v21

    goto :goto_0

    .line 233
    :cond_1
    move-object/from16 v21, v3

    move-wide/from16 v22, v8

    move/from16 v24, v11

    move/from16 v0, v24

    int-to-long v0, v0

    move-wide/from16 v24, v0

    move-object/from16 v26, v3

    move-object/from16 v0, v26

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move/from16 v26, v0

    move/from16 v0, v26

    int-to-long v0, v0

    move-wide/from16 v26, v0

    mul-long v24, v24, v26

    add-long v22, v22, v24

    invoke-direct/range {v21 .. v23}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->readPtr(J)J

    move-result-wide v21

    move-wide/from16 v12, v21

    .line 234
    move-object/from16 v21, v3

    move-object/from16 v0, v21

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v21, v0

    move-wide/from16 v22, v12

    invoke-virtual/range {v21 .. v23}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapVirtualAddress(J)J

    move-result-wide v21

    move-wide/from16 v14, v21

    .line 235
    move-wide/from16 v21, v14

    const/16 v23, 0x0

    move/from16 v0, v23

    int-to-long v0, v0

    move-wide/from16 v23, v0

    cmp-long v21, v21, v23

    if-gez v21, :cond_3

    .line 232
    :cond_2
    :goto_2
    add-int/lit8 v11, v11, 0x1

    goto :goto_1

    .line 238
    :cond_3
    move-object/from16 v21, v3

    move-wide/from16 v22, v14

    invoke-direct/range {v21 .. v23}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->readPtr(J)J

    move-result-wide v21

    move-wide/from16 v16, v21

    .line 239
    move-object/from16 v21, v3

    move-object/from16 v0, v21

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v21, v0

    move-wide/from16 v22, v16

    invoke-virtual/range {v21 .. v23}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapVirtualAddress(J)J

    move-result-wide v21

    move-wide/from16 v18, v21

    .line 240
    move-wide/from16 v21, v18

    const/16 v23, 0x0

    move/from16 v0, v23

    int-to-long v0, v0

    move-wide/from16 v23, v0

    cmp-long v21, v21, v23

    if-ltz v21, :cond_4

    move-wide/from16 v21, v18

    move-object/from16 v23, v3

    move-object/from16 v0, v23

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object/from16 v23, v0

    invoke-virtual/range {v23 .. v23}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->size()I

    move-result v23

    move/from16 v0, v23

    int-to-long v0, v0

    move-wide/from16 v23, v0

    cmp-long v21, v21, v23

    if-ltz v21, :cond_5

    .line 241
    :cond_4
    goto :goto_2

    .line 243
    :cond_5
    move-object/from16 v21, v6

    move/from16 v22, v11

    aget-object v21, v21, v22

    move-object/from16 v22, v3

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object/from16 v22, v0

    move-wide/from16 v23, v18

    move-wide/from16 v0, v23

    long-to-int v0, v0

    move/from16 v23, v0

    invoke-virtual/range {v22 .. v23}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readStringToNull(I)Ljava/lang/String;

    move-result-object v22

    invoke-virtual/range {v21 .. v22}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v21

    if-eqz v21, :cond_2

    .line 244
    add-int/lit8 v10, v10, 0x1

    goto :goto_2
.end method


# virtual methods
.method public checkMethodPointers(I)Ljava/lang/String;
    .locals 36

    .prologue
    .line 400
    move-object/from16 v2, p0

    move/from16 v3, p1

    move-object/from16 v24, v2

    move/from16 v25, v3

    invoke-direct/range {v24 .. v25}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->moduleVA(I)J

    move-result-wide v24

    move-wide/from16 v5, v24

    .line 401
    move-wide/from16 v24, v5

    const/16 v26, 0x0

    move/from16 v0, v26

    int-to-long v0, v0

    move-wide/from16 v26, v0

    cmp-long v24, v24, v26

    if-gtz v24, :cond_0

    .line 402
    const-string v24, "\u043c\u043e\u0434\u0443\u043b\u044c \u043d\u0435\u0434\u043e\u0441\u0442\u0443\u043f\u0435\u043d"

    move-object/from16 v2, v24

    .line 430
    :goto_0
    return-object v2

    .line 404
    :cond_0
    move-object/from16 v24, v2

    move-object/from16 v0, v24

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v24, v0

    move-wide/from16 v25, v5

    invoke-virtual/range {v24 .. v26}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapVirtualAddress(J)J

    move-result-wide v24

    move-wide/from16 v7, v24

    .line 405
    move-wide/from16 v24, v7

    const/16 v26, 0x0

    move/from16 v0, v26

    int-to-long v0, v0

    move-wide/from16 v26, v0

    cmp-long v24, v24, v26

    if-gez v24, :cond_1

    .line 406
    const-string v24, "\u043c\u043e\u0434\u0443\u043b\u044c \u0432\u043d\u0435 \u0444\u0430\u0439\u043b\u0430"

    move-object/from16 v2, v24

    goto :goto_0

    .line 408
    :cond_1
    move-object/from16 v24, v2

    move-wide/from16 v25, v7

    move-object/from16 v27, v2

    move-object/from16 v0, v27

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move/from16 v27, v0

    move/from16 v0, v27

    int-to-long v0, v0

    move-wide/from16 v27, v0

    add-long v25, v25, v27

    invoke-direct/range {v24 .. v26}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->readPtr(J)J

    move-result-wide v24

    move-wide/from16 v9, v24

    .line 409
    move-object/from16 v24, v2

    move-wide/from16 v25, v7

    const-wide/16 v27, 0x2

    move-object/from16 v29, v2

    move-object/from16 v0, v29

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move/from16 v29, v0

    move/from16 v0, v29

    int-to-long v0, v0

    move-wide/from16 v29, v0

    mul-long v27, v27, v29

    add-long v25, v25, v27

    invoke-direct/range {v24 .. v26}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->readPtr(J)J

    move-result-wide v24

    move-wide/from16 v11, v24

    .line 410
    move-object/from16 v24, v2

    move-object/from16 v0, v24

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v24, v0

    move-wide/from16 v25, v11

    invoke-virtual/range {v24 .. v26}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapVirtualAddress(J)J

    move-result-wide v24

    move-wide/from16 v13, v24

    .line 411
    move-wide/from16 v24, v9

    const/16 v26, 0x0

    move/from16 v0, v26

    int-to-long v0, v0

    move-wide/from16 v26, v0

    cmp-long v24, v24, v26

    if-lez v24, :cond_2

    move-wide/from16 v24, v9

    const v26, 0x1e8480

    move/from16 v0, v26

    int-to-long v0, v0

    move-wide/from16 v26, v0

    cmp-long v24, v24, v26

    if-gtz v24, :cond_2

    move-wide/from16 v24, v13

    const/16 v26, 0x0

    move/from16 v0, v26

    int-to-long v0, v0

    move-wide/from16 v26, v0

    cmp-long v24, v24, v26

    if-gez v24, :cond_3

    .line 412
    :cond_2
    const-string v24, "\u043f\u043e\u0434\u043e\u0437\u0440\u0438\u0442\u0435\u043b\u044c\u043d\u043e: count=%d, pointers=0x%X"

    const/16 v25, 0x2

    move/from16 v0, v25

    new-array v0, v0, [Ljava/lang/Object;

    move-object/from16 v25, v0

    move-object/from16 v33, v25

    move-object/from16 v25, v33

    move-object/from16 v26, v33

    const/16 v27, 0x0

    move-wide/from16 v28, v9

    new-instance v30, Ljava/lang/Long;

    move-wide/from16 v33, v28

    move-object/from16 v35, v30

    move-object/from16 v28, v35

    move-wide/from16 v29, v33

    move-object/from16 v31, v35

    move-wide/from16 v33, v29

    move-object/from16 v35, v31

    move-object/from16 v29, v35

    move-wide/from16 v30, v33

    move-object/from16 v32, v35

    invoke-direct/range {v29 .. v31}, Ljava/lang/Long;-><init>(J)V

    aput-object v28, v26, v27

    move-object/from16 v33, v25

    move-object/from16 v25, v33

    move-object/from16 v26, v33

    const/16 v27, 0x1

    move-wide/from16 v28, v11

    new-instance v30, Ljava/lang/Long;

    move-wide/from16 v33, v28

    move-object/from16 v35, v30

    move-object/from16 v28, v35

    move-wide/from16 v29, v33

    move-object/from16 v31, v35

    move-wide/from16 v33, v29

    move-object/from16 v35, v31

    move-object/from16 v29, v35

    move-wide/from16 v30, v33

    move-object/from16 v32, v35

    invoke-direct/range {v29 .. v31}, Ljava/lang/Long;-><init>(J)V

    aput-object v28, v26, v27

    invoke-static/range {v24 .. v25}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v24

    move-object/from16 v2, v24

    goto/16 :goto_0

    .line 415
    :cond_3
    move-wide/from16 v24, v9

    const/16 v26, 0x100

    move/from16 v0, v26

    int-to-long v0, v0

    move-wide/from16 v26, v0

    invoke-static/range {v24 .. v27}, Ljava/lang/Math;->min(JJ)J

    move-result-wide v24

    move-wide/from16 v0, v24

    long-to-int v0, v0

    move/from16 v24, v0

    move/from16 v15, v24

    .line 416
    const/16 v24, 0x0

    move/from16 v16, v24

    .line 417
    const/16 v24, 0x0

    move/from16 v17, v24

    .line 418
    const/16 v24, 0x0

    move/from16 v18, v24

    :goto_1
    move/from16 v24, v18

    move/from16 v25, v15

    move/from16 v0, v24

    move/from16 v1, v25

    if-lt v0, v1, :cond_4

    .line 430
    :goto_2
    const-string v24, "\u043c\u0435\u0442\u043e\u0434\u043e\u0432 %d, \u0438\u0437 %d \u043f\u0440\u043e\u0431 \u0438\u0441\u043f\u043e\u043b\u043d\u044f\u0435\u043c\u044b\u0445 %d, \u043d\u0443\u043b\u0435\u0432\u044b\u0445 %d"

    const/16 v25, 0x4

    move/from16 v0, v25

    new-array v0, v0, [Ljava/lang/Object;

    move-object/from16 v25, v0

    move-object/from16 v33, v25

    move-object/from16 v25, v33

    move-object/from16 v26, v33

    const/16 v27, 0x0

    move-wide/from16 v28, v9

    new-instance v30, Ljava/lang/Long;

    move-wide/from16 v33, v28

    move-object/from16 v35, v30

    move-object/from16 v28, v35

    move-wide/from16 v29, v33

    move-object/from16 v31, v35

    move-wide/from16 v33, v29

    move-object/from16 v35, v31

    move-object/from16 v29, v35

    move-wide/from16 v30, v33

    move-object/from16 v32, v35

    invoke-direct/range {v29 .. v31}, Ljava/lang/Long;-><init>(J)V

    aput-object v28, v26, v27

    move-object/from16 v33, v25

    move-object/from16 v25, v33

    move-object/from16 v26, v33

    const/16 v27, 0x1

    move/from16 v28, v15

    new-instance v29, Ljava/lang/Integer;

    move/from16 v33, v28

    move-object/from16 v34, v29

    move-object/from16 v28, v34

    move/from16 v29, v33

    move-object/from16 v30, v34

    move/from16 v33, v29

    move-object/from16 v34, v30

    move-object/from16 v29, v34

    move/from16 v30, v33

    invoke-direct/range {v29 .. v30}, Ljava/lang/Integer;-><init>(I)V

    aput-object v28, v26, v27

    move-object/from16 v33, v25

    move-object/from16 v25, v33

    move-object/from16 v26, v33

    const/16 v27, 0x2

    move/from16 v28, v16

    new-instance v29, Ljava/lang/Integer;

    move/from16 v33, v28

    move-object/from16 v34, v29

    move-object/from16 v28, v34

    move/from16 v29, v33

    move-object/from16 v30, v34

    move/from16 v33, v29

    move-object/from16 v34, v30

    move-object/from16 v29, v34

    move/from16 v30, v33

    invoke-direct/range {v29 .. v30}, Ljava/lang/Integer;-><init>(I)V

    aput-object v28, v26, v27

    move-object/from16 v33, v25

    move-object/from16 v25, v33

    move-object/from16 v26, v33

    const/16 v27, 0x3

    move/from16 v28, v17

    new-instance v29, Ljava/lang/Integer;

    move/from16 v33, v28

    move-object/from16 v34, v29

    move-object/from16 v28, v34

    move/from16 v29, v33

    move-object/from16 v30, v34

    move/from16 v33, v29

    move-object/from16 v34, v30

    move-object/from16 v29, v34

    move/from16 v30, v33

    invoke-direct/range {v29 .. v30}, Ljava/lang/Integer;-><init>(I)V

    aput-object v28, v26, v27

    invoke-static/range {v24 .. v25}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v24

    move-object/from16 v2, v24

    goto/16 :goto_0

    .line 419
    :cond_4
    move-wide/from16 v24, v13

    move/from16 v26, v18

    move/from16 v0, v26

    int-to-long v0, v0

    move-wide/from16 v26, v0

    move-object/from16 v28, v2

    move-object/from16 v0, v28

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move/from16 v28, v0

    move/from16 v0, v28

    int-to-long v0, v0

    move-wide/from16 v28, v0

    mul-long v26, v26, v28

    add-long v24, v24, v26

    move-wide/from16 v19, v24

    .line 420
    move-wide/from16 v24, v19

    move-object/from16 v26, v2

    move-object/from16 v0, v26

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move/from16 v26, v0

    move/from16 v0, v26

    int-to-long v0, v0

    move-wide/from16 v26, v0

    add-long v24, v24, v26

    move-object/from16 v26, v2

    move-object/from16 v0, v26

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object/from16 v26, v0

    invoke-virtual/range {v26 .. v26}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->size()I

    move-result v26

    move/from16 v0, v26

    int-to-long v0, v0

    move-wide/from16 v26, v0

    cmp-long v24, v24, v26

    if-lez v24, :cond_5

    .line 421
    goto/16 :goto_2

    .line 423
    :cond_5
    move-object/from16 v24, v2

    move-wide/from16 v25, v19

    invoke-direct/range {v24 .. v26}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->readPtr(J)J

    move-result-wide v24

    move-wide/from16 v21, v24

    .line 424
    move-wide/from16 v24, v21

    const/16 v26, 0x0

    move/from16 v0, v26

    int-to-long v0, v0

    move-wide/from16 v26, v0

    cmp-long v24, v24, v26

    if-nez v24, :cond_7

    .line 425
    add-int/lit8 v17, v17, 0x1

    .line 418
    :cond_6
    :goto_3
    add-int/lit8 v18, v18, 0x1

    goto/16 :goto_1

    .line 426
    :cond_7
    move-object/from16 v24, v2

    move-wide/from16 v25, v21

    invoke-direct/range {v24 .. v26}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->isExecutable(J)Z

    move-result v24

    if-eqz v24, :cond_6

    .line 427
    add-int/lit8 v16, v16, 0x1

    goto :goto_3
.end method

.method public codeGenModulesVA()J
    .locals 4

    .prologue
    .line 63
    move-object v0, p0

    move-object v2, v0

    iget-wide v2, v2, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->codeGenModulesVA:J

    move-wide v0, v2

    return-wide v0
.end method

.method public describe()Ljava/lang/String;
    .locals 27

    .prologue
    .line 448
    move-object/from16 v2, p0

    new-instance v12, Ljava/lang/StringBuilder;

    move-object/from16 v24, v12

    move-object/from16 v12, v24

    move-object/from16 v13, v24

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    move-object v4, v12

    .line 449
    move-object v12, v4

    const-string v13, "MetadataRegistration: 0x%X\n"

    const/4 v14, 0x1

    new-array v14, v14, [Ljava/lang/Object;

    move-object/from16 v24, v14

    move-object/from16 v14, v24

    move-object/from16 v15, v24

    const/16 v16, 0x0

    move-object/from16 v17, v2

    move-object/from16 v0, v17

    iget-wide v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->metadataRegistrationVA:J

    move-wide/from16 v17, v0

    new-instance v19, Ljava/lang/Long;

    move-wide/from16 v24, v17

    move-object/from16 v26, v19

    move-object/from16 v17, v26

    move-wide/from16 v18, v24

    move-object/from16 v20, v26

    move-wide/from16 v24, v18

    move-object/from16 v26, v20

    move-object/from16 v18, v26

    move-wide/from16 v19, v24

    move-object/from16 v21, v26

    invoke-direct/range {v18 .. v20}, Ljava/lang/Long;-><init>(J)V

    aput-object v17, v15, v16

    invoke-static {v13, v14}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    .line 450
    move-object v12, v4

    const-string v13, "  types           0x%X  (%d)%s\n"

    const/4 v14, 0x3

    new-array v14, v14, [Ljava/lang/Object;

    move-object/from16 v24, v14

    move-object/from16 v14, v24

    move-object/from16 v15, v24

    const/16 v16, 0x0

    move-object/from16 v17, v2

    move-object/from16 v0, v17

    iget-wide v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->typesVA:J

    move-wide/from16 v17, v0

    new-instance v19, Ljava/lang/Long;

    move-wide/from16 v24, v17

    move-object/from16 v26, v19

    move-object/from16 v17, v26

    move-wide/from16 v18, v24

    move-object/from16 v20, v26

    move-wide/from16 v24, v18

    move-object/from16 v26, v20

    move-object/from16 v18, v26

    move-wide/from16 v19, v24

    move-object/from16 v21, v26

    invoke-direct/range {v18 .. v20}, Ljava/lang/Long;-><init>(J)V

    aput-object v17, v15, v16

    move-object/from16 v24, v14

    move-object/from16 v14, v24

    move-object/from16 v15, v24

    const/16 v16, 0x1

    move-object/from16 v17, v2

    move-object/from16 v0, v17

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->typesCount:I

    move/from16 v17, v0

    new-instance v18, Ljava/lang/Integer;

    move/from16 v24, v17

    move-object/from16 v25, v18

    move-object/from16 v17, v25

    move/from16 v18, v24

    move-object/from16 v19, v25

    move/from16 v24, v18

    move-object/from16 v25, v19

    move-object/from16 v18, v25

    move/from16 v19, v24

    invoke-direct/range {v18 .. v19}, Ljava/lang/Integer;-><init>(I)V

    aput-object v17, v15, v16

    move-object/from16 v24, v14

    move-object/from16 v14, v24

    move-object/from16 v15, v24

    const/16 v16, 0x2

    move-object/from16 v17, v2

    move-object/from16 v0, v17

    iget-wide v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->typesVA:J

    move-wide/from16 v17, v0

    const/16 v19, 0x0

    move/from16 v0, v19

    int-to-long v0, v0

    move-wide/from16 v19, v0

    cmp-long v17, v17, v19

    if-nez v17, :cond_3

    const-string v17, "  <-- \u043d\u0435 \u043e\u043f\u0440\u0435\u0434\u0435\u043b\u0451\u043d"

    :goto_0
    aput-object v17, v15, v16

    invoke-static {v13, v14}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    .line 452
    move-object v12, v4

    const-string v13, "  fieldOffsets    0x%X  (%s)\n"

    const/4 v14, 0x2

    new-array v14, v14, [Ljava/lang/Object;

    move-object/from16 v24, v14

    move-object/from16 v14, v24

    move-object/from16 v15, v24

    const/16 v16, 0x0

    move-object/from16 v17, v2

    move-object/from16 v0, v17

    iget-wide v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->fieldOffsetsVA:J

    move-wide/from16 v17, v0

    new-instance v19, Ljava/lang/Long;

    move-wide/from16 v24, v17

    move-object/from16 v26, v19

    move-object/from16 v17, v26

    move-wide/from16 v18, v24

    move-object/from16 v20, v26

    move-wide/from16 v24, v18

    move-object/from16 v26, v20

    move-object/from16 v18, v26

    move-wide/from16 v19, v24

    move-object/from16 v21, v26

    invoke-direct/range {v18 .. v20}, Ljava/lang/Long;-><init>(J)V

    aput-object v17, v15, v16

    move-object/from16 v24, v14

    move-object/from16 v14, v24

    move-object/from16 v15, v24

    const/16 v16, 0x1

    move-object/from16 v17, v2

    move-object/from16 v0, v17

    iget-boolean v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->fieldOffsetsArePointers:Z

    move/from16 v17, v0

    if-eqz v17, :cond_4

    const-string v17, "\u043c\u0430\u0441\u0441\u0438\u0432 \u0443\u043a\u0430\u0437\u0430\u0442\u0435\u043b\u0435\u0439"

    :goto_1
    aput-object v17, v15, v16

    invoke-static {v13, v14}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    .line 454
    move-object v12, v4

    const-string v13, "  typeSizes       0x%X\n"

    const/4 v14, 0x1

    new-array v14, v14, [Ljava/lang/Object;

    move-object/from16 v24, v14

    move-object/from16 v14, v24

    move-object/from16 v15, v24

    const/16 v16, 0x0

    move-object/from16 v17, v2

    move-object/from16 v0, v17

    iget-wide v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->typeSizesVA:J

    move-wide/from16 v17, v0

    new-instance v19, Ljava/lang/Long;

    move-wide/from16 v24, v17

    move-object/from16 v26, v19

    move-object/from16 v17, v26

    move-wide/from16 v18, v24

    move-object/from16 v20, v26

    move-wide/from16 v24, v18

    move-object/from16 v26, v20

    move-object/from16 v18, v26

    move-wide/from16 v19, v24

    move-object/from16 v21, v26

    invoke-direct/range {v18 .. v20}, Ljava/lang/Long;-><init>(J)V

    aput-object v17, v15, v16

    invoke-static {v13, v14}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    .line 455
    move-object v12, v2

    iget-wide v12, v12, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->codeGenModulesVA:J

    const/4 v14, 0x0

    int-to-long v14, v14

    cmp-long v12, v12, v14

    if-ltz v12, :cond_0

    .line 456
    move-object v12, v4

    const-string v13, "codeGenModules: 0x%X  (%d \u0441\u0431\u043e\u0440\u043e\u043a)\n"

    const/4 v14, 0x2

    new-array v14, v14, [Ljava/lang/Object;

    move-object/from16 v24, v14

    move-object/from16 v14, v24

    move-object/from16 v15, v24

    const/16 v16, 0x0

    move-object/from16 v17, v2

    move-object/from16 v0, v17

    iget-wide v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->codeGenModulesVA:J

    move-wide/from16 v17, v0

    new-instance v19, Ljava/lang/Long;

    move-wide/from16 v24, v17

    move-object/from16 v26, v19

    move-object/from16 v17, v26

    move-wide/from16 v18, v24

    move-object/from16 v20, v26

    move-wide/from16 v24, v18

    move-object/from16 v26, v20

    move-object/from16 v18, v26

    move-wide/from16 v19, v24

    move-object/from16 v21, v26

    invoke-direct/range {v18 .. v20}, Ljava/lang/Long;-><init>(J)V

    aput-object v17, v15, v16

    move-object/from16 v24, v14

    move-object/from16 v14, v24

    move-object/from16 v15, v24

    const/16 v16, 0x1

    move-object/from16 v17, v2

    move-object/from16 v0, v17

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object/from16 v17, v0

    invoke-virtual/range {v17 .. v17}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->images()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;

    move-result-object v17

    move-object/from16 v0, v17

    array-length v0, v0

    move/from16 v17, v0

    new-instance v18, Ljava/lang/Integer;

    move/from16 v24, v17

    move-object/from16 v25, v18

    move-object/from16 v17, v25

    move/from16 v18, v24

    move-object/from16 v19, v25

    move/from16 v24, v18

    move-object/from16 v25, v19

    move-object/from16 v18, v25

    move/from16 v19, v24

    invoke-direct/range {v18 .. v19}, Ljava/lang/Integer;-><init>(I)V

    aput-object v17, v15, v16

    invoke-static {v13, v14}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    .line 458
    move-object v12, v2

    const/4 v13, 0x0

    invoke-virtual {v12, v13}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->moduleName(I)Ljava/lang/String;

    move-result-object v12

    move-object v5, v12

    .line 459
    move-object v12, v2

    iget-object v12, v12, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object v13, v2

    iget-object v13, v13, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    invoke-virtual {v13}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->images()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;

    move-result-object v13

    const/4 v14, 0x0

    aget-object v13, v13, v14

    iget v13, v13, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;->nameIndex:I

    invoke-virtual {v12, v13}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->getString(I)Ljava/lang/String;

    move-result-object v12

    move-object v6, v12

    .line 460
    move-object v12, v4

    const-string v13, "  \u043f\u0435\u0440\u0432\u044b\u0439 \u043c\u043e\u0434\u0443\u043b\u044c: "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    move-object v13, v5

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    move-object v13, v5

    if-eqz v13, :cond_5

    move-object v13, v5

    move-object v14, v6

    invoke-virtual {v13, v14}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_5

    const-string v13, "  (\u0441\u043e\u0432\u043f\u0430\u043b)"

    :goto_2
    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const/16 v13, 0xa

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v12

    .line 463
    move-object v12, v4

    const-string v13, "  "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    move-object v13, v2

    const/4 v14, 0x0

    invoke-virtual {v13, v14}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->checkMethodPointers(I)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const/16 v13, 0xa

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v12

    .line 468
    :cond_0
    move-object v12, v4

    const-string v13, "\n\u041f\u0440\u043e\u0431\u0430 \u0441\u043c\u0435\u0449\u0435\u043d\u0438\u0439:\n"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    .line 469
    const/4 v12, 0x0

    move v5, v12

    .line 470
    move-object v12, v2

    iget-object v12, v12, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    invoke-virtual {v12}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->types()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    move-result-object v12

    move-object v6, v12

    .line 471
    const/4 v12, 0x0

    move v7, v12

    :goto_3
    move v12, v7

    move-object v13, v6

    array-length v13, v13

    if-ge v12, v13, :cond_1

    move v12, v5

    const/4 v13, 0x5

    if-lt v12, v13, :cond_6

    .line 486
    :cond_1
    move-object v12, v2

    iget-object v12, v12, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->notes:Ljava/util/List;

    invoke-interface {v12}, Ljava/util/List;->isEmpty()Z

    move-result v12

    if-nez v12, :cond_2

    .line 487
    move-object v12, v4

    const-string v13, "\n\u0417\u0430\u043c\u0435\u0447\u0430\u043d\u0438\u044f:\n"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    .line 488
    const/4 v12, 0x0

    move v7, v12

    :goto_4
    move v12, v7

    move-object v13, v2

    iget-object v13, v13, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->notes:Ljava/util/List;

    invoke-interface {v13}, Ljava/util/List;->size()I

    move-result v13

    if-lt v12, v13, :cond_9

    .line 492
    :cond_2
    move-object v12, v4

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    move-object v2, v12

    return-object v2

    .line 450
    :cond_3
    const-string v17, ""

    goto/16 :goto_0

    .line 452
    :cond_4
    const-string v17, "\u043f\u043b\u043e\u0441\u043a\u0438\u0439"

    goto/16 :goto_1

    .line 460
    :cond_5
    new-instance v13, Ljava/lang/StringBuffer;

    move-object/from16 v24, v13

    move-object/from16 v13, v24

    move-object/from16 v14, v24

    invoke-direct {v14}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v14, Ljava/lang/StringBuffer;

    move-object/from16 v24, v14

    move-object/from16 v14, v24

    move-object/from16 v15, v24

    invoke-direct {v15}, Ljava/lang/StringBuffer;-><init>()V

    const-string v15, "  (\u043e\u0436\u0438\u0434\u0430\u043b\u0441\u044f "

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    move-object v15, v6

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    const-string v14, ")"

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v13

    goto/16 :goto_2

    .line 472
    :cond_6
    move-object v12, v6

    move v13, v7

    aget-object v12, v12, v13

    iget v12, v12, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->fieldCount:I

    const/4 v13, 0x2

    if-ge v12, v13, :cond_7

    .line 471
    :goto_5
    add-int/lit8 v7, v7, 0x1

    goto :goto_3

    .line 475
    :cond_7
    move-object v12, v4

    const-string v13, "  "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    move-object v13, v2

    iget-object v13, v13, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object v14, v6

    move v15, v7

    aget-object v14, v14, v15

    invoke-virtual {v13, v14}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->fullName(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, " (\u0440\u0430\u0437\u043c\u0435\u0440 "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    move-object v13, v2

    move v14, v7

    invoke-virtual {v13, v14}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->typeSize(I)I

    move-result v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v12

    const-string v13, "):\n"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    .line 477
    move-object v12, v6

    move v13, v7

    aget-object v12, v12, v13

    iget v12, v12, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->fieldCount:I

    const/4 v13, 0x4

    invoke-static {v12, v13}, Ljava/lang/Math;->min(II)I

    move-result v12

    move v8, v12

    .line 478
    const/4 v12, 0x0

    move v9, v12

    :goto_6
    move v12, v9

    move v13, v8

    if-lt v12, v13, :cond_8

    .line 483
    add-int/lit8 v5, v5, 0x1

    goto :goto_5

    .line 479
    :cond_8
    move-object v12, v2

    iget-object v12, v12, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    invoke-virtual {v12}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->fields()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$FieldDefinition;

    move-result-object v12

    move-object v13, v6

    move v14, v7

    aget-object v13, v13, v14

    iget v13, v13, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->fieldStart:I

    move v14, v9

    add-int/2addr v13, v14

    aget-object v12, v12, v13

    move-object v10, v12

    .line 480
    move-object v12, v4

    const-string v13, "      0x%02X  %s\n"

    const/4 v14, 0x2

    new-array v14, v14, [Ljava/lang/Object;

    move-object/from16 v24, v14

    move-object/from16 v14, v24

    move-object/from16 v15, v24

    const/16 v16, 0x0

    move-object/from16 v17, v2

    move/from16 v18, v7

    move/from16 v19, v9

    invoke-virtual/range {v17 .. v19}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->fieldOffset(II)I

    move-result v17

    new-instance v18, Ljava/lang/Integer;

    move/from16 v24, v17

    move-object/from16 v25, v18

    move-object/from16 v17, v25

    move/from16 v18, v24

    move-object/from16 v19, v25

    move/from16 v24, v18

    move-object/from16 v25, v19

    move-object/from16 v18, v25

    move/from16 v19, v24

    invoke-direct/range {v18 .. v19}, Ljava/lang/Integer;-><init>(I)V

    aput-object v17, v15, v16

    move-object/from16 v24, v14

    move-object/from16 v14, v24

    move-object/from16 v15, v24

    const/16 v16, 0x1

    move-object/from16 v17, v2

    move-object/from16 v0, v17

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object/from16 v17, v0

    move-object/from16 v18, v10

    move-object/from16 v0, v18

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$FieldDefinition;->nameIndex:I

    move/from16 v18, v0

    invoke-virtual/range {v17 .. v18}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->getString(I)Ljava/lang/String;

    move-result-object v17

    aput-object v17, v15, v16

    invoke-static {v13, v14}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    .line 478
    add-int/lit8 v9, v9, 0x1

    goto :goto_6

    .line 489
    :cond_9
    move-object v12, v4

    const-string v13, "  - "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    move-object v13, v2

    iget-object v13, v13, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->notes:Ljava/util/List;

    move v14, v7

    invoke-interface {v13, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v13

    check-cast v13, Ljava/lang/String;

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v12

    const/16 v13, 0xa

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v12

    .line 488
    add-int/lit8 v7, v7, 0x1

    goto/16 :goto_4
.end method

.method public elf()Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;
    .locals 3

    .prologue
    .line 96
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object v0, v2

    return-object v0
.end method

.method public fieldOffset(II)I
    .locals 23

    .prologue
    .line 291
    move-object/from16 v3, p0

    move/from16 v4, p1

    move/from16 v5, p2

    move-object/from16 v16, v3

    move-object/from16 v0, v16

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v16, v0

    move-object/from16 v17, v3

    move-object/from16 v0, v17

    iget-wide v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->fieldOffsetsVA:J

    move-wide/from16 v17, v0

    invoke-virtual/range {v16 .. v18}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapVirtualAddress(J)J

    move-result-wide v16

    move-wide/from16 v7, v16

    .line 292
    move-wide/from16 v16, v7

    const/16 v18, 0x0

    move/from16 v0, v18

    int-to-long v0, v0

    move-wide/from16 v18, v0

    cmp-long v16, v16, v18

    if-gez v16, :cond_0

    .line 293
    const/16 v16, -0x1

    move/from16 v3, v16

    .line 315
    :goto_0
    return v3

    .line 295
    :cond_0
    move-object/from16 v16, v3

    move-object/from16 v0, v16

    iget-boolean v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->fieldOffsetsArePointers:Z

    move/from16 v16, v0

    if-eqz v16, :cond_4

    .line 296
    move-object/from16 v16, v3

    move-wide/from16 v17, v7

    move/from16 v19, v4

    move/from16 v0, v19

    int-to-long v0, v0

    move-wide/from16 v19, v0

    move-object/from16 v21, v3

    move-object/from16 v0, v21

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move/from16 v21, v0

    move/from16 v0, v21

    int-to-long v0, v0

    move-wide/from16 v21, v0

    mul-long v19, v19, v21

    add-long v17, v17, v19

    invoke-direct/range {v16 .. v18}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->readPtr(J)J

    move-result-wide v16

    move-wide/from16 v9, v16

    .line 297
    move-wide/from16 v16, v9

    const/16 v18, 0x0

    move/from16 v0, v18

    int-to-long v0, v0

    move-wide/from16 v18, v0

    cmp-long v16, v16, v18

    if-nez v16, :cond_1

    .line 298
    const/16 v16, -0x1

    move/from16 v3, v16

    goto :goto_0

    .line 300
    :cond_1
    move-object/from16 v16, v3

    move-object/from16 v0, v16

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v16, v0

    move-wide/from16 v17, v9

    invoke-virtual/range {v16 .. v18}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapVirtualAddress(J)J

    move-result-wide v16

    move-wide/from16 v11, v16

    .line 301
    move-wide/from16 v16, v11

    const/16 v18, 0x0

    move/from16 v0, v18

    int-to-long v0, v0

    move-wide/from16 v18, v0

    cmp-long v16, v16, v18

    if-gez v16, :cond_2

    .line 302
    const/16 v16, -0x1

    move/from16 v3, v16

    goto :goto_0

    .line 304
    :cond_2
    move-wide/from16 v16, v11

    move/from16 v18, v5

    move/from16 v0, v18

    int-to-long v0, v0

    move-wide/from16 v18, v0

    const/16 v20, 0x4

    move/from16 v0, v20

    int-to-long v0, v0

    move-wide/from16 v20, v0

    mul-long v18, v18, v20

    add-long v16, v16, v18

    move-wide/from16 v13, v16

    .line 305
    move-wide/from16 v16, v13

    const/16 v18, 0x4

    move/from16 v0, v18

    int-to-long v0, v0

    move-wide/from16 v18, v0

    add-long v16, v16, v18

    move-object/from16 v18, v3

    move-object/from16 v0, v18

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object/from16 v18, v0

    invoke-virtual/range {v18 .. v18}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->size()I

    move-result v18

    move/from16 v0, v18

    int-to-long v0, v0

    move-wide/from16 v18, v0

    cmp-long v16, v16, v18

    if-lez v16, :cond_3

    .line 306
    const/16 v16, -0x1

    move/from16 v3, v16

    goto/16 :goto_0

    .line 308
    :cond_3
    move-object/from16 v16, v3

    move-object/from16 v0, v16

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object/from16 v16, v0

    move-wide/from16 v17, v13

    move-wide/from16 v0, v17

    long-to-int v0, v0

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readIntAt(I)I

    move-result v16

    move/from16 v3, v16

    goto/16 :goto_0

    .line 310
    :cond_4
    move-object/from16 v16, v3

    move-object/from16 v0, v16

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->metadata:Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;

    move-object/from16 v16, v0

    invoke-virtual/range {v16 .. v16}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->types()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    move-result-object v16

    move/from16 v17, v4

    aget-object v16, v16, v17

    move-object/from16 v9, v16

    .line 311
    move-wide/from16 v16, v7

    move-object/from16 v18, v9

    move-object/from16 v0, v18

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->fieldStart:I

    move/from16 v18, v0

    move/from16 v19, v5

    add-int v18, v18, v19

    move/from16 v0, v18

    int-to-long v0, v0

    move-wide/from16 v18, v0

    const/16 v20, 0x4

    move/from16 v0, v20

    int-to-long v0, v0

    move-wide/from16 v20, v0

    mul-long v18, v18, v20

    add-long v16, v16, v18

    move-wide/from16 v10, v16

    .line 312
    move-wide/from16 v16, v10

    const/16 v18, 0x0

    move/from16 v0, v18

    int-to-long v0, v0

    move-wide/from16 v18, v0

    cmp-long v16, v16, v18

    if-ltz v16, :cond_5

    move-wide/from16 v16, v10

    const/16 v18, 0x4

    move/from16 v0, v18

    int-to-long v0, v0

    move-wide/from16 v18, v0

    add-long v16, v16, v18

    move-object/from16 v18, v3

    move-object/from16 v0, v18

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object/from16 v18, v0

    invoke-virtual/range {v18 .. v18}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->size()I

    move-result v18

    move/from16 v0, v18

    int-to-long v0, v0

    move-wide/from16 v18, v0

    cmp-long v16, v16, v18

    if-lez v16, :cond_6

    .line 313
    :cond_5
    const/16 v16, -0x1

    move/from16 v3, v16

    goto/16 :goto_0

    .line 315
    :cond_6
    move-object/from16 v16, v3

    move-object/from16 v0, v16

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object/from16 v16, v0

    move-wide/from16 v17, v10

    move-wide/from16 v0, v17

    long-to-int v0, v0

    move/from16 v17, v0

    invoke-virtual/range {v16 .. v17}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readIntAt(I)I

    move-result v16

    move/from16 v3, v16

    goto/16 :goto_0
.end method

.method public metadataRegistrationVA()J
    .locals 4

    .prologue
    .line 59
    move-object v0, p0

    move-object v2, v0

    iget-wide v2, v2, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->metadataRegistrationVA:J

    move-wide v0, v2

    return-wide v0
.end method

.method public methodAddress(II)J
    .locals 27

    .prologue
    .line 369
    move-object/from16 v2, p0

    move/from16 v3, p1

    move/from16 v4, p2

    move-object/from16 v20, v2

    move/from16 v21, v3

    invoke-direct/range {v20 .. v21}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->moduleVA(I)J

    move-result-wide v20

    move-wide/from16 v6, v20

    .line 370
    move-wide/from16 v20, v6

    const/16 v22, 0x0

    move/from16 v0, v22

    int-to-long v0, v0

    move-wide/from16 v22, v0

    cmp-long v20, v20, v22

    if-gtz v20, :cond_0

    .line 371
    const/16 v20, -0x1

    move/from16 v0, v20

    int-to-long v0, v0

    move-wide/from16 v20, v0

    move-wide/from16 v2, v20

    .line 391
    :goto_0
    return-wide v2

    .line 373
    :cond_0
    move-object/from16 v20, v2

    move-object/from16 v0, v20

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v20, v0

    move-wide/from16 v21, v6

    invoke-virtual/range {v20 .. v22}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapVirtualAddress(J)J

    move-result-wide v20

    move-wide/from16 v8, v20

    .line 374
    move-wide/from16 v20, v8

    const/16 v22, 0x0

    move/from16 v0, v22

    int-to-long v0, v0

    move-wide/from16 v22, v0

    cmp-long v20, v20, v22

    if-gez v20, :cond_1

    .line 375
    const/16 v20, -0x1

    move/from16 v0, v20

    int-to-long v0, v0

    move-wide/from16 v20, v0

    move-wide/from16 v2, v20

    goto :goto_0

    .line 377
    :cond_1
    move-object/from16 v20, v2

    move-wide/from16 v21, v8

    move-object/from16 v23, v2

    move-object/from16 v0, v23

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move/from16 v23, v0

    move/from16 v0, v23

    int-to-long v0, v0

    move-wide/from16 v23, v0

    add-long v21, v21, v23

    invoke-direct/range {v20 .. v22}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->readPtr(J)J

    move-result-wide v20

    move-wide/from16 v10, v20

    .line 378
    move-object/from16 v20, v2

    move-wide/from16 v21, v8

    const-wide/16 v23, 0x2

    move-object/from16 v25, v2

    move-object/from16 v0, v25

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move/from16 v25, v0

    move/from16 v0, v25

    int-to-long v0, v0

    move-wide/from16 v25, v0

    mul-long v23, v23, v25

    add-long v21, v21, v23

    invoke-direct/range {v20 .. v22}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->readPtr(J)J

    move-result-wide v20

    move-wide/from16 v12, v20

    .line 379
    move/from16 v20, v4

    const v21, 0xffffff

    and-int v20, v20, v21

    const/16 v21, 0x1

    add-int/lit8 v20, v20, -0x1

    move/from16 v14, v20

    .line 380
    move/from16 v20, v14

    const/16 v21, 0x0

    move/from16 v0, v20

    move/from16 v1, v21

    if-lt v0, v1, :cond_2

    move/from16 v20, v14

    move/from16 v0, v20

    int-to-long v0, v0

    move-wide/from16 v20, v0

    move-wide/from16 v22, v10

    cmp-long v20, v20, v22

    if-ltz v20, :cond_3

    .line 381
    :cond_2
    const/16 v20, -0x1

    move/from16 v0, v20

    int-to-long v0, v0

    move-wide/from16 v20, v0

    move-wide/from16 v2, v20

    goto/16 :goto_0

    .line 383
    :cond_3
    move-object/from16 v20, v2

    move-object/from16 v0, v20

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object/from16 v20, v0

    move-wide/from16 v21, v12

    invoke-virtual/range {v20 .. v22}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapVirtualAddress(J)J

    move-result-wide v20

    move-wide/from16 v15, v20

    .line 384
    move-wide/from16 v20, v15

    const/16 v22, 0x0

    move/from16 v0, v22

    int-to-long v0, v0

    move-wide/from16 v22, v0

    cmp-long v20, v20, v22

    if-gez v20, :cond_4

    .line 385
    const/16 v20, -0x1

    move/from16 v0, v20

    int-to-long v0, v0

    move-wide/from16 v20, v0

    move-wide/from16 v2, v20

    goto/16 :goto_0

    .line 387
    :cond_4
    move-wide/from16 v20, v15

    move/from16 v22, v14

    move/from16 v0, v22

    int-to-long v0, v0

    move-wide/from16 v22, v0

    move-object/from16 v24, v2

    move-object/from16 v0, v24

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move/from16 v24, v0

    move/from16 v0, v24

    int-to-long v0, v0

    move-wide/from16 v24, v0

    mul-long v22, v22, v24

    add-long v20, v20, v22

    move-wide/from16 v17, v20

    .line 388
    move-wide/from16 v20, v17

    move-object/from16 v22, v2

    move-object/from16 v0, v22

    iget v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move/from16 v22, v0

    move/from16 v0, v22

    int-to-long v0, v0

    move-wide/from16 v22, v0

    add-long v20, v20, v22

    move-object/from16 v22, v2

    move-object/from16 v0, v22

    iget-object v0, v0, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object/from16 v22, v0

    invoke-virtual/range {v22 .. v22}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->size()I

    move-result v22

    move/from16 v0, v22

    int-to-long v0, v0

    move-wide/from16 v22, v0

    cmp-long v20, v20, v22

    if-lez v20, :cond_5

    .line 389
    const/16 v20, -0x1

    move/from16 v0, v20

    int-to-long v0, v0

    move-wide/from16 v20, v0

    move-wide/from16 v2, v20

    goto/16 :goto_0

    .line 391
    :cond_5
    move-object/from16 v20, v2

    move-wide/from16 v21, v17

    invoke-direct/range {v20 .. v22}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->readPtr(J)J

    move-result-wide v20

    move-wide/from16 v2, v20

    goto/16 :goto_0
.end method

.method public moduleName(I)Ljava/lang/String;
    .locals 16

    .prologue
    .line 348
    move-object/from16 v0, p0

    move/from16 v1, p1

    move-object v12, v0

    move v13, v1

    invoke-direct {v12, v13}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->moduleVA(I)J

    move-result-wide v12

    move-wide v3, v12

    .line 349
    move-wide v12, v3

    const/4 v14, 0x0

    int-to-long v14, v14

    cmp-long v12, v12, v14

    if-gtz v12, :cond_0

    .line 350
    const/4 v12, 0x0

    check-cast v12, Ljava/lang/String;

    move-object v0, v12

    .line 361
    :goto_0
    return-object v0

    .line 352
    :cond_0
    move-object v12, v0

    iget-object v12, v12, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-wide v13, v3

    invoke-virtual {v12, v13, v14}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapVirtualAddress(J)J

    move-result-wide v12

    move-wide v5, v12

    .line 353
    move-wide v12, v5

    const/4 v14, 0x0

    int-to-long v14, v14

    cmp-long v12, v12, v14

    if-gez v12, :cond_1

    .line 354
    const/4 v12, 0x0

    check-cast v12, Ljava/lang/String;

    move-object v0, v12

    goto :goto_0

    .line 356
    :cond_1
    move-object v12, v0

    move-wide v13, v5

    invoke-direct {v12, v13, v14}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->readPtr(J)J

    move-result-wide v12

    move-wide v7, v12

    .line 357
    move-object v12, v0

    iget-object v12, v12, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-wide v13, v7

    invoke-virtual {v12, v13, v14}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapVirtualAddress(J)J

    move-result-wide v12

    move-wide v9, v12

    .line 358
    move-wide v12, v9

    const/4 v14, 0x0

    int-to-long v14, v14

    cmp-long v12, v12, v14

    if-gez v12, :cond_2

    .line 359
    const/4 v12, 0x0

    check-cast v12, Ljava/lang/String;

    move-object v0, v12

    goto :goto_0

    .line 361
    :cond_2
    move-object v12, v0

    iget-object v12, v12, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-wide v13, v9

    long-to-int v13, v13

    invoke-virtual {v12, v13}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readStringToNull(I)Ljava/lang/String;

    move-result-object v12

    move-object v0, v12

    goto :goto_0
.end method

.method public notes()Ljava/util/List;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List",
            "<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    .prologue
    .line 104
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->notes:Ljava/util/List;

    move-object v0, v2

    return-object v0
.end method

.method public pointerSize()I
    .locals 3

    .prologue
    .line 100
    move-object v0, p0

    move-object v2, v0

    iget v2, v2, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    move v0, v2

    return v0
.end method

.method public registrationField(I)J
    .locals 12

    .prologue
    .line 80
    move-object v0, p0

    move v1, p1

    move-object v6, v0

    iget-wide v6, v6, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->registrationOffset:J

    const/4 v8, 0x0

    int-to-long v8, v8

    cmp-long v6, v6, v8

    if-gez v6, :cond_0

    .line 81
    const/4 v6, -0x1

    int-to-long v6, v6

    move-wide v0, v6

    .line 87
    :goto_0
    return-wide v0

    .line 83
    :cond_0
    move-object v6, v0

    iget-wide v6, v6, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->registrationOffset:J

    move v8, v1

    int-to-long v8, v8

    move-object v10, v0

    iget v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    int-to-long v10, v10

    mul-long/2addr v8, v10

    add-long/2addr v6, v8

    move-wide v3, v6

    .line 84
    move-wide v6, v3

    const/4 v8, 0x0

    int-to-long v8, v8

    cmp-long v6, v6, v8

    if-ltz v6, :cond_1

    move-wide v6, v3

    move-object v8, v0

    iget v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->pointerSize:I

    int-to-long v8, v8

    add-long/2addr v6, v8

    move-object v8, v0

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    invoke-virtual {v8}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->size()I

    move-result v8

    int-to-long v8, v8

    cmp-long v6, v6, v8

    if-lez v6, :cond_2

    .line 85
    :cond_1
    const/4 v6, -0x1

    int-to-long v6, v6

    move-wide v0, v6

    goto :goto_0

    .line 87
    :cond_2
    move-object v6, v0

    move-wide v7, v3

    invoke-direct {v6, v7, v8}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->readPtr(J)J

    move-result-wide v6

    move-wide v0, v6

    goto :goto_0
.end method

.method public setTypesArray(JI)V
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(JI)V"
        }
    .end annotation

    .prologue
    .line 91
    move-object v0, p0

    move-wide v1, p1

    move v3, p3

    move-object v5, v0

    move-wide v6, v1

    iput-wide v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->typesVA:J

    .line 92
    move-object v5, v0

    move v6, v3

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->typesCount:I

    return-void
.end method

.method public typeSize(I)I
    .locals 14

    .prologue
    .line 320
    move-object v0, p0

    move v1, p1

    move-object v8, v0

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->elf:Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;

    move-object v9, v0

    iget-wide v9, v9, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->typeSizesVA:J

    invoke-virtual {v8, v9, v10}, Lcom/Leon4ikMods/UniversalDumper/elf/ElfFile;->mapVirtualAddress(J)J

    move-result-wide v8

    move-wide v3, v8

    .line 321
    move-wide v8, v3

    const/4 v10, 0x0

    int-to-long v10, v10

    cmp-long v8, v8, v10

    if-gez v8, :cond_0

    .line 322
    const/4 v8, -0x1

    move v0, v8

    .line 328
    :goto_0
    return v0

    .line 324
    :cond_0
    move-wide v8, v3

    move v10, v1

    int-to-long v10, v10

    const/4 v12, 0x4

    int-to-long v12, v12

    mul-long/2addr v10, v12

    add-long/2addr v8, v10

    move-wide v5, v8

    .line 325
    move-wide v8, v5

    const/4 v10, 0x4

    int-to-long v10, v10

    add-long/2addr v8, v10

    move-object v10, v0

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    invoke-virtual {v10}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->size()I

    move-result v10

    int-to-long v10, v10

    cmp-long v8, v8, v10

    if-lez v8, :cond_1

    .line 326
    const/4 v8, -0x1

    move v0, v8

    goto :goto_0

    .line 328
    :cond_1
    move-object v8, v0

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-wide v9, v5

    long-to-int v9, v9

    invoke-virtual {v8, v9}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readIntAt(I)I

    move-result v8

    move v0, v8

    goto :goto_0
.end method

.method public typesCount()I
    .locals 3

    .prologue
    .line 67
    move-object v0, p0

    move-object v2, v0

    iget v2, v2, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->typesCount:I

    move v0, v2

    return v0
.end method

.method public typesVA()J
    .locals 4

    .prologue
    .line 71
    move-object v0, p0

    move-object v2, v0

    iget-wide v2, v2, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Il2CppBinary;->typesVA:J

    move-wide v0, v2

    return-wide v0
.end method
