.class public final Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;
.super Ljava/lang/Object;
.source "Structs.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x39
    name = "TypeDefinition"
.end annotation


# static fields
.field public static final SIZE_24_2:I = 0x58


# instance fields
.field public bitfield:I

.field public byvalTypeIndex:I

.field public declaringTypeIndex:I

.field public elementTypeIndex:I

.field public eventCount:I

.field public eventStart:I

.field public fieldCount:I

.field public fieldStart:I

.field public flags:I

.field public genericContainerIndex:I

.field public interfaceOffsetsCount:I

.field public interfaceOffsetsStart:I

.field public interfacesCount:I

.field public interfacesStart:I

.field public methodCount:I

.field public methodStart:I

.field public nameIndex:I

.field public namespaceIndex:I

.field public nestedTypeCount:I

.field public nestedTypesStart:I

.field public parentIndex:I

.field public propertyCount:I

.field public propertyStart:I

.field public token:I

.field public vtableCount:I

.field public vtableStart:I


# direct methods
.method public constructor <init>()V
    .locals 3

    .prologue
    .line 118
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static read(Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;I)Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;
    .locals 8

    .prologue
    .line 52
    move-object v0, p0

    move v1, p1

    move-object v5, v0

    move v6, v1

    invoke-virtual {v5, v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->seek(I)V

    .line 53
    new-instance v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    move-object v7, v5

    move-object v5, v7

    move-object v6, v7

    invoke-direct {v6}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;-><init>()V

    move-object v3, v5

    .line 54
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->nameIndex:I

    .line 55
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->namespaceIndex:I

    .line 56
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->byvalTypeIndex:I

    .line 57
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->declaringTypeIndex:I

    .line 58
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->parentIndex:I

    .line 59
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->elementTypeIndex:I

    .line 60
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->genericContainerIndex:I

    .line 61
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->flags:I

    .line 62
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->fieldStart:I

    .line 63
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->methodStart:I

    .line 64
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->eventStart:I

    .line 65
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->propertyStart:I

    .line 66
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->nestedTypesStart:I

    .line 67
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->interfacesStart:I

    .line 68
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->vtableStart:I

    .line 69
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->interfaceOffsetsStart:I

    .line 70
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readUShort()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->methodCount:I

    .line 71
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readUShort()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->propertyCount:I

    .line 72
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readUShort()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->fieldCount:I

    .line 73
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readUShort()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->eventCount:I

    .line 74
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readUShort()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->nestedTypeCount:I

    .line 75
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readUShort()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->vtableCount:I

    .line 76
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readUShort()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->interfacesCount:I

    .line 77
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readUShort()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->interfaceOffsetsCount:I

    .line 78
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->bitfield:I

    .line 79
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->token:I

    .line 80
    move-object v5, v3

    move-object v0, v5

    return-object v0
.end method


# virtual methods
.method public isInterface()Z
    .locals 4

    .prologue
    .line 117
    move-object v0, p0

    move-object v2, v0

    iget v2, v2, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->flags:I

    const/16 v3, 0x20

    and-int/lit8 v2, v2, 0x20

    const/4 v3, 0x0

    if-ne v2, v3, :cond_0

    const/4 v2, 0x0

    :goto_0
    move v0, v2

    return v0

    :cond_0
    const/4 v2, 0x1

    goto :goto_0
.end method

.method public modifiers()Ljava/lang/String;
    .locals 7

    .prologue
    .line 85
    move-object v0, p0

    new-instance v4, Ljava/lang/StringBuilder;

    move-object v6, v4

    move-object v4, v6

    move-object v5, v6

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    move-object v2, v4

    .line 86
    move-object v4, v0

    iget v4, v4, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->flags:I

    const/4 v5, 0x7

    and-int/lit8 v4, v4, 0x7

    packed-switch v4, :pswitch_data_0

    .line 104
    :pswitch_0
    move-object v4, v2

    const-string v5, "internal "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 107
    :goto_0
    move-object v4, v0

    iget v4, v4, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->flags:I

    const/16 v5, 0x80

    and-int/lit16 v4, v4, 0x80

    const/4 v5, 0x0

    if-eq v4, v5, :cond_0

    .line 108
    move-object v4, v2

    const-string v5, "abstract "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 110
    :cond_0
    move-object v4, v0

    iget v4, v4, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->flags:I

    const/16 v5, 0x100

    and-int/lit16 v4, v4, 0x100

    const/4 v5, 0x0

    if-eq v4, v5, :cond_1

    .line 111
    move-object v4, v2

    const-string v5, "sealed "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 113
    :cond_1
    move-object v4, v2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    move-object v0, v4

    return-object v0

    .line 89
    :pswitch_1
    move-object v4, v2

    const-string v5, "public "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 90
    goto :goto_0

    .line 92
    :pswitch_2
    move-object v4, v2

    const-string v5, "private "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 93
    goto :goto_0

    .line 95
    :pswitch_3
    move-object v4, v2

    const-string v5, "protected "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 96
    goto :goto_0

    .line 98
    :pswitch_4
    move-object v4, v2

    const-string v5, "private protected "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 99
    goto :goto_0

    .line 101
    :pswitch_5
    move-object v4, v2

    const-string v5, "protected internal "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    .line 102
    goto :goto_0

    .line 86
    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_1
        :pswitch_1
        :pswitch_2
        :pswitch_3
        :pswitch_0
        :pswitch_4
        :pswitch_5
    .end packed-switch
.end method
