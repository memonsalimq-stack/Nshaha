.class public final Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ParameterDefinition;
.super Ljava/lang/Object;
.source "Structs.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x39
    name = "ParameterDefinition"
.end annotation


# static fields
.field public static final SIZE_24_2:I = 0xc


# instance fields
.field public nameIndex:I

.field public token:I

.field public typeIndex:I


# direct methods
.method public constructor <init>()V
    .locals 3

    .prologue
    .line 223
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static read(Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;I)Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ParameterDefinition;
    .locals 8

    .prologue
    .line 217
    move-object v0, p0

    move v1, p1

    move-object v5, v0

    move v6, v1

    invoke-virtual {v5, v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->seek(I)V

    .line 218
    new-instance v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ParameterDefinition;

    move-object v7, v5

    move-object v5, v7

    move-object v6, v7

    invoke-direct {v6}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ParameterDefinition;-><init>()V

    move-object v3, v5

    .line 219
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ParameterDefinition;->nameIndex:I

    .line 220
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ParameterDefinition;->token:I

    .line 221
    move-object v5, v3

    move-object v6, v0

    invoke-virtual {v6}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v6

    iput v6, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ParameterDefinition;->typeIndex:I

    .line 222
    move-object v5, v3

    move-object v0, v5

    return-object v0
.end method
