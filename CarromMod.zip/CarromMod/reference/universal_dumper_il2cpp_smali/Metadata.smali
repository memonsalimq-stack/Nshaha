.class public Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;
.super Ljava/lang/Object;
.source "Metadata.java"


# instance fields
.field private final bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

.field private fieldStructSize:I

.field private fields:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$FieldDefinition;

.field private final header:Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

.field private images:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;

.field private interfaceIndices:[I

.field private methodStructSize:I

.field private methods:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;

.field private final notes:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List",
            "<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private parameters:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ParameterDefinition;

.field private typeStructSize:I

.field private types:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;


# direct methods
.method public constructor <init>(Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;)V
    .locals 7

    .prologue
    .line 35
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    new-instance v4, Ljava/util/ArrayList;

    move-object v6, v4

    move-object v4, v6

    move-object v5, v6

    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    iput-object v4, v3, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->notes:Ljava/util/List;

    .line 36
    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    .line 37
    move-object v3, v0

    move-object v4, v1

    invoke-static {v4}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->read(Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;)Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    move-result-object v4

    iput-object v4, v3, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header:Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    .line 38
    move-object v3, v0

    invoke-direct {v3}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->validate()V

    .line 39
    move-object v3, v0

    invoke-direct {v3}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->loadTypes()V

    .line 40
    move-object v3, v0

    invoke-direct {v3}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->loadMethodsAndFields()V

    .line 41
    move-object v3, v0

    invoke-direct {v3}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->loadParameters()V

    .line 42
    move-object v3, v0

    invoke-direct {v3}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->loadInterfaces()V

    .line 43
    move-object v3, v0

    invoke-direct {v3}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->loadImages()V

    return-void
.end method

.method private deriveSize(Ljava/lang/String;II[I)I
    .locals 23

    .prologue
    .line 235
    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    move-object/from16 v4, p4

    move v10, v3

    const/4 v11, 0x0

    if-gt v10, v11, :cond_0

    .line 236
    new-instance v10, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;

    move-object/from16 v22, v10

    move-object/from16 v10, v22

    move-object/from16 v11, v22

    new-instance v12, Ljava/lang/StringBuffer;

    move-object/from16 v22, v12

    move-object/from16 v12, v22

    move-object/from16 v13, v22

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    move-object v13, v1

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    const-string v13, ": \u043d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043e\u043f\u0440\u0435\u0434\u0435\u043b\u0438\u0442\u044c \u0447\u0438\u0441\u043b\u043e \u044d\u043b\u0435\u043c\u0435\u043d\u0442\u043e\u0432"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-direct {v11, v12}, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;-><init>(Ljava/lang/String;)V

    throw v10

    .line 238
    :cond_0
    move v10, v2

    move v11, v3

    rem-int/2addr v10, v11

    const/4 v11, 0x0

    if-eq v10, v11, :cond_1

    .line 239
    new-instance v10, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;

    move-object/from16 v22, v10

    move-object/from16 v10, v22

    move-object/from16 v11, v22

    new-instance v12, Ljava/lang/StringBuffer;

    move-object/from16 v22, v12

    move-object/from16 v12, v22

    move-object/from16 v13, v22

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v13, Ljava/lang/StringBuffer;

    move-object/from16 v22, v13

    move-object/from16 v13, v22

    move-object/from16 v14, v22

    invoke-direct {v14}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v14, Ljava/lang/StringBuffer;

    move-object/from16 v22, v14

    move-object/from16 v14, v22

    move-object/from16 v15, v22

    invoke-direct {v15}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v15, Ljava/lang/StringBuffer;

    move-object/from16 v22, v15

    move-object/from16 v15, v22

    move-object/from16 v16, v22

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v16, Ljava/lang/StringBuffer;

    move-object/from16 v22, v16

    move-object/from16 v16, v22

    move-object/from16 v17, v22

    invoke-direct/range {v17 .. v17}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v17, Ljava/lang/StringBuffer;

    move-object/from16 v22, v17

    move-object/from16 v17, v22

    move-object/from16 v18, v22

    invoke-direct/range {v18 .. v18}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v18, Ljava/lang/StringBuffer;

    move-object/from16 v22, v18

    move-object/from16 v18, v22

    move-object/from16 v19, v22

    invoke-direct/range {v19 .. v19}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v19, Ljava/lang/StringBuffer;

    move-object/from16 v22, v19

    move-object/from16 v19, v22

    move-object/from16 v20, v22

    invoke-direct/range {v20 .. v20}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v20, Ljava/lang/StringBuffer;

    move-object/from16 v22, v20

    move-object/from16 v20, v22

    move-object/from16 v21, v22

    invoke-direct/range {v21 .. v21}, Ljava/lang/StringBuffer;-><init>()V

    move-object/from16 v21, v1

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v20

    const-string v21, ": \u0442\u0430\u0431\u043b\u0438\u0446\u0430 "

    invoke-virtual/range {v20 .. v21}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v20

    invoke-virtual/range {v20 .. v20}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v20

    invoke-virtual/range {v19 .. v20}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v19

    move/from16 v20, v2

    invoke-virtual/range {v19 .. v20}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v19

    invoke-virtual/range {v19 .. v19}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v19

    invoke-virtual/range {v18 .. v19}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v18

    const-string v19, " \u0431\u0430\u0439\u0442 \u043d\u0435 \u0434\u0435\u043b\u0438\u0442\u0441\u044f \u043d\u0430 "

    invoke-virtual/range {v18 .. v19}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v18

    invoke-virtual/range {v18 .. v18}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v18

    invoke-virtual/range {v17 .. v18}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v17

    move/from16 v18, v3

    invoke-virtual/range {v17 .. v18}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v17

    invoke-virtual/range {v17 .. v17}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v17

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    const-string v17, " \u044d\u043b\u0435\u043c\u0435\u043d\u0442\u043e\u0432"

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v16

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v15

    const-string v16, " (\u043e\u0441\u0442\u0430\u0442\u043e\u043a "

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    move v15, v2

    move/from16 v16, v3

    rem-int v15, v15, v16

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    const-string v14, ")."

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    const-string v13, " \u0417\u043d\u0430\u0447\u0438\u0442, \u0433\u0440\u0430\u043d\u0438\u0446\u044b \u0432 \u0442\u0438\u043f\u0430\u0445 \u043f\u0440\u043e\u0447\u0438\u0442\u0430\u043d\u044b \u043d\u0435\u0432\u0435\u0440\u043d\u043e."

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-direct {v11, v12}, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;-><init>(Ljava/lang/String;)V

    throw v10

    .line 244
    :cond_1
    move v10, v2

    move v11, v3

    div-int/2addr v10, v11

    move v6, v10

    .line 245
    const/4 v10, 0x0

    move v7, v10

    .line 246
    const/4 v10, 0x0

    move v8, v10

    :goto_0
    move v10, v8

    move-object v11, v4

    array-length v11, v11

    if-lt v10, v11, :cond_3

    .line 252
    :goto_1
    move v10, v7

    if-nez v10, :cond_2

    .line 253
    move-object v10, v0

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->notes:Ljava/util/List;

    new-instance v11, Ljava/lang/StringBuffer;

    move-object/from16 v22, v11

    move-object/from16 v11, v22

    move-object/from16 v12, v22

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v12, Ljava/lang/StringBuffer;

    move-object/from16 v22, v12

    move-object/from16 v12, v22

    move-object/from16 v13, v22

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v13, Ljava/lang/StringBuffer;

    move-object/from16 v22, v13

    move-object/from16 v13, v22

    move-object/from16 v14, v22

    invoke-direct {v14}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v14, Ljava/lang/StringBuffer;

    move-object/from16 v22, v14

    move-object/from16 v14, v22

    move-object/from16 v15, v22

    invoke-direct {v15}, Ljava/lang/StringBuffer;-><init>()V

    move-object v15, v1

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    const-string v15, " = "

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    move v14, v6

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    const-string v13, " \u0431\u0430\u0439\u0442 \u2014 \u0440\u0430\u0437\u043c\u0435\u0440 \u043d\u0435\u0437\u043d\u0430\u043a\u043e\u043c\u044b\u0439,"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    const-string v12, " \u043f\u043e\u043b\u044f \u043c\u043e\u0433\u0443\u0442 \u0447\u0438\u0442\u0430\u0442\u044c\u0441\u044f \u0441\u043e \u0441\u0434\u0432\u0438\u0433\u043e\u043c"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-interface {v10, v11}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v10

    .line 256
    :cond_2
    move v10, v6

    move v0, v10

    return v0

    .line 247
    :cond_3
    move-object v10, v4

    move v11, v8

    aget v10, v10, v11

    move v11, v6

    if-ne v10, v11, :cond_4

    .line 248
    const/4 v10, 0x1

    move v7, v10

    .line 249
    goto :goto_1

    .line 246
    :cond_4
    add-int/lit8 v8, v8, 0x1

    goto/16 :goto_0
.end method

.method private loadImages()V
    .locals 15
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 293
    move-object v0, p0

    move-object v8, v0

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header:Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    const-string v9, "images"

    invoke-virtual {v8, v9}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->count(Ljava/lang/String;)I

    move-result v8

    move v2, v8

    .line 294
    const/16 v8, 0x28

    move v3, v8

    .line 295
    move v8, v2

    move v9, v3

    rem-int/2addr v8, v9

    const/4 v9, 0x0

    if-eq v8, v9, :cond_0

    .line 296
    move-object v8, v0

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->notes:Ljava/util/List;

    new-instance v9, Ljava/lang/StringBuffer;

    move-object v14, v9

    move-object v9, v14

    move-object v10, v14

    invoke-direct {v10}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v10, Ljava/lang/StringBuffer;

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    invoke-direct {v11}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v11, Ljava/lang/StringBuffer;

    move-object v14, v11

    move-object v11, v14

    move-object v12, v14

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v12, Ljava/lang/StringBuffer;

    move-object v14, v12

    move-object v12, v14

    move-object v13, v14

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    const-string v13, "\u0442\u0430\u0431\u043b\u0438\u0446\u0430 images ("

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    move v13, v2

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    const-string v12, " \u0431\u0430\u0439\u0442) \u043d\u0435 \u0434\u0435\u043b\u0438\u0442\u0441\u044f \u043d\u0430 "

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v10

    move v11, v3

    invoke-virtual {v10, v11}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    const-string v10, " \u2014 \u0441\u043f\u0438\u0441\u043e\u043a \u0441\u0431\u043e\u0440\u043e\u043a \u043f\u0440\u043e\u043f\u0443\u0449\u0435\u043d"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-interface {v8, v9}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v8

    .line 298
    move-object v8, v0

    const/4 v9, 0x0

    new-array v9, v9, [Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;

    iput-object v9, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->images:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;

    .line 304
    :goto_0
    return-void

    .line 301
    :cond_0
    move-object v8, v0

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header:Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    const-string v9, "images"

    invoke-virtual {v8, v9}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->offset(Ljava/lang/String;)I

    move-result v8

    move v4, v8

    .line 302
    move v8, v2

    move v9, v3

    div-int/2addr v8, v9

    move v5, v8

    .line 303
    move-object v8, v0

    move v9, v5

    new-array v9, v9, [Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;

    iput-object v9, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->images:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;

    .line 304
    const/4 v8, 0x0

    move v6, v8

    :goto_1
    move v8, v6

    move v9, v5

    if-lt v8, v9, :cond_1

    goto :goto_0

    .line 305
    :cond_1
    move-object v8, v0

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->images:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;

    move v9, v6

    move-object v10, v0

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move v11, v4

    move v12, v6

    move v13, v3

    mul-int/2addr v12, v13

    add-int/2addr v11, v12

    invoke-static {v10, v11}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;->read(Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;I)Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;

    move-result-object v10

    aput-object v10, v8, v9

    .line 304
    add-int/lit8 v6, v6, 0x1

    goto :goto_1
.end method

.method private loadInterfaces()V
    .locals 13
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 283
    move-object v0, p0

    move-object v7, v0

    iget-object v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header:Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    const-string v8, "interfaces"

    invoke-virtual {v7, v8}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->count(Ljava/lang/String;)I

    move-result v7

    move v2, v7

    .line 284
    move-object v7, v0

    iget-object v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header:Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    const-string v8, "interfaces"

    invoke-virtual {v7, v8}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->offset(Ljava/lang/String;)I

    move-result v7

    move v3, v7

    .line 285
    move v7, v2

    const/4 v8, 0x4

    div-int/lit8 v7, v7, 0x4

    move v4, v7

    .line 286
    move-object v7, v0

    move v8, v4

    new-array v8, v8, [I

    iput-object v8, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->interfaceIndices:[I

    .line 287
    const/4 v7, 0x0

    move v5, v7

    :goto_0
    move v7, v5

    move v8, v4

    if-lt v7, v8, :cond_0

    return-void

    .line 288
    :cond_0
    move-object v7, v0

    iget-object v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->interfaceIndices:[I

    move v8, v5

    move-object v9, v0

    iget-object v9, v9, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move v10, v3

    move v11, v5

    const/4 v12, 0x4

    mul-int/lit8 v11, v11, 0x4

    add-int/2addr v10, v11

    invoke-virtual {v9, v10}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readIntAt(I)I

    move-result v9

    aput v9, v7, v8

    .line 287
    add-int/lit8 v5, v5, 0x1

    goto :goto_0
.end method

.method private loadMethodsAndFields()V
    .locals 18
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 200
    move-object/from16 v0, p0

    const/4 v8, 0x0

    move v2, v8

    .line 201
    const/4 v8, 0x0

    move v3, v8

    .line 202
    const/4 v8, 0x0

    move v4, v8

    :goto_0
    move v8, v4

    move-object v9, v0

    iget-object v9, v9, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->types:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    array-length v9, v9

    if-lt v8, v9, :cond_0

    .line 212
    move-object v8, v0

    move-object v9, v0

    const-string v10, "Il2CppMethodDefinition"

    move-object v11, v0

    iget-object v11, v11, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header:Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    const-string v12, "methods"

    invoke-virtual {v11, v12}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->count(Ljava/lang/String;)I

    move-result v11

    move v12, v2

    const/4 v13, 0x2

    new-array v13, v13, [I

    fill-array-data v13, :array_0

    invoke-direct {v9, v10, v11, v12, v13}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->deriveSize(Ljava/lang/String;II[I)I

    move-result v9

    iput v9, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->methodStructSize:I

    .line 216
    move-object v8, v0

    move-object v9, v0

    const-string v10, "Il2CppFieldDefinition"

    move-object v11, v0

    iget-object v11, v11, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header:Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    const-string v12, "fields"

    invoke-virtual {v11, v12}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->count(Ljava/lang/String;)I

    move-result v11

    move v12, v3

    const/4 v13, 0x1

    new-array v13, v13, [I

    move-object/from16 v17, v13

    move-object/from16 v13, v17

    move-object/from16 v14, v17

    const/4 v15, 0x0

    const/16 v16, 0xc

    aput v16, v14, v15

    invoke-direct {v9, v10, v11, v12, v13}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->deriveSize(Ljava/lang/String;II[I)I

    move-result v9

    iput v9, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->fieldStructSize:I

    .line 220
    move-object v8, v0

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header:Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    const-string v9, "methods"

    invoke-virtual {v8, v9}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->offset(Ljava/lang/String;)I

    move-result v8

    move v4, v8

    .line 221
    move-object v8, v0

    move v9, v2

    new-array v9, v9, [Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;

    iput-object v9, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->methods:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;

    .line 222
    const/4 v8, 0x0

    move v5, v8

    :goto_1
    move v8, v5

    move v9, v2

    if-lt v8, v9, :cond_3

    .line 227
    move-object v8, v0

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header:Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    const-string v9, "fields"

    invoke-virtual {v8, v9}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->offset(Ljava/lang/String;)I

    move-result v8

    move v5, v8

    .line 228
    move-object v8, v0

    move v9, v3

    new-array v9, v9, [Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$FieldDefinition;

    iput-object v9, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->fields:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$FieldDefinition;

    .line 229
    const/4 v8, 0x0

    move v6, v8

    :goto_2
    move v8, v6

    move v9, v3

    if-lt v8, v9, :cond_4

    return-void

    .line 203
    :cond_0
    move-object v8, v0

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->types:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    move v9, v4

    aget-object v8, v8, v9

    move-object v5, v8

    .line 204
    move-object v8, v5

    iget v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->methodCount:I

    const/4 v9, 0x0

    if-le v8, v9, :cond_1

    move-object v8, v5

    iget v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->methodStart:I

    const/4 v9, 0x0

    if-lt v8, v9, :cond_1

    .line 205
    move v8, v2

    move-object v9, v5

    iget v9, v9, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->methodStart:I

    move-object v10, v5

    iget v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->methodCount:I

    add-int/2addr v9, v10

    invoke-static {v8, v9}, Ljava/lang/Math;->max(II)I

    move-result v8

    move v2, v8

    .line 207
    :cond_1
    move-object v8, v5

    iget v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->fieldCount:I

    const/4 v9, 0x0

    if-le v8, v9, :cond_2

    move-object v8, v5

    iget v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->fieldStart:I

    const/4 v9, 0x0

    if-lt v8, v9, :cond_2

    .line 208
    move v8, v3

    move-object v9, v5

    iget v9, v9, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->fieldStart:I

    move-object v10, v5

    iget v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->fieldCount:I

    add-int/2addr v9, v10

    invoke-static {v8, v9}, Ljava/lang/Math;->max(II)I

    move-result v8

    move v3, v8

    .line 202
    :cond_2
    add-int/lit8 v4, v4, 0x1

    goto/16 :goto_0

    .line 223
    :cond_3
    move-object v8, v0

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->methods:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;

    move v9, v5

    move-object v10, v0

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move v11, v4

    move v12, v5

    move-object v13, v0

    iget v13, v13, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->methodStructSize:I

    mul-int/2addr v12, v13

    add-int/2addr v11, v12

    move-object v12, v0

    iget v12, v12, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->methodStructSize:I

    invoke-static {v10, v11, v12}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->read(Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;II)Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;

    move-result-object v10

    aput-object v10, v8, v9

    .line 222
    add-int/lit8 v5, v5, 0x1

    goto :goto_1

    .line 230
    :cond_4
    move-object v8, v0

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->fields:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$FieldDefinition;

    move v9, v6

    move-object v10, v0

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move v11, v5

    move v12, v6

    move-object v13, v0

    iget v13, v13, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->fieldStructSize:I

    mul-int/2addr v12, v13

    add-int/2addr v11, v12

    invoke-static {v10, v11}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$FieldDefinition;->read(Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;I)Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$FieldDefinition;

    move-result-object v10

    aput-object v10, v8, v9

    .line 229
    add-int/lit8 v6, v6, 0x1

    goto :goto_2

    .line 212
    :array_0
    .array-data 4
        0x20
        0x24
    .end array-data
.end method

.method private loadParameters()V
    .locals 16
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 260
    move-object/from16 v0, p0

    const/4 v7, 0x0

    move v2, v7

    .line 261
    const/4 v7, 0x0

    move v3, v7

    :goto_0
    move v7, v3

    move-object v8, v0

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->methods:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;

    array-length v8, v8

    if-lt v7, v8, :cond_0

    .line 267
    move v7, v2

    const/4 v8, 0x0

    if-ne v7, v8, :cond_2

    .line 268
    move-object v7, v0

    const/4 v8, 0x0

    new-array v8, v8, [Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ParameterDefinition;

    iput-object v8, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->parameters:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ParameterDefinition;

    .line 276
    :goto_1
    return-void

    .line 262
    :cond_0
    move-object v7, v0

    iget-object v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->methods:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;

    move v8, v3

    aget-object v7, v7, v8

    move-object v4, v7

    .line 263
    move-object v7, v4

    iget v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->parameterCount:I

    const/4 v8, 0x0

    if-le v7, v8, :cond_1

    move-object v7, v4

    iget v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->parameterStart:I

    const/4 v8, 0x0

    if-lt v7, v8, :cond_1

    .line 264
    move v7, v2

    move-object v8, v4

    iget v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->parameterStart:I

    move-object v9, v4

    iget v9, v9, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->parameterCount:I

    add-int/2addr v8, v9

    invoke-static {v7, v8}, Ljava/lang/Math;->max(II)I

    move-result v7

    move v2, v7

    .line 261
    :cond_1
    add-int/lit8 v3, v3, 0x1

    goto :goto_0

    .line 271
    :cond_2
    move-object v7, v0

    const-string v8, "Il2CppParameterDefinition"

    move-object v9, v0

    iget-object v9, v9, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header:Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    const-string v10, "parameters"

    invoke-virtual {v9, v10}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->count(Ljava/lang/String;)I

    move-result v9

    move v10, v2

    const/4 v11, 0x1

    new-array v11, v11, [I

    move-object v15, v11

    move-object v11, v15

    move-object v12, v15

    const/4 v13, 0x0

    const/16 v14, 0xc

    aput v14, v12, v13

    invoke-direct {v7, v8, v9, v10, v11}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->deriveSize(Ljava/lang/String;II[I)I

    move-result v7

    move v3, v7

    .line 274
    move-object v7, v0

    iget-object v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header:Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    const-string v8, "parameters"

    invoke-virtual {v7, v8}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->offset(Ljava/lang/String;)I

    move-result v7

    move v4, v7

    .line 275
    move-object v7, v0

    move v8, v2

    new-array v8, v8, [Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ParameterDefinition;

    iput-object v8, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->parameters:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ParameterDefinition;

    .line 276
    const/4 v7, 0x0

    move v5, v7

    :goto_2
    move v7, v5

    move v8, v2

    if-lt v7, v8, :cond_3

    goto :goto_1

    .line 277
    :cond_3
    move-object v7, v0

    iget-object v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->parameters:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ParameterDefinition;

    move v8, v5

    move-object v9, v0

    iget-object v9, v9, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move v10, v4

    move v11, v5

    move v12, v3

    mul-int/2addr v11, v12

    add-int/2addr v10, v11

    invoke-static {v9, v10}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ParameterDefinition;->read(Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;I)Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ParameterDefinition;

    move-result-object v9

    aput-object v9, v7, v8

    .line 276
    add-int/lit8 v5, v5, 0x1

    goto :goto_2
.end method

.method private loadTypes()V
    .locals 19
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 125
    move-object/from16 v0, p0

    move-object v10, v0

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header:Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    const-string v11, "typeDefinitions"

    invoke-virtual {v10, v11}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->offset(Ljava/lang/String;)I

    move-result v10

    move v2, v10

    .line 126
    move-object v10, v0

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header:Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    const-string v11, "typeDefinitions"

    invoke-virtual {v10, v11}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->count(Ljava/lang/String;)I

    move-result v10

    move v3, v10

    .line 127
    move-object v10, v0

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header:Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    const-string v11, "string"

    invoke-virtual {v10, v11}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->count(Ljava/lang/String;)I

    move-result v10

    move v4, v10

    .line 129
    new-instance v10, Ljava/util/ArrayList;

    move-object/from16 v17, v10

    move-object/from16 v10, v17

    move-object/from16 v11, v17

    invoke-direct {v11}, Ljava/util/ArrayList;-><init>()V

    move-object v5, v10

    .line 130
    move-object v10, v5

    const/16 v11, 0x58

    new-instance v12, Ljava/lang/Integer;

    move/from16 v17, v11

    move-object/from16 v18, v12

    move-object/from16 v11, v18

    move/from16 v12, v17

    move-object/from16 v13, v18

    move/from16 v17, v12

    move-object/from16 v18, v13

    move-object/from16 v12, v18

    move/from16 v13, v17

    invoke-direct {v12, v13}, Ljava/lang/Integer;-><init>(I)V

    invoke-interface {v10, v11}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v10

    .line 131
    const/16 v10, 0x40

    move v6, v10

    :goto_0
    move v10, v6

    const/16 v11, 0xa0

    if-le v10, v11, :cond_0

    .line 137
    const/4 v10, -0x1

    move v6, v10

    .line 138
    const/4 v10, 0x0

    move v7, v10

    :goto_1
    move v10, v7

    move-object v11, v5

    invoke-interface {v11}, Ljava/util/List;->size()I

    move-result v11

    if-lt v10, v11, :cond_2

    .line 149
    :goto_2
    move v10, v6

    const/4 v11, 0x0

    if-ge v10, v11, :cond_5

    .line 150
    new-instance v10, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;

    move-object/from16 v17, v10

    move-object/from16 v10, v17

    move-object/from16 v11, v17

    new-instance v12, Ljava/lang/StringBuffer;

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v13, Ljava/lang/StringBuffer;

    move-object/from16 v17, v13

    move-object/from16 v13, v17

    move-object/from16 v14, v17

    invoke-direct {v14}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v14, Ljava/lang/StringBuffer;

    move-object/from16 v17, v14

    move-object/from16 v14, v17

    move-object/from16 v15, v17

    invoke-direct {v15}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v15, Ljava/lang/StringBuffer;

    move-object/from16 v17, v15

    move-object/from16 v15, v17

    move-object/from16 v16, v17

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuffer;-><init>()V

    const-string v16, "\u043d\u0435 \u043f\u043e\u0434\u043e\u0431\u0440\u0430\u043d \u0440\u0430\u0437\u043c\u0435\u0440 Il2CppTypeDefinition:"

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v15

    const-string v16, " \u0442\u0430\u0431\u043b\u0438\u0446\u0430 "

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    move v15, v3

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    const-string v14, " \u0431\u0430\u0439\u0442, \u043d\u0438 \u043e\u0434\u0438\u043d \u0434\u0435\u043b\u0438\u0442\u0435\u043b\u044c 64..160"

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    const-string v13, " \u043d\u0435 \u0434\u0430\u0451\u0442 \u043a\u043e\u0440\u0440\u0435\u043a\u0442\u043d\u044b\u0435 \u0438\u043d\u0434\u0435\u043a\u0441\u044b \u0438\u043c\u0451\u043d"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-direct {v11, v12}, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;-><init>(Ljava/lang/String;)V

    throw v10

    .line 132
    :cond_0
    move v10, v6

    const/16 v11, 0x58

    if-eq v10, v11, :cond_1

    .line 133
    move-object v10, v5

    move v11, v6

    new-instance v12, Ljava/lang/Integer;

    move/from16 v17, v11

    move-object/from16 v18, v12

    move-object/from16 v11, v18

    move/from16 v12, v17

    move-object/from16 v13, v18

    move/from16 v17, v12

    move-object/from16 v18, v13

    move-object/from16 v12, v18

    move/from16 v13, v17

    invoke-direct {v12, v13}, Ljava/lang/Integer;-><init>(I)V

    invoke-interface {v10, v11}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v10

    .line 131
    :cond_1
    move v10, v6

    const/4 v11, 0x4

    add-int/lit8 v10, v10, 0x4

    move v6, v10

    goto/16 :goto_0

    .line 139
    :cond_2
    move-object v10, v5

    move v11, v7

    invoke-interface {v10, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/Integer;

    check-cast v10, Ljava/lang/Integer;

    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    move-result v10

    move v8, v10

    .line 140
    move v10, v3

    move v11, v8

    rem-int/2addr v10, v11

    const/4 v11, 0x0

    if-eq v10, v11, :cond_4

    .line 138
    :cond_3
    add-int/lit8 v7, v7, 0x1

    goto/16 :goto_1

    .line 143
    :cond_4
    move-object v10, v0

    move v11, v2

    move v12, v3

    move v13, v8

    div-int/2addr v12, v13

    move v13, v8

    move v14, v4

    invoke-direct {v10, v11, v12, v13, v14}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->looksLikeTypeTable(IIII)Z

    move-result v10

    if-eqz v10, :cond_3

    .line 144
    move v10, v8

    move v6, v10

    .line 145
    goto/16 :goto_2

    .line 155
    :cond_5
    move-object v10, v0

    move v11, v6

    iput v11, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->typeStructSize:I

    .line 156
    move v10, v3

    move v11, v6

    div-int/2addr v10, v11

    move v7, v10

    .line 157
    move-object v10, v0

    move v11, v7

    new-array v11, v11, [Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    iput-object v11, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->types:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    .line 158
    const/4 v10, 0x0

    move v8, v10

    :goto_3
    move v10, v8

    move v11, v7

    if-lt v10, v11, :cond_7

    .line 161
    move v10, v6

    const/16 v11, 0x58

    if-eq v10, v11, :cond_6

    .line 162
    move-object v10, v0

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->notes:Ljava/util/List;

    new-instance v11, Ljava/lang/StringBuffer;

    move-object/from16 v17, v11

    move-object/from16 v11, v17

    move-object/from16 v12, v17

    invoke-direct {v12}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v12, Ljava/lang/StringBuffer;

    move-object/from16 v17, v12

    move-object/from16 v12, v17

    move-object/from16 v13, v17

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v13, Ljava/lang/StringBuffer;

    move-object/from16 v17, v13

    move-object/from16 v13, v17

    move-object/from16 v14, v17

    invoke-direct {v14}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v14, Ljava/lang/StringBuffer;

    move-object/from16 v17, v14

    move-object/from16 v14, v17

    move-object/from16 v15, v17

    invoke-direct {v15}, Ljava/lang/StringBuffer;-><init>()V

    const-string v15, "Il2CppTypeDefinition = "

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    move v15, v6

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    const-string v14, " \u0431\u0430\u0439\u0442 (\u043e\u0436\u0438\u0434\u0430\u043b\u043e\u0441\u044c "

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    const/16 v13, 0x58

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    const-string v12, ") \u2014 \u0440\u0430\u0441\u043a\u043b\u0430\u0434\u043a\u0430 \u043e\u0442\u043b\u0438\u0447\u0430\u0435\u0442\u0441\u044f \u043e\u0442 v24.2"

    invoke-virtual {v11, v12}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v11

    invoke-virtual {v11}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v11

    invoke-interface {v10, v11}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    move-result v10

    :cond_6
    return-void

    .line 159
    :cond_7
    move-object v10, v0

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->types:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    move v11, v8

    move-object v12, v0

    iget-object v12, v12, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move v13, v2

    move v14, v8

    move v15, v6

    mul-int/2addr v14, v15

    add-int/2addr v13, v14

    invoke-static {v12, v13}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->read(Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;I)Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    move-result-object v12

    aput-object v12, v10, v11

    .line 158
    add-int/lit8 v8, v8, 0x1

    goto/16 :goto_3
.end method

.method private looksLikeTypeTable(IIII)Z
    .locals 17

    .prologue
    .line 169
    move-object/from16 v0, p0

    move/from16 v1, p1

    move/from16 v2, p2

    move/from16 v3, p3

    move/from16 v4, p4

    move v14, v2

    const/4 v15, 0x1

    if-ge v14, v15, :cond_0

    .line 170
    const/4 v14, 0x0

    move v0, v14

    .line 192
    :goto_0
    return v0

    .line 172
    :cond_0
    move v14, v2

    const/16 v15, 0x80

    invoke-static {v14, v15}, Ljava/lang/Math;->min(II)I

    move-result v14

    move v6, v14

    .line 173
    const/4 v14, 0x0

    move v7, v14

    .line 174
    const/4 v14, 0x0

    move v8, v14

    :goto_1
    move v14, v8

    move v15, v6

    if-lt v14, v15, :cond_1

    .line 192
    move v14, v7

    move v15, v6

    const/16 v16, 0x3

    mul-int/lit8 v15, v15, 0x3

    const/16 v16, 0x4

    div-int/lit8 v15, v15, 0x4

    if-ge v14, v15, :cond_8

    const/4 v14, 0x0

    :goto_2
    move v0, v14

    goto :goto_0

    .line 175
    :cond_1
    move v14, v1

    move v15, v8

    move/from16 v16, v3

    mul-int v15, v15, v16

    add-int/2addr v14, v15

    move v9, v14

    .line 176
    move v14, v9

    const/16 v15, 0x8

    add-int/lit8 v14, v14, 0x8

    move-object v15, v0

    iget-object v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    invoke-virtual {v15}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->size()I

    move-result v15

    if-le v14, v15, :cond_2

    .line 177
    const/4 v14, 0x0

    move v0, v14

    goto :goto_0

    .line 179
    :cond_2
    move-object v14, v0

    iget-object v14, v14, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move v15, v9

    invoke-virtual {v14, v15}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readIntAt(I)I

    move-result v14

    move v10, v14

    .line 180
    move-object v14, v0

    iget-object v14, v14, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move v15, v9

    const/16 v16, 0x4

    add-int/lit8 v15, v15, 0x4

    invoke-virtual {v14, v15}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readIntAt(I)I

    move-result v14

    move v11, v14

    .line 181
    move v14, v10

    const/4 v15, 0x0

    if-lt v14, v15, :cond_3

    move v14, v10

    move v15, v4

    if-lt v14, v15, :cond_4

    .line 182
    :cond_3
    const/4 v14, 0x0

    move v0, v14

    goto :goto_0

    .line 184
    :cond_4
    move v14, v11

    const/4 v15, 0x0

    if-lt v14, v15, :cond_5

    move v14, v11

    move v15, v4

    if-lt v14, v15, :cond_6

    .line 185
    :cond_5
    const/4 v14, 0x0

    move v0, v14

    goto :goto_0

    .line 187
    :cond_6
    move-object v14, v0

    iget-object v14, v14, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object v15, v0

    iget-object v15, v15, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header:Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    const-string v16, "string"

    invoke-virtual/range {v15 .. v16}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->offset(Ljava/lang/String;)I

    move-result v15

    move/from16 v16, v10

    add-int v15, v15, v16

    invoke-virtual {v14, v15}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readStringToNull(I)Ljava/lang/String;

    move-result-object v14

    move-object v12, v14

    .line 188
    move-object v14, v12

    invoke-virtual {v14}, Ljava/lang/String;->length()I

    move-result v14

    const/4 v15, 0x0

    if-le v14, v15, :cond_7

    move-object v14, v12

    invoke-virtual {v14}, Ljava/lang/String;->length()I

    move-result v14

    const/16 v15, 0x200

    if-ge v14, v15, :cond_7

    .line 189
    add-int/lit8 v7, v7, 0x1

    .line 174
    :cond_7
    add-int/lit8 v8, v8, 0x1

    goto/16 :goto_1

    .line 192
    :cond_8
    const/4 v14, 0x1

    goto :goto_2
.end method

.method private validate()V
    .locals 22
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .prologue
    .line 310
    move-object/from16 v1, p0

    move-object v10, v1

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    invoke-virtual {v10}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->size()I

    move-result v10

    move v3, v10

    .line 311
    move-object v10, v1

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header:Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    invoke-virtual {v10}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->tables()Ljava/util/Map;

    move-result-object v10

    invoke-interface {v10}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v10

    check-cast v10, Ljava/util/Collection;

    invoke-interface {v10}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v10

    move-object v4, v10

    .line 315
    :cond_0
    move-object v10, v4

    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    move-result v10

    if-nez v10, :cond_1

    return-void

    .line 311
    :cond_1
    move-object v10, v4

    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/util/Map$Entry;

    move-object v6, v10

    .line 312
    move-object v10, v6

    invoke-interface {v10}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, [I

    const/4 v11, 0x0

    aget v10, v10, v11

    move v7, v10

    .line 313
    move-object v10, v6

    invoke-interface {v10}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v10

    check-cast v10, [I

    const/4 v11, 0x1

    aget v10, v10, v11

    move v8, v10

    .line 314
    move v10, v7

    const/4 v11, 0x0

    if-lt v10, v11, :cond_2

    move v10, v8

    const/4 v11, 0x0

    if-lt v10, v11, :cond_2

    move v10, v7

    move v11, v3

    if-gt v10, v11, :cond_2

    move v10, v7

    int-to-long v10, v10

    move v12, v8

    int-to-long v12, v12

    add-long/2addr v10, v12

    move v12, v3

    int-to-long v12, v12

    cmp-long v10, v10, v12

    if-lez v10, :cond_0

    .line 315
    :cond_2
    new-instance v10, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;

    move-object/from16 v21, v10

    move-object/from16 v10, v21

    move-object/from16 v11, v21

    new-instance v12, Ljava/lang/StringBuffer;

    move-object/from16 v21, v12

    move-object/from16 v12, v21

    move-object/from16 v13, v21

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v13, Ljava/lang/StringBuffer;

    move-object/from16 v21, v13

    move-object/from16 v13, v21

    move-object/from16 v14, v21

    invoke-direct {v14}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v14, Ljava/lang/StringBuffer;

    move-object/from16 v21, v14

    move-object/from16 v14, v21

    move-object/from16 v15, v21

    invoke-direct {v15}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v15, Ljava/lang/StringBuffer;

    move-object/from16 v21, v15

    move-object/from16 v15, v21

    move-object/from16 v16, v21

    invoke-direct/range {v16 .. v16}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v16, Ljava/lang/StringBuffer;

    move-object/from16 v21, v16

    move-object/from16 v16, v21

    move-object/from16 v17, v21

    invoke-direct/range {v17 .. v17}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v17, Ljava/lang/StringBuffer;

    move-object/from16 v21, v17

    move-object/from16 v17, v21

    move-object/from16 v18, v21

    invoke-direct/range {v18 .. v18}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v18, Ljava/lang/StringBuffer;

    move-object/from16 v21, v18

    move-object/from16 v18, v21

    move-object/from16 v19, v21

    invoke-direct/range {v19 .. v19}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v19, Ljava/lang/StringBuffer;

    move-object/from16 v21, v19

    move-object/from16 v19, v21

    move-object/from16 v20, v21

    invoke-direct/range {v20 .. v20}, Ljava/lang/StringBuffer;-><init>()V

    const-string v20, "\u0442\u0430\u0431\u043b\u0438\u0446\u0430 \'"

    invoke-virtual/range {v19 .. v20}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v19

    move-object/from16 v20, v6

    invoke-interface/range {v20 .. v20}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v20

    check-cast v20, Ljava/lang/String;

    invoke-virtual/range {v19 .. v20}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v19

    invoke-virtual/range {v19 .. v19}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v19

    invoke-virtual/range {v18 .. v19}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v18

    const-string v19, "\' \u0432\u044b\u0445\u043e\u0434\u0438\u0442 \u0437\u0430 \u0433\u0440\u0430\u043d\u0438\u0446\u044b \u0444\u0430\u0439\u043b\u0430: offset="

    invoke-virtual/range {v18 .. v19}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v18

    invoke-virtual/range {v18 .. v18}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v18

    invoke-virtual/range {v17 .. v18}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v17

    move/from16 v18, v7

    invoke-virtual/range {v17 .. v18}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v17

    invoke-virtual/range {v17 .. v17}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v17

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    const-string v17, ", size="

    invoke-virtual/range {v16 .. v17}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v16

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v15

    move/from16 v16, v8

    invoke-virtual/range {v15 .. v16}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v15

    invoke-virtual {v15}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    const-string v15, ", \u0444\u0430\u0439\u043b="

    invoke-virtual {v14, v15}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v14

    invoke-virtual {v14}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v13

    move v14, v3

    invoke-virtual {v13, v14}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v13

    invoke-virtual {v13}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    const-string v13, ". \u0421\u043a\u043e\u0440\u0435\u0435 \u0432\u0441\u0435\u0433\u043e \u043c\u0435\u0442\u0430\u0434\u0430\u043d\u043d\u044b\u0435 \u0437\u0430\u0448\u0438\u0444\u0440\u043e\u0432\u0430\u043d\u044b \u0438\u043b\u0438 \u0432\u0435\u0440\u0441\u0438\u044f \u043e\u043f\u0440\u0435\u0434\u0435\u043b\u0435\u043d\u0430 \u043d\u0435\u0432\u0435\u0440\u043d\u043e."

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-direct {v11, v12}, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;-><init>(Ljava/lang/String;)V

    throw v10
.end method


# virtual methods
.method public describe()Ljava/lang/String;
    .locals 17

    .prologue
    .line 326
    move-object/from16 v1, p0

    new-instance v7, Ljava/lang/StringBuilder;

    move-object v15, v7

    move-object v7, v15

    move-object v8, v15

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    move-object v3, v7

    .line 327
    move-object v7, v3

    const-string v8, "\u0412\u0435\u0440\u0441\u0438\u044f \u043c\u0435\u0442\u0430\u0434\u0430\u043d\u043d\u044b\u0445: "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    move-object v8, v1

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header:Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    invoke-virtual {v8}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->version()D

    move-result-wide v8

    invoke-virtual {v7, v8, v9}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    move-result-object v7

    const/16 v8, 0xa

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 328
    move-object v7, v3

    const-string v8, "\u0420\u0430\u0437\u043c\u0435\u0440 \u0444\u0430\u0439\u043b\u0430: "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    move-object v8, v1

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    invoke-virtual {v8}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->size()I

    move-result v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, " \u0431\u0430\u0439\u0442\n\n"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 330
    move-object v7, v3

    const-string v8, "\u0420\u0430\u0437\u043c\u0435\u0440\u044b \u0441\u0442\u0440\u0443\u043a\u0442\u0443\u0440 (\u0432\u044b\u0432\u0435\u0434\u0435\u043d\u044b \u0438\u0437 \u0434\u0430\u043d\u043d\u044b\u0445):\n"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 331
    move-object v7, v3

    const-string v8, "  Il2CppTypeDefinition   = "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    move-object v8, v1

    iget v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->typeStructSize:I

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, " \u0431\u0430\u0439\u0442\n"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 332
    move-object v7, v3

    const-string v8, "  Il2CppMethodDefinition = "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    move-object v8, v1

    iget v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->methodStructSize:I

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, " \u0431\u0430\u0439\u0442\n"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 333
    move-object v7, v3

    const-string v8, "  Il2CppFieldDefinition  = "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    move-object v8, v1

    iget v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->fieldStructSize:I

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, " \u0431\u0430\u0439\u0442\n\n"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 335
    move-object v7, v3

    const-string v8, "\u041a\u043b\u0430\u0441\u0441\u043e\u0432: "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    move-object v8, v1

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->types:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    array-length v8, v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const/16 v8, 0xa

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 336
    move-object v7, v3

    const-string v8, "\u041c\u0435\u0442\u043e\u0434\u043e\u0432: "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    move-object v8, v1

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->methods:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;

    array-length v8, v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const/16 v8, 0xa

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 337
    move-object v7, v3

    const-string v8, "\u041f\u043e\u043b\u0435\u0439:   "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    move-object v8, v1

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->fields:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$FieldDefinition;

    array-length v8, v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const/16 v8, 0xa

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 338
    move-object v7, v3

    const-string v8, "\u0421\u0431\u043e\u0440\u043e\u043a:  "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    move-object v8, v1

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->images:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;

    array-length v8, v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v8, "\n\n"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 340
    move-object v7, v3

    const-string v8, "\u0421\u0431\u043e\u0440\u043a\u0438:\n"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 341
    const/4 v7, 0x0

    move v4, v7

    :goto_0
    move v7, v4

    move-object v8, v1

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->images:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;

    array-length v8, v8

    if-lt v7, v8, :cond_1

    .line 347
    move-object v7, v1

    iget-object v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->notes:Ljava/util/List;

    invoke-interface {v7}, Ljava/util/List;->isEmpty()Z

    move-result v7

    if-nez v7, :cond_0

    .line 348
    move-object v7, v3

    const-string v8, "\n\u0417\u0430\u043c\u0435\u0447\u0430\u043d\u0438\u044f:\n"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 349
    const/4 v7, 0x0

    move v4, v7

    :goto_1
    move v7, v4

    move-object v8, v1

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->notes:Ljava/util/List;

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v8

    if-lt v7, v8, :cond_2

    .line 353
    :cond_0
    move-object v7, v3

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    move-object v1, v7

    return-object v1

    .line 342
    :cond_1
    move-object v7, v1

    iget-object v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->images:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;

    move v8, v4

    aget-object v7, v7, v8

    move-object v5, v7

    .line 343
    move-object v7, v3

    const-string v8, "  %-34s \u043a\u043b\u0430\u0441\u0441\u043e\u0432=%d\n"

    const/4 v9, 0x2

    new-array v9, v9, [Ljava/lang/Object;

    move-object v15, v9

    move-object v9, v15

    move-object v10, v15

    const/4 v11, 0x0

    move-object v12, v1

    move-object v13, v5

    iget v13, v13, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;->nameIndex:I

    invoke-virtual {v12, v13}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->getString(I)Ljava/lang/String;

    move-result-object v12

    aput-object v12, v10, v11

    move-object v15, v9

    move-object v9, v15

    move-object v10, v15

    const/4 v11, 0x1

    move-object v12, v5

    iget v12, v12, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;->typeCount:I

    new-instance v13, Ljava/lang/Integer;

    move v15, v12

    move-object/from16 v16, v13

    move-object/from16 v12, v16

    move v13, v15

    move-object/from16 v14, v16

    move v15, v13

    move-object/from16 v16, v14

    move-object/from16 v13, v16

    move v14, v15

    invoke-direct {v13, v14}, Ljava/lang/Integer;-><init>(I)V

    aput-object v12, v10, v11

    invoke-static {v8, v9}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 341
    add-int/lit8 v4, v4, 0x1

    goto :goto_0

    .line 350
    :cond_2
    move-object v7, v3

    const-string v8, "  - "

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    move-object v8, v1

    iget-object v8, v8, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->notes:Ljava/util/List;

    move v9, v4

    invoke-interface {v8, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const/16 v8, 0xa

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    move-result-object v7

    .line 349
    add-int/lit8 v4, v4, 0x1

    goto :goto_1
.end method

.method public fields()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$FieldDefinition;
    .locals 3

    .prologue
    .line 67
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->fields:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$FieldDefinition;

    move-object v0, v2

    return-object v0
.end method

.method public fullName(Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;)Ljava/lang/String;
    .locals 10

    .prologue
    .line 357
    move-object v0, p0

    move-object v1, p1

    move-object v6, v0

    move-object v7, v1

    iget v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->namespaceIndex:I

    invoke-virtual {v6, v7}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->getString(I)Ljava/lang/String;

    move-result-object v6

    move-object v3, v6

    .line 358
    move-object v6, v0

    move-object v7, v1

    iget v7, v7, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;->nameIndex:I

    invoke-virtual {v6, v7}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->getString(I)Ljava/lang/String;

    move-result-object v6

    move-object v4, v6

    .line 359
    move-object v6, v3

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v6

    const/4 v7, 0x0

    if-le v6, v7, :cond_0

    new-instance v6, Ljava/lang/StringBuffer;

    move-object v9, v6

    move-object v6, v9

    move-object v7, v9

    invoke-direct {v7}, Ljava/lang/StringBuffer;-><init>()V

    new-instance v7, Ljava/lang/StringBuffer;

    move-object v9, v7

    move-object v7, v9

    move-object v8, v9

    invoke-direct {v8}, Ljava/lang/StringBuffer;-><init>()V

    move-object v8, v3

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    const-string v8, "."

    invoke-virtual {v7, v8}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    move-object v7, v4

    invoke-virtual {v6, v7}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v6

    :goto_0
    move-object v0, v6

    return-object v0

    :cond_0
    move-object v6, v4

    goto :goto_0
.end method

.method public getString(I)Ljava/lang/String;
    .locals 6

    .prologue
    .line 91
    move-object v0, p0

    move v1, p1

    move v3, v1

    const/4 v4, 0x0

    if-ge v3, v4, :cond_0

    .line 92
    const-string v3, ""

    move-object v0, v3

    .line 94
    :goto_0
    return-object v0

    :cond_0
    move-object v3, v0

    iget-object v3, v3, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object v4, v0

    iget-object v4, v4, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header:Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    const-string v5, "string"

    invoke-virtual {v4, v5}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->offset(Ljava/lang/String;)I

    move-result v4

    move v5, v1

    add-int/2addr v4, v5

    invoke-virtual {v3, v4}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readStringToNull(I)Ljava/lang/String;

    move-result-object v3

    move-object v0, v3

    goto :goto_0
.end method

.method public getStringLiteral(I)Ljava/lang/String;
    .locals 15

    .prologue
    .line 98
    move-object v0, p0

    move/from16 v1, p1

    move-object v10, v0

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header:Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    const-string v11, "stringLiteral"

    invoke-virtual {v10, v11}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->offset(Ljava/lang/String;)I

    move-result v10

    move v3, v10

    .line 99
    move-object v10, v0

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header:Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    const-string v11, "stringLiteral"

    invoke-virtual {v10, v11}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->count(Ljava/lang/String;)I

    move-result v10

    const/16 v11, 0x8

    div-int/lit8 v10, v10, 0x8

    move v4, v10

    .line 100
    move v10, v1

    const/4 v11, 0x0

    if-lt v10, v11, :cond_0

    move v10, v1

    move v11, v4

    if-lt v10, v11, :cond_1

    .line 101
    :cond_0
    new-instance v10, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    new-instance v12, Ljava/lang/StringBuffer;

    move-object v14, v12

    move-object v12, v14

    move-object v13, v14

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    const-string v13, "\u0438\u043d\u0434\u0435\u043a\u0441 \u0441\u0442\u0440\u043e\u043a\u043e\u0432\u043e\u0433\u043e \u043b\u0438\u0442\u0435\u0440\u0430\u043b\u0430 \u0432\u043d\u0435 \u0434\u0438\u0430\u043f\u0430\u0437\u043e\u043d\u0430: "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    move v13, v1

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-direct {v11, v12}, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;-><init>(Ljava/lang/String;)V

    throw v10

    .line 103
    :cond_1
    move-object v10, v0

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move v11, v3

    move v12, v1

    const/16 v13, 0x8

    mul-int/lit8 v12, v12, 0x8

    add-int/2addr v11, v12

    invoke-virtual {v10, v11}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->seek(I)V

    .line 104
    move-object v10, v0

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    invoke-virtual {v10}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v10

    move v5, v10

    .line 105
    move-object v10, v0

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    invoke-virtual {v10}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v10

    move v6, v10

    .line 106
    move v10, v5

    const/4 v11, 0x0

    if-gt v10, v11, :cond_2

    .line 107
    const-string v10, ""

    move-object v0, v10

    .line 112
    :goto_0
    return-object v0

    .line 109
    :cond_2
    move-object v10, v0

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object v11, v0

    iget-object v11, v11, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header:Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    const-string v12, "stringLiteralData"

    invoke-virtual {v11, v12}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->offset(Ljava/lang/String;)I

    move-result v11

    move v12, v6

    add-int/2addr v11, v12

    invoke-virtual {v10, v11}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->seek(I)V

    .line 110
    move-object v10, v0

    iget-object v10, v10, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move v11, v5

    invoke-virtual {v10, v11}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readBytes(I)[B

    move-result-object v10

    move-object v7, v10

    .line 112
    :try_start_0
    new-instance v10, Ljava/lang/String;

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    move-object v12, v7

    const-string v13, "UTF-8"

    invoke-direct {v11, v12, v13}, Ljava/lang/String;-><init>([BLjava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    move-object v0, v10

    goto :goto_0

    :catch_0
    move-exception v10

    move-object v8, v10

    .line 114
    new-instance v10, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;

    move-object v14, v10

    move-object v10, v14

    move-object v11, v14

    new-instance v12, Ljava/lang/StringBuffer;

    move-object v14, v12

    move-object v12, v14

    move-object v13, v14

    invoke-direct {v13}, Ljava/lang/StringBuffer;-><init>()V

    const-string v13, "\u043d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u0434\u0435\u043a\u043e\u0434\u0438\u0440\u043e\u0432\u0430\u0442\u044c \u043b\u0438\u0442\u0435\u0440\u0430\u043b "

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    move-result-object v12

    move v13, v1

    invoke-virtual {v12, v13}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    move-result-object v12

    invoke-virtual {v12}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v12

    move-object v13, v8

    invoke-direct {v11, v12, v13}, Lcom/Leon4ikMods/UniversalDumper/core/DumpException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    throw v10
.end method

.method public header()Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;
    .locals 3

    .prologue
    .line 51
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header:Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    move-object v0, v2

    return-object v0
.end method

.method public images()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;
    .locals 3

    .prologue
    .line 71
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->images:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ImageDefinition;

    move-object v0, v2

    return-object v0
.end method

.method public interfaceTypeIndex(I)I
    .locals 5

    .prologue
    .line 80
    move-object v0, p0

    move v1, p1

    move-object v3, v0

    iget-object v3, v3, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->interfaceIndices:[I

    if-eqz v3, :cond_0

    move v3, v1

    const/4 v4, 0x0

    if-lt v3, v4, :cond_0

    move v3, v1

    move-object v4, v0

    iget-object v4, v4, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->interfaceIndices:[I

    array-length v4, v4

    if-lt v3, v4, :cond_1

    .line 81
    :cond_0
    const/4 v3, -0x1

    move v0, v3

    .line 83
    :goto_0
    return v0

    :cond_1
    move-object v3, v0

    iget-object v3, v3, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->interfaceIndices:[I

    move v4, v1

    aget v3, v3, v4

    move v0, v3

    goto :goto_0
.end method

.method public methods()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;
    .locals 3

    .prologue
    .line 63
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->methods:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;

    move-object v0, v2

    return-object v0
.end method

.method public parameters()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ParameterDefinition;
    .locals 3

    .prologue
    .line 75
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->parameters:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$ParameterDefinition;

    move-object v0, v2

    return-object v0
.end method

.method public stream()Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;
    .locals 3

    .prologue
    .line 47
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->bs:Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;

    move-object v0, v2

    return-object v0
.end method

.method public typeStructSize()I
    .locals 3

    .prologue
    .line 87
    move-object v0, p0

    move-object v2, v0

    iget v2, v2, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->typeStructSize:I

    move v0, v2

    return v0
.end method

.method public types()[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;
    .locals 3

    .prologue
    .line 59
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->types:[Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$TypeDefinition;

    move-object v0, v2

    return-object v0
.end method

.method public version()D
    .locals 4

    .prologue
    .line 55
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Metadata;->header:Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;

    invoke-virtual {v2}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/MetadataHeader;->version()D

    move-result-wide v2

    move-wide v0, v2

    return-wide v0
.end method
