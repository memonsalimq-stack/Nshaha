.class public final Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;
.super Ljava/lang/Object;
.source "Structs.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x39
    name = "MethodDefinition"
.end annotation


# static fields
.field public static final SIZE_24_2:I = 0x20

.field public static final SIZE_31:I = 0x24


# instance fields
.field public declaringType:I

.field public flags:I

.field public genericContainerIndex:I

.field public iflags:I

.field public nameIndex:I

.field public parameterCount:I

.field public parameterStart:I

.field public returnParameterToken:I

.field public returnType:I

.field public slot:I

.field public token:I


# direct methods
.method public constructor <init>()V
    .locals 3

    .prologue
    .line 183
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static read(Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;II)Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;
    .locals 9

    .prologue
    .line 141
    move-object v0, p0

    move v1, p1

    move v2, p2

    move-object v6, v0

    move v7, v1

    invoke-virtual {v6, v7}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->seek(I)V

    .line 142
    new-instance v6, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;

    move-object v8, v6

    move-object v6, v8

    move-object v7, v8

    invoke-direct {v7}, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;-><init>()V

    move-object v4, v6

    .line 143
    move-object v6, v4

    move-object v7, v0

    invoke-virtual {v7}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v7

    iput v7, v6, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->nameIndex:I

    .line 144
    move-object v6, v4

    move-object v7, v0

    invoke-virtual {v7}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v7

    iput v7, v6, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->declaringType:I

    .line 145
    move-object v6, v4

    move-object v7, v0

    invoke-virtual {v7}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v7

    iput v7, v6, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->returnType:I

    .line 146
    move v6, v2

    const/16 v7, 0x24

    if-lt v6, v7, :cond_0

    .line 147
    move-object v6, v4

    move-object v7, v0

    invoke-virtual {v7}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v7

    iput v7, v6, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->returnParameterToken:I

    .line 149
    :cond_0
    move-object v6, v4

    move-object v7, v0

    invoke-virtual {v7}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v7

    iput v7, v6, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->parameterStart:I

    .line 150
    move-object v6, v4

    move-object v7, v0

    invoke-virtual {v7}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v7

    iput v7, v6, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->genericContainerIndex:I

    .line 151
    move-object v6, v4

    move-object v7, v0

    invoke-virtual {v7}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readInt()I

    move-result v7

    iput v7, v6, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->token:I

    .line 152
    move-object v6, v4

    move-object v7, v0

    invoke-virtual {v7}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readUShort()I

    move-result v7

    iput v7, v6, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->flags:I

    .line 153
    move-object v6, v4

    move-object v7, v0

    invoke-virtual {v7}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readUShort()I

    move-result v7

    iput v7, v6, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->iflags:I

    .line 154
    move-object v6, v4

    move-object v7, v0

    invoke-virtual {v7}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readUShort()I

    move-result v7

    iput v7, v6, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->slot:I

    .line 155
    move-object v6, v4

    move-object v7, v0

    invoke-virtual {v7}, Lcom/Leon4ikMods/UniversalDumper/core/BinaryStream;->readUShort()I

    move-result v7

    iput v7, v6, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->parameterCount:I

    .line 156
    move-object v6, v4

    move-object v0, v6

    return-object v0
.end method


# virtual methods
.method public modifiers()Ljava/lang/String;
    .locals 8

    .prologue
    .line 161
    move-object v0, p0

    new-instance v5, Ljava/lang/StringBuilder;

    move-object v7, v5

    move-object v5, v7

    move-object v6, v7

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    move-object v2, v5

    .line 162
    move-object v5, v0

    iget v5, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->flags:I

    const/4 v6, 0x7

    and-int/lit8 v5, v5, 0x7

    move v3, v5

    .line 163
    move v5, v3

    const/4 v6, 0x1

    if-ne v5, v6, :cond_2

    .line 164
    move-object v5, v2

    const-string v6, "private "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 174
    :goto_0
    move-object v5, v0

    iget v5, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->flags:I

    const/16 v6, 0x10

    and-int/lit8 v5, v5, 0x10

    const/4 v6, 0x0

    if-eq v5, v6, :cond_0

    .line 175
    move-object v5, v2

    const-string v6, "static "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 177
    :cond_0
    move-object v5, v0

    iget v5, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->flags:I

    const/16 v6, 0x400

    and-int/lit16 v5, v5, 0x400

    const/4 v6, 0x0

    if-eq v5, v6, :cond_6

    .line 178
    move-object v5, v2

    const-string v6, "abstract "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    .line 182
    :cond_1
    :goto_1
    move-object v5, v2

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    move-object v0, v5

    return-object v0

    .line 165
    :cond_2
    move v5, v3

    const/4 v6, 0x3

    if-ne v5, v6, :cond_3

    .line 166
    move-object v5, v2

    const-string v6, "internal "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    goto :goto_0

    .line 167
    :cond_3
    move v5, v3

    const/4 v6, 0x4

    if-ne v5, v6, :cond_4

    .line 168
    move-object v5, v2

    const-string v6, "protected "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    goto :goto_0

    .line 169
    :cond_4
    move v5, v3

    const/4 v6, 0x6

    if-ne v5, v6, :cond_5

    .line 170
    move-object v5, v2

    const-string v6, "public "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    goto :goto_0

    .line 172
    :cond_5
    move-object v5, v2

    const-string v6, "private "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    goto :goto_0

    .line 179
    :cond_6
    move-object v5, v0

    iget v5, v5, Lcom/Leon4ikMods/UniversalDumper/il2cpp/Structs$MethodDefinition;->flags:I

    const/16 v6, 0x40

    and-int/lit8 v5, v5, 0x40

    const/4 v6, 0x0

    if-eq v5, v6, :cond_1

    .line 180
    move-object v5, v2

    const-string v6, "virtual "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    goto :goto_1
.end method
