public class AppDelegateCarrom : AppDelegate // Size: 0x3C
{
	void beforeStart(); // RVA: 0x10020F5C8
}

public class CarrominhoMenu : MenuStateNode // Size: 0x3E0
{
	static NSObject getCCBName(); // RVA: 0x10232490C
	void onEnter(); // RVA: 0x102324918
	void animationEnded(); // RVA: 0x102324A44
}

public class CarromitchiNode : CCNodeRGBA // Size: 0x410
{
	CCSprite _sprite; // 0x3A8 (size: 0x8)
	object _textures; // 0x3B0 (size: 0x28)
	long _state; // 0x3D8 (size: 0x8)
	CGPoint _target; // 0x3E0 (size: 0x10)
	float _stateTimer; // 0x3F0 (size: 0x4)
	float _animTimer; // 0x3F4 (size: 0x4)
	int _animFrame; // 0x3F8 (size: 0x4)
	CGSize _bounds; // 0x400 (size: 0x10)

	NSObject init(); // RVA: 0x102322F28
	void dealloc(); // RVA: 0x102323080
	void onEnter(); // RVA: 0x1023230FC
	void onExit(); // RVA: 0x102323204
	void update:(); // RVA: 0x102323248
	void updateWalking:(); // RVA: 0x102323278
	void maybeRestartWalkingAnimation(); // RVA: 0x1023234A0
	void updateSitting:(); // RVA: 0x102323514
	void updateSleeping:(); // RVA: 0x102323534
	void pickNewTarget(); // RVA: 0x102323608
	NSObject textureFromPalette:palette:(); // RVA: 0x102323698
}

public class ClubsLeaderboardClubEntry : CCNodeRGBA // Size: 0x3F0
{
	ClubsLeaderboardClubEntryView _view; // 0x3A8 (size: 0x8)
	StringMap _clubLeagueEntry; // 0x3B0 (size: 0x28)
	basic_string<char, std::char_traits<char>, std::allocator<char>> _clubId; // 0x3D8 (size: 0x18)

	ulong hash { get; set; } // property
	Class superclass { get; set; } // property
	NSString description { get; set; } // property
	NSString debugDescription { get; set; } // property

	static NSObject stickyEntryWithClubLeagueEntry:nodeSize:(); // RVA: 0x1000AFA28
	static NSObject entryWithClubLeagueEntry:nodeSize:(); // RVA: 0x1000AFA58
	NSObject initWithClubLeagueEntry:nodeSize:(); // RVA: 0x1000AFA9C
	void dealloc(); // RVA: 0x1000AFB18
	void setupWithLeagueEntry:(); // RVA: 0x1000AFB5C
	void loadView(); // RVA: 0x1000AFC10
	void unloadView(); // RVA: 0x1000AFC90
	void enableInput(); // RVA: 0x1000AFCE4
	void disableInput(); // RVA: 0x1000AFCF4
	void onEnterVisibleArea(); // RVA: 0x1000AFD04
	void onExitVisibleArea(); // RVA: 0x1000AFD08
	void setEnabled:(); // RVA: 0x1000AFD0C
	void showClubInfo(); // RVA: 0x1000AFD10
	void .cxx_destruct(); // RVA: 0x1000AFD44
	NSObject .cxx_construct(); // RVA: 0x1000AFD88
}

public class ClubsLeaderboardClubEntryView : CCNodeRGBA // Size: 0x3E0
{
	MCFramedSprite _standardFrame; // 0x3A8 (size: 0x8)
	MCFramedSprite _highlightFrame; // 0x3B0 (size: 0x8)
	CCNodeRGBA _rankContainer; // 0x3B8 (size: 0x8)
	MCLabelTTF _winningsLabel; // 0x3C0 (size: 0x8)
	CCNodeRGBA _clubViewContainer; // 0x3C8 (size: 0x8)
	CCSprite _coinsIcon; // 0x3D0 (size: 0x8)
	MCMenuItemNodeRGBA _avatarButton; // 0x3D8 (size: 0x8)

	void setupWithClubLeagueEntry:clubId:(); // RVA: 0x1002073F8
	void setupWithClubLeagueEntry:clubId:owner:(); // RVA: 0x100207400
	void reset(); // RVA: 0x100207A80
	void enableInput(); // RVA: 0x100207AF8
	void disableInput(); // RVA: 0x100207B0C
}

public class ClubsLeaderboardComponent : ClubsTableComponent // Size: 0x488
{
	<ClubsLeaderboardComponentDelegate> _leaderboardDelegate; // 0x438 (size: 0x8)
	ClubsLeaderboardComponentBuilder _leaderboardBuilder; // 0x440 (size: 0x8)
	CCNodeRGBA _stickyCellPivot; // 0x448 (size: 0x8)
	ClubsTableComponentLeaderboardTeaserNode _stickyTeaserNode; // 0x450 (size: 0x8)
	CCNodeRGBA _tableHeaderNode; // 0x458 (size: 0x8)
	MCAdjustableLabelTTF _rankLabel; // 0x460 (size: 0x8)
	MCAdjustableLabelTTF _clubNameLabel; // 0x468 (size: 0x8)
	MCAdjustableLabelTTF _membersLabel; // 0x470 (size: 0x8)
	MCAdjustableLabelTTF _winningsLabel; // 0x478 (size: 0x8)
	MCAdjustableLabelTTF _loadingLabel; // 0x480 (size: 0x8)

	CCNodeRGBA tableHeaderNode { get; set; } // property
	MCAdjustableLabelTTF rankLabel { get; set; } // property
	MCAdjustableLabelTTF clubNameLabel { get; set; } // property
	MCAdjustableLabelTTF membersLabel { get; set; } // property
	MCAdjustableLabelTTF winningsLabel { get; set; } // property
	MCAdjustableLabelTTF loadingLabel { get; set; } // property

	static NSObject createTableComponentWithSize:position:anchorPoint:builder:delegate:(); // RVA: 0x10034B2D4
	NSObject initWithBuilder:size:scheduler:delegate:(); // RVA: 0x10034B39C
	void dealloc(); // RVA: 0x10034B4A4
	void refreshAndKeepPosition:(); // RVA: 0x10034B514
	void createFrame(); // RVA: 0x10034B5B0
	void createTableHeader(); // RVA: 0x10034B68C
	NSObject createHeaderLabelWithString:position:anchorPoint:(); // RVA: 0x10034B90C
	void createLoadingSprite(); // RVA: 0x10034BA10
	void animateLoadingNode(); // RVA: 0x10034BB54
	void stopLoadingNodeAnimation(); // RVA: 0x10034BBE8
	void fadeIn(); // RVA: 0x10034BC20
	void scrollCallback(); // RVA: 0x10034BC6C
	int getRank:(); // RVA: 0x10034BCB0
	void snapPlayerRow(); // RVA: 0x10034BD00
	void updatePlayerRow(); // RVA: 0x10034BD04
	void createStickyTeaserNode(); // RVA: 0x10034BDAC
	bool isPlayerClubVisible(); // RVA: 0x10034BF94
	NSObject createMemberLeaderboardNodeWithClubId:clubMember:isCurrentUser:(); // RVA: 0x10034BFD4
	NSObject createLeaderboardNodeWithData:maxClubMembers:isCurrentUserClub:useFramePool:touchPriority:target:selector:(); // RVA: 0x10034C040
	void didTapOnLeaderboardNode:(); // RVA: 0x10034C0E0
	int currentRankOnBottom(); // RVA: 0x10034C218
	void fillTableWithLeaderboardData:orderByRank:useFramePool:(); // RVA: 0x10034C2F8
	void fillTableWithLeaderboardData:orderByRank:entriesToShow:useFramePool:(); // RVA: 0x10034C3F0
	void fillTableWithLeaderboardEntries:ownClubEntry:orderByRank:entriesToShow:useFramePool:(); // RVA: 0x10034C4EC
	void createStickyCell:maxClubMembers:useFramePool:memberNumber:(); // RVA: 0x10034C848
	void fillTableWithClubId:clubMemberLeaderboard:orderByRank:(); // RVA: 0x10034C84C
	void cleanLeaderboard(); // RVA: 0x10034CA6C
	void onNodePressedWithClubMemberUserId:clubMemberName:nodeSize:nodePosition:(); // RVA: 0x10034CAC0
	NSObject tableHeaderNode(); // RVA: 0x10034CB44
	void setTableHeaderNode:(); // RVA: 0x10034CB54
	NSObject rankLabel(); // RVA: 0x10034CB64
	void setRankLabel:(); // RVA: 0x10034CB74
	NSObject clubNameLabel(); // RVA: 0x10034CB84
	void setClubNameLabel:(); // RVA: 0x10034CB94
	NSObject membersLabel(); // RVA: 0x10034CBA4
	void setMembersLabel:(); // RVA: 0x10034CBB4
	NSObject winningsLabel(); // RVA: 0x10034CBC4
	void setWinningsLabel:(); // RVA: 0x10034CBD4
	NSObject loadingLabel(); // RVA: 0x10034CBE4
	void setLoadingLabel:(); // RVA: 0x10034CBF4
}

public class ClubsLeaderboardComponentBuilder : ClubsTableComponentBuilder // Size: 0x98
{
	bool _isStickyCellEnabled; // 0x90 (size: 0x1)
	bool _hasUserClub; // 0x91 (size: 0x1)
	bool _shouldShowTeaserNode; // 0x92 (size: 0x1)
	float _picktRectHeightOffset; // 0x94 (size: 0x4)

	bool hasUserClub { get; set; } // property
	bool shouldShowTeaserNode { get; set; } // property
	bool isStickyCellEnabled { get; set; } // property
	float picktRectHeightOffset { get; set; } // property

	NSObject init(); // RVA: 0x1002C7754
	bool isStickyCellEnabled(); // RVA: 0x1002C77C0
	void setIsStickyCellEnabled:(); // RVA: 0x1002C77D0
	bool hasUserClub(); // RVA: 0x1002C77E0
	void setHasUserClub:(); // RVA: 0x1002C77F0
	bool shouldShowTeaserNode(); // RVA: 0x1002C7800
	void setShouldShowTeaserNode:(); // RVA: 0x1002C7810
	float picktRectHeightOffset(); // RVA: 0x1002C7820
	void setPicktRectHeightOffset:(); // RVA: 0x1002C7830
}

public class ClubsLeaderboardEntriesNode : CCNodeRGBA // Size: 0x3B0
{
	MCScrollList _leaderboardEntriesList; // 0x3A8 (size: 0x8)

	void setContentSize:(); // RVA: 0x1001DA460
	void populateWithClubInfo:(); // RVA: 0x1001DA4CC
	void populateWithClubLeaderboard:(); // RVA: 0x1001DA678
	void clean(); // RVA: 0x1001DA844
}

public class ClubsLeaderboardMemberEntry : CCNodeRGBA // Size: 0x410
{
	CCNodeRGBA _view; // 0x3A8 (size: 0x8)
	PlayerAvatarNode _playerAvatar; // 0x3B0 (size: 0x8)
	PlayerNameNode _playerName; // 0x3B8 (size: 0x8)
	StarNode _starNode; // 0x3C0 (size: 0x8)
	MCFramedSprite _standardFrame; // 0x3C8 (size: 0x8)
	MCFramedSprite _highlightFrame; // 0x3D0 (size: 0x8)
	MCLabelTTF _winnings; // 0x3D8 (size: 0x8)
	MCLabelTTF _rank; // 0x3E0 (size: 0x8)
	CCNodeRGBA _rankContainer; // 0x3E8 (size: 0x8)
	CCNodeRGBA _flagContainer; // 0x3F0 (size: 0x8)
	basic_string<char, std::char_traits<char>, std::allocator<char>> _userId; // 0x3F8 (size: 0x18)

	ulong hash { get; set; } // property
	Class superclass { get; set; } // property
	NSString description { get; set; } // property
	NSString debugDescription { get; set; } // property

	static NSObject entryWithClubMember:nodeSize:(); // RVA: 0x1000B7790
	void setupWithClubMemberEntry:(); // RVA: 0x1000B77D4
	void avatarPressed(); // RVA: 0x1000B7AE4
	void onEnterVisibleArea(); // RVA: 0x1000B7AF8
	void onExitVisibleArea(); // RVA: 0x1000B7B0C
	void setEnabled:(); // RVA: 0x1000B7B20
	void .cxx_destruct(); // RVA: 0x1000B7B24
	NSObject .cxx_construct(); // RVA: 0x1000B7B44
}

public class ClubsLeaderboardsCompetitionResultsPopup : MenuPopup // Size: 0x4E4
{
	PlayerAvatarNode _playerAvatar; // 0x470 (size: 0x8)
	PlayerNameNode _playerName; // 0x478 (size: 0x8)
	StarNode _starNode; // 0x480 (size: 0x8)
	CCNodeRGBA _iconContainer; // 0x488 (size: 0x8)
	CCNodeRGBA _iconLeagueContainer; // 0x490 (size: 0x8)
	MCLabelTTF _leaderboardName; // 0x498 (size: 0x8)
	MCLabelTTF _winningsLabel; // 0x4A0 (size: 0x8)
	CCNodeRGBA _rankContainer; // 0x4A8 (size: 0x8)
	MCLabelTTF _prizeLabel; // 0x4B0 (size: 0x8)
	CCSprite _prizeGems; // 0x4B8 (size: 0x8)
	CCSprite _prizeCoins; // 0x4C0 (size: 0x8)
	CCNodeRGBA _clubAvatarContainer; // 0x4C8 (size: 0x8)
	CCNodeRGBA _clubAvatarGlow; // 0x4D0 (size: 0x8)
	MCLabelTTF _youWonLabel; // 0x4D8 (size: 0x8)
	int _boardType; // 0x4E0 (size: 0x4)

	static void queueLeagueChangePopup(); // RVA: 0x10008CFA8
	NSObject initWithParameters:(); // RVA: 0x10008CFEC
	float enter(); // RVA: 0x10008D08C
	void loadResults(); // RVA: 0x10008D0E4
	void fullResultsButtonCallback(); // RVA: 0x10008DA34
}

public class ClubsLeaderboardsContent : CCNodeRGBA // Size: 0x419
{
	ClubsLeaderboardEntriesNode _leaderboardEntriesNode; // 0x3A8 (size: 0x8)
	SkinRadioButtonGroup _leaderboardTypeButtonGroup; // 0x3B0 (size: 0x8)
	CCNodeRGBA _loadingCircle; // 0x3B8 (size: 0x8)
	MCFramedSprite _clubLeaderboardInfoFrame; // 0x3C0 (size: 0x8)
	MCFramedSprite _clubLeaderboardInfoShadow; // 0x3C8 (size: 0x8)
	ClubsLeaderboardsInfoNode _clubsLeaderboardsInfoNode; // 0x3D0 (size: 0x8)
	StringMap _clubLeagueData; // 0x3D8 (size: 0x28)
	MakeWeak _makeWeak; // 0x400 (size: 0x10)
	ClubsEventDispatcherWrapper _wrapper; // 0x410 (size: 0x8)
	bool _isFrameStandardSize; // 0x418 (size: 0x1)

	void onEnter(); // RVA: 0x100256E0C
	void setupWithClubInfo:(); // RVA: 0x100256FF0
	void setupWithClubsLeaderboardType:(); // RVA: 0x100257038
	void refresh(); // RVA: 0x100257348
	void setEndTimestamp(); // RVA: 0x10025773C
	void onReceivedClubLeagueData:(); // RVA: 0x100257778
	void setLeaderboardType:(); // RVA: 0x1002577F4
	void setLeaderboardFrameContentSizeAsStandard:(); // RVA: 0x1002578A4
	void .cxx_destruct(); // RVA: 0x100257A60
	NSObject .cxx_construct(); // RVA: 0x100257AB4
}

public class ClubsLeaderboardsGenericInfoPopup : MenuPopup // Size: 0x470
{
	NSObject initWithParameters:(); // RVA: 0x100174C50
}

public class ClubsLeaderboardsInfoNode : CCNodeRGBA // Size: 0x3F8
{
	CCNodeRGBA _iconContainer; // 0x3A8 (size: 0x8)
	CCNodeRGBA _currencyIconContainer; // 0x3B0 (size: 0x8)
	MCLayout _prizeBracketsContainer; // 0x3B8 (size: 0x8)
	MCLabelTTF _leaderboardNameLabel; // 0x3C0 (size: 0x8)
	MCLabelTTF _timerLabel; // 0x3C8 (size: 0x8)
	MCLabelTTF _prizeLabel; // 0x3D0 (size: 0x8)
	MCMenuItemNodeRGBA _infoButton; // 0x3D8 (size: 0x8)
	MCMenuItemNodeRGBA _lastWeekResultsButton; // 0x3E0 (size: 0x8)
	uint _leagueId; // 0x3E8 (size: 0x4)
	int _clubLeagueBoardType; // 0x3EC (size: 0x4)
	MCTimer _endsInTimer; // 0x3F0 (size: 0x8)

	NSObject init(); // RVA: 0x100256134
	void dealloc(); // RVA: 0x100256178
	void setupWithBoard:(); // RVA: 0x1002561D0
	void setupWithMembership(); // RVA: 0x1002568DC
	void setTimerWithEndTimestamp:(); // RVA: 0x100256A70
	void updateTimer(); // RVA: 0x100256B14
	void clean(); // RVA: 0x100256BAC
	void infoButtonCallback(); // RVA: 0x100256BF4
	void lastWeekResultsButtonCallback(); // RVA: 0x100256C88
}

public class ClubsLeaderboardsLastWeekNoResultsPopup : MenuPopup // Size: 0x470
{
	NSObject initWithParameters:(); // RVA: 0x100087BA4
}

public class ClubsLeaderboardsLastWeekResultsPopup : MenuPopup // Size: 0x490
{
	MCLabelTTF _subtitleLabel; // 0x470 (size: 0x8)
	MCLayout _prizeBracketsContainer; // 0x478 (size: 0x8)
	MCScrollList _topEntriesContainer; // 0x480 (size: 0x8)
	CCNodeRGBA _ownClubEntryContainer; // 0x488 (size: 0x8)

	static void showLastWeekResultsWithClubLeaderboardType:(); // RVA: 0x1002340B8
	NSObject initWithParameters:(); // RVA: 0x100234104
}

public class ClubsLeaderboardsLeagueChangePopup : MenuPopup // Size: 0x498
{
	CCNodeRGBA _leagueIconContainer; // 0x470 (size: 0x8)
	MCLabelTTF _leagueChangeLabel; // 0x478 (size: 0x8)
	MCLabelTTF _leagueName; // 0x480 (size: 0x8)
	CCNodeRGBA _clubAvatarContainer; // 0x488 (size: 0x8)
	MCLabelTTF _newWinnings; // 0x490 (size: 0x8)

	NSObject initWithParameters:(); // RVA: 0x1001957A0
	void backButtonCallbackImpl(); // RVA: 0x100195CF0
	float leave(); // RVA: 0x100195D08
}

// --- dump by Zoroo_God (t.me/Zoroo_God) via Privet Dumper.py

public class ClubsLeaderboardsLeagueInfoNode : CCNodeRGBA // Size: 0x3D8
{
	MCLabelTTF _nameLabel; // 0x3A8 (size: 0x8)
	MCLabelTTF _rewardValue; // 0x3B0 (size: 0x8)
	CCNodeRGBA _leagueIconContainer; // 0x3B8 (size: 0x8)
	CCNodeRGBA _gemReward; // 0x3C0 (size: 0x8)
	CCNodeRGBA _coinReward; // 0x3C8 (size: 0x8)
	int _numPromotedRanks; // 0x3D0 (size: 0x4)
	int _numRelegatedRanks; // 0x3D4 (size: 0x4)

	int numPromotedRanks { get; set; } // property
	int numRelegatedRanks { get; set; } // property

	void setupWithLeagueId:(); // RVA: 0x10007EDD8
	int numPromotedRanks(); // RVA: 0x10007F218
	void setNumPromotedRanks:(); // RVA: 0x10007F228
	int numRelegatedRanks(); // RVA: 0x10007F238
	void setNumRelegatedRanks:(); // RVA: 0x10007F248
}

public class ClubsLeaderboardsLeagueInfoPopup : MenuPopup // Size: 0x4D0
{
	MCLayout _clubLeagueInfoNodeEntries; // 0x470 (size: 0x8)
	MCMenuItemNodeRGBAStatic _overviewButton; // 0x478 (size: 0x8)
	MCMenuItemNodeRGBAStatic _infoButton; // 0x480 (size: 0x8)
	MCMenuItemNodeRGBAStatic _rulesButton; // 0x488 (size: 0x8)
	MCMenuItemNodeRGBAStatic _resultsButton; // 0x490 (size: 0x8)
	CCNodeRGBA _infoContent; // 0x498 (size: 0x8)
	MCScrollList _rulesContent; // 0x4A0 (size: 0x8)
	CCNodeRGBA _resultsContent; // 0x4A8 (size: 0x8)
	MCLabelTTF _infoText1; // 0x4B0 (size: 0x8)
	MCLabelTTF _resultsText3; // 0x4B8 (size: 0x8)
	MCLabelTTF _resultsText4; // 0x4C0 (size: 0x8)
	MCScrollList _contributionsGrid; // 0x4C8 (size: 0x8)

	static void showInfoPopupWithLeagueId:(); // RVA: 0x100039D68
	NSObject initWithParameters:(); // RVA: 0x100039DBC
	void setupWithLeagueId:(); // RVA: 0x100039E60
	NSObject computeContributionsInfoWithInfo:contributions:width:height:(); // RVA: 0x10003A410
	NSObject createLabelWithString:dimensions:color:(); // RVA: 0x10003ABE4
	void toggleButtonsWithState:(); // RVA: 0x10003AC90
	void overviewCallback(); // RVA: 0x10003AD90
	void infoCallback(); // RVA: 0x10003AD98
	void rulesCallback(); // RVA: 0x10003ADA0
	void resultsCallback(); // RVA: 0x10003ADA8
}

public class ClubsLeaderboardsPrizeBracket : CCNodeRGBA // Size: 0x3C8
{
	CCSprite _coinsSprite; // 0x3A8 (size: 0x8)
	CCSprite _gemsSprite; // 0x3B0 (size: 0x8)
	MCLabelTTF _prizeLabel; // 0x3B8 (size: 0x8)
	MCLabelTTF _rankLabel; // 0x3C0 (size: 0x8)

	static NSObject nodeWithPrizeBracket:(); // RVA: 0x100199510
	void setupWithPrizeBracket:(); // RVA: 0x1001995C8
}

public class ClubsOnboardingMenu : MenuStateNode // Size: 0x3E0
{
	static NSObject getCCBName(); // RVA: 0x10017AD6C
	static NSObject getCCBSetName(); // RVA: 0x10017AD78
	static NSObject getTitleTag(); // RVA: 0x10017AE18
	void createClubPressed(); // RVA: 0x10017AE24
	void backButtonCallbackImpl(); // RVA: 0x10017AE40
	void setupOverlayConfig(); // RVA: 0x10017AEF4
}

public class ClubsTableComponentLeaderboardEmptyNode : CCMenuItem // Size: 0x468
{
	_ccColorThreeB color { get; set; } // property
	_ccColorThreeB displayedColor { get; set; } // property
	bool cascadeColorEnabled { get; set; } // property
	byte opacity { get; set; } // property
	byte displayedOpacity { get; set; } // property
	bool cascadeOpacityEnabled { get; set; } // property
	ulong hash { get; set; } // property
	Class superclass { get; set; } // property
	NSString description { get; set; } // property
	NSString debugDescription { get; set; } // property

	NSObject init(); // RVA: 0x1002CC900
	void dealloc(); // RVA: 0x1002CC934
	void execute(); // RVA: 0x1002CC968
	void loadData(); // RVA: 0x1002CC96C
	void unloadData(); // RVA: 0x1002CC970
}

public class ClubsTableComponentLeaderboardNode : CCMenuItem // Size: 0x50E
{
	BufferedTasksScheduler _bufferedScheduler; // 0x468 (size: 0x8)
	ClubsTableComponentBuilder _configuration; // 0x470 (size: 0x8)
	NSString _id; // 0x478 (size: 0x8)
	NSNumber _rank; // 0x480 (size: 0x8)
	NSString _name; // 0x488 (size: 0x8)
	NSNumber _members; // 0x490 (size: 0x8)
	NSNumber _maxMembers; // 0x498 (size: 0x8)
	NSNumber _winnings; // 0x4A0 (size: 0x8)
	int _clubSpriteId; // 0x4A8 (size: 0x4)
	CCTableMenu _menu; // 0x4B0 (size: 0x8)
	CCNode _rankSprite; // 0x4B8 (size: 0x8)
	CCNode _clubSprite; // 0x4C0 (size: 0x8)
	CCSprite _coins; // 0x4C8 (size: 0x8)
	MCAdjustableLabelTTF _nameLabel; // 0x4D0 (size: 0x8)
	MCAdjustableLabelTTF _winningsLabel; // 0x4D8 (size: 0x8)
	MCAdjustableLabelTTF _membersCountLabel; // 0x4E0 (size: 0x8)
	MCFramedSprite _mainFrame; // 0x4E8 (size: 0x8)
	MCMenuItemNodeRGBAStatic _profileButton; // 0x4F0 (size: 0x8)
	NSObject _target; // 0x4F8 (size: 0x8)
	SEL _selector; // 0x500 (size: 0x8)
	bool _loaded; // 0x508 (size: 0x1)
	bool _loading; // 0x509 (size: 0x1)
	bool _scrollbarVisible; // 0x50A (size: 0x1)
	bool _showLeagueStarAndCountryFlag; // 0x50B (size: 0x1)
	bool _isCurrentUserClub; // 0x50C (size: 0x1)
	bool _useFramePool; // 0x50D (size: 0x1)

	NSString clubID { get; set; } // property
	NSNumber rank { get; set; } // property
	_ccColorThreeB color { get; set; } // property
	_ccColorThreeB displayedColor { get; set; } // property
	bool cascadeColorEnabled { get; set; } // property
	byte opacity { get; set; } // property
	byte displayedOpacity { get; set; } // property
	bool cascadeOpacityEnabled { get; set; } // property
	ulong hash { get; set; } // property
	Class superclass { get; set; } // property
	NSString description { get; set; } // property
	NSString debugDescription { get; set; } // property

	NSObject initWithConfiguration:scheduler:scrollBarVisible:memberLeagueInfo:maxMemberNumber:isCurrentUserClub:useFramePool:touchPriority:target:selector:(); // RVA: 0x10032A488
	void dealloc(); // RVA: 0x10032A5FC
	void extractLeagueInfo:maxMemberNumber:(); // RVA: 0x10032A710
	NSObject getFramePool(); // RVA: 0x10032A89C
	NSObject getFramedSprite(); // RVA: 0x10032A8B8
	void createFrame(); // RVA: 0x10032A8FC
	void createRankBadge(); // RVA: 0x10032A9E8
	void executeSelector(); // RVA: 0x10032AA90
	void createCellButton(); // RVA: 0x10032AAB8
	void createClubSprite(); // RVA: 0x10032AB84
	void createClubNameLabel(); // RVA: 0x10032AD38
	void setClubNameDimensions(); // RVA: 0x10032ADE8
	void createMembersCountLabel(); // RVA: 0x10032AEE4
	void createWinnings(); // RVA: 0x10032AFE8
	void createWinningsBackground(); // RVA: 0x10032B02C
	void createWinningsLabel(); // RVA: 0x10032B0F8
	void createWinningsCoins(); // RVA: 0x10032B220
	void setIsEnabled:(); // RVA: 0x10032B2C0
	void execute(); // RVA: 0x10032B2F4
	void loadData(); // RVA: 0x10032B384
	void unloadData(); // RVA: 0x10032B3C8
	double rightOf:(); // RVA: 0x10032B5B4
	NSObject rank(); // RVA: 0x10032B614
	NSObject clubID(); // RVA: 0x10032B624
}

public class ClubsTableComponentLeaderboardTeaserNode : CCMenuItem // Size: 0x468
{
	_ccColorThreeB color { get; set; } // property
	_ccColorThreeB displayedColor { get; set; } // property
	bool cascadeColorEnabled { get; set; } // property
	byte opacity { get; set; } // property
	byte displayedOpacity { get; set; } // property
	bool cascadeOpacityEnabled { get; set; } // property
	ulong hash { get; set; } // property
	Class superclass { get; set; } // property
	NSString description { get; set; } // property
	NSString debugDescription { get; set; } // property

	static NSObject loadClubsTableComponentLeaderboardTeaserNodeWithParent:andSize:(); // RVA: 0x100316218
	void joinCallback(); // RVA: 0x1003162BC
	void execute(); // RVA: 0x1003162E4
	void loadData(); // RVA: 0x1003162E8
	void unloadData(); // RVA: 0x1003162EC
}

public class ClubsTableComponentMemberLeaderboardNode : MCMenuItemNodeRGBA // Size: 0x5EA
{
	<ClubsTableComponentMemberLeaderboardNodeDelegate> _delegate; // 0x4F0 (size: 0x8)
	ClubsLeaderboardComponentBuilder _builder; // 0x4F8 (size: 0x8)
	BufferedTasksScheduler _bufferedScheduler; // 0x500 (size: 0x8)
	basic_string<char, std::char_traits<char>, std::allocator<char>> _clubId; // 0x508 (size: 0x18)
	basic_string<char, std::char_traits<char>, std::allocator<char>> _userId; // 0x520 (size: 0x18)
	uint _role; // 0x538 (size: 0x4)
	uint _rank; // 0x53C (size: 0x4)
	basic_string<char, std::char_traits<char>, std::allocator<char>> _name; // 0x540 (size: 0x18)
	basic_string<char, std::char_traits<char>, std::allocator<char>> _countryCode; // 0x558 (size: 0x18)
	ulong _winnings; // 0x570 (size: 0x8)
	float _spacingBetweenNodes; // 0x578 (size: 0x4)
	uint _level; // 0x57C (size: 0x4)
	uint _league; // 0x580 (size: 0x4)
	bool _isCurrentUser; // 0x584 (size: 0x1)
	bool _isCurrentUserMemberOfThisClub; // 0x585 (size: 0x1)
	bool _isAddFriendButtonEnabled; // 0x586 (size: 0x1)
	CCNode<CCRGBAProtocol> _rankSprite; // 0x588 (size: 0x8)
	CCSprite _leagueStar; // 0x590 (size: 0x8)
	CCSprite _countryFlag; // 0x598 (size: 0x8)
	CCSprite _coins; // 0x5A0 (size: 0x8)
	MCAdjustableLabelTTF _nameLabel; // 0x5A8 (size: 0x8)
	MCAdjustableLabelTTF _clubRoleLabel; // 0x5B0 (size: 0x8)
	MCAdjustableLabelTTF _winningsLabel; // 0x5B8 (size: 0x8)
	MCFramedSprite _frame; // 0x5C0 (size: 0x8)
	CCNodeRGBA _avatar; // 0x5C8 (size: 0x8)
	MCMenuItemNodeRGBA _addFriendsButton; // 0x5D0 (size: 0x8)
	MCMenuItemNodeRGBA _profileButton; // 0x5D8 (size: 0x8)
	CCHybridMenu _menu; // 0x5E0 (size: 0x8)
	bool _loaded; // 0x5E8 (size: 0x1)
	bool _loading; // 0x5E9 (size: 0x1)

	uint rank { get; set; } // property
	ulong hash { get; set; } // property
	Class superclass { get; set; } // property
	NSString description { get; set; } // property
	NSString debugDescription { get; set; } // property

	NSObject initWithBuilder:clubId:clubMember:isCurrentUser:scheduler:delegate:(); // RVA: 0x10031D064
	void dealloc(); // RVA: 0x10031D364
	void createFrame(); // RVA: 0x10031D458
	void createRankBadge(); // RVA: 0x10031D4F4
	void createAvatar(); // RVA: 0x10031D5E4
	void createLeagueStar(); // RVA: 0x10031D87C
	void createFlag(); // RVA: 0x10031D9D8
	void createName(); // RVA: 0x10031DA98
	void createClubRole(); // RVA: 0x10031DBC4
	void createWinnings(); // RVA: 0x10031DCF8
	void createCoinSprite(); // RVA: 0x10031DE64
	void addFriend(); // RVA: 0x10031DF54
	void createAddFriendsNode(); // RVA: 0x10031E07C
	double xPositionToTheRightOf:(); // RVA: 0x10031E1A0
	void setIsEnabled:(); // RVA: 0x10031E200
	void cellTapCallback(); // RVA: 0x10031E234
	NSObject getFramePool(); // RVA: 0x10031E2AC
	void execute(); // RVA: 0x10031E2C8
	void loadData(); // RVA: 0x10031E368
	void unloadData(); // RVA: 0x10031E3AC
	uint rank(); // RVA: 0x10031E5C0
	void .cxx_destruct(); // RVA: 0x10031E5D0
	NSObject .cxx_construct(); // RVA: 0x10031E664
}

public class CollectionRulesPopup : MenuPopup // Size: 0x470
{
	static NSObject getCCBName(); // RVA: 0x10017A2C0
	float enterAnimation(); // RVA: 0x10017A2CC
	float leaveAnimation(); // RVA: 0x10017A2D0
}

public class CustomEventActionScoreboardNode : CustomEventActionNode // Size: 0x4F8
{
	void registerStates(); // RVA: 0x10212C738
	basic_string<char, std::char_traits<char>, std::allocator<char>> getPreloadedStateName(); // RVA: 0x10212C974
	basic_string<char, std::char_traits<char>, std::allocator<char>> discoverStateName(); // RVA: 0x10212C984
	void onEnter(); // RVA: 0x10212CA8C
	void joinPressed(); // RVA: 0x10212CAEC
	void joinTimeoutCallback(); // RVA: 0x10212CBC4
}

public class CustomEventPointRuleSummary : CCNodeRGBA // Size: 0x3A8
{
	static NSObject ruleWithDescription:iconImageName:points:shouldShowSeparator:separatorColor:parentSize:(); // RVA: 0x1022BD06C
}

public class CustomEventRulesButton : CCNodeRGBA // Size: 0x3D0
{
	Reference _customEvent; // 0x3A8 (size: 0x8)
	int _bubbleLayout; // 0x3B0 (size: 0x4)
	CGPoint _bubblePosition; // 0x3B8 (size: 0x10)
	CCNode _bubbleHolder; // 0x3C8 (size: 0x8)

	CGPoint bubblePosition { get; set; } // property

	void didLoadFromCCB:(); // RVA: 0x10219E6B0
	void infoButtonPressed(); // RVA: 0x10219E754
	CGPoint bubblePosition(); // RVA: 0x10219E780
	NSObject .cxx_construct(); // RVA: 0x10219E794
}

public class CustomEventRulesLayout : CCNodeRGBA // Size: 0x3B0
{
	NSString _transitionEffect; // 0x3A8 (size: 0x8)

	NSString transitionEffect { get; set; } // property

	void dealloc(); // RVA: 0x1023315B0
	NSObject transitionEffect(); // RVA: 0x102331600
}

public class CustomEventRulesPopup : MenuPopup // Size: 0x478
{
	MCScrollList _rulesList; // 0x470 (size: 0x8)

	static NSObject getCCBName(); // RVA: 0x102321E70
	static void getCCBParameters:didLoadData:(); // RVA: 0x102321E7C
	void didLoadFromCCB:(); // RVA: 0x102321FA4
	float enterAnimation(); // RVA: 0x102322378
	float leaveAnimation(); // RVA: 0x1023223CC
	void setupWithParameters:(); // RVA: 0x102322420
}

public class CustomScoreboardAnnouncementPopup : MenuPopup // Size: 0x490
{
	CCSprite _loadingCircle; // 0x470 (size: 0x8)
	bool _shouldRedirect; // 0x478 (size: 0x1)
	bool _shouldShowEventPopup; // 0x479 (size: 0x1)
	Reference _scoreboard; // 0x480 (size: 0x8)
	EventBus _bus; // 0x488 (size: 0x8)

	Reference scoreboard { get; set; } // property

	static bool canBeStacked(); // RVA: 0x102183A3C
	static NSObject getCCBName(); // RVA: 0x102183ADC
	static bool canQueuePopup(); // RVA: 0x102183AE8
	static void queueWithIdentifier:(); // RVA: 0x102183B38
	static void showWithIdentifier:(); // RVA: 0x102183BB0
	static void setParameterizedShowEventPopup:(); // RVA: 0x102183BD0
	static void getCCBParameters:didLoadData:(); // RVA: 0x102183C18
	void setupWithParameters:(); // RVA: 0x102183E3C
	void refreshState(); // RVA: 0x102183FE4
	void finishLeave(); // RVA: 0x102184070
	void redirectPressed(); // RVA: 0x1021840F8
	void joinPressed(); // RVA: 0x10218410C
	void joinTimedOut(); // RVA: 0x1021841C0
	Reference scoreboard(); // RVA: 0x1021841E0
	void .cxx_destruct(); // RVA: 0x1021841F0
	NSObject .cxx_construct(); // RVA: 0x102184214
}

public class CustomScoreboardCarouselLayout : CCNodeRGBA // Size: 0x3C0
{
	CCHybridMenu _menu; // 0x3A8 (size: 0x8)
	MCMenuItem _closeButton; // 0x3B0 (size: 0x8)
	Reference _scoreboard; // 0x3B8 (size: 0x8)

	const scoreboard { get; set; } // property
	bool isPending { get; set; } // property

	static NSObject layoutWithScoreboard:owner:(); // RVA: 0x1022B9A50
	const scoreboard(); // RVA: 0x1022B9BBC
	bool isPending(); // RVA: 0x1022B9BCC
	void didLoadFromCCB:(); // RVA: 0x1022B9BD4
	void disableInput(); // RVA: 0x1022B9C54
	void enableInput(); // RVA: 0x1022B9C68
	NSObject .cxx_construct(); // RVA: 0x1022B9C7C
}

public class CustomScoreboardCollectableLayout : CustomScoreboardCarouselLayout // Size: 0x3E4
{
	CustomScoreboardsViewListEntry _userEntryView; // 0x3C0 (size: 0x8)
	MCLayout _rewardsLayout; // 0x3C8 (size: 0x8)
	bool _isPending; // 0x3D0 (size: 0x1)
	EventBus _bus; // 0x3D8 (size: 0x8)
	ScreenInput _screenInput; // 0x3E0 (size: 0x4)

	static NSObject layoutWithScoreboard:parameters:(); // RVA: 0x10222D08C
	NSObject init(); // RVA: 0x10222D198
	void didLoadFromCCB:(); // RVA: 0x10222D1E0
	bool requestInfo(); // RVA: 0x10222D3DC
	void onInfoReceived:(); // RVA: 0x10222D440
	void collectRewards(); // RVA: 0x10222D44C
	void wait(); // RVA: 0x10222D484
	void done(); // RVA: 0x10222D4C0
	void tryLater(); // RVA: 0x10222D518
	void tryLaterFinished(); // RVA: 0x10222D578
	void collectPressed(); // RVA: 0x10222D598
	void okPressed(); // RVA: 0x10222D5CC
	bool isPending(); // RVA: 0x10222D600
	void .cxx_destruct(); // RVA: 0x10222D610
	NSObject .cxx_construct(); // RVA: 0x10222D650
}

public class CustomScoreboardLayout : CCNodeRGBA // Size: 0x3DC
{
	CustomScoreboardsViewList _view; // 0x3A8 (size: 0x8)
	LoadingWidget _loadingWidget; // 0x3B0 (size: 0x8)
	MCLabelTTF _errorMessage; // 0x3B8 (size: 0x8)
	Reference _scoreboard; // 0x3C0 (size: 0x8)
	int _state; // 0x3C8 (size: 0x4)
	EventBus _bus; // 0x3D0 (size: 0x8)
	ScreenInput _screenInput; // 0x3D8 (size: 0x4)

	void didLoadFromCCBAfterChildren:(); // RVA: 0x1022F47D8
	void visit(); // RVA: 0x1022F494C
	void requestInfo(); // RVA: 0x1022F49D8
	void onInfoReceived:(); // RVA: 0x1022F4A40
	void onScoreboardUpdated(); // RVA: 0x1022F4C04
	void showParticipationResult(); // RVA: 0x1022F4C68
	void collectParticipationRewards(); // RVA: 0x1022F4E84
	void .cxx_destruct(); // RVA: 0x1022F4ED0
	NSObject .cxx_construct(); // RVA: 0x1022F4F10
}

public class CustomScoreboardLayoutLudo : CustomScoreboardLayout // Size: 0x3DC
{
	void didLoadFromCCB:(); // RVA: 0x10028AF00
}

public class CustomScoreboardOverviewNode : CCNodeRGBA // Size: 0x508
{
	MCLabelTTF _remainingTimeLabel; // 0x3A8 (size: 0x8)
	<CustomScoreboardsViewProtocol> _progressView; // 0x3B0 (size: 0x8)
	NodeController _controller; // 0x3B8 (size: 0x140)
	EventBus _bus; // 0x4F8 (size: 0x8)
	Reference _scoreboard; // 0x500 (size: 0x8)

	const scoreboard { get; set; } // property

	void didLoadFromCCB:(); // RVA: 0x1021AC8C8
	void onEnter(); // RVA: 0x1021AC958
	void onExit(); // RVA: 0x1021AC9D8
	const scoreboard(); // RVA: 0x1021ACA28
	void registerStates(); // RVA: 0x1021ACA38
	void preloadState(); // RVA: 0x1021ACE90
	void validateState(); // RVA: 0x1021ACF24
	basic_string<char, std::char_traits<char>, std::allocator<char>> discoverStateName(); // RVA: 0x1021ACFA8
	void refresh(); // RVA: 0x1021AD05C
	void updateRemainingTime(); // RVA: 0x1021AD160
	void .cxx_destruct(); // RVA: 0x1021AD1E4
	NSObject .cxx_construct(); // RVA: 0x1021AD220
}

public class CustomScoreboardPopup : MenuPopup // Size: 0x470
{
	static basic_string<char, std::char_traits<char>, std::allocator<char>> getParameterizedScoreboardId(); // RVA: 0x102156A74
	static NSObject getCCBName(); // RVA: 0x102156AC0
	static void getCCBParameters:didLoadData:(); // RVA: 0x102156ACC
	float enterAnimation(); // RVA: 0x102156C4C
	float leaveAnimation(); // RVA: 0x102156C50
	void backButtonCallback(); // RVA: 0x102156C54
}

public class CustomScoreboardRewardNode : CCNodeRGBA // Size: 0x3D8
{
	CCNodeRGBA _productContainer; // 0x3A8 (size: 0x8)
	MCMenuItemNodeRGBAStatic _infoButton; // 0x3B0 (size: 0x8)
	function<void ()> _infoCallback; // 0x3B8 (size: 0x20)

	void didLoadFromCCBAfterChildren:(); // RVA: 0x102330144
	void infoButtonPressed(); // RVA: 0x102330458
	void .cxx_destruct(); // RVA: 0x10233047C
	NSObject .cxx_construct(); // RVA: 0x1023304B4
}

public class CustomScoreboardRewardPrizeNode : CCNodeRGBA // Size: 0x3E0
{
	MCFramedSprite _tintableBackground; // 0x3A8 (size: 0x8)
	CCNodeRGBA _productContainer; // 0x3B0 (size: 0x8)
	MCLabelTTF _amountLabel; // 0x3B8 (size: 0x8)
	MCMenuItemNodeRGBAStatic _infoButton; // 0x3C0 (size: 0x8)
	basic_string<char, std::char_traits<char>, std::allocator<char>> _productId; // 0x3C8 (size: 0x18)

	static NSObject nodeWithProductInfo:scaledDown:(); // RVA: 0x1023309DC
	void setupWithProductInfo:(); // RVA: 0x102330A38
	void infoButtonPressed(); // RVA: 0x102330BD4
	void .cxx_destruct(); // RVA: 0x102330BF0
	NSObject .cxx_construct(); // RVA: 0x102330C10
}

public class CustomScoreboardSelectorButton : CustomEventSelectorButton // Size: 0x510
{
	Reference _scoreboard; // 0x500 (size: 0x8)
	EventBus _bus; // 0x508 (size: 0x8)

	NSObject init(); // RVA: 0x102148B98
	void setTag:(); // RVA: 0x102148BFC
	long tag(); // RVA: 0x102148C00
	bool isHighlighted(); // RVA: 0x102148C08
	void didLoadFromCCB:(); // RVA: 0x102148C1C
	void .cxx_destruct(); // RVA: 0x102148C9C
	NSObject .cxx_construct(); // RVA: 0x102148CC0
}

public class CustomScoreboardSelectorContent : CustomEventSelectorContent // Size: 0x3D0
{
	CCNodeRGBA _contentView; // 0x3B0 (size: 0x8)
	CCNodeRGBA _teaserView; // 0x3B8 (size: 0x8)
	Reference _scoreboard; // 0x3C0 (size: 0x8)
	EventBus _bus; // 0x3C8 (size: 0x8)

	void setTag:(); // RVA: 0x1020ACF84
	long tag(); // RVA: 0x1020ACF88
	void setVisible:(); // RVA: 0x1020ACF90
	void didLoadFromCCBAfterChildren:(); // RVA: 0x1020AD008
	void updateVisibility(); // RVA: 0x1020AD0AC
	void .cxx_destruct(); // RVA: 0x1020AD158
	NSObject .cxx_construct(); // RVA: 0x1020AD17C
}

public class CustomScoreboardViewListRankSurpass : CCNodeRGBA // Size: 0x3C0
{
	CCNodeRGBA _surpassingContainer; // 0x3A8 (size: 0x8)
	CCNodeRGBA _surpassedContainer; // 0x3B0 (size: 0x8)
	NSString _customEntryViewCCB; // 0x3B8 (size: 0x8)

	_ccColorThreeB color { get; set; } // property
	_ccColorThreeB displayedColor { get; set; } // property
	bool cascadeColorEnabled { get; set; } // property
	byte opacity { get; set; } // property
	byte displayedOpacity { get; set; } // property
	bool cascadeOpacityEnabled { get; set; } // property
	ulong hash { get; set; } // property
	Class superclass { get; set; } // property
	NSString description { get; set; } // property
	NSString debugDescription { get; set; } // property

	void dealloc(); // RVA: 0x1022C6718
	void setupEntries:(); // RVA: 0x1022C6768
	void updateEntries:callback:(); // RVA: 0x1022C6770
	void fillEntriesWithScoreboard:showScores:(); // RVA: 0x1022C695C
	void addEntry:scoreboard:parameters:container:(); // RVA: 0x1022C6BB0
}

public class CustomScoreboardsCarouselPopup : MenuPopup // Size: 0x4A8
{
	RewardsScrollList _scoreboardsList; // 0x470 (size: 0x8)
	SkinRadioButtonGroup _buttonsGroup; // 0x478 (size: 0x8)
	CCNodeRGBA _navigationContainer; // 0x480 (size: 0x8)
	MCMenuItemNodeRGBAStatic _previousNavigationButton; // 0x488 (size: 0x8)
	MCMenuItemNodeRGBAStatic _nextNavigationButton; // 0x490 (size: 0x8)
	int _focusedLayoutTag; // 0x498 (size: 0x4)
	CustomScoreboardCarouselLayout _snappedLayout; // 0x4A0 (size: 0x8)

	static bool canBeStacked(); // RVA: 0x1021624CC
	static NSObject getCCBName(); // RVA: 0x102162520
	static void queueWithScoreboard:(); // RVA: 0x10216252C
	NSObject init(); // RVA: 0x10216261C
	void onEnter(); // RVA: 0x102162660
	void enterFromStack(); // RVA: 0x1021626D8
	void loadScoreboards(); // RVA: 0x102162720
	void logScoreboardWithId:(); // RVA: 0x1021629F4
	void backButtonCallbackImpl(); // RVA: 0x102162A64
	void previousPressed(); // RVA: 0x102162A68
	void nextPressed(); // RVA: 0x102162AB0
	void updateNavigationButtons(); // RVA: 0x102162AF8
	void leaveIfNoPendings(); // RVA: 0x102162B94
	void setupOverlayConfig(); // RVA: 0x102162CA4
}

public class CustomScoreboardsCountdownTimerNode : CountdownTimerNode // Size: 0x3C1
{
	void didLoadFromCCB:(); // RVA: 0x1022214E8
}

public class CustomScoreboardsRankNode : CCNodeRGBA // Size: 0x3B0
{
	MCLabelTTF _rankLabel; // 0x3A8 (size: 0x8)

	static NSObject nodeWithRank:ccbi:(); // RVA: 0x10212C5B4
	void setupRankLabel:(); // RVA: 0x10212C630
}

public class CustomScoreboardsViewEmpty : CCNodeRGBA // Size: 0x3B8
{
	MCLabelTTF _availableScoreboardMessage; // 0x3A8 (size: 0x8)
	MCLabelTTF _unavailableScoreboardMessage; // 0x3B0 (size: 0x8)

	void didLoadFromCCBAfterChildren:(); // RVA: 0x1021DAEDC
}

public class CustomScoreboardsViewEntry : CCNodeRGBA // Size: 0x3D8
{
	PlayerAvatarNode _playerAvatar; // 0x3A8 (size: 0x8)
	PlayerNameNode _playerName; // 0x3B0 (size: 0x8)
	MCLabelTTF _pointsLabel; // 0x3B8 (size: 0x8)
	CCNodeRGBA _rankHolder; // 0x3C0 (size: 0x8)
	MCLabelTTF _rankLabel; // 0x3C8 (size: 0x8)
	StarNode _starNode; // 0x3D0 (size: 0x8)

	void setupWithEntry:scoreboard:(); // RVA: 0x102093AA0
}

public class CustomScoreboardsViewList : CCNodeRGBA // Size: 0x3B0
{
	MCScrollList _list; // 0x3A8 (size: 0x8)

	_ccColorThreeB color { get; set; } // property
	_ccColorThreeB displayedColor { get; set; } // property
	bool cascadeColorEnabled { get; set; } // property
	byte opacity { get; set; } // property
	byte displayedOpacity { get; set; } // property
	bool cascadeOpacityEnabled { get; set; } // property
	ulong hash { get; set; } // property
	Class superclass { get; set; } // property
	NSString description { get; set; } // property
	NSString debugDescription { get; set; } // property

	void onEnter(); // RVA: 0x1021E45E4
	void setupEntries:(); // RVA: 0x1021E4638
	void updateEntries:callback:(); // RVA: 0x1021E4640
	void fillEntriesWithScoreboard:showScores:(); // RVA: 0x1021E46B0
}

public class CustomScoreboardsViewListEntry : CustomScoreboardsViewEntry // Size: 0x3E0
{
	CCNodeRGBA _productContainer; // 0x3D8 (size: 0x8)

	void setupWithEntry:scoreboard:(); // RVA: 0x10215D694
	void setupRankWithEntry:(); // RVA: 0x10215D6E4
	void setupRewardNodeWithBundleId:(); // RVA: 0x10215D72C
	void setEnabled:(); // RVA: 0x10215D768
}

public class CustomScoreboardsViewListEntryRank : CustomScoreboardsRankNode // Size: 0x3B0
{
}

public class CustomScoreboardsViewListTopPeek : CCNodeRGBA // Size: 0x3B0
{
	MCLayout _list; // 0x3A8 (size: 0x8)

	_ccColorThreeB color { get; set; } // property
	_ccColorThreeB displayedColor { get; set; } // property
	bool cascadeColorEnabled { get; set; } // property
	byte opacity { get; set; } // property
	byte displayedOpacity { get; set; } // property
	bool cascadeOpacityEnabled { get; set; } // property
	ulong hash { get; set; } // property
	Class superclass { get; set; } // property
	NSString description { get; set; } // property
	NSString debugDescription { get; set; } // property

	void setupEntries:(); // RVA: 0x10217977C
	void updateEntries:callback:(); // RVA: 0x102179784
	void fillEntriesWithScoreboard:showScores:(); // RVA: 0x1021797F4
	void addEntry:scoreboard:parameters:(); // RVA: 0x102179AEC
}

public class CustomScoreboardsViewListUnlock : CustomScoreboardsViewList // Size: 0x3C0
{
	CCNodeRGBA _scoreboardContent; // 0x3B0 (size: 0x8)
	CCNodeRGBA _emptyContent; // 0x3B8 (size: 0x8)

	void onEnter(); // RVA: 0x1021E1B40
	void setupEntries:(); // RVA: 0x1021E1BA8
	void updateEntries:callback:(); // RVA: 0x1021E1C18
}

public class CustomScoreboardsViewProgressRank : CustomScoreboardsViewListEntry // Size: 0x3E0
{
	_ccColorThreeB color { get; set; } // property
	_ccColorThreeB displayedColor { get; set; } // property
	bool cascadeColorEnabled { get; set; } // property
	byte opacity { get; set; } // property
	byte displayedOpacity { get; set; } // property
	bool cascadeOpacityEnabled { get; set; } // property
	ulong hash { get; set; } // property
	Class superclass { get; set; } // property
	NSString description { get; set; } // property
	NSString debugDescription { get; set; } // property

	void setupEntries:(); // RVA: 0x1020E7E6C
	void updateEntries:callback:(); // RVA: 0x1020E7E70
	void setupWithScoreboard:(); // RVA: 0x1020E7EAC
}

public class CustomScoreboardsViewProgressScore : CCNodeRGBA // Size: 0x3B0
{
	ProgressNode _progressNode; // 0x3A8 (size: 0x8)

	_ccColorThreeB color { get; set; } // property
	_ccColorThreeB displayedColor { get; set; } // property
	bool cascadeColorEnabled { get; set; } // property
	byte opacity { get; set; } // property
	byte displayedOpacity { get; set; } // property
	bool cascadeOpacityEnabled { get; set; } // property
	ulong hash { get; set; } // property
	Class superclass { get; set; } // property
	NSString description { get; set; } // property
	NSString debugDescription { get; set; } // property

	void setupEntries:(); // RVA: 0x10232F0C8
	void updateEntries:callback:(); // RVA: 0x10232F0EC
}

public class CustomScoreboardsViewRace : CCNodeRGBA // Size: 0x3E0
{
	MCScrollList _entries; // 0x3A8 (size: 0x8)
	unordered_map<std::string, CustomScoreboardsViewRaceEntry *, std::hash<std::string>, std::equal_to<std::string>, std::allocator<std::pair<const std::string, CustomScoreboardsViewRaceEntry *>>> _usersViews; // 0x3B0 (size: 0x28)
	ulong _updatingCounter; // 0x3D8 (size: 0x8)

	_ccColorThreeB color { get; set; } // property
	_ccColorThreeB displayedColor { get; set; } // property
	bool cascadeColorEnabled { get; set; } // property
	byte opacity { get; set; } // property
	byte displayedOpacity { get; set; } // property
	bool cascadeOpacityEnabled { get; set; } // property
	ulong hash { get; set; } // property
	Class superclass { get; set; } // property
	NSString description { get; set; } // property
	NSString debugDescription { get; set; } // property

	void setupEntries:(); // RVA: 0x10212D9C0
	void updateEntries:callback:(); // RVA: 0x10212D9C8
	void fillEntriesWithScoreboard:showScores:(); // RVA: 0x10212DD28
	void .cxx_destruct(); // RVA: 0x10212E2C4
	NSObject .cxx_construct(); // RVA: 0x10212E2D4
}

public class CustomScoreboardsViewRaceEntry : CustomScoreboardsViewEntry // Size: 0x41C
{
	CCNodeRGBA _racerNode; // 0x3D8 (size: 0x8)
	MCSpineNode _racerSpine; // 0x3E0 (size: 0x8)
	CCNodeRGBA _scoreMeterNode; // 0x3E8 (size: 0x8)
	MCLabelTTF _scoreMeterLabel; // 0x3F0 (size: 0x8)
	long _targetScore; // 0x3F8 (size: 0x8)
	float _racerSpeed; // 0x400 (size: 0x4)
	Reference _entry; // 0x408 (size: 0x8)
	unique_ptr<CustomScoreboardRacerDelegate, std::default_delete<CustomScoreboardRacerDelegate>> _racerDelegate; // 0x410 (size: 0x8)
	float _racerMoveUnitDuration; // 0x418 (size: 0x4)

	void setupWithEntry:scoreboard:(); // RVA: 0x1022D03DC
	void updateWithEntry:callback:(); // RVA: 0x1022D06BC
	void setupRank(); // RVA: 0x1022D081C
	void finishRace(); // RVA: 0x1022D0890
	void setRacerPosition:(); // RVA: 0x1022D097C
	void updateScoreMeter(); // RVA: 0x1022D09F0
	void moveRacerToPosition:callback:(); // RVA: 0x1022D0A58
	void .cxx_destruct(); // RVA: 0x1022D0CFC
	NSObject .cxx_construct(); // RVA: 0x1022D0D24
}

public class EquipmentCardPocketEffect : EquipmentCard // Size: 0x510
{
	shared_ptr<const configuration::PocketEffectEntity> _pocketEffect; // 0x4A0 (size: 0x10)
	MCAutoScalableSprite _image; // 0x4B0 (size: 0x8)
	MCAutoScalableSprite _tableBackground; // 0x4B8 (size: 0x8)
	MCLabelTTF _acquisitionSourceLabel; // 0x4C0 (size: 0x8)
	CCNodeRGBA _getItDescriptionNode; // 0x4C8 (size: 0x8)
	TimeLimitedProductTimer _expirationTimer; // 0x4D0 (size: 0x8)
	CCNodeRGBA _lockedDescriptionNode; // 0x4D8 (size: 0x8)
	CCSprite _lockIcon; // 0x4E0 (size: 0x8)
	CCSprite _rvIcon; // 0x4E8 (size: 0x8)
	bool _hasPromoAssociated; // 0x4F0 (size: 0x1)
	basic_string<char, std::char_traits<char>, std::allocator<char>> _promoId; // 0x4F8 (size: 0x18)

	basic_string<cha promoId { get; set; } // property
	bool hasPromoAssociated { get; set; } // property

	NSObject init(); // RVA: 0x1001ECC34
	void setPocketEffect:level:(); // RVA: 0x1001ECCDC
	void setImage:(); // RVA: 0x1001ECE64
	void refresh(); // RVA: 0x1001ECE98
	void setLocked:(); // RVA: 0x1001ECE9C
	const getRarity(); // RVA: 0x1001ED098
	basic_string<char, std::char_traits<char>, std::allocator<char>> promoId(); // RVA: 0x1001ED0A0
	bool hasPromoAssociated(); // RVA: 0x1001ED0D4
	void .cxx_destruct(); // RVA: 0x1001ED0E4
	NSObject .cxx_construct(); // RVA: 0x1001ED128
}

public class EquipmentCardPuck : EquipmentCard // Size: 0x4D8
{
	basic_string<char, std::char_traits<char>, std::allocator<char>> _puckId; // 0x4A0 (size: 0x18)
	CGPoint _originalInnerNodePosition; // 0x4B8 (size: 0x10)
	const _puck; // 0x4C8 (size: 0x8)
	CCSprite _staticGlow; // 0x4D0 (size: 0x8)

	NSObject init(); // RVA: 0x100105D70
	void resetState(); // RVA: 0x100105E04
	void refresh(); // RVA: 0x100105E7C
	bool showRotatingGlowIfEligible(); // RVA: 0x100105EBC
	void setPuck:(); // RVA: 0x1001061B4
	void setLevel:current:max:(); // RVA: 0x100106550
	bool showBarMaxLevel(); // RVA: 0x1001065C8
	int getMaxLevel(); // RVA: 0x1001065D0
	void levelChangeCallback(); // RVA: 0x1001065D8
	void barAnimationEnded(); // RVA: 0x10010687C
	const getRarity(); // RVA: 0x1001068C0
	void .cxx_destruct(); // RVA: 0x1001068D4
	NSObject .cxx_construct(); // RVA: 0x1001068F4
}

public class EquipmentCardStriker : EquipmentCard // Size: 0x528
{
	CCBAnimationManager _animationManager; // 0x4A0 (size: 0x8)
	CCNodeRGBA _imageContainer; // 0x4A8 (size: 0x8)
	CCNodeRGBA _powerContainer; // 0x4B0 (size: 0x8)
	CCNodeRGBA _aimContainer; // 0x4B8 (size: 0x8)
	CCNodeRGBA _timeContainer; // 0x4C0 (size: 0x8)
	CCNodeRGBA _pointsContainer; // 0x4C8 (size: 0x8)
	MCLabelTTF _pointsLabel; // 0x4D0 (size: 0x8)
	CCSprite _pointsIcon; // 0x4D8 (size: 0x8)
	MCLayout _upgradeWithCoinsInfo; // 0x4E0 (size: 0x8)
	MCLayout _upgradeWithTokensInfo; // 0x4E8 (size: 0x8)
	StrikerPowerBar _powerBar; // 0x4F0 (size: 0x8)
	StrikerPowerBar _timeBar; // 0x4F8 (size: 0x8)
	StrikerPowerBar _aimBar; // 0x500 (size: 0x8)
	bool _pendingPowerUpgrade; // 0x508 (size: 0x1)
	bool _pendingTimeUpgrade; // 0x509 (size: 0x1)
	bool _pendingAimUpgrade; // 0x50A (size: 0x1)
	bool _strikerRotationAnimationActive; // 0x50B (size: 0x1)
	CCSprite _staticGlow; // 0x510 (size: 0x8)
	int _maxLevel; // 0x518 (size: 0x4)
	IntPtr _striker; // 0x520 (size: 0x8)

	ulong hash { get; set; } // property
	Class superclass { get; set; } // property
	NSString description { get; set; } // property
	NSString debugDescription { get; set; } // property

	NSObject init(); // RVA: 0x10006E908
	void resetState(); // RVA: 0x10006EAE8
	int getMaxLevel(); // RVA: 0x10006EB78
	void setLocked:(); // RVA: 0x10006EB88
	bool showRotatingGlowIfEligible(); // RVA: 0x10006EC08
	void setStriker:withBuff:(); // RVA: 0x10006EEFC
	void setStriker:(); // RVA: 0x10006F4C0
	void refresh(); // RVA: 0x10006F4C8
	void levelChangeCallback(); // RVA: 0x10006F510
	void onShowUpgradeButton(); // RVA: 0x10006F670
	void barAnimationEnded(); // RVA: 0x10006F90C
	void upgradeButtonPressed(); // RVA: 0x10006F950
	void disableUpgradeButton(); // RVA: 0x10006FB94
	void enableUpgradeButton(); // RVA: 0x10006FBCC
	void upgradeAnimationEnded(); // RVA: 0x10006FC00
	void informBuffPointsStreamAnimationReady(); // RVA: 0x10006FC58
	const getRarity(); // RVA: 0x10006FF24
	void completedAnimationSequenceNamed:(); // RVA: 0x10006FF48
	void setupRotationAnimation(); // RVA: 0x10006FFC0
	void runRotationAnimation(); // RVA: 0x1000700B8
	void showUpgradePoints(); // RVA: 0x1000700F0
	void showUpgradeAnimation(); // RVA: 0x100070148
}

public class EquipmentCardStrikerTrail : EquipmentCard // Size: 0x4D8
{
	basic_string<char, std::char_traits<char>, std::allocator<char>> _trailId; // 0x4A0 (size: 0x18)
	shared_ptr<configuration::StrikerTrailEntity> _strikerTrailEntity; // 0x4B8 (size: 0x10)
	MCAutoScalableSprite _image; // 0x4C8 (size: 0x8)
	TimeLimitedProductTimer _expirationTimer; // 0x4D0 (size: 0x8)

	NSObject init(); // RVA: 0x10013CBF4
	void setStrikerTrail:level:(); // RVA: 0x10013CC9C
	void setImage:(); // RVA: 0x10013CDCC
	void resetState(); // RVA: 0x10013CE00
	void refresh(); // RVA: 0x10013CE54
	const getRarity(); // RVA: 0x10013CE58
	void .cxx_destruct(); // RVA: 0x10013CE60
	NSObject .cxx_construct(); // RVA: 0x10013CEB0
}

public class EquipmentListPocketEffectItem : EquipmentListItem // Size: 0x3E4
{
	<EquipmentTabPocketEffectDelegate> _delegate; // 0x3A8 (size: 0x8)
	shared_ptr<const configuration::PocketEffectEntity> _pocketEffect; // 0x3B0 (size: 0x10)
	EquipmentCardPocketEffect _card; // 0x3C0 (size: 0x8)
	basic_string<char, std::char_traits<char>, std::allocator<char>> _pocketEffectId; // 0x3C8 (size: 0x18)
	bool _wasDisplayed; // 0x3E0 (size: 0x1)
	bool _isEquipped; // 0x3E1 (size: 0x1)
	bool _isOwned; // 0x3E2 (size: 0x1)
	bool _isNew; // 0x3E3 (size: 0x1)

	static NSObject nodeWithPocketEffect:delegate:(); // RVA: 0x10007AF74
	static void cleanNodePool(); // RVA: 0x10007B594
	NSObject initWithPocketEffect:delegate:(); // RVA: 0x10007AFAC
	void onEnterVisibleArea(); // RVA: 0x10007B178
	void onExitVisibleArea(); // RVA: 0x10007B28C
	void cardPressed(); // RVA: 0x10007B2DC
	void setIsEquipped:(); // RVA: 0x10007B444
	basic_string<char, std::char_traits<char>, std::allocator<char>> getItemId(); // RVA: 0x10007B468
	void refresh(); // RVA: 0x10007B49C
	void enableInput(); // RVA: 0x10007B574
	void disableInput(); // RVA: 0x10007B584
	void .cxx_destruct(); // RVA: 0x10007B5A8
	NSObject .cxx_construct(); // RVA: 0x10007B5EC
}

public class EquipmentListPuckItem : EquipmentListItem // Size: 0x3BA
{
	EquipmentCardPuck _card; // 0x3A8 (size: 0x8)
	IntPtr _puckEntity; // 0x3B0 (size: 0x8)
	bool _isNew; // 0x3B8 (size: 0x1)
	bool _wasDisplayed; // 0x3B9 (size: 0x1)

	static void cleanNodePool(); // RVA: 0x100004644
	NSObject initWithPuckEntity:(); // RVA: 0x100004068
	void dealloc(); // RVA: 0x1000040EC
	void onEnterVisibleArea(); // RVA: 0x100004140
	void onExitVisibleArea(); // RVA: 0x1000042E0
	void refreshSelection(); // RVA: 0x100004344
	void cardPressed(); // RVA: 0x10000440C
	void disableInput(); // RVA: 0x1000045F0
	void enableInput(); // RVA: 0x100004600
	basic_string<char, std::char_traits<char>, std::allocator<char>> getItemId(); // RVA: 0x100004610
}

public class EquipmentListStrikerItem : EquipmentListItem // Size: 0x3C8
{
	EquipmentCardStriker _card; // 0x3A8 (size: 0x8)
	IntPtr _striker; // 0x3B0 (size: 0x8)
	bool _isNew; // 0x3B8 (size: 0x1)
	bool _wasDisplayed; // 0x3B9 (size: 0x1)
	EventBus _bus; // 0x3C0 (size: 0x8)

	static void cleanNodePool(); // RVA: 0x100098F18
	NSObject initWithUpgradeableStriker:(); // RVA: 0x1000988A8
	void dealloc(); // RVA: 0x100098958
	void onEnterVisibleArea(); // RVA: 0x1000989AC
	void onExitVisibleArea(); // RVA: 0x100098B84
	void refreshSelection(); // RVA: 0x100098BE8
	void cardPressed(); // RVA: 0x100098CB8
	void disableInput(); // RVA: 0x100098EA0
	void enableInput(); // RVA: 0x100098EB0
	basic_string<char, std::char_traits<char>, std::allocator<char>> getItemId(); // RVA: 0x100098EC0
	void .cxx_destruct(); // RVA: 0x100098F2C
	NSObject .cxx_construct(); // RVA: 0x100098F50
}

public class EquipmentListStrikerTrailItem : EquipmentListItem // Size: 0x3E8
{
	<EquipmentTabStrikerTrailsDelegate> _delegate; // 0x3A8 (size: 0x8)
	EquipmentCardStrikerTrail _card; // 0x3B0 (size: 0x8)
	shared_ptr<configuration::StrikerTrailEntity> _strikerTrailEntity; // 0x3B8 (size: 0x10)
	basic_string<char, std::char_traits<char>, std::allocator<char>> _trailId; // 0x3C8 (size: 0x18)
	bool _isNew; // 0x3E0 (size: 0x1)
	bool _wasDisplayed; // 0x3E1 (size: 0x1)
	bool _isEquipped; // 0x3E2 (size: 0x1)
	int _level; // 0x3E4 (size: 0x4)

	<EquipmentTabStrikerTrailsDelegate> delegate { get; set; } // property

	static NSObject nodeWithStrikerTrailEntity:delegate:(); // RVA: 0x1001ED264
	static void cleanNodePool(); // RVA: 0x1001ED7D8
	NSObject initWithStrikerTrailEntity:delegate:(); // RVA: 0x1001ED29C
	void setIsEquipped:(); // RVA: 0x1001ED48C
	void refresh(); // RVA: 0x1001ED4A8
	void onEnterVisibleArea(); // RVA: 0x1001ED57C
	void onExitVisibleArea(); // RVA: 0x1001ED690
	void cardPressed(); // RVA: 0x1001ED6E0
	void enableInput(); // RVA: 0x1001ED784
	void disableInput(); // RVA: 0x1001ED794
	basic_string<char, std::char_traits<char>, std::allocator<char>> getItemId(); // RVA: 0x1001ED7A4
	NSObject delegate(); // RVA: 0x1001ED7EC
	void .cxx_destruct(); // RVA: 0x1001ED7FC
	NSObject .cxx_construct(); // RVA: 0x1001ED840
}

public class EquipmentNodePuck : CCNodeRGBA // Size: 0x3A8
{
	NSObject initWithPuckId:(); // RVA: 0x1001E3C38
}

public class EquipmentNodeStriker : CCNodeRGBA // Size: 0x408
{
	StrikerVisual _strikerVisual; // 0x3A8 (size: 0x8)
	BuffNode _buffNode; // 0x3B0 (size: 0x8)
	MCLabelTTF _nameLabel; // 0x3B8 (size: 0x8)
	RarityNameNode _rarityNameNode; // 0x3C0 (size: 0x8)
	CCNodeRGBA _powerBarContainer; // 0x3C8 (size: 0x8)
	CCNodeRGBA _aimBarContainer; // 0x3D0 (size: 0x8)
	CCNodeRGBA _timeBarContainer; // 0x3D8 (size: 0x8)
	basic_string<char, std::char_traits<char>, std::allocator<char>> _buffId; // 0x3E0 (size: 0x18)
	MakeWeak _makeWeak; // 0x3F8 (size: 0x10)

	static NSObject nodeWithStrikerId:level:buffId:contentSize:(); // RVA: 0x100108064
	static NSObject nodeWithStrikerId:level:buffId:power:aim:time:contentSize:(); // RVA: 0x1001080FC
	void setStrikerWithId:level:buffId:power:aim:time:(); // RVA: 0x100108180
	NSObject createPowerBarWithTitle:parentNode:withPower:debugTagPrefix:(); // RVA: 0x100108470
	void guaranteeSameFontSizeOnBars:(); // RVA: 0x1001084F0
	void hideStriker(); // RVA: 0x10010858C
	void .cxx_destruct(); // RVA: 0x1001086B0
	NSObject .cxx_construct(); // RVA: 0x10010870C
}

public class EquipmentTabPocketEffect : EquipmentTab // Size: 0x3E0
{
	EquipmentListPocketEffectItem _selectedItem; // 0x3C0 (size: 0x8)
	PocketEffectInfoNode _infoNode; // 0x3C8 (size: 0x8)
	MakeWeak _makeWeak; // 0x3D0 (size: 0x10)

	ulong hash { get; set; } // property
	Class superclass { get; set; } // property
	NSString description { get; set; } // property
	NSString debugDescription { get; set; } // property

	static NSObject nodeWithSize:(); // RVA: 0x10003916C
	void didLoadFromCCBAfterChildren(); // RVA: 0x100039228
	void selectItem:(); // RVA: 0x100039570
	void setSelectedItem:(); // RVA: 0x100039660
	void .cxx_destruct(); // RVA: 0x1000396AC
	NSObject .cxx_construct(); // RVA: 0x1000396C8
}

public class EquipmentTabPucks : EquipmentTab // Size: 0x3C0
{
	static NSObject nodeWithSize:(); // RVA: 0x10026B0BC
}

public class EquipmentTabStrikerTrails : EquipmentTab // Size: 0x3E0
{
	EquipmentListStrikerTrailItem _selectedItem; // 0x3C0 (size: 0x8)
	StrikerTrailInfoNode _infoNode; // 0x3C8 (size: 0x8)
	MakeWeak _makeWeak; // 0x3D0 (size: 0x10)

	ulong hash { get; set; } // property
	Class superclass { get; set; } // property
	NSString description { get; set; } // property
	NSString debugDescription { get; set; } // property

	static NSObject nodeWithSize:(); // RVA: 0x100038464
	void didLoadFromCCBAfterChildren(); // RVA: 0x100038520
	void setVisible:(); // RVA: 0x100038868
	void selectItem:(); // RVA: 0x1000388C0
	void setSelectedItem:(); // RVA: 0x1000389B0
	void refreshEquippedStriker(); // RVA: 0x1000389FC
	void .cxx_destruct(); // RVA: 0x100038A0C
	NSObject .cxx_construct(); // RVA: 0x100038A28
}

public class EquipmentTabStrikers : EquipmentTab // Size: 0x419
{
	CCNodeRGBA _filterContainer; // 0x3C0 (size: 0x8)
	EquipmentFilterList _filterListNode; // 0x3C8 (size: 0x8)
	StrikerInfoNode _infoNode; // 0x3D0 (size: 0x8)
	vector<cfg::EquipmentFilterTypes::Row, std::allocator<cfg::EquipmentFilterTypes::Row>> _filterList; // 0x3D8 (size: 0x18)
	unordered_map<int, bool, std::hash<int>, std::equal_to<int>, std::allocator<std::pair<const int, bool>>> _filtersStatus; // 0x3F0 (size: 0x28)
	bool _isPreviewShown; // 0x418 (size: 0x1)

	static NSObject nodeWithSize:(); // RVA: 0x100100388
	void setupEquipmentListWithShopItemsCallback:cleanupCallback:equipmentListDebugTag:rowDebugTag:(); // RVA: 0x100100570
	void openFilterMenuPressed(); // RVA: 0x100100814
	void filterOptionPressed:(); // RVA: 0x1001008DC
	void reapplyFilters(); // RVA: 0x10010098C
	bool checkFilterType:filterRow:striker:(); // RVA: 0x100100DE8
	void updateEquipped(); // RVA: 0x100100EB4
	void refreshSelection(); // RVA: 0x1001010A4
	void .cxx_destruct(); // RVA: 0x1001010B8
	NSObject .cxx_construct(); // RVA: 0x100101104
}

public class EventsLobbyNodeCustomScoreboard : EventsLobbyNode // Size: 0x3E8
{
	CustomScoreboardOverviewNode _overviewNode; // 0x3E0 (size: 0x8)

	static NSObject nodeWithEventId:(); // RVA: 0x10230108C
	void didLoadFromCCBAfterChildren(); // RVA: 0x102301208
	void onNodePressedImpl(); // RVA: 0x102301268
}

public class FBAdQualityRule // Size: 0x20
{
	bool _continuous; // 0x8 (size: 0x1)
	float _viewableRatio; // 0xC (size: 0x4)
	NSObject _endCallback; // 0x10 (size: 0x8)
	double _viewableSeconds; // 0x18 (size: 0x8)

	bool continuous { get; set; } // property
	NSObject endCallback { get; set; } // property
	float viewableRatio { get; set; } // property
	double viewableSeconds { get; set; } // property

	static NSObject mrcRuleWithEndCallback:(); // RVA: 0x101A0D194
	static NSObject viewableImpressionRuleWithEndCallback:(); // RVA: 0x101A0D1B0
	static NSObject ruleWithViewableRatio:viewableSeconds:continuous:endCallback:(); // RVA: 0x101A0D1D4
	NSObject initWithViewableRatio:viewableSeconds:continuous:endCallback:(); // RVA: 0x101A0D234
	NSObject init(); // RVA: 0x101A0D2BC
	bool isContinuous(); // RVA: 0x101A0D2D8
	NSObject endCallback(); // RVA: 0x101A0D2E0
	float viewableRatio(); // RVA: 0x101A0D2E8
	double viewableSeconds(); // RVA: 0x101A0D2F0
	void .cxx_destruct(); // RVA: 0x101A0D2F8
}

public class FBSDKMACARuleMatchingManager // Size: 0x50
{
	void isEnable; // 0x8 (size: 0x1)
	void macaRules; // 0x10 (size: 0x8)
	void keys; // 0x18 (size: 0x8)
	void configuredDependencies; // 0x20 (size: 0x18)
	void defaultDependencies; // 0x38 (size: 0x18)

	void enable(); // RVA: 0x10057C168
	NSObject processParameters:event:(); // RVA: 0x10057DA0C
	NSObject init(); // RVA: 0x10057DC08
	void .cxx_destruct(); // RVA: 0x10057DC28
}

public class FBSDKSKAdNetworkCoarseCVRule // Size: 0x18
{
	NSString _coarseCvValue; // 0x8 (size: 0x8)
	NSArray _events; // 0x10 (size: 0x8)

	NSString coarseCvValue { get; set; } // property
	NSArray events { get; set; } // property

	NSObject initWithJSON:(); // RVA: 0x10052FD28
	bool isMatchedWithRecordedCoarseEvents:recordedCoarseValues:(); // RVA: 0x10052FEDC
	NSObject coarseCvValue(); // RVA: 0x100530258
	void setCoarseCvValue:(); // RVA: 0x100530260
	NSObject events(); // RVA: 0x10053026C
	void .cxx_destruct(); // RVA: 0x100530274
}

public class FBSDKSKAdNetworkLockWindowRule // Size: 0x28
{
	NSString _lockWindowType; // 0x8 (size: 0x8)
	long _time; // 0x10 (size: 0x8)
	NSArray _events; // 0x18 (size: 0x8)
	long _postbackSequenceIndex; // 0x20 (size: 0x8)

	NSString lockWindowType { get; set; } // property
	long time { get; set; } // property
	NSArray events { get; set; } // property
	long postbackSequenceIndex { get; set; } // property

	NSObject initWithJSON:(); // RVA: 0x1005318BC
	NSObject lockWindowType(); // RVA: 0x100531B44
	void setLockWindowType:(); // RVA: 0x100531B4C
	long time(); // RVA: 0x100531B58
	void setTime:(); // RVA: 0x100531B60
	NSObject events(); // RVA: 0x100531B68
	long postbackSequenceIndex(); // RVA: 0x100531B70
	void setPostbackSequenceIndex:(); // RVA: 0x100531B78
	void .cxx_destruct(); // RVA: 0x100531B80
}

public class FBSDKSKAdNetworkRule // Size: 0x18
{
	long _conversionValue; // 0x8 (size: 0x8)
	NSArray _events; // 0x10 (size: 0x8)

	long conversionValue { get; set; } // property
	NSArray events { get; set; } // property

	NSObject initWithJSON:(); // RVA: 0x1005360F4
	bool isMatchedWithRecordedEvents:recordedValues:(); // RVA: 0x100536280
	long conversionValue(); // RVA: 0x1005365FC
	void setConversionValue:(); // RVA: 0x100536604
	NSObject events(); // RVA: 0x10053660C
	void setEvents:(); // RVA: 0x100536614
	void .cxx_destruct(); // RVA: 0x10053661C
}

public class FBViewpointKeyboardTrackable // Size: 0x28
{
	CGRect _keyboardFrame; // 0x8 (size: 0x20)

	ulong hash { get; set; } // property
	Class superclass { get; set; } // property
	NSString description { get; set; } // property
	NSString debugDescription { get; set; } // property

	NSObject init(); // RVA: 0x101A44584
	void _keyboardWillShow:(); // RVA: 0x101A4464C
	void _keyboardDidHide:(); // RVA: 0x101A446D0
	CGPoint vp_bottomRightRelativeToWindow(); // RVA: 0x101A446E8
	CGRect vp_visibleRectRelativeToWindow(); // RVA: 0x101A44748
	long vp_level(); // RVA: 0x101A44754
	CGPoint vp_topLeftRelativeToWindow(); // RVA: 0x101A4475C
	double vp_totalArea(); // RVA: 0x101A447AC
	double vp_visibleAreaInViewport:(); // RVA: 0x101A447F0
	bool vp_shouldTrack(); // RVA: 0x101A447FC
	NSObject vp_occlusiondetection_parent(); // RVA: 0x101A44814
	NSObject vp_occlusiondetection_children(); // RVA: 0x101A4481C
	bool vp_occlusiondetection_isOpaque(); // RVA: 0x101A44824
	bool vp_shouldOccludeTrackablesBelow(); // RVA: 0x101A4482C
	NSObject vp_parentTrackable(); // RVA: 0x101A44834
	NSObject vp_childTrackables(); // RVA: 0x101A44860
}

public class GADPatternMatchingFlagCache // Size: 0x18
{
	NSArray _patternMatchingRules; // 0x8 (size: 0x8)
	NSArray _preprocessingRules; // 0x10 (size: 0x8)

	NSArray patternMatchingRules { get; set; } // property
	NSArray preprocessingRules { get; set; } // property

	static NSObject sharedInstance(); // RVA: 0x100A37C90
	void updatePatternMatchingRules(); // RVA: 0x100A37D00
	NSObject patternMatchingRules(); // RVA: 0x100A37DD8
	NSObject preprocessingRules(); // RVA: 0x100A37E84
	void .cxx_destruct(); // RVA: 0x100A37F30
}

public class GameMenuMatchPlayerNode : MenuMatchPlayerNode // Size: 0x490
{
	CCNodeRGBA _clubContainer; // 0x478 (size: 0x8)
	MCFramedSprite _clubBackground; // 0x480 (size: 0x8)
	ClubBasicInfo _clubBasicInfo; // 0x488 (size: 0x8)

	static NSObject playerNode(); // RVA: 0x10019533C
	void setupWithPlayerInfo:(); // RVA: 0x100195350
	void setupWithPlayerInfo:isLeftSide:(); // RVA: 0x100195554
	void showClubInfo(); // RVA: 0x100195634
	void hideClubInfo(); // RVA: 0x100195694
	void setClubName:avatarId:(); // RVA: 0x1001956A8
}

public class GameMenuMatchResults : MenuMatchResults // Size: 0x720
{
	void setupWithParameters:(); // RVA: 0x10013F570
	void startMatchEnding(); // RVA: 0x10013F6D4
	void applyPositionLabelVisibilityFor:withPosition:(); // RVA: 0x10013F760
	void showExtraRewardList(); // RVA: 0x10013F770
	void updateOpponentNodeWithInfo:opponentNode:isLeftSide:(); // RVA: 0x10013F908
}

public class GameplayHudStrikerBar : CCLayerRGBA // Size: 0x500
{
	StrikerBarDelegate _delegate; // 0x3B8 (size: 0xC0)
	CCNodeRGBA _backgroundSprite; // 0x478 (size: 0x8)
	CCNode _strikerNode; // 0x480 (size: 0x8)
	CCSprite _glow; // 0x488 (size: 0x8)
	map<float, CGPoint, std::less<float>, std::allocator<std::pair<const float, CGPoint>>> _storedTouchesMoved; // 0x490 (size: 0x18)
	double _baselineWidth; // 0x4A8 (size: 0x8)
	float _leftEdge; // 0x4B0 (size: 0x4)
	float _rightEdge; // 0x4B4 (size: 0x4)
	float _inputMargin; // 0x4B8 (size: 0x4)
	bool _hasMadeAMove; // 0x4BC (size: 0x1)
	bool _hasMovedEnough; // 0x4BD (size: 0x1)
	bool _inputOngoing; // 0x4BE (size: 0x1)
	bool _inputEnabled; // 0x4BF (size: 0x1)
	float _barAlpha; // 0x4C0 (size: 0x4)
	float _inputTime; // 0x4C4 (size: 0x4)
	CGPoint _storedTouchesBegan; // 0x4C8 (size: 0x10)
	float _initialOffset; // 0x4D8 (size: 0x4)
	MCTouch _referenceTouch; // 0x4E0 (size: 0x8)
	vector<MCTouch *, std::allocator<MCTouch *>> _filteredCurrentTouches; // 0x4E8 (size: 0x18)

	bool isInputEnabled { get; set; } // property

	NSObject init(); // RVA: 0x100119110
	NSObject initWithFieldEntity:striker:delegate:(); // RVA: 0x100119400
	void dealloc(); // RVA: 0x100119668
	void setupWithFieldEntity:striker:delegate:(); // RVA: 0x1001196E4
	void setupWithFieldEntity:striker:(); // RVA: 0x100119758
	void setDelegate:(); // RVA: 0x1001199AC
	void disableInput(); // RVA: 0x1001199C0
	void enableInput(); // RVA: 0x1001199D0
	void setSliderSizeWithTable:(); // RVA: 0x1001199F4
	void ccTouchesBegan:(); // RVA: 0x100119A70
	void ccTouchesMoved:(); // RVA: 0x100119F54
	void touchesMoved:store:touchEnd:(); // RVA: 0x100119F9C
	void ccTouchesEnded:(); // RVA: 0x10011A180
	void ccTouchesCancelled:(); // RVA: 0x10011A484
	void update:(); // RVA: 0x10011A648
	NSObject filterReferenceTouch:(); // RVA: 0x10011A7C4
	CGPoint touchToScreenPoint:(); // RVA: 0x10011A8C0
	bool isInsideBar:(); // RVA: 0x10011A900
	void startGlow(); // RVA: 0x10011A9F0
	void stopGlow(); // RVA: 0x10011AAD0
	CGSize contentSize(); // RVA: 0x10011AB44
	bool inputOngoing(); // RVA: 0x10011AB54
	bool isInputEnabled(); // RVA: 0x10011AB64
	void .cxx_destruct(); // RVA: 0x10011AB74
	NSObject .cxx_construct(); // RVA: 0x10011ACD8
}

public class GoldenShotScoreboardButton : MCMenuItemNodeRGBAStatic // Size: 0x4F8
{
	CountdownTimerNode _countdownTimerNode; // 0x4F0 (size: 0x8)

	void didLoadFromCCBAfterChildren(); // RVA: 0x10019D8FC
	void refresh(); // RVA: 0x10019D944
}

public class GoldenShotScoreboardInfoHeader : CCNodeRGBA // Size: 0x3A8
{
	void didLoadFromCCB:(); // RVA: 0x100283280
	void infoButtonPressed(); // RVA: 0x1002832B4
}

public class GoldenShotScoreboardInfoPopup : MenuPopup // Size: 0x470
{
	static NSObject getCCBName(); // RVA: 0x10016BF28
}

public class GoldenShotScoreboardResultsPopup : MenuPopup // Size: 0x470
{
	static NSObject getCCBName(); // RVA: 0x100052D2C
	static void getCCBParameters:didLoadData:parameters:(); // RVA: 0x100052D38
	void setupOverlayConfig(); // RVA: 0x100052DC0
}

public class Keyboard // Size: 0x100
{
	CustomUITextField_MCPlatform _textField; // 0x8 (size: 0x8)
	UIButton _textFieldBackgroundButton; // 0x10 (size: 0x8)
	UIButton _dismissButton; // 0x18 (size: 0x8)
	UIButton _confirmButton; // 0x20 (size: 0x8)
	bool _isVisible; // 0x28 (size: 0x1)
	bool _currentlyRotatingScreen; // 0x29 (size: 0x1)
	Configuration _configuration; // 0x30 (size: 0xD0)

	ulong hash { get; set; } // property
	Class superclass { get; set; } // property
	NSString description { get; set; } // property
	NSString debugDescription { get; set; } // property

	static NSObject instance(); // RVA: 0x1024B0048
	NSObject capString:ToLength:(); // RVA: 0x1024B0080
	bool showKeyboardWithConfiguration:(); // RVA: 0x1024B0354
	bool isVisible(); // RVA: 0x1024B0858
	bool close(); // RVA: 0x1024B0860
	void keyboardWillRotate:(); // RVA: 0x1024B0B0C
	void keyboardDidRotate:(); // RVA: 0x1024B0B18
	void keyboardWillChange:(); // RVA: 0x1024B0B20
	void animateInputBarToY:withDuration:andAnimationCurve:(); // RVA: 0x1024B0FC0
	void fadeDismissButtonToAlpha:withDuration:andAnimationCurve:(); // RVA: 0x1024B10E0
	NSObject text(); // RVA: 0x1024B1154
	bool setText:(); // RVA: 0x1024B1178
	bool clearText(); // RVA: 0x1024B138C
	uint caretPosition(); // RVA: 0x1024B1398
	bool setCaretPosition:(); // RVA: 0x1024B1408
	bool caretPositionChanged:(); // RVA: 0x1024B14B0
	void confirmButtonPressed:(); // RVA: 0x1024B16A4
	void dismissButtonPressed:(); // RVA: 0x1024B16DC
	bool textField:shouldChangeCharactersInRange:replacementString:(); // RVA: 0x1024B18BC
	void observeValueForKeyPath:ofObject:change:context:(); // RVA: 0x1024B1B4C
	bool textFieldShouldReturn:(); // RVA: 0x1024B1D5C
	bool textFieldShouldClear:(); // RVA: 0x1024B1DA4
	void textFieldDidBeginEditing:(); // RVA: 0x1024B1F98
	void textFieldDidEndEditing:(); // RVA: 0x1024B1FE4
	bool shouldCloseKeyboardWithCallbacks:(); // RVA: 0x1024B1FFC
	void callCallback:(); // RVA: 0x1024B23A0
	void callCallback:withDelay:(); // RVA: 0x1024B2474
	void .cxx_destruct(); // RVA: 0x1024B26D4
	NSObject .cxx_construct(); // RVA: 0x1024B27E4
}

public class LeaderboardsClubsTab : LeaderboardsGenericTab // Size: 0x4A8
{
	CCNodeRGBA _loadingCircle; // 0x440 (size: 0x8)
	MCLabelTTF _timerLabel; // 0x448 (size: 0x8)
	LeaderboardsPrizeBracket _prizeBracket1; // 0x450 (size: 0x8)
	LeaderboardsPrizeBracket _prizeBracket2; // 0x458 (size: 0x8)
	LeaderboardsPrizeBracket _prizeBracket3; // 0x460 (size: 0x8)
	LeaderboardsPrizeBracket _prizeBracket4; // 0x468 (size: 0x8)
	StringMap _clubLeagueBoard; // 0x470 (size: 0x28)
	MCTimer _endsInTimer; // 0x498 (size: 0x8)
	ulong _endTimestamp; // 0x4A0 (size: 0x8)

	static NSObject nodeWithSize:clubLeagueBoard:endTimestamp:(); // RVA: 0x10018C190
	void dealloc(); // RVA: 0x10018C1E4
	void setupWithClubLeagueBoard:endTimestamp:(); // RVA: 0x10018C23C
	void refresh(); // RVA: 0x10018C294
	void populateTable:(); // RVA: 0x10018C430
	void setupInfoNode:(); // RVA: 0x10018C614
	void updateTimer(); // RVA: 0x10018C87C
	void enableInput(); // RVA: 0x10018C90C
	void disableInput(); // RVA: 0x10018CA0C
	void lastWeekResultsButtonCallback(); // RVA: 0x10018CB0C
	void infoButtonCallback(); // RVA: 0x10018CBBC
	void .cxx_destruct(); // RVA: 0x10018CC0C
	NSObject .cxx_construct(); // RVA: 0x10018CC1C
}

public class LeaderboardsCompetitionResultsPopup : MenuPopup // Size: 0x4D0
{
	CCNodeRGBA _iconContainer; // 0x470 (size: 0x8)
	MCLabelTTF _leaderboardName; // 0x478 (size: 0x8)
	MCLabelTTF _winningsLabel; // 0x480 (size: 0x8)
	CCNodeRGBA _rankContainer; // 0x488 (size: 0x8)
	MCLabelTTF _prizeLabel; // 0x490 (size: 0x8)
	CCSprite _prizeGems; // 0x498 (size: 0x8)
	CCSprite _prizeCoins; // 0x4A0 (size: 0x8)
	CCNodeRGBA _particleContainer; // 0x4A8 (size: 0x8)
	PlayerAvatarNode _playerAvatar; // 0x4B0 (size: 0x8)
	StarNode _starNode; // 0x4B8 (size: 0x8)
	MCLabelTTF _youWonLabel; // 0x4C0 (size: 0x8)
	const _resultsInfo; // 0x4C8 (size: 0x8)

	static bool canBeShown(); // RVA: 0x10013EFF0
	NSObject initWithParameters:(); // RVA: 0x10013F03C
	float enter(); // RVA: 0x10013F0C8
	void loadResults(); // RVA: 0x10013F120
	void winnerGlowAnimation(); // RVA: 0x10013F3EC
	void fullResultsButtonCallback(); // RVA: 0x10013F448
}

public class LeaderboardsFriendsTab : LeaderboardsGenericTab // Size: 0x450
{
	SocialInviteCell _socialInviteCell; // 0x440 (size: 0x8)
	MCScrollList _challengeTable; // 0x448 (size: 0x8)

	static NSObject nodeWithSize:tryToShowAddFriendsButton:(); // RVA: 0x100041A20
	void setupTryToShowAddFriendsButton:(); // RVA: 0x100041A64
	void leave(); // RVA: 0x100041EF4
	void updateButtonsState(); // RVA: 0x100041F44
	void enableInput(); // RVA: 0x10004203C
	void disableInput(); // RVA: 0x100042154
	void scrollCallback(); // RVA: 0x10004226C
	vector<FriendInfo, std::allocator<FriendInfo>> getFriendsList(); // RVA: 0x1000422C4
}

public class LeaderboardsGenericInfoPopup : MenuPopup // Size: 0x470
{
	NSObject initWithParameters:(); // RVA: 0x1000094CC
}

public class LeaderboardsGenericPlayerNode : CCNodeRGBA // Size: 0x421
{
	MCFramedSprite _standardFrame; // 0x3A8 (size: 0x8)
	MCFramedSprite _highlightFrame; // 0x3B0 (size: 0x8)
	PlayerAvatarNode _playerAvatar; // 0x3B8 (size: 0x8)
	StarNode _starNode; // 0x3C0 (size: 0x8)
	CCNodeRGBA _rankContainer; // 0x3C8 (size: 0x8)
	PlayerNameNode _playerName; // 0x3D0 (size: 0x8)
	MCLabelTTF _winnings; // 0x3D8 (size: 0x8)
	CCNodeRGBA _flagContainer; // 0x3E0 (size: 0x8)
	MCLabelTTF _playerRank; // 0x3E8 (size: 0x8)
	CCMenu _itemMenu; // 0x3F0 (size: 0x8)
	CCNodeRGBA _clubContainer; // 0x3F8 (size: 0x8)
	ClubBasicInfo _clubBasicInfo; // 0x400 (size: 0x8)
	NSString _countryCode; // 0x408 (size: 0x8)
	int _rank; // 0x410 (size: 0x4)
	NSString _userId; // 0x418 (size: 0x8)
	bool _tryToShowAddFriendsButton; // 0x420 (size: 0x1)

	static NSObject nodeWithSize:(); // RVA: 0x1002556F0
	NSObject init(); // RVA: 0x100255708
	void dealloc(); // RVA: 0x100255774
	void setupWithPlayerEntry:(); // RVA: 0x1002557E4
	void setHighlight:(); // RVA: 0x100255C1C
	void setTryToShowAddFriendsButton:(); // RVA: 0x100255C5C
	void avatarPressed(); // RVA: 0x100255C6C
	void enableInput(); // RVA: 0x100255CEC
	void disableInput(); // RVA: 0x100255D00
}

public class LeaderboardsGenericTab : CCNodeRGBA // Size: 0x440
{
	LeaderboardsInfoNode _infoNode; // 0x3A8 (size: 0x8)
	LeaderboardsGenericTableItem _playerNodeTable; // 0x3B0 (size: 0x8)
	LeaderboardsGenericPlayerNode _playerNode; // 0x3B8 (size: 0x8)
	const _playerEntry; // 0x3C0 (size: 0x8)
	CGRect _bottomTableClipRect; // 0x3C8 (size: 0x20)
	CGRect _topTableClipRect; // 0x3E8 (size: 0x20)
	CGRect _originalTableClipRect; // 0x408 (size: 0x20)
	MCLabelTTF _emptyListLabel; // 0x428 (size: 0x8)
	MCScrollList _table; // 0x430 (size: 0x8)
	CCNodeRGBA _tableAreaNode; // 0x438 (size: 0x8)

	static NSObject nodeWithSize:leaderboardType:tryToShowAddFriendsButton:(); // RVA: 0x1000443B0
	NSObject init(); // RVA: 0x100044404
	void setupWithType:tryToShowAddFriendsButton:(); // RVA: 0x100044454
	void setupTable(); // RVA: 0x10004469C
	void leave(); // RVA: 0x100044774
	void enableInput(); // RVA: 0x100044874
	void disableInput(); // RVA: 0x100044970
	void scrollCallback(); // RVA: 0x100044A6C
	void positionPlayerNode(); // RVA: 0x100044A70
	void showTopPlayerStatic(); // RVA: 0x100044B74
	void showBottomPlayerStatic(); // RVA: 0x100044BEC
	void hidePlayerStatic(); // RVA: 0x100044C50
}

public class LeaderboardsGenericTableItem : CCMenuItem // Size: 0x57A
{
	PlayerEntry _playerEntry; // 0x468 (size: 0x108)
	LeaderboardsGenericPlayerNode _view; // 0x570 (size: 0x8)
	bool _loaded; // 0x578 (size: 0x1)
	bool _tryToShowAddFriendsButton; // 0x579 (size: 0x1)

	ulong hash { get; set; } // property
	Class superclass { get; set; } // property
	NSString description { get; set; } // property
	NSString debugDescription { get; set; } // property

	NSObject initWithPlayerEntry:tryToShowAddFriendsButton:(); // RVA: 0x100044D74
	void onEnterVisibleArea(); // RVA: 0x100044E9C
	void onExitVisibleArea(); // RVA: 0x100045038
	void enableInput(); // RVA: 0x1000450A0
	void disableInput(); // RVA: 0x1000450C8
	PlayerEntry getPlayerEntry(); // RVA: 0x1000450F0
	void .cxx_destruct(); // RVA: 0x100045104
	NSObject .cxx_construct(); // RVA: 0x100045114
}

public class LeaderboardsInfoNode : CCNodeRGBA // Size: 0x3F0
{
	LeaderboardsPrizeBracket _prizeBracket1; // 0x3A8 (size: 0x8)
	LeaderboardsPrizeBracket _prizeBracket2; // 0x3B0 (size: 0x8)
	LeaderboardsPrizeBracket _prizeBracket3; // 0x3B8 (size: 0x8)
	LeaderboardsPrizeBracket _prizeBracket4; // 0x3C0 (size: 0x8)
	MCLabelTTF _leaderboardNameLabel; // 0x3C8 (size: 0x8)
	MCLabelTTF _timerLabel; // 0x3D0 (size: 0x8)
	CCNode _iconContainer; // 0x3D8 (size: 0x8)
	int _leaderboardType; // 0x3E0 (size: 0x4)
	MCTimer _endsInTimer; // 0x3E8 (size: 0x8)

	static NSObject nodeWithLeaderboardType:(); // RVA: 0x10012D108
	void dealloc(); // RVA: 0x10012D15C
	void setupWithType:(); // RVA: 0x10012D1BC
	void updateTimer(); // RVA: 0x10012D4DC
	void infoButtonCallback(); // RVA: 0x10012D56C
	void lastWeekResultsButtonCallback(); // RVA: 0x10012D5E8
}

public class LeaderboardsLastWeekNoResultsPopup : MenuPopup // Size: 0x470
{
	NSObject initWithParameters:(); // RVA: 0x10000E83C
}

public class LeaderboardsLastWeekResultsPopup : MenuPopup // Size: 0x4B8
{
	MCLabelTTF _subtitleLabel; // 0x470 (size: 0x8)
	LeaderboardsPrizeBracket _prizeBracket1; // 0x478 (size: 0x8)
	LeaderboardsPrizeBracket _prizeBracket2; // 0x480 (size: 0x8)
	LeaderboardsPrizeBracket _prizeBracket3; // 0x488 (size: 0x8)
	LeaderboardsPrizeBracket _prizeBracket4; // 0x490 (size: 0x8)
	LeaderboardsGenericPlayerNode _playerNode1; // 0x498 (size: 0x8)
	LeaderboardsGenericPlayerNode _playerNode2; // 0x4A0 (size: 0x8)
	LeaderboardsGenericPlayerNode _playerNode3; // 0x4A8 (size: 0x8)
	LeaderboardsGenericPlayerNode _playerNodePlayer; // 0x4B0 (size: 0x8)

	static bool canBeShown(); // RVA: 0x10016FA2C
	NSObject initWithParameters:(); // RVA: 0x10016FA78
}

public class LeaderboardsLeagueInfoNode : CCNodeRGBA // Size: 0x3D8
{
	MCLabelTTF _nameLabel; // 0x3A8 (size: 0x8)
	MCLabelTTF _levelLabel; // 0x3B0 (size: 0x8)
	MCLabelTTF _rewardValue; // 0x3B8 (size: 0x8)
	LeaderboardsLeagueSprite _leaderboardsLeagueSprite; // 0x3C0 (size: 0x8)
	CCNodeRGBA _gemReward; // 0x3C8 (size: 0x8)
	CCNodeRGBA _coinReward; // 0x3D0 (size: 0x8)

	static NSObject nodeWithOwner:leagueInfo:(); // RVA: 0x100265490
	void setupWithLeagueInfo:(); // RVA: 0x1002654D4
	void setupWithLeagueId:(); // RVA: 0x1002656F4
	void setupWithLevel:(); // RVA: 0x100265728
}

public class LeaderboardsLeagueInfoPopup : MenuPopup // Size: 0x4B0
{
	MCMenuItemNodeRGBAStatic _overviewButton; // 0x470 (size: 0x8)
	MCMenuItemNodeRGBAStatic _infoButton; // 0x478 (size: 0x8)
	MCMenuItemNodeRGBAStatic _resultsButton; // 0x480 (size: 0x8)
	CCNodeRGBA _overviewContent; // 0x488 (size: 0x8)
	CCNodeRGBA _infoContent; // 0x490 (size: 0x8)
	CCNodeRGBA _resultsContent; // 0x498 (size: 0x8)
	MCLabelTTF _leagueInfoText1; // 0x4A0 (size: 0x8)
	MCLabelTTF _leagueInfoText4; // 0x4A8 (size: 0x8)

	NSObject initWithParameters:(); // RVA: 0x1002651A0
	void setup(); // RVA: 0x10026522C
	void toggleButtonsWithState:(); // RVA: 0x100265328
	void infoCallback(); // RVA: 0x1002653EC
	void overviewCallback(); // RVA: 0x1002653F4
	void resultsCallback(); // RVA: 0x1002653FC
}

public class LeaderboardsLeagueRankBadge : CCNodeRGBA // Size: 0x3B0
{
	MCLabelTTF _rank; // 0x3A8 (size: 0x8)

	static NSObject nodeWithRank:(); // RVA: 0x10014B4A0
	void dealloc(); // RVA: 0x10014B4E4
	void setupWithRank:(); // RVA: 0x10014B528
}

public class LeaderboardsLeagueSprite : CCNodeRGBA // Size: 0x3B0
{
	CCSprite _leagueTintableSprite; // 0x3A8 (size: 0x8)

	static NSObject node(); // RVA: 0x1022C6F40
	static NSObject nodeWithLeague:(); // RVA: 0x1022C6F54
	static NSObject nodeWithTint:(); // RVA: 0x1022C6F94
	void setTint:(); // RVA: 0x1022C6FD4
	void setLeague:(); // RVA: 0x1022C6FE8
	void setLevel:(); // RVA: 0x1022C703C
}

public class LeaderboardsLeagueUpgradePopup : MenuPopup // Size: 0x490
{
	CCNodeRGBA _centerNode; // 0x470 (size: 0x8)
	LeaderboardsLeagueSprite _leagueSpriteNode; // 0x478 (size: 0x8)
	MCLabelTTF _levelLabel; // 0x480 (size: 0x8)
	MCLabelTTF _leagueName; // 0x488 (size: 0x8)

	static bool canBeShown(); // RVA: 0x100164C88
	NSObject initWithParameters:(); // RVA: 0x100164CD4
	void backButtonCallbackImpl(); // RVA: 0x100164E34
	float leave(); // RVA: 0x100164E54
}

public class LeaderboardsMenu : MenuStateNode // Size: 0x46C
{
	CCNodeRGBA _contentContainer; // 0x3E0 (size: 0x8)
	CCNodeRGBA _loadingContainer; // 0x3E8 (size: 0x8)
	CCNodeRGBA _view; // 0x3F0 (size: 0x8)
	CCNode _tabsContentContainer; // 0x3F8 (size: 0x8)
	CCNode _tabsContainer; // 0x400 (size: 0x8)
	TabsNode _tabsNode; // 0x408 (size: 0x8)
	LeaderboardsGenericTab _leaguesLeaderboard; // 0x410 (size: 0x8)
	LeaderboardsFriendsTab _friendsLeaderboard; // 0x418 (size: 0x8)
	LeaderboardsGenericTab _countryLeaderboard; // 0x420 (size: 0x8)
	LeaderboardsGenericTab _worldLeaderboard; // 0x428 (size: 0x8)
	LeaderboardsClubsTab _clubsLeaderboard; // 0x430 (size: 0x8)
	StringMap _clubLeagueData; // 0x438 (size: 0x28)
	ClubsEventDispatcherWrapper _wrapper; // 0x460 (size: 0x8)
	int _tabSelected; // 0x468 (size: 0x4)

	static NSObject getCCBName(); // RVA: 0x1000430E4
	static NSObject getTitleTag(); // RVA: 0x1000430F0
	void setupWithParameters:(); // RVA: 0x1000430FC
	void dealloc(); // RVA: 0x10004339C
	void onReceivedClubLeagueData:(); // RVA: 0x100043418
	void backButtonCallbackImpl(); // RVA: 0x1000434BC
	void leaderboardsInfoCallback(); // RVA: 0x1000434D8
	void userInfoChanged(); // RVA: 0x100043570
	void setupMenu(); // RVA: 0x1000435E4
	void enterFromStack(); // RVA: 0x100043ACC
	float leave(); // RVA: 0x100043B20
	void enableInput(); // RVA: 0x100043BC4
	void disableInput(); // RVA: 0x100043C68
	NSObject leaguesTabCreationCallback(); // RVA: 0x100043D0C
	void leaguesTabSelectedCallback(); // RVA: 0x100043DB4
	NSObject friendsTabCreationCallback(); // RVA: 0x100043DC4
	void friendsTabSelectedCallback(); // RVA: 0x100043E68
	NSObject countryTabCreationCallback(); // RVA: 0x100043ED0
	void countryTabSelectedCallback(); // RVA: 0x100043F78
	NSObject worldTabCreationCallback(); // RVA: 0x100043F8C
	void worldTabSelectedCallback(); // RVA: 0x100044034
	NSObject clubsTabCreationCallback(); // RVA: 0x100044048
	void clubsTabSelectedCallback(); // RVA: 0x100044148
	void setupOverlayConfig(); // RVA: 0x10004415C
	void .cxx_destruct(); // RVA: 0x1000441B0
	NSObject .cxx_construct(); // RVA: 0x1000441E8
}

public class LeaderboardsPlayerPassedNode : CCNodeRGBA // Size: 0x3D4
{
	PlayerAvatarNode _playerAvatar; // 0x3A8 (size: 0x8)
	StarNode _starNode; // 0x3B0 (size: 0x8)
	CCNodeRGBA _rankContainer; // 0x3B8 (size: 0x8)
	PlayerNameNode _playerName; // 0x3C0 (size: 0x8)
	MCLabelTTF _winnings; // 0x3C8 (size: 0x8)
	int _rankToShowAfterAnimation; // 0x3D0 (size: 0x4)

	static NSObject nodeWithSetName:(); // RVA: 0x10009D160
	static NSObject nodeWithSetName:ranksPassed:(); // RVA: 0x10009D17C
	void setupWithPlayerEntry:previousRank:(); // RVA: 0x10009D390
	void setupWithPlayerEntry:(); // RVA: 0x10009D40C
	void refreshRank(); // RVA: 0x10009D508
	void startRankAnimation(); // RVA: 0x10009D560
}

public class LeaderboardsPlayerPassedPopup : MenuPopup // Size: 0x494
{
	CCNodeRGBA _entriesContainer; // 0x470 (size: 0x8)
	vector<CCNodeRGBA *, std::allocator<CCNodeRGBA *>> _entriesToAnimate; // 0x478 (size: 0x18)
	int _numRanksToShow; // 0x490 (size: 0x4)

	static bool canBeStacked(); // RVA: 0x100099330
	NSObject initWithParameters:(); // RVA: 0x100099358
	void finishEnter(); // RVA: 0x100099484
	void setupEntries(); // RVA: 0x100099524
	NSObject createLeaderboardEntryWithPlayerEntry:setName:yPosition:(); // RVA: 0x100099990
	NSObject createLeaderboardEntryWithPlayerEntry:setName:yPosition:previousRank:(); // RVA: 0x100099998
	void playAnimationForEntries:(); // RVA: 0x100099AD4
	const getOwnPlayer(); // RVA: 0x100099D24
	void backButtonCallbackImpl(); // RVA: 0x100099DEC
	void .cxx_destruct(); // RVA: 0x100099E08
	NSObject .cxx_construct(); // RVA: 0x100099E28
}

public class LeaderboardsPrizeBracket : CCNodeRGBA // Size: 0x3C8
{
	CCSprite _coinsSprite; // 0x3A8 (size: 0x8)
	CCSprite _gemsSprite; // 0x3B0 (size: 0x8)
	MCLabelTTF _prizeLabel; // 0x3B8 (size: 0x8)
	MCLabelTTF _rankLabel; // 0x3C0 (size: 0x8)

	static NSObject nodeWithPrizeBracket:contentSize:(); // RVA: 0x10006BA40
	void setupWithPrizeBracket:(); // RVA: 0x10006BAF8
}

public class LobbyLeaveMatchConfirmationPopup : MenuPopup // Size: 0x4A0
{
	basic_string<char, std::char_traits<char>, std::allocator<char>> _lobbyToken; // 0x470 (size: 0x18)
	basic_string<char, std::char_traits<char>, std::allocator<char>> _userId; // 0x488 (size: 0x18)

	static void showWithLobbyToken:userId:(); // RVA: 0x1023934F0
	NSObject initWithParameters:(); // RVA: 0x102393594
	float enterAnimation(); // RVA: 0x10239368C
	float leaveAnimation(); // RVA: 0x102393690
	void leaveButtonCallback(); // RVA: 0x102393694
	void keepPlayingButtonCallback(); // RVA: 0x1023936C8
	void exitButtonCallback(); // RVA: 0x1023936CC
	void backButtonCallbackImpl(); // RVA: 0x1023936D0
	void .cxx_destruct(); // RVA: 0x102393714
	NSObject .cxx_construct(); // RVA: 0x102393770
}

public class LobbyMenuMatchResults : MenuStateNode // Size: 0x5F4
{
	MatchInfo _matchInfo; // 0x3E0 (size: 0x1B0)
	shared_ptr<mc::Task> _rejoinLobbyTask; // 0x590 (size: 0x10)
	MenuMatchPlayerNode _playerNode; // 0x5A0 (size: 0x8)
	MenuMatchPlayerNode _opponentNode; // 0x5A8 (size: 0x8)
	MenuMatchPlayerNode _opponent2Node; // 0x5B0 (size: 0x8)
	MenuMatchPlayerNode _opponent3Node; // 0x5B8 (size: 0x8)
	MatchmakingVSNode _vsNode; // 0x5C0 (size: 0x8)
	MenuMatchPlayerNodePositionLabel _drawPositionLabel; // 0x5C8 (size: 0x8)
	MCLabelTTF _modeLabel; // 0x5D0 (size: 0x8)
	CCSprite _opponent2Frame; // 0x5D8 (size: 0x8)
	CCSprite _opponent3Frame; // 0x5E0 (size: 0x8)
	Fireworks _fireworks; // 0x5E8 (size: 0x8)
	int _playerCount; // 0x5F0 (size: 0x4)

	static NSObject getCCBName(); // RVA: 0x1021996DC
	void setupWithParameters:(); // RVA: 0x1021996E8
	void dealloc(); // RVA: 0x102199DBC
	float enter(); // RVA: 0x102199E14
	float leave(); // RVA: 0x102199E7C
	void finishEnter(); // RVA: 0x102199ED0
	void finishLeave(); // RVA: 0x102199F40
	void applyPositionLabelVisibilityFor:position:(); // RVA: 0x102199F98
	void startMatchEnding(); // RVA: 0x102199FC4
	void updateOpponentNodeWithInfo:opponentNode:isLeftSide:(); // RVA: 0x10219A1B8
	void startFireworks(); // RVA: 0x10219A300
	void setupOverlayConfig(); // RVA: 0x10219A3E0
	void backButtonCallbackImpl(); // RVA: 0x10219A434
	void .cxx_destruct(); // RVA: 0x10219A470
	NSObject .cxx_construct(); // RVA: 0x10219A518
}

public class LockedPocketEffectCurrencyPurchase : CCNodeRGBA // Size: 0x3F0
{
	MCMenuItemNodeRGBA _upgradeButton; // 0x3A8 (size: 0x8)
	MCLabelTTF _priceLabel; // 0x3B0 (size: 0x8)
	CCSprite _gemSprite; // 0x3B8 (size: 0x8)
	CCSprite _coinSprite; // 0x3C0 (size: 0x8)
	basic_string<char, std::char_traits<char>, std::allocator<char>> _purchaseId; // 0x3C8 (size: 0x18)
	ScreenInput _screenInput; // 0x3E0 (size: 0x4)
	EventBus _bus; // 0x3E8 (size: 0x8)

	static NSObject nodeWithPocketEffectEntity:contentSize:(); // RVA: 0x10024BF74
	void setupWithPocketEffectEntity:(); // RVA: 0x10024BFB8
	void onPurchaseComplete:(); // RVA: 0x10024C14C
	void purchasePressed(); // RVA: 0x10024C240
	void .cxx_destruct(); // RVA: 0x10024C340
	NSObject .cxx_construct(); // RVA: 0x10024C3A4
}

public class LockedPocketEffectRVWatch : CCNodeRGBA // Size: 0x430
{
	MCLabelTTF _description; // 0x3A8 (size: 0x8)
	ProgressBarSegmented _progressBar; // 0x3B0 (size: 0x8)
	WatchAdButton _watchAdButton; // 0x3B8 (size: 0x8)
	MCMenuItemNodeRGBA _unlockButton; // 0x3C0 (size: 0x8)
	EventBus _bus; // 0x3C8 (size: 0x8)
	MakeWeak _makeWeak; // 0x3D0 (size: 0x10)
	ScreenInput _screenInput; // 0x3E0 (size: 0x4)
	basic_string<char, std::char_traits<char>, std::allocator<char>> _rvPurchaseId; // 0x3E8 (size: 0x18)
	basic_string<char, std::char_traits<char>, std::allocator<char>> _rvPlacementId; // 0x400 (size: 0x18)
	basic_string<char, std::char_traits<char>, std::allocator<char>> _pocketEffectId; // 0x418 (size: 0x18)

	static NSObject nodeWithPocketEffectEntity:contentSize:(); // RVA: 0x1000473F4
	void setupWithPocketEffectEntity:(); // RVA: 0x100047438
	void onEnter(); // RVA: 0x100047638
	void refresh(); // RVA: 0x100047680
	void watchAdPressed(); // RVA: 0x1000476F0
	void unlockPocketEffect(); // RVA: 0x100047A38
	void unlockPressed(); // RVA: 0x100047B38
	void onPurchaseComplete:(); // RVA: 0x100047B3C
	void onVideoAdWatched:(); // RVA: 0x100047C44
	void .cxx_destruct(); // RVA: 0x100047CD0
	NSObject .cxx_construct(); // RVA: 0x100047D80
}

public class LudoPuckNode : CCNodeRGBA // Size: 0x3F0
{
	CCNodeRGBA _puckContainer; // 0x3A8 (size: 0x8)
	CCNodeRGBA _puckItemNode; // 0x3B0 (size: 0x8)
	CCNodeRGBA _highlightNode; // 0x3B8 (size: 0x8)
	BubbleIndicatorNode _indicatorNode; // 0x3C0 (size: 0x8)
	int _puckColor; // 0x3C8 (size: 0x4)
	CCBAnimationManager _animationManager; // 0x3D0 (size: 0x8)
	CCNodeRGBA _potAnimationSprites; // 0x3D8 (size: 0x8)
	CCSprite _puckShine; // 0x3E0 (size: 0x8)
	bool _touchEnabled; // 0x3E8 (size: 0x1)
	bool _pottingAnimationTriggered; // 0x3E9 (size: 0x1)
	bool _isHighlighted; // 0x3EA (size: 0x1)
	uint _highlightZOrder; // 0x3EC (size: 0x4)

	NSObject init(); // RVA: 0x100068AF4
	void setupPuckWithColor:position:scale:(); // RVA: 0x100068BDC
	void update:logic:rotationDegrees:(); // RVA: 0x100068FFC
	void highlight:(); // RVA: 0x100069154
	void enableTouch(); // RVA: 0x1000691D8
	void disableTouch(); // RVA: 0x1000691EC
	bool isTouchEnabled(); // RVA: 0x1000691FC
	int getPuckColor(); // RVA: 0x10006920C
	void showIndicatorWithValue:(); // RVA: 0x10006921C
	void hideIndicator(); // RVA: 0x1000692B0
	void showCaptureParticles(); // RVA: 0x1000692F8
	void runPottingAnimation(); // RVA: 0x1000692FC
	void triggerPottingParticles(); // RVA: 0x100069368
	void pottingAnimationFinished(); // RVA: 0x10006936C
}

public class LudoTableNode : CCLayer // Size: 0x440
{
	unique_ptr<ludo::TableLogic, std::default_delete<ludo::TableLogic>> _tableLogic; // 0x3B0 (size: 0x8)
	CCNodeRGBA _tableContainerNode; // 0x3B8 (size: 0x8)
	CCNodeRGBA _extrudeContainerNode; // 0x3C0 (size: 0x8)
	CCNodeRGBA _bubbleContainer; // 0x3C8 (size: 0x8)
	CCNodeRGBA _pucksContainer; // 0x3D0 (size: 0x8)
	CCSprite _tableSprite; // 0x3D8 (size: 0x8)
	GameplayHudBubbleLayer _bubbleLayer; // 0x3E0 (size: 0x8)
	GenericPointer _pointer; // 0x3E8 (size: 0x8)
	map<unsigned int, LudoPuckNode *, std::less<unsigned int>, std::allocator<std::pair<const unsigned int, LudoPuckNode *>>> _puckNodes; // 0x3F0 (size: 0x18)
	uint _touchedPuckId; // 0x408 (size: 0x4)
	LudoTableNodeDelegate _delegate; // 0x410 (size: 0x20)
	DicePickBubble _dicePickBubble; // 0x430 (size: 0x8)
	uint _rotationDegrees; // 0x438 (size: 0x4)
	uint _rotationDegreesPuckBase; // 0x43C (size: 0x4)

	NSObject init(); // RVA: 0x100072038
	void setupTableWithLogicDelegate:nodeDelegate:baseWithVisualPriority:bottomLeftColor:tierId:(); // RVA: 0x100072390
	void addPuckWithColor:puckId:position:ownerPuckBase:ownerPlayerId:(); // RVA: 0x1000725A8
	void removeAllPucks(); // RVA: 0x10007268C
	void removePucksForBase:(); // RVA: 0x1000726F0
	void removePuck:(); // RVA: 0x100072788
	void update:(); // RVA: 0x100072808
	void setTableState:animation:(); // RVA: 0x100072B94
	NSObject createFadeAnimationSequenceWithTableState:puckNode:puckId:animation:animationCompleteCallback:(); // RVA: 0x100072C88
	void setTableState:animation:animationCompleteCallback:(); // RVA: 0x1000731DC
	GameTableState getTableState(); // RVA: 0x100073624
	void movePuck:newPosition:withAnimationFinishedCallback:prioritizePuck:(); // RVA: 0x100073634
	void movePuckToBase:withAnimationFinishedCallback:(); // RVA: 0x100073730
	void showCaptureParticlesOnPuck:(); // RVA: 0x10007381C
	void highlightPuck:isHighlighted:(); // RVA: 0x100073820
	void showDicePickingForPuck:diceId:diceValues:validIndexes:pressedCallback:(); // RVA: 0x100073898
	int getBubbleLayoutForPuckPosition:andDiceValuesSize:(); // RVA: 0x100073C20
	int getPlayerUIPosition:(); // RVA: 0x100073C68
	int getBubbleLayoutForPuckPosition:(); // RVA: 0x100073CC0
	void hideDicePicking(); // RVA: 0x100073D9C
	void showBubbleAtPuckPosition:bubbleId:text:offset:duration:dimension:(); // RVA: 0x100073DDC
	void showBubbleAtPuckPosition:bubbleId:text:offset:duration:(); // RVA: 0x100073DE0
	void showBubbleAtPuck:bubbleId:text:duration:offset:dimension:(); // RVA: 0x100073DF8
	void showBubbleAtHomeForBase:bubbleId:text:callback:(); // RVA: 0x100073E9C
	void showPointerOnPuckPosition:(); // RVA: 0x100073EA0
	void showPointerOnPuckPosition:offset:(); // RVA: 0x100073EC8
	void hidePointer(); // RVA: 0x100073F6C
	void hideBubbleWithId:(); // RVA: 0x100073F80
	bool ccTouchBegan:(); // RVA: 0x10007400C
	void ccTouchEnded:(); // RVA: 0x100074058
	void ccTouchCancelled:(); // RVA: 0x1000740D8
	pair<unsigned int, float> getClosestPuckIdToTouch:(); // RVA: 0x1000740E8
	float getDistanceFromTouch:toPuckId:(); // RVA: 0x1000741C0
	CGPoint touchToScreenPoint:(); // RVA: 0x100074288
	void enablePuckTouch:(); // RVA: 0x1000742C8
	void disablePuckTouch:(); // RVA: 0x10007433C
	bool isPuckEnabled:(); // RVA: 0x1000743B0
	void rotateTableToBottomPuckBase:(); // RVA: 0x100074430
	void rotateTableToBottomLeftColor:(); // RVA: 0x100074478
	void .cxx_destruct(); // RVA: 0x100074528
	NSObject .cxx_construct(); // RVA: 0x10007459C
}

public class MTGVideoAdBiddingTokenRuleManager // Size: 0x18
{
	NSMutableDictionary _biddingTokenRuleDic; // 0x8 (size: 0x8)
	NSLock _lock; // 0x10 (size: 0x8)

	NSMutableDictionary biddingTokenRuleDic { get; set; } // property
	NSLock lock { get; set; } // property

	static NSObject sharedInstance(); // RVA: 0x100E5FF30
	void cacheVideoAdBiddingTokenRuleInfoWithUnitId:loadBidToken:(); // RVA: 0x100E5FFB4
	void updatePriceToVideoAdBiddingTokenRuleInfoWithPrice:unitId:loadBidToken:(); // RVA: 0x100E60168
	void confirmReplacedToVideoAdBiddingTokenRuleInfoWithUnitId:loadBidToken:shownBidToken:(); // RVA: 0x100E603E4
	NSObject getVideoAdBidTokenCacheInfoWithUnitId:shownBidToken:(); // RVA: 0x100E6066C
	void removeVideoAdBiddingTokenRuleInfoWithUnitId:shownBidToken:(); // RVA: 0x100E608D0
	NSObject biddingTokenRuleDic(); // RVA: 0x100E60B20
	NSObject lock(); // RVA: 0x100E60B68
	void setBiddingTokenRuleDic:(); // RVA: 0x100E60BB0
	void setLock:(); // RVA: 0x100E60BBC
	void .cxx_destruct(); // RVA: 0x100E60BC8
}

public class MatchControllerGoldenShotObjcWrapper // Size: 0x10
{
	IntPtr _matchController; // 0x8 (size: 0x8)

	NSObject initWithMatchController:(); // RVA: 0x1000B1B30
	void goBackCallback(); // RVA: 0x1000B1B78
	void onFinishLeaveCallbackWithState:(); // RVA: 0x1000B1B90
	void resetReward(); // RVA: 0x1000B1BD0
	const getCurrentStateDetails(); // RVA: 0x1000B1BE4
}

public class MatchHudPlayerInfo : CCNodeRGBA // Size: 0x3E1
{
	IngamePlayerAvatarNode _avatarNode; // 0x3A8 (size: 0x8)
	PlayerNameNode _playerName; // 0x3B0 (size: 0x8)
	CCNodeRGBA _bubbleMute; // 0x3B8 (size: 0x8)
	ChatBubble _chatBubble; // 0x3C0 (size: 0x8)
	CCNodeRGBA _chatBubbleSpawn; // 0x3C8 (size: 0x8)
	CCNodeRGBA _emojiBubbleSpawn; // 0x3D0 (size: 0x8)
	Reference _player; // 0x3D8 (size: 0x8)
	bool _turnStarted; // 0x3E0 (size: 0x1)

	static NSObject nodeWithPlayer:isLeftToRight:(); // RVA: 0x100011A84
	void setupWithPlayer:(); // RVA: 0x100011C90
	void dealloc(); // RVA: 0x100011E20
	void onExit(); // RVA: 0x100011E6C
	void beginTurn(); // RVA: 0x100011EB0
	void resumeTurn:(); // RVA: 0x100011EDC
	void pauseTurn(); // RVA: 0x100011F04
	void endTurn(); // RVA: 0x100011F4C
	void deactivate(); // RVA: 0x100011FA8
	void startTurn:animation:(); // RVA: 0x100012030
	void startEndTurnHint(); // RVA: 0x1000120DC
	void stopEndTurnHint(); // RVA: 0x100012104
	void avatarButtonPressed(); // RVA: 0x1000121B0
	const playerId(); // RVA: 0x10001220C
	void updateMutedState(); // RVA: 0x10001221C
	void showChatMessage:withBubbleLayout:(); // RVA: 0x10001225C
	NSObject .cxx_construct(); // RVA: 0x100012314
}

public class MatchHudPuckPoints : MCLabelTTF // Size: 0x7D0
{
	NSString _delimiter; // 0x7C8 (size: 0x8)

	void dealloc(); // RVA: 0x10016C2B4
	void didLoadFromCCB:(); // RVA: 0x10016C304
	basic_string<char, std::char_traits<char>, std::allocator<char>> getPuckPointsText:(); // RVA: 0x10016C47C
}

public class MatchHudScore : MCLayout // Size: 0x47C
{
	MCLabelTTF _scoreLabel; // 0x448 (size: 0x8)
	MCLabelTTF _pointsToWinLabel; // 0x450 (size: 0x8)
	PuckNode _puckNode; // 0x458 (size: 0x8)
	PuckNode _queenNode; // 0x460 (size: 0x8)
	CCNodeRGBA _queenContainer; // 0x468 (size: 0x8)
	CCNodeRGBA _queenBubbleSpawn; // 0x470 (size: 0x8)
	int _score; // 0x478 (size: 0x4)

	int score { get; set; } // property

	void setScore:(); // RVA: 0x100214088
	void potQueen(); // RVA: 0x100214148
	void coverQueen(); // RVA: 0x100214194
	void returnQueen(); // RVA: 0x1002141E0
	void bumpPuck(); // RVA: 0x10021422C
	CGPoint puckPosition(); // RVA: 0x10021427C
	CGPoint queenPosition(); // RVA: 0x10021428C
	CGPoint queenBubbleSpawnPosition(); // RVA: 0x10021429C
	CGPoint pointsToWinLabelPosition(); // RVA: 0x1002142AC
	double pointsToWinLabelWidth(); // RVA: 0x1002142BC
	void playAnimation:forNode:once:(); // RVA: 0x1002142CC
	int score(); // RVA: 0x100214340
}

public class MatchHudTeamInfo : CCNodeRGBA // Size: 0x3C8
{
	MCLayout _playerInfoHudLayout; // 0x3A8 (size: 0x8)
	MatchHudScore _hudScore; // 0x3B0 (size: 0x8)
	bool _isLeftToRight; // 0x3B8 (size: 0x1)
	Reference _team; // 0x3C0 (size: 0x8)

	MatchHudScore hudScore { get; set; } // property
	bool isLeftToRight { get; set; } // property

	static NSObject nodeWithMatch:teamIndex:leftToRight:(); // RVA: 0x10024C660
	void setupWithTeam:isLeftToRight:(); // RVA: 0x10024C944
	void addPlayer:zOrder:(); // RVA: 0x10024CA1C
	void beginTurn(); // RVA: 0x10024CAA0
	void resumeTurn:(); // RVA: 0x10024CB8C
	void pauseTurn(); // RVA: 0x10024CC88
	void endTurn(); // RVA: 0x10024CD74
	void setScore:(); // RVA: 0x10024CE60
	void deactivatePlayer(); // RVA: 0x10024CE70
	void showChatMessage:forPlayerWithId:(); // RVA: 0x10024CF5C
	NSObject hudScore(); // RVA: 0x10024D0DC
	bool isLeftToRight(); // RVA: 0x10024D0EC
	void setIsLeftToRight:(); // RVA: 0x10024D0FC
	NSObject .cxx_construct(); // RVA: 0x10024D10C
}

public class MatchMenuCoinAnimation : CCNodeRGBA // Size: 0x3A8
{
	static void moveCoinAnimation:finalPosition:coin:(); // RVA: 0x1020BFE9C
}

public class MatchResultsProductNodeSquare : ProductNodeSquare // Size: 0x428
{
	CCNodeRGBA _view; // 0x420 (size: 0x8)

	NSObject init(); // RVA: 0x102329174
	NSObject initDefaultChest(); // RVA: 0x1023291E0
	NSObject createView(); // RVA: 0x102329294
	void runSpawnAnimation(); // RVA: 0x1023292D4
	void runQuantityEndAnimation(); // RVA: 0x102329364
	void animationCallback(); // RVA: 0x102329380
	void animateQuantityToValue:withDuration:(); // RVA: 0x102329460
	void setQuantity:(); // RVA: 0x1023294EC
}

public class MatchResultsRewardsList : RewardsScrollList // Size: 0x750
{
	ulong _squareIndex; // 0x6F8 (size: 0x8)
	float _rewardAnimationDelay; // 0x700 (size: 0x4)
	float _scrollAnimationSpeed; // 0x704 (size: 0x4)
	EventBus _bus; // 0x708 (size: 0x8)
	function<void ()> _defaultChestCallback; // 0x710 (size: 0x20)
	uint _maxVisibleRewards; // 0x730 (size: 0x4)
	set<int, std::less<int>, std::allocator<int>> _childTags; // 0x738 (size: 0x18)

	NSObject init(); // RVA: 0x102168A18
	void addProduct:quantity:tag:(); // RVA: 0x102168B84
	void addProductNode:tag:(); // RVA: 0x102168BDC
	void setMaxVisibleRewards:(); // RVA: 0x102168C48
	float rewardsAnimationDuration(); // RVA: 0x102168C58
	void runNextNodeSpawnAnimation(); // RVA: 0x102168C8C
	void runSquareAnimation(); // RVA: 0x102168EC8
	void animateQuantityToValue:value:durationSeconds:(); // RVA: 0x102168F40
	void addDefaultChestNodeWithCallback:(); // RVA: 0x1021690BC
	NSObject getDefaultChestNode(); // RVA: 0x102169148
	void .cxx_destruct(); // RVA: 0x102169150
	NSObject .cxx_construct(); // RVA: 0x1021691C8
}

public class MatchRouletteNode : CCNodeRGBA // Size: 0x3F0
{
	CCSprite mOpponentRoulet; // 0x3A8 (size: 0x8)
	CCSprite mOpponentRouletAux; // 0x3B0 (size: 0x8)
	float mOpponentRouletOffset; // 0x3B8 (size: 0x4)
	float mOpponentRouletteTextureHeight; // 0x3BC (size: 0x4)
	float mOpponentRouletteHeight; // 0x3C0 (size: 0x4)
	float mOpponentRouletSpeed; // 0x3C4 (size: 0x4)
	CCRenderTexture _renderTexture; // 0x3C8 (size: 0x8)
	CCNodeRGBA _renderNode; // 0x3D0 (size: 0x8)
	CCSprite _photoFrame; // 0x3D8 (size: 0x8)
	NSObject _stopTarget; // 0x3E0 (size: 0x8)
	SEL _stopSelector; // 0x3E8 (size: 0x8)

	void dealloc(); // RVA: 0x102309FC4
	void onExit(); // RVA: 0x10230A030
	void stopRouletteWithTarget:selector:(); // RVA: 0x10230A078
	void startRoulette(); // RVA: 0x10230A09C
	void appBecameActive(); // RVA: 0x10230A4BC
	void clearNotificationObserver(); // RVA: 0x10230A508
	void updateOpponentRoulette:(); // RVA: 0x10230A534
	void updateOpponentRouletteSpeed:(); // RVA: 0x10230A6C8
	void visit(); // RVA: 0x10230A7B0
}

public class MatchmakingVSNode : CCNodeRGBA // Size: 0x3B0
{
	CCBAnimationManager _animationManager; // 0x3A8 (size: 0x8)

	void didLoadFromCCBAfterChildren(); // RVA: 0x102131BF8
	void runStampAnimation(); // RVA: 0x102131C24
	void setIdle(); // RVA: 0x102131C3C
}

public class MenuEquipmentStrikerInfoPopup : MenuPopup // Size: 0x470
{
	NSObject initWithParameters:(); // RVA: 0x100104A0C
}

public class MenuMatchPlayerNode : CCNodeRGBA // Size: 0x471
{
	PlayerAvatarNode _playerAvatar; // 0x3A8 (size: 0x8)
	StarNode _starNode; // 0x3B0 (size: 0x8)
	PlayerNameNode _playerName; // 0x3B8 (size: 0x8)
	MCMenuItemNodeRGBAStatic _chatButton; // 0x3C0 (size: 0x8)
	MCMenuItemNodeRGBAStatic _addFriendButton; // 0x3C8 (size: 0x8)
	MCLabelTTF _coinsLabel; // 0x3D0 (size: 0x8)
	MCFramedSprite _coinsFrame; // 0x3D8 (size: 0x8)
	MatchRouletteNode _rouletteNode; // 0x3E0 (size: 0x8)
	CCNodeRGBA _rouletteContainer; // 0x3E8 (size: 0x8)
	MCFramedSprite _whiteGlow; // 0x3F0 (size: 0x8)
	CCNodeRGBA _glowParticleContainer; // 0x3F8 (size: 0x8)
	CCNodeRGBA _particleContainer; // 0x400 (size: 0x8)
	CCSprite _burstGlow; // 0x408 (size: 0x8)
	MenuMatchPlayerNodePositionLabel _positionLabel; // 0x410 (size: 0x8)
	CCBAnimationManager _animationManager; // 0x418 (size: 0x8)
	ChatBubble _chatBubble; // 0x420 (size: 0x8)
	basic_string<char, std::char_traits<char>, std::allocator<char>> _userId; // 0x428 (size: 0x18)
	function<void ()> _addFriendCallback; // 0x440 (size: 0x20)
	NSObject _chatButtonTarget; // 0x460 (size: 0x8)
	SEL _chatButtonSelector; // 0x468 (size: 0x8)
	bool _isLeftSide; // 0x470 (size: 0x1)

	bool isActive { get; set; } // property
	bool isLeftSide { get; set; } // property

	static NSObject playerNode(); // RVA: 0x102308990
	void didLoadFromCCBAfterChildren(); // RVA: 0x1023089A4
	void setupWithPlayerInfo:(); // RVA: 0x102308B20
	void setupWithPlayerInfo:isLeftSide:(); // RVA: 0x102308C64
	void setIsActive:(); // RVA: 0x102308DA0
	bool isActive(); // RVA: 0x102308E10
	void setUserId:(); // RVA: 0x102308E34
	basic_string<char, std::char_traits<char>, std::allocator<char>> getUserId(); // RVA: 0x102308E48
	void setLevel:league:(); // RVA: 0x102308E7C
	void setName:(); // RVA: 0x102308FAC
	void loadAvatar:userId:(); // RVA: 0x102308FBC
	void showCoins:(); // RVA: 0x102309020
	void setCoins:(); // RVA: 0x1023090B4
	void fadeOutCoins(); // RVA: 0x102309100
	void fadeOutCoinsFrame(); // RVA: 0x102309140
	void whiteGlow(); // RVA: 0x102309198
	void setGameEndPosition:(); // RVA: 0x1023091F0
	void setWinnerGlow(); // RVA: 0x102309268
	void startParticlesWithQuantity:(); // RVA: 0x10230947C
	void updateFrameParticle:(); // RVA: 0x1023094B8
	void playerAvatarButtonCallback(); // RVA: 0x1023097AC
	void showAddFriend:isLeftSide:(); // RVA: 0x1023097C0
	void hideAddFriend(); // RVA: 0x102309850
	NSObject getAddFriendButton(); // RVA: 0x102309864
	void addFriendCallback(); // RVA: 0x102309874
	void showChat:selector:(); // RVA: 0x102309898
	void hideChat(); // RVA: 0x1023098F0
	void chatButtonCallback(); // RVA: 0x102309904
	void showChatMessage:(); // RVA: 0x102309924
	void showTextBubble:hideLater:(); // RVA: 0x1023099C0
	void stopRouletteWithTarget:selector:(); // RVA: 0x102309A6C
	void startRoulette(); // RVA: 0x102309A7C
	void hideAvatar(); // RVA: 0x102309AD8
	void showAvatar(); // RVA: 0x102309AEC
	bool isAvatarVisible(); // RVA: 0x102309B00
	void leave(); // RVA: 0x102309B10
	void dealloc(); // RVA: 0x102309B20
	bool isLeftSide(); // RVA: 0x102309B78
	void setIsLeftSide:(); // RVA: 0x102309B88
	void .cxx_destruct(); // RVA: 0x102309B98
	NSObject .cxx_construct(); // RVA: 0x102309C0C
}

public class MenuMatchPlayerNodePositionLabel : CCNodeRGBA // Size: 0x3D0
{
	CCBAnimationManager _animationManager; // 0x3A8 (size: 0x8)
	MCLabelTTF _valueLabel; // 0x3B0 (size: 0x8)
	CCNodeRGBA _additiveLabelContainer; // 0x3B8 (size: 0x8)
	MCLabelTTF _additiveLabel; // 0x3C0 (size: 0x8)
	CCRenderTexture _renderTexture; // 0x3C8 (size: 0x8)

	void didLoadFromCCBAfterChildren(); // RVA: 0x102109BFC
	void playWinAnimation(); // RVA: 0x102109C60
	void setGameEndPosition:(); // RVA: 0x102109C78
}

public class MenuMatchResults : MenuStateNode // Size: 0x720
{
	EventBus _bus; // 0x3E0 (size: 0x8)
	int _tier; // 0x3E8 (size: 0x4)
	MatchInfo _matchInfo; // 0x3F0 (size: 0x1B0)
	CCNodeRGBA _allNodesContainer; // 0x5A0 (size: 0x8)
	MenuMatchPlayerNode _playerNode; // 0x5A8 (size: 0x8)
	MenuMatchPlayerNode _opponentNode; // 0x5B0 (size: 0x8)
	MenuMatchPlayerNode _opponent2Node; // 0x5B8 (size: 0x8)
	MenuMatchPlayerNode _opponent3Node; // 0x5C0 (size: 0x8)
	MatchmakingVSNode _vsNode; // 0x5C8 (size: 0x8)
	MenuMatchPlayerNodePositionLabel _drawPositionLabel; // 0x5D0 (size: 0x8)
	CCNodeRGBA _tierLogoContainer; // 0x5D8 (size: 0x8)
	CCNodeRGBA _newRankContainer; // 0x5E0 (size: 0x8)
	ChatMenu _chatMenu; // 0x5E8 (size: 0x8)
	MCLabelTTF mWinner; // 0x5F0 (size: 0x8)
	MCLabelTTF _modeLabel; // 0x5F8 (size: 0x8)
	MCLabelTTF _slotsFullLabel; // 0x600 (size: 0x8)
	CCMenu mMenu; // 0x608 (size: 0x8)
	MCMenuItemNodeRGBA mRematchButton; // 0x610 (size: 0x8)
	CCMenuItem mBackgroundButton; // 0x618 (size: 0x8)
	CCNodeRGBA _rewardListContainer; // 0x620 (size: 0x8)
	CCNodeRGBA _animatedBadgesContainerBackground; // 0x628 (size: 0x8)
	CCHybridMenu _animatedBadgesHybridMenu; // 0x630 (size: 0x8)
	AnimatedEventBadgeContainer _animatedEventBadgeContainer; // 0x638 (size: 0x8)
	CCSprite mCoins; // 0x640 (size: 0x8)
	MCFramedSprite _potCoinsLabelFrame; // 0x648 (size: 0x8)
	MCLabelTTF _potCoinsLabel; // 0x650 (size: 0x8)
	CCNodeRGBA _matchScore; // 0x658 (size: 0x8)
	MCLabelTTF _matchScoreLabel; // 0x660 (size: 0x8)
	MatchResultsRewardsList _rewardList; // 0x668 (size: 0x8)
	int _wonCoins; // 0x670 (size: 0x4)
	int _wonCash; // 0x674 (size: 0x4)
	bool _wonChest; // 0x678 (size: 0x1)
	int _playerCount; // 0x67C (size: 0x4)
	bool _customEventTierPointsShown; // 0x680 (size: 0x1)
	vector<std::reference_wrapper<const ProductInfo>, std::allocator<std::reference_wrapper<const ProductInfo>>> _highPriorityRewards; // 0x688 (size: 0x18)
	float _incrementCoinsStep; // 0x6A0 (size: 0x4)
	float _launchCoinsThreshold; // 0x6A4 (size: 0x4)
	float _launchCoinsValue; // 0x6A8 (size: 0x4)
	int _potCoins; // 0x6AC (size: 0x4)
	float _potCoinsTmp; // 0x6B0 (size: 0x4)
	float _playerCoinsTarget; // 0x6B4 (size: 0x4)
	float _playerCoins; // 0x6B8 (size: 0x4)
	float _opponentCoinsTarget; // 0x6BC (size: 0x4)
	float _opponentCoins; // 0x6C0 (size: 0x4)
	float _opponent2CoinsTarget; // 0x6C4 (size: 0x4)
	float _opponent2Coins; // 0x6C8 (size: 0x4)
	float _opponent3CoinsTarget; // 0x6CC (size: 0x4)
	float _opponent3Coins; // 0x6D0 (size: 0x4)
	CCSprite _seasonPassPointsPile; // 0x6D8 (size: 0x8)
	int _seasonPassPointsPot; // 0x6E0 (size: 0x4)
	Fireworks mFireworks; // 0x6E8 (size: 0x8)
	bool _isRematchDisabled; // 0x6F0 (size: 0x1)
	bool _canShowOpponentTextBubble; // 0x6F1 (size: 0x1)
	NSString _postponedOpponentTextBubbleString; // 0x6F8 (size: 0x8)
	bool _postponedOpponentTextBubbleHide; // 0x700 (size: 0x1)
	ulong _bubbleTimestamp; // 0x708 (size: 0x8)
	MakeWeak _makeWeak; // 0x710 (size: 0x10)

	static NSObject getCCBName(); // RVA: 0x1023015DC
	static NSObject getCCBSetName(); // RVA: 0x1023015E8
	NSObject init(); // RVA: 0x10230166C
	void setupWithParameters:(); // RVA: 0x10230177C
	void onEnterTransitionDidFinish(); // RVA: 0x102301E70
	void dealloc(); // RVA: 0x102301F10
	void enterFromStack(); // RVA: 0x1023020BC
	float enter(); // RVA: 0x102302150
	void finishEnter(); // RVA: 0x1023021F4
	float leave(); // RVA: 0x10230224C
	void onAnimatedEventBadgePoll:(); // RVA: 0x1023022B4
	void onAnimatedEventBadgeStreamPoll:(); // RVA: 0x102302304
	void setupMatchScore(); // RVA: 0x102302334
	NSObject getBackButtonOverlayNode(); // RVA: 0x102302428
	void startMatchEnding(); // RVA: 0x102302444
	void showRewardList(); // RVA: 0x102302A58
	void showExtraRewardList(); // RVA: 0x102302F90
	void trySetupCustomEventPoints(); // RVA: 0x102302F94
	void showRewardSquares(); // RVA: 0x102303268
	void updateCurrencyHeader(); // RVA: 0x102303278
	void showChessSlotsFullBubble(); // RVA: 0x1023032D4
	void applyPositionLabelVisibilityFor:withPosition:(); // RVA: 0x102303474
	void updateOpponentNodeWithInfo:opponentNode:isLeftSide:(); // RVA: 0x1023034A0
	void startFireworks(); // RVA: 0x102303714
	void addFriend:opponentNode:bubbleLayout:(); // RVA: 0x1023037F4
	void showAddFriendPopup:(); // RVA: 0x102303A14
	void removePopupCallback:(); // RVA: 0x102303AB4
	void rematchButtonCallback(); // RVA: 0x102303AC0
	void rematchSuccess(); // RVA: 0x102303CB0
	void matchEndingSendCoins(); // RVA: 0x102303D20
	void updateCoinsFromPot:(); // RVA: 0x102303F24
	void moveCoinsTo:(); // RVA: 0x1023042CC
	void didFinishUpdateCoinsFromPot(); // RVA: 0x1023043A0
	void matchEndingSendSeasonPassPoints(); // RVA: 0x1023045CC
	void updateSeasonPassPointsFromPot:(); // RVA: 0x1023046F0
	void didFinishUpdateSeasonPassPointsFromPot(); // RVA: 0x1023048E0
	void tryShowChest(); // RVA: 0x1023049C0
	void showPostponedOpponentTextBubble(); // RVA: 0x102304C7C
	void postponeOpponentTextBubble:hideLater:(); // RVA: 0x102304CDC
	void tryShowOpponentTextBubble:hideLater:(); // RVA: 0x102304D38
	void showRematch(); // RVA: 0x102304D60
	void tryShowRematch(); // RVA: 0x102304DE0
	void chatButtonCallback(); // RVA: 0x102304EF4
	void backgroundCallback(); // RVA: 0x1023053D0
	void matchRequestDeclined:isRematch:(); // RVA: 0x10230540C
	void chatMessageReceived:(); // RVA: 0x1023054A0
	void tryShowBottomButtons(); // RVA: 0x102305704
	void backButtonCallbackImpl(); // RVA: 0x102305754
	void setupOverlayConfig(); // RVA: 0x1023057DC
	void .cxx_destruct(); // RVA: 0x102305870
	NSObject .cxx_construct(); // RVA: 0x102305954
}

public class MenuMatchmaking : MenuStateNode // Size: 0x510
{
	int _tier; // 0x3E0 (size: 0x4)
	bool _hasPresetOpponent; // 0x3E4 (size: 0x1)
	bool _didCameFromChallenge; // 0x3E5 (size: 0x1)
	int _playerCount; // 0x3E8 (size: 0x4)
	basic_string<char, std::char_traits<char>, std::allocator<char>> _opponentId; // 0x3F0 (size: 0x18)
	basic_string<char, std::char_traits<char>, std::allocator<char>> _gameMode; // 0x408 (size: 0x18)
	bool _canRunEnterAnimation; // 0x420 (size: 0x1)
	GameMenuMatchPlayerNode _playerNode; // 0x428 (size: 0x8)
	GameMenuMatchPlayerNode _opponentNode; // 0x430 (size: 0x8)
	GameMenuMatchPlayerNode _opponent2Node; // 0x438 (size: 0x8)
	GameMenuMatchPlayerNode _opponent3Node; // 0x440 (size: 0x8)
	CCNodeRGBA _leftPanel; // 0x448 (size: 0x8)
	CCNodeRGBA _rightPanel; // 0x450 (size: 0x8)
	MatchmakingVSNode _vsNode; // 0x458 (size: 0x8)
	CCNodeRGBA _tierLogo; // 0x460 (size: 0x8)
	CCSprite mCoins; // 0x468 (size: 0x8)
	MCLabelTTF _modeLabel; // 0x470 (size: 0x8)
	MCLabelTTF _eligibleForWinningsLabel; // 0x478 (size: 0x8)
	MCFramedSprite _potCoinsLabelFrame; // 0x480 (size: 0x8)
	MCLabelTTF _potCoinsLabel; // 0x488 (size: 0x8)
	int _playerCoins; // 0x490 (size: 0x4)
	int _opponentCoins; // 0x494 (size: 0x4)
	int _opponent2Coins; // 0x498 (size: 0x4)
	int _opponent3Coins; // 0x49C (size: 0x4)
	int _potCoins; // 0x4A0 (size: 0x4)
	float _playerCoinsTmp; // 0x4A4 (size: 0x4)
	float _opponentCoinsTmp; // 0x4A8 (size: 0x4)
	float _opponent2CoinsTmp; // 0x4AC (size: 0x4)
	float _opponent3CoinsTmp; // 0x4B0 (size: 0x4)
	float _potCoinsTmp; // 0x4B4 (size: 0x4)
	float _incrementCoinsStep; // 0x4B8 (size: 0x4)
	float _launchCoinsThreshold; // 0x4BC (size: 0x4)
	float _launchCoinsValue; // 0x4C0 (size: 0x4)
	float _playerCashTmp; // 0x4C4 (size: 0x4)
	ulong _coinsConverted; // 0x4C8 (size: 0x8)
	float _conversionDecrementCashStep; // 0x4D0 (size: 0x4)
	float _conversionIncrementCoinsStep; // 0x4D4 (size: 0x4)
	float _yPositionDeviation; // 0x4D8 (size: 0x4)
	TipMessage _tip; // 0x4E0 (size: 0x8)
	EventBus _bus; // 0x4E8 (size: 0x8)
	Async _async; // 0x4F0 (size: 0x20)

	static NSObject getCCBName(); // RVA: 0x1001109CC
	void setupWithParameters:(); // RVA: 0x1001109D8
	void onEnter(); // RVA: 0x1001117B4
	void placeTierLogo:(); // RVA: 0x100111814
	void finishEnter(); // RVA: 0x1001118A0
	void stopOpponentRouletAnimationCallback(); // RVA: 0x1001118F0
	void rouletteStoppedCallback(); // RVA: 0x10011190C
	void endStartingAnimationCallback(); // RVA: 0x100111E70
	void updateConversion:(); // RVA: 0x1001121D8
	void updateCoinsToPot:(); // RVA: 0x100112364
	void updateWithOpponentInfo:localPlayerOrder:tierId:(); // RVA: 0x100112B08
	void updateOpponentNodeWithInfo:opponentNode:isLeftSide:(); // RVA: 0x100112E20
	void gameStartingWithOpponent:localPlayerOrder:tierId:eligibleForLeaderboards:(); // RVA: 0x100112E78
	void matchRequestDeclined:isRematch:(); // RVA: 0x1001130DC
	void challengeDeclinedLeaveAnimation(); // RVA: 0x1001132A8
	void backButtonCallbackImpl(); // RVA: 0x10011332C
	float leave(); // RVA: 0x1001133C0
	void dealloc(); // RVA: 0x100113518
	void setupOverlayConfig(); // RVA: 0x100113610
	void .cxx_destruct(); // RVA: 0x10011370C
	NSObject .cxx_construct(); // RVA: 0x10011378C
}

public class MenuStateGameCarrom : MenuStateGame // Size: 0x3F0
{
	void setupOverlayConfig(); // RVA: 0x1001045A4
}

public class MessageTableNode : CCNodeRGBA // Size: 0x3D9
{
	<MessageTableNodeDataSource> _dataSource; // 0x3A8 (size: 0x8)
	BufferedTasksScheduler _bufferedTasksScheduler; // 0x3B0 (size: 0x8)
	IntPtr _factory; // 0x3B8 (size: 0x8)
	ulong _viewIndex; // 0x3C0 (size: 0x8)
	IntPtr _view; // 0x3C8 (size: 0x8)
	float _padding; // 0x3D0 (size: 0x4)
	float _width; // 0x3D4 (size: 0x4)
	bool _isLoading; // 0x3D8 (size: 0x1)

	ulong viewIndex { get; set; } // property
	ulong hash { get; set; } // property
	Class superclass { get; set; } // property
	NSString description { get; set; } // property
	NSString debugDescription { get; set; } // property

	bool isLoaded(); // RVA: 0x10036E690
	void loadData(); // RVA: 0x10036E6A8
	void returnViewToPool(); // RVA: 0x10036E700
	void unloadData(); // RVA: 0x10036E738
	NSObject initWithFactory:dataSource:scheduler:padding:width:(); // RVA: 0x10036E788
	void setContentSize(); // RVA: 0x10036E860
	void dealloc(); // RVA: 0x10036E9A0
	void disableInput(); // RVA: 0x10036EA08
	void enableInput(); // RVA: 0x10036EA4C
	void execute(); // RVA: 0x10036EA90
	void finishedExecuting(); // RVA: 0x10036EB98
	IntPtr getView(); // RVA: 0x10036EBA8
	IntPtr view(); // RVA: 0x10036EBB8
	ulong viewIndex(); // RVA: 0x10036EBC8
	void setViewIndex:(); // RVA: 0x10036EBD8
}

public class MultiplierRewardProductNodeSquare : MatchResultsProductNodeSquare // Size: 0x430
{
	MCLabelTTF _bannerLabel; // 0x428 (size: 0x8)

	NSObject initWithProductId:quantity:wonMatch:(); // RVA: 0x10027BE08
	NSObject createView(); // RVA: 0x10027BE7C
}

public class PocketEffectInfoNode : CCNodeRGBA // Size: 0x3C0
{
	MCLabelTTF _nameLabel; // 0x3A8 (size: 0x8)
	RarityNameNode _rarityNameNode; // 0x3B0 (size: 0x8)
	PocketEffectPreviewNode _preview; // 0x3B8 (size: 0x8)

	static NSObject nodeWithPocketEffectId:parentSize:isPopup:(); // RVA: 0x10005272C
	void setupWithPocketEffectId:(); // RVA: 0x10005278C
	void setDescriptionForPocketEffect:(); // RVA: 0x100052834
	void updatePocketEffectWithId:(); // RVA: 0x1000528F0
	void playPreview(); // RVA: 0x100052998
	void stopPreview(); // RVA: 0x1000529A8
}

public class PocketEffectNode : CCNodeRGBA // Size: 0x3B8
{
	MCSpineNode _spineNode; // 0x3A8 (size: 0x8)
	CCParticleSystemQuad _particles; // 0x3B0 (size: 0x8)

	static NSObject nodeWithPocketEffectEntity:(); // RVA: 0x100091814
	static NSObject nodeWithPocketEffectEntity:completeCallback:(); // RVA: 0x1000918D4
	void setupSpineWithCallback:(); // RVA: 0x100091ACC
}

public class PocketEffectPreviewNode : CCNodeRGBA // Size: 0x3C8
{
	MCSpineNode _spineNode; // 0x3A8 (size: 0x8)
	CCNodeRGBA _pocketEffectContainer; // 0x3B0 (size: 0x8)
	shared_ptr<const configuration::PocketEffectEntity> _pocketEffectEntity; // 0x3B8 (size: 0x10)

	void setupWithPocketEffectEntity:(); // RVA: 0x10024D1D0
	void updatePocketEffectWithEntity:(); // RVA: 0x10024D3E4
	void playPreview(); // RVA: 0x10024D3E8
	void stopPreview(); // RVA: 0x10024D424
	void .cxx_destruct(); // RVA: 0x10024D468
	NSObject .cxx_construct(); // RVA: 0x10024D478
}

public class PocketEffectPreviewPopup : MenuPopup // Size: 0x478
{
	PocketEffectInfoNode _infoNode; // 0x470 (size: 0x8)

	static void showWithPocketEffectId:(); // RVA: 0x100087398
	static NSObject getCCBName(); // RVA: 0x1000873F8
	void setupWithParameters:(); // RVA: 0x100087404
	void finishEnter(); // RVA: 0x1000874C8
	float leave(); // RVA: 0x100087518
}

public class PocketNode : CCNodeRGBA // Size: 0x3B4
{
	CCSprite _pocketHighlight; // 0x3A8 (size: 0x8)
	float _lastPocketHighlightDuration; // 0x3B0 (size: 0x4)

	NSObject init(); // RVA: 0x100114A8C
	NSObject initWithField:(); // RVA: 0x100114B14
	void setup:(); // RVA: 0x100114BB0
	void highlightAnimationWithDuration:(); // RVA: 0x100114C3C
	void stopHightlightAnimation(); // RVA: 0x100114D50
}

public class PreviewUpgradeStriker : CCNodeRGBA // Size: 0x428
{
	StrikerVisual _strikerVisual; // 0x3A8 (size: 0x8)
	MCLabelTTF _nameLabel; // 0x3B0 (size: 0x8)
	RarityNameNode _rarityNameNode; // 0x3B8 (size: 0x8)
	CCNodeRGBA _powerBarContainer; // 0x3C0 (size: 0x8)
	CCNodeRGBA _aimBarContainer; // 0x3C8 (size: 0x8)
	CCNodeRGBA _timeBarContainer; // 0x3D0 (size: 0x8)
	MCMenuItemNodeRGBA _upgradeButton; // 0x3D8 (size: 0x8)
	MCLabelTTF _priceLabel; // 0x3E0 (size: 0x8)
	MCLabelTTF _pointsLabel; // 0x3E8 (size: 0x8)
	CCSprite _gemSprite; // 0x3F0 (size: 0x8)
	CCSprite _coinSprite; // 0x3F8 (size: 0x8)
	basic_string<char, std::char_traits<char>, std::allocator<char>> _strikerId; // 0x400 (size: 0x18)
	MakeWeak _makeWeak; // 0x418 (size: 0x10)

	basic_string<cha strikerId { get; set; } // property

	static NSObject nodeWithStriker:owner:contentSize:(); // RVA: 0x100060734
	void setStriker:(); // RVA: 0x100060774
	NSObject createPowerBarWithTitle:parentNode:withPower:debugTagPrefix:(); // RVA: 0x100060BD4
	void enableUpgradeButton:(); // RVA: 0x100060C54
	basic_string<char, std::char_traits<char>, std::allocator<char>> strikerId(); // RVA: 0x100060C64
	void .cxx_destruct(); // RVA: 0x100060C98
	NSObject .cxx_construct(); // RVA: 0x100060CF4
}

public class PuckNode : CCNodeRGBA // Size: 0x3F8
{
	CCNodeRGBA _bottomSpriteContainer; // 0x3A8 (size: 0x8)
	CCNodeRGBA _topSpriteContainer; // 0x3B0 (size: 0x8)
	CCSprite _topSprite; // 0x3B8 (size: 0x8)
	MCDrawableShape _shinyShape; // 0x3C0 (size: 0x8)
	MCLabelTTF _pointsLabel; // 0x3C8 (size: 0x8)
	NSString _image; // 0x3D0 (size: 0x8)
	float _radius; // 0x3D8 (size: 0x4)
	bool _fadeOut; // 0x3DC (size: 0x1)
	bool _fadeOutDirty; // 0x3DD (size: 0x1)
	bool _hintHighlightRunning; // 0x3DE (size: 0x1)
	CCSprite _hintGlow; // 0x3E0 (size: 0x8)
	MakeWeak _makeWeak; // 0x3E8 (size: 0x10)

	static NSObject nodeWithPuckId:(); // RVA: 0x10022A86C
	static NSObject nodeWithPuckEntity:points:(); // RVA: 0x10022A8BC
	NSObject init(); // RVA: 0x10022AAC8
	void dealloc(); // RVA: 0x10022AB68
	void didLoadFromCCBAfterChildren(); // RVA: 0x10022ABDC
	void forcePosition:(); // RVA: 0x10022AC68
	void setup:(); // RVA: 0x10022AC7C
	void update:visualRotation:(); // RVA: 0x10022B09C
	int getZOrder:visualRotation:(); // RVA: 0x10022B36C
	void hintHighlight:(); // RVA: 0x10022B3C4
	void highlight:(); // RVA: 0x10022B54C
	void fadeOut:(); // RVA: 0x10022B5DC
	void startShinySpawning(); // RVA: 0x10022B604
	void scheduleShinyBasedOnPosition(); // RVA: 0x10022B6B8
	void visualBump(); // RVA: 0x10022B7C4
	void resetVisual(); // RVA: 0x10022B848
	CGSize spriteContentSize(); // RVA: 0x10022B888
	void .cxx_destruct(); // RVA: 0x10022B898
	NSObject .cxx_construct(); // RVA: 0x10022B8B4
}

public class StaticStrikerTrail : StrikerTrail // Size: 0x4CC
{
	float _widthMultiplier; // 0x4C8 (size: 0x4)

	static NSObject nodeWithStrikerTrailEntity:windForce:variance:frequency:particlesEffectRatio:widthMultiplier:playOnAwake:(); // RVA: 0x10022EAA4
	NSObject initWithStrikerTrailEntity:widthMultiplier:playOnAwake:(); // RVA: 0x10022EB44
	void updateStrikerTrailWithEntity:(); // RVA: 0x10022EBAC
}

public class StrikerCascadeAnimation : CCNodeRGBA // Size: 0x415
{
	CCRenderTexture _trail; // 0x3A8 (size: 0x8)
	NSMutableArray _strikerPool; // 0x3B0 (size: 0x8)
	vector<StrikerCascadeFlyer, std::allocator<StrikerCascadeFlyer>> _flyers; // 0x3B8 (size: 0x18)
	CGPoint _center; // 0x3D0 (size: 0x10)
	float _left; // 0x3E0 (size: 0x4)
	float _right; // 0x3E4 (size: 0x4)
	float _floor; // 0x3E8 (size: 0x4)
	float _top; // 0x3EC (size: 0x4)
	float _edgeInset; // 0x3F0 (size: 0x4)
	float _gravity; // 0x3F4 (size: 0x4)
	float _minVX; // 0x3F8 (size: 0x4)
	float _maxVX; // 0x3FC (size: 0x4)
	ulong _launchedCount; // 0x400 (size: 0x8)
	ulong _totalToLaunch; // 0x408 (size: 0x8)
	float _timeSinceLaunch; // 0x410 (size: 0x4)
	bool _finishing; // 0x414 (size: 0x1)

	static void presentOverRunningScene(); // RVA: 0x1001DB948
	void dealloc(); // RVA: 0x1001DB9B0
	void start(); // RVA: 0x1001DBA24
	void setupBounds(); // RVA: 0x1001DBAE4
	void buildStrikerPool(); // RVA: 0x1001DBC2C
	void buildTrail(); // RVA: 0x1001DBDB4
	void update:(); // RVA: 0x1001DBE34
	void spawnFlyer(); // RVA: 0x1001DC080
	void beginFinishing(); // RVA: 0x1001DC244
	void visit(); // RVA: 0x1001DC31C
	void .cxx_destruct(); // RVA: 0x1001DC3D8
	NSObject .cxx_construct(); // RVA: 0x1001DC3F8
}

public class StrikerEvolutionMenu : MenuStateNode // Size: 0x410
{
	StrikerVisual _strikerVisual; // 0x3E0 (size: 0x8)
	MCSpineNode _levelUpAnimation; // 0x3E8 (size: 0x8)
	MCLabelTTF _strikerName; // 0x3F0 (size: 0x8)
	StrikerStatsNode _strikerStatsNode; // 0x3F8 (size: 0x8)
	const _striker; // 0x400 (size: 0x8)
	EventBus _bus; // 0x408 (size: 0x8)

	static NSObject getCCBName(); // RVA: 0x100265818
	static void showUpgradeWithStrikerId:nextLevel:(); // RVA: 0x100265824
	void setupWithParameters:(); // RVA: 0x100265888
	void setupOverlayConfig(); // RVA: 0x100265A84
	void finishEnter(); // RVA: 0x100265AD8
	void showLevelUpAnimation(); // RVA: 0x100265AFC
	void showNextLevelVisual(); // RVA: 0x100265B3C
	void showStatsUpgrade(); // RVA: 0x100265B5C
	void upgradeAnimationEnded(); // RVA: 0x100265B70
	void backButtonCallbackImpl(); // RVA: 0x100265B94
	void .cxx_destruct(); // RVA: 0x100265C14
	NSObject .cxx_construct(); // RVA: 0x100265C38
}

public class StrikerInfoNode : CCNodeRGBA // Size: 0x3C0
{
	MCLabelTTF _nameLabel; // 0x3A8 (size: 0x8)
	RarityNameNode _rarityNameNode; // 0x3B0 (size: 0x8)
	StrikerVisual _strikerVisual; // 0x3B8 (size: 0x8)

	void setupWithStrikerId:(); // RVA: 0x100016E9C
	void setupWithStriker:(); // RVA: 0x100016ED0
}

public class StrikerNode : CCNodeRGBA // Size: 0x408
{
	CCNodeRGBA _view; // 0x3A8 (size: 0x8)
	StrikerVisual _visual; // 0x3B0 (size: 0x8)
	StrikerTrail _trail; // 0x3B8 (size: 0x8)
	BuffNodeContainer _buffNodeContainer; // 0x3C0 (size: 0x8)
	bool _highlight; // 0x3C8 (size: 0x1)
	bool _highlightVisible; // 0x3C9 (size: 0x1)
	bool _highlightDirty; // 0x3CA (size: 0x1)
	bool _highlightGrabbed; // 0x3CB (size: 0x1)
	bool _highlightGrabbedDirty; // 0x3CC (size: 0x1)
	bool _shouldHighlightInvalid; // 0x3CD (size: 0x1)
	bool _highlightInvalid; // 0x3CE (size: 0x1)
	bool _highlightInvalidDirty; // 0x3CF (size: 0x1)
	bool _fadeOut; // 0x3D0 (size: 0x1)
	bool _fadeOutDirty; // 0x3D1 (size: 0x1)
	basic_string<char, std::char_traits<char>, std::allocator<char>> _buffId; // 0x3D8 (size: 0x18)
	MakeWeak _makeWeak; // 0x3F0 (size: 0x10)
	EventBus _bus; // 0x400 (size: 0x8)

	static NSObject nodeWithStriker:(); // RVA: 0x10014F730
	static NSObject nodeWithStrikerId:level:(); // RVA: 0x10014F738
	NSObject init(); // RVA: 0x10014F834
	void forcePosition:(); // RVA: 0x10014F8F4
	void setupWithStrikerId:level:buffEntity:trailEntity:(); // RVA: 0x10014F908
	void update:visualRotation:activeControls:(); // RVA: 0x10014FC44
	int getZOrder:visualRotation:(); // RVA: 0x100150334
	void forceFadeOut:(); // RVA: 0x10015038C
	void highlight:(); // RVA: 0x1001503DC
	void highlightGrabbed:(); // RVA: 0x1001504A0
	void highlightInvalid:(); // RVA: 0x1001504D4
	void fadeOut:(); // RVA: 0x100150510
	void setTrailVisible:(); // RVA: 0x100150544
	float getTopAssetRotation(); // RVA: 0x1001505DC
	void .cxx_destruct(); // RVA: 0x1001505EC
	NSObject .cxx_construct(); // RVA: 0x10015065C
}

public class StrikerPowerBar : CCNodeRGBA // Size: 0x448
{
	float _spacing; // 0x3A8 (size: 0x4)
	float _textWidth; // 0x3AC (size: 0x4)
	float _fontSize; // 0x3B0 (size: 0x4)
	float _nodeScale; // 0x3B4 (size: 0x4)
	int _power; // 0x3B8 (size: 0x4)
	int _buff; // 0x3BC (size: 0x4)
	bool _buffDirty; // 0x3C0 (size: 0x1)
	vector<CCNode *, std::allocator<CCNode *>> _blackNodes; // 0x3C8 (size: 0x18)
	vector<CCNode *, std::allocator<CCNode *>> _greenNodes; // 0x3E0 (size: 0x18)
	vector<CCNode *, std::allocator<CCNode *>> _purpleNodes; // 0x3F8 (size: 0x18)
	MCLabelTTF _plusOneLabel; // 0x410 (size: 0x8)
	MCLabelTTF _powerLabel; // 0x418 (size: 0x8)
	CCSprite _cellUpgradeSprite; // 0x420 (size: 0x8)
	CCSprite _pendingUpgradeSprite; // 0x428 (size: 0x8)
	CCSpriteBatchNode _greenNodesContainer; // 0x430 (size: 0x8)
	CCSpriteBatchNode _blackNodesContainer; // 0x438 (size: 0x8)
	CCSpriteBatchNode _purpleNodesContainer; // 0x440 (size: 0x8)

	MCLabelTTF powerLabel { get; set; } // property
	int power { get; set; } // property
	int buff { get; set; } // property
	bool hasPendingUpgrade { get; set; } // property

	NSObject initWithLabel:layoutType:(); // RVA: 0x10004F678
	void dealloc(); // RVA: 0x10004FC68
	float xPosition:(); // RVA: 0x10004FC9C
	void setPower:(); // RVA: 0x10004FCC8
	void setBuff:(); // RVA: 0x10004FE64
	bool hasPendingUpgrade(); // RVA: 0x10004FEA0
	void animatePendingUpgrade(); // RVA: 0x10004FEB0
	void stopAnimatingPendingUpgrade(); // RVA: 0x10004FFE8
	void upgrade:(); // RVA: 0x100050038
	void updateGreenBarForAnimation(); // RVA: 0x100050310
	void onEndUpgradeAnimation(); // RVA: 0x100050324
	void runPlusOneAnimation(); // RVA: 0x100050358
	NSObject powerLabel(); // RVA: 0x1000504A0
	int power(); // RVA: 0x1000504B0
	int buff(); // RVA: 0x1000504C0
	void .cxx_destruct(); // RVA: 0x1000504D0
	NSObject .cxx_construct(); // RVA: 0x100050548
}

public class StrikerStatsNode : CCNodeRGBA // Size: 0x3E0
{
	CCNodeRGBA _powerBarContainer; // 0x3A8 (size: 0x8)
	StrikerPowerBar _powerBar; // 0x3B0 (size: 0x8)
	CCNodeRGBA _aimBarContainer; // 0x3B8 (size: 0x8)
	StrikerPowerBar _aimBar; // 0x3C0 (size: 0x8)
	CCNodeRGBA _timeBarContainer; // 0x3C8 (size: 0x8)
	StrikerPowerBar _timeBar; // 0x3D0 (size: 0x8)
	bool _animatePendingUpgrade; // 0x3D8 (size: 0x1)
	int _enumStrikerPowerBarLayoutType; // 0x3DC (size: 0x4)

	static NSObject nodeWithUpgradeableStriker:buffEntity:(); // RVA: 0x1001887CC
	static NSObject nodeWithStrikerProperties:buffProperties:(); // RVA: 0x100188890
	static NSObject nodeWithPower:powerBuff:hasPowerUpgrade:aim:aimBuff:hasAimUpgrade:time:timeBuff:hasTimeUpgrade:(); // RVA: 0x1001888D4
	NSObject init(); // RVA: 0x100188974
	void setupWithUpgradeableStriker:buffEntity:(); // RVA: 0x1001889BC
	void setupWithStrikerProperties:buffProperties:(); // RVA: 0x100188A80
	void setupWithPower:powerBuff:hasPowerUpgrade:aim:aimBuff:hasAimUpgrade:time:timeBuff:hasTimeUpgrade:(); // RVA: 0x100188AC4
	NSObject createPowerBarWithTitle:parentNode:power:buff:hasUpgrade:debugTagPrefix:(); // RVA: 0x100188E7C
	void guaranteeSameFontSizeOnBars:(); // RVA: 0x100188F78
	void setAnimatePendingUpgrade:(); // RVA: 0x100189014
	void upgrade:(); // RVA: 0x1001890B0
}

public class StrikerTrail : CCMotionStreak // Size: 0x4C8
{
	basic_string<char, std::char_traits<char>, std::allocator<char>> _strikerTrailId; // 0x4B0 (size: 0x18)

	static NSObject nodeWithStrikerTrailEntity:playOnAwake:(); // RVA: 0x100031984
	void updateStrikerTrailWithEntity:(); // RVA: 0x1000319D4
	void .cxx_destruct(); // RVA: 0x100031C04
	NSObject .cxx_construct(); // RVA: 0x100031C24
}

public class StrikerTrailInfoNode : CCNodeRGBA // Size: 0x3C0
{
	MCLabelTTF _nameLabel; // 0x3A8 (size: 0x8)
	RarityNameNode _rarityNameNode; // 0x3B0 (size: 0x8)
	StrikerTrailPreviewNode _preview; // 0x3B8 (size: 0x8)

	static NSObject nodeWithStrikerTrailId:playOnAwake:parentSize:isPopup:(); // RVA: 0x10016BF34
	void setupWithStrikerTrailId:playOnAwake:(); // RVA: 0x10016BFA0
	void refreshEquippedStriker(); // RVA: 0x10016C058
	void updateStrikerTrailWithId:(); // RVA: 0x10016C068
	void setDescriptionForStrikerTrail:(); // RVA: 0x10016C110
	void setTrailVisible:(); // RVA: 0x10016C1E8
}

public class StrikerTrailPreviewNode : CCNodeRGBA // Size: 0x3DC
{
	CCNodeRGBA _trailContainer; // 0x3A8 (size: 0x8)
	StrikerVisual _strikerVisual; // 0x3B0 (size: 0x8)
	StaticStrikerTrail _trail; // 0x3B8 (size: 0x8)
	float _windForceX; // 0x3C0 (size: 0x4)
	float _windForceY; // 0x3C4 (size: 0x4)
	float _varianceX; // 0x3C8 (size: 0x4)
	float _varianceY; // 0x3CC (size: 0x4)
	float _frequency; // 0x3D0 (size: 0x4)
	float _particlesEffectRatio; // 0x3D4 (size: 0x4)
	float _widthMultiplier; // 0x3D8 (size: 0x4)

	void setupWithStrikerTrailEntity:playOnAwake:(); // RVA: 0x10006CD2C
	void refreshEquippedStriker(); // RVA: 0x10006CDF0
	void updateStrikerTrailWithEntity:(); // RVA: 0x10006CE7C
	void setTrailVisible:(); // RVA: 0x10006CE8C
}

public class StrikerTrailPreviewPopup : MenuPopup // Size: 0x478
{
	StrikerTrailInfoNode _infoNode; // 0x470 (size: 0x8)

	static void showWithStrikerTrailId:(); // RVA: 0x10023CF7C
	static NSObject getCCBName(); // RVA: 0x10023CFDC
	void setupWithParameters:(); // RVA: 0x10023CFE8
	void finishEnter(); // RVA: 0x10023D0AC
	float leave(); // RVA: 0x10023D0C0
}

public class StrikerVisual : CCNodeRGBA // Size: 0x3C0
{
	bool _animated; // 0x3A8 (size: 0x1)
	MakeWeak _makeWeak; // 0x3B0 (size: 0x10)

	bool animated { get; set; } // property

	static NSObject nodeWithStrikerId:(); // RVA: 0x1001DAA18
	static NSObject nodeWithStrikerId:level:(); // RVA: 0x1001DAA4C
	static NSObject nodeWithUpgradeableStriker:(); // RVA: 0x1001DAA94
	NSObject init(); // RVA: 0x1001DAB00
	void setupWithStrikerId:(); // RVA: 0x1001DAB48
	void setupWithStrikerId:level:(); // RVA: 0x1001DAB7C
	void setupWithUpgradeableStriker:(); // RVA: 0x1001DACF4
	void addVisualWithImageName:(); // RVA: 0x1001DAD5C
	void addVisualWithSpineName:(); // RVA: 0x1001DADCC
	void setAnimated:(); // RVA: 0x1001DB3C4
	bool animated(); // RVA: 0x1001DB468
	void .cxx_destruct(); // RVA: 0x1001DB478
	NSObject .cxx_construct(); // RVA: 0x1001DB494
}

public class StrikerVisualUpgradePopup : MenuPopup // Size: 0x4F8
{
	MCLabelTTF _currentTitle; // 0x470 (size: 0x8)
	CCNodeRGBA _currentVisualsContainer; // 0x478 (size: 0x8)
	StrikerStatsNode _currentStrikerStatsNode; // 0x480 (size: 0x8)
	CCNodeRGBA _evolveHint; // 0x488 (size: 0x8)
	MCLabelTTF _nextTitle; // 0x490 (size: 0x8)
	CCNodeRGBA _nextVisualsContainer; // 0x498 (size: 0x8)
	MCLabelTTF _bottomDescription; // 0x4A0 (size: 0x8)
	ProgressBarSegmented _progressBar; // 0x4A8 (size: 0x8)
	WatchAdButton _watchAdButton; // 0x4B0 (size: 0x8)
	MCMenuItemNodeRGBAStatic _upgradeButton; // 0x4B8 (size: 0x8)
	basic_string<char, std::char_traits<char>, std::allocator<char>> _strikerId; // 0x4C0 (size: 0x18)
	int _nextVisualLevel; // 0x4D8 (size: 0x4)
	bool _skipLeaveAnimation; // 0x4DC (size: 0x1)
	MakeWeak _makeWeak; // 0x4E0 (size: 0x10)
	EventBus _bus; // 0x4F0 (size: 0x8)

	static NSObject getCCBName(); // RVA: 0x1000BC2B4
	void setupWithParameters:(); // RVA: 0x1000BC2C0
	float enter(); // RVA: 0x1000BC798
	float leave(); // RVA: 0x1000BC7F4
	void watchAdPressed(); // RVA: 0x1000BC84C
	void upgradePressed(); // RVA: 0x1000BCBB8
	void upgradeStriker(); // RVA: 0x1000BCBBC
	void .cxx_destruct(); // RVA: 0x1000BCD04
	NSObject .cxx_construct(); // RVA: 0x1000BCD74
}

public class TableNode : CCLayerRGBA // Size: 0x538
{
	unique_ptr<TableLogic, std::default_delete<TableLogic>> _tableLogic; // 0x3B8 (size: 0x8)
	map<int, PuckNode *, std::less<int>, std::allocator<std::pair<const int, PuckNode *>>> _puckNodes; // 0x3C0 (size: 0x18)
	map<int, StrikerNode *, std::less<int>, std::allocator<std::pair<const int, StrikerNode *>>> _strikerNodes; // 0x3D8 (size: 0x18)
	map<int, PocketNode *, std::less<int>, std::allocator<std::pair<const int, PocketNode *>>> _pocketNodes; // 0x3F0 (size: 0x18)
	CCNodeRGBA _tableShadow; // 0x408 (size: 0x8)
	CCNodeRGBA _tableContainer; // 0x410 (size: 0x8)
	CCNodeRGBA _tableVisualsContainer; // 0x418 (size: 0x8)
	TableVisualsStaticNode _tableVisualsStatic; // 0x420 (size: 0x8)
	CCNodeRGBA _discsContainer; // 0x428 (size: 0x8)
	float _visualRotation; // 0x430 (size: 0x4)
	float _originalVisualRotation; // 0x434 (size: 0x4)
	TableInputDelegate _tableInputDelegate; // 0x438 (size: 0x80)
	map<int, ns_ptr<ControlsLogicRemote *>, std::less<int>, std::allocator<std::pair<const int, ns_ptr<ControlsLogicRemote *>>>> _controlsLogicRemote; // 0x4B8 (size: 0x18)
	map<int, ns_ptr<ControlsLogicLocal *>, std::less<int>, std::allocator<std::pair<const int, ns_ptr<ControlsLogicLocal *>>>> _controlsLogicLocal; // 0x4D0 (size: 0x18)
	map<int, ControlsBackgroundNode *, std::less<int>, std::allocator<std::pair<const int, ControlsBackgroundNode *>>> _controlsBackgroundNodes; // 0x4E8 (size: 0x18)
	map<int, ControlsForegroundNode *, std::less<int>, std::allocator<std::pair<const int, ControlsForegroundNode *>>> _controlsForegroundNodes; // 0x500 (size: 0x18)
	CCNodeRGBA _controlsBackgroundContainer; // 0x518 (size: 0x8)
	CCNodeRGBA _controlsForegroundContainer; // 0x520 (size: 0x8)
	MCPoint _visualRotationPoint; // 0x528 (size: 0x10)

	float originalVisualRotation { get; set; } // property

	NSObject init(); // RVA: 0x10007589C
	NSObject initLegacy(); // RVA: 0x100075958
	IntPtr getTableLogic(); // RVA: 0x100075A2C
	GameTableState getTableState(); // RVA: 0x100075A3C
	void setTableState:(); // RVA: 0x100075A4C
	MatchTableState getMatchTableState(); // RVA: 0x100075B58
	void setMatchTableState:(); // RVA: 0x100075B68
	void rebuildPucks:(); // RVA: 0x100075B7C
	void setupTableVisuals:(); // RVA: 0x100075B90
	void setupField:withDelegate:(); // RVA: 0x100075C48
	void setInputDelegate:(); // RVA: 0x100075FFC
	void setVisualRotation:(); // RVA: 0x100076050
	void setOriginalVisualRotation:(); // RVA: 0x100076144
	void setVisualRotationPoint:(); // RVA: 0x100076154
	MCPoint applyVisualRotation:(); // RVA: 0x100076168
	MCPoint applyVisualRotationPoint:(); // RVA: 0x1000761A4
	MCPoint applyBaselineOffset:baselineId:(); // RVA: 0x1000761C0
	MCPoint pointToTableSpace:(); // RVA: 0x1000761D4
	CGPoint tableSpaceToPoint:(); // RVA: 0x100076204
	void addPuck:puckId:position:(); // RVA: 0x100076224
	void addPuck:puckId:position:points:(); // RVA: 0x100076310
	void removePuck:(); // RVA: 0x100076404
	void addStriker:strikerLevel:buff:strikerId:powerLevel:position:(); // RVA: 0x1000764C4
	void addStriker:strikerLevel:buff:trail:strikerId:powerLevel:position:(); // RVA: 0x100076544
	void removeStriker:(); // RVA: 0x100076660
	void soundEnabled:(); // RVA: 0x100076720
	double skipToAnimationEnd(); // RVA: 0x100076734
	void update:(); // RVA: 0x100076744
	void takeShot:power:angle:(); // RVA: 0x100076BD8
	MCPoint findBestFitForStriker:projectedPoint:baselineId:(); // RVA: 0x100076BEC
	MCPoint findBestFitForPuck:projectedPoint:(); // RVA: 0x100076C04
	MCPoint getOutsidePositionForBaselineId:(); // RVA: 0x100076C18
	void normalizePlayingStrikerPosition:baselineId:(); // RVA: 0x100076C2C
	void normalizeNotPlayingStrikerPosition:baselineId:(); // RVA: 0x100076C44
	void preventStrikerPositioningHack:baselineId:(); // RVA: 0x100076C5C
	bool validateStrikerPosition:baselineId:(); // RVA: 0x100076C74
	void preventAutoWinHack:(); // RVA: 0x100076C8C
	void resetPuckVisual:(); // RVA: 0x100076CA0
	void setHighlightPuck:puckId:(); // RVA: 0x100076D14
	void setHintHighlightPuck:puckId:(); // RVA: 0x100076D98
	void setFadeOutPuck:puckId:(); // RVA: 0x100076E1C
	void visualBumpPuck:(); // RVA: 0x100076EA0
	void setHighlightStriker:strikerId:(); // RVA: 0x100076F14
	void setHighlightGrabbedStriker:strikerId:(); // RVA: 0x100076F98
	void setHighlightInvalidStriker:strikerId:(); // RVA: 0x10007701C
	void setFadeOutStriker:strikerId:(); // RVA: 0x1000770A0
	void highlightPocketAnimation:pocketId:(); // RVA: 0x100077124
	void stopHighlightPocketAnimation:(); // RVA: 0x1000771A8
	void setFadeOutAllStrikers(); // RVA: 0x10007721C
	void forceFadeOutAllStrikers(); // RVA: 0x100077290
	void hideAllStrikerTrails(); // RVA: 0x100077344
	void removeAllStaticVisuals(); // RVA: 0x1000773B8
	void setPuckInPlay:(); // RVA: 0x1000773C8
	void setPuckPotted:(); // RVA: 0x1000773DC
	void setStrikerInPlay:(); // RVA: 0x1000773F0
	void setStrikerOffTable:(); // RVA: 0x1000774B0
	void movePuckToPosition:position:endCallback:(); // RVA: 0x1000774E4
	void movePuckToPosition:position:maxDelay:minTime:maxTime:endCallback:(); // RVA: 0x1000775EC
	void moveStrikerToPosition:position:endCallback:(); // RVA: 0x100077714
	void moveStrikerToPosition:position:maxDelay:minTime:maxTime:endCallback:(); // RVA: 0x10007781C
	void forcePuckPosition:position:(); // RVA: 0x1000779DC
	void forceStrikerPosition:position:(); // RVA: 0x100077A28
	void forceMoveAnimationEndedCall(); // RVA: 0x100077A74
	void moveStrikerToPositionSmooth:position:remote:(); // RVA: 0x100077A84
	void moveStrikerToPositionSmoothCancel:(); // RVA: 0x100077A9C
	MCPoint getPuckPosition:(); // RVA: 0x100077AB0
	MCPoint getStrikerPosition:(); // RVA: 0x100077AE8
	int pickPuckAtPosition:(); // RVA: 0x100077B20
	bool controlsHaveEnoughPower:(); // RVA: 0x100077B58
	double controlsGetAngle:(); // RVA: 0x100077BD4
	int getPuckState:(); // RVA: 0x100077C4C
	bool physicsAnimating(); // RVA: 0x100077C80
	NSObject tableBackgroundContainer(); // RVA: 0x100077C90
	int getSpecialShotType:(); // RVA: 0x100077CA0
	void addControlsLocal:aimLevel:delegate:(); // RVA: 0x100077CD0
	void addControlsRemote:aimLevel:(); // RVA: 0x100077FAC
	void setControlsRemote:angle:power:(); // RVA: 0x100078100
	void setControlsStriker:controlsId:(); // RVA: 0x1000781F0
	void controlsReset:(); // RVA: 0x100078318
	void controlsDisable:(); // RVA: 0x1000783D4
	void controlsEnable:(); // RVA: 0x100078490
	void controlsRemoteForceDelay:delay:(); // RVA: 0x10007854C
	bool isLocalControlEnabled:(); // RVA: 0x1000785C8
	void addSpecialShotSpine:pocketId:(); // RVA: 0x10007864C
	void showPocketEffect:pocketId:(); // RVA: 0x1000786BC
	void ccTouchesBegan:(); // RVA: 0x10007872C
	void ccTouchesMoved:(); // RVA: 0x1000787E4
	void ccTouchesEnded:(); // RVA: 0x10007889C
	void ccTouchesCancelled:(); // RVA: 0x100078954
	NSObject controlsForStriker:(); // RVA: 0x100078A0C
	float originalVisualRotation(); // RVA: 0x100078B00
	void .cxx_destruct(); // RVA: 0x100078B10
	NSObject .cxx_construct(); // RVA: 0x100078C80
}

public class TableVisualsStaticNode : CCNodeRGBA // Size: 0x3A8
{
	NSObject getContainerNodeForPocketNode:(); // RVA: 0x1001891C0
	void addSpecialShotSpine:pocketNode:(); // RVA: 0x100189264
	void showPocketEffectNode:pocketNode:(); // RVA: 0x100189380
}

// --- dump by Zoroo_God (t.me/Zoroo_God) via Privet Dumper.py

public class TierNodeBack1On1Carrom : TierNodeBack1On1 // Size: 0x3B8
{
	NSObject getObjectPoolInstance(); // RVA: 0x100039168
}

public class TierNodeBack1On1CarromView : TierNodeBack1On1View // Size: 0x3C0
{
}

public class TierNodeBack1On1PointCarrom : TierNodeBack1On1 // Size: 0x3BC
{
	int _pointMode; // 0x3B8 (size: 0x4)

	NSObject initWithTierEntity:withPointMode:(); // RVA: 0x10020F790
	NSObject getObjectPoolInstance(); // RVA: 0x10020F7E0
}

public class TierNodeBack1On1PointCarromView : TierNodeBack1On1View // Size: 0x3C0
{
}

public class TikTokSKAdNetworkRule // Size: 0x20
{
	long _fineConversionValue; // 0x8 (size: 0x8)
	NSString _coarseConversionValue; // 0x10 (size: 0x8)
	NSArray _eventFunnel; // 0x18 (size: 0x8)

	long fineConversionValue { get; set; } // property
	NSString coarseConversionValue { get; set; } // property
	NSArray eventFunnel { get; set; } // property

	NSObject initWithDict:(); // RVA: 0x101387BC4
	bool isMatched(); // RVA: 0x101387E1C
	long fineConversionValue(); // RVA: 0x101387F2C
	void setFineConversionValue:(); // RVA: 0x101387F34
	NSObject coarseConversionValue(); // RVA: 0x101387F3C
	void setCoarseConversionValue:(); // RVA: 0x101387F44
	NSObject eventFunnel(); // RVA: 0x101387F50
	void setEventFunnel:(); // RVA: 0x101387F58
	void .cxx_destruct(); // RVA: 0x101387F60
}

public class TikTokSKAdNetworkRuleEvent // Size: 0x28
{
	bool _isMatched; // 0x8 (size: 0x1)
	NSString _eventName; // 0x10 (size: 0x8)
	NSNumber _minRevenue; // 0x18 (size: 0x8)
	NSNumber _maxRevenue; // 0x20 (size: 0x8)

	NSString eventName { get; set; } // property
	NSNumber minRevenue { get; set; } // property
	NSNumber maxRevenue { get; set; } // property
	bool isMatched { get; set; } // property

	NSObject initWithDict:(); // RVA: 0x101387F90
	NSObject eventName(); // RVA: 0x10138817C
	void setEventName:(); // RVA: 0x101388184
	NSObject minRevenue(); // RVA: 0x10138818C
	void setMinRevenue:(); // RVA: 0x101388194
	NSObject maxRevenue(); // RVA: 0x1013881A0
	void setMaxRevenue:(); // RVA: 0x1013881A8
	bool isMatched(); // RVA: 0x1013881B4
	void setIsMatched:(); // RVA: 0x1013881BC
	void .cxx_destruct(); // RVA: 0x1013881C4
}

public class _TtC6CarromP33_8F089C033A19060093A4FC0437A4583219ResourceBundleClass // Size: 0x10
{
}

public class _TtC8FBAEMKit24AEMAdvertiserRuleFactory // Size: 0x10
{
}

public class _TtC8FBAEMKit27AEMAdvertiserMultiEntryRule // Size: 0x18
{
	void operator; // 0x8 (size: 0x1)
	void rules; // 0x10 (size: 0x8)

	static bool supportsSecureCoding(); // RVA: 0x10041729C
	NSObject initWithCoder:(); // RVA: 0x100417660
	void encodeWithCoder:(); // RVA: 0x100417758
	NSObject init(); // RVA: 0x1004177D4
	void .cxx_destruct(); // RVA: 0x100417800
}

public class _TtC8FBAEMKit28AEMAdvertiserSingleEntryRule // Size: 0x48
{
	void operator; // 0x8 (size: 0x1)
	void paramKey; // 0x10 (size: 0x10)
	void linguisticCondition; // 0x20 (size: 0x10)
	void numericalCondition; // 0x30 (size: 0x9)
	void arrayCondition; // 0x40 (size: 0x8)

	static bool supportsSecureCoding(); // RVA: 0x10041B5C8
	static void setSupportsSecureCoding:(); // RVA: 0x10041B64C
	NSObject initWithCoder:(); // RVA: 0x10041BA30
	void encodeWithCoder:(); // RVA: 0x10041BC9C
	bool isEqual:(); // RVA: 0x10041BF40
	NSObject init(); // RVA: 0x10041BFEC
	void .cxx_destruct(); // RVA: 0x10041C018
}

public class _TtC8FBAEMKit7AEMRule // Size: 0x20
{
	void conversionValue; // 0x8 (size: 0x8)
	void priority; // 0x10 (size: 0x8)
	void events; // 0x18 (size: 0x8)

	static bool supportsSecureCoding(); // RVA: 0x10043DB60
	NSObject initWithCoder:(); // RVA: 0x10043DBD8
	void encodeWithCoder:(); // RVA: 0x10043DD30
	bool isEqual:(); // RVA: 0x10043DE84
	NSObject init(); // RVA: 0x10043DF38
	void .cxx_destruct(); // RVA: 0x10043DF64
}
