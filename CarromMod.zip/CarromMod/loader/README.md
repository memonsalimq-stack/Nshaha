# Loader: getting CarromMod into the game process

(See ../hook.txt for the full list of hooks. The patch below is the only change inside the game.)

This mirrors the pattern used by the Easy Victory loader in the reference APK:
`CarromActivity.onCreate` gets one extra line that calls a mod class's `Start(Context)`,
which calls `System.loadLibrary(...)`. Everything else happens inside the native library
(`JNI_OnLoad` starts a bootstrap thread — see `jni/src/main.cpp`).

## What's here
The loader class itself now lives in the main Android Studio project, at
`../app/src/main/java/com/carrommod/loader/MainActivity.java` (same shape as
`com.easyvictory.mods.MainActivity` in the reference APK: `Start(Context)` →
`System.loadLibrary`, exceptions swallowed so a bad load never crashes the game) — building
`../app` with Gradle compiles and dexes it for real, instead of hand-assembling smali.

## Patching the target APK (same steps the reference APK's build used)
Not done by this project — do this yourself once `../app` is built (see the root `README.md`
for how) and you are ready to test on a real device:

1. Decompile the target APK with apktool (`apktool d game.apk`).
2. Build `../app` in Android Studio, then pull `com/carrommod/loader/MainActivity.class`'s
   compiled form out of the resulting APK/AAB's `classes.dex` (e.g. with `apktool d` on
   CarromMod's own output APK) and copy that class's `smali` into the target APK as a NEW dex
   (`smali_classesN/com/carrommod/loader/MainActivity.smali`), the way the reference APK keeps
   its loader in its own `classesN.dex`.
3. Patch `com/miniclip/carrom/CarromActivity.smali`'s `onCreate` method: insert one line that
   calls `Lcom/carrommod/loader/MainActivity;->Start(Landroid/content/Context;)V` — in the
   reference APK this line sits right after `invoke-super ... onCreate(...)V` and before the
   rest of onCreate's body. Example smali line (adjust the register to a live Context
   register at that point, same as `invoke-static {v1}, Lcom/easyvictory/mods/MainActivity;
   ->Start(Landroid/content/Context;)V` in the reference APK):
   ```
   invoke-static {p0}, Lcom/carrommod/loader/MainActivity;->Start(Landroid/content/Context;)V
   ```
4. Put the built `libCarromMod.so` (from `jni/Android.mk`, see the project root README) into
   `lib/arm64-v8a/`.
5. Rebuild with apktool, zipalign, and sign with your own key (`apksigner` or `uber-apk-signer`).
   None of this is automated here: signing keys and which APK to patch are yours to choose.

## Why it's split this way
`CarromMod` (this project) never assumes which APK or which patch tool you use — it only
needs to end up loaded into the Carrom Pool process and given a writable files directory,
which `System.loadLibrary` + `JNI_OnLoad` provide regardless of how the call got there.
