// EnumerateModules is tested against THIS process' real /proc/self/maps (no mocking needed:
// the test binary and libc are always mapped in any process, Linux or Android).
#include <cstdio>
#include <cstring>
#include <unistd.h>

#include "check.h"
#include "logic/RuntimeDumper.h"
#include "platform/ModuleEnum.h"

using namespace carrom;

static void TestEnumerateRealProcess() {
    std::printf("[module enumeration: real self process]\n");
    const auto mods = EnumerateModules();
    CHECK(!mods.empty());

    bool foundSelf = false, foundLibc = false;
    for (const auto& m : mods) {
        CHECK(m.end > m.base);              // every merged range is non-empty
        CHECK(!m.name.empty());
        if (m.name.find("test_runtime_dumper") != std::string::npos) foundSelf = true;
        if (m.name.find("libc") != std::string::npos) foundLibc = true;
    }
    CHECK(foundSelf);                       // the test binary itself must be mapped
    CHECK(foundLibc);                       // libc is mapped in every process

    const auto libcOnly = FindModulesContaining("libc");
    CHECK(!libcOnly.empty());
    for (const auto& m : libcOnly) CHECK(m.name.find("libc") != std::string::npos);

    CHECK(FindModulesContaining("definitely_not_a_real_library_xyz").empty());
    CHECK(FindModulesContaining("").empty());   // empty needle matches nothing, not everything

    // auto-detect finds nothing on a plain host test binary (no il2cpp/cocos2d/etc linked in) —
    // proves the candidate filter doesn't just return everything
    const auto auto_ = AutoDetectCandidates();
    for (const auto& m : auto_) CHECK(m.everExecutable);
}

static void TestDumpModule() {
    std::printf("[dump module: real self memory]\n");
    // dump a real, small, stable region: this test binary's own .text, found via enumeration
    const auto mods = EnumerateModules();
    const MappedModule* self = nullptr;
    for (const auto& m : mods)
        if (m.name.find("test_runtime_dumper") != std::string::npos && m.everExecutable) { self = &m; break; }
    CHECK(self != nullptr);
    if (!self) return;

    RuntimeDumper dumper;
    const std::string path = "/tmp/carrom_runtime_dump_test.bin";
    MappedModule small = *self;
    small.end = small.base + 4096 * 4; // keep the test fast: dump only the first 4 pages
    const DumpResult r = dumper.DumpModule(small, path);
    CHECK(r.ok);
    CHECK(r.bytesWritten == 4096 * 4);
    CHECK(r.base == small.base);

    std::FILE* f = std::fopen(path.c_str(), "rb");
    CHECK(f != nullptr);
    if (f) {
        uint8_t buf[16] = {0};
        const size_t n = std::fread(buf, 1, sizeof(buf), f);
        std::fclose(f);
        CHECK(n == sizeof(buf));
        // an ELF's first page always starts with the ELF magic
        CHECK(buf[0] == 0x7f && buf[1] == 'E' && buf[2] == 'L' && buf[3] == 'F');
    }

    // invalid ranges are refused cleanly
    MappedModule bad;
    bad.base = 0; bad.end = 100;
    CHECK(!dumper.DumpModule(bad, path).ok);
    MappedModule backwards;
    backwards.base = 100; backwards.end = 50;
    CHECK(!dumper.DumpModule(backwards, path).ok);

    // a hole in the middle (unmapped address) is zero-filled, not fatal
    MappedModule withHole = *self;
    withHole.base = 0x1;                 // address 0x1 is never mapped
    withHole.end = 0x1 + 4096;
    const DumpResult r2 = dumper.DumpModule(withHole, path);
    CHECK(r2.ok);
    CHECK(r2.pagesSkipped >= 1);

    CHECK(!dumper.DumpModule(small, "/nonexistent_dir/x.bin").ok);
}

static void TestMetadataHeader() {
    // The full table-of-content parsing logic itself is tested exhaustively in
    // test_il2cpp_metadata.cpp (logic/Il2CppMetadata.*). This just proves RuntimeDumper's thin
    // file-reading wrapper reaches it correctly.
    std::printf("[il2cpp metadata header: via RuntimeDumper's file wrapper]\n");
    uint8_t bad[12] = {1, 2, 3, 4, 20, 0, 0, 0, 0, 0, 0, 0};
    const std::string path = "/tmp/carrom_metadata_test.dat";
    std::FILE* f = std::fopen(path.c_str(), "wb");
    std::fwrite(bad, 1, sizeof(bad), f);
    std::fclose(f);
    auto m = RuntimeDumper::ReadMetadataHeaderFromFile(path);
    CHECK(!m.ok);
    CHECK(m.error.find("0xFAB11BAF") != std::string::npos);
    CHECK(!RuntimeDumper::ReadMetadataHeaderFromFile("/nonexistent/x.dat").ok);
}

int main() {
    TestEnumerateRealProcess();
    TestDumpModule();
    TestMetadataHeader();
    return Finish("test_runtime_dumper");
}
