// Minimal test harness: no framework, exit code = number of failed checks (capped).
#pragma once
#include <cmath>
#include <cstdio>

inline int g_failed = 0, g_passed = 0;

#define CHECK(cond)                                                              \
    do {                                                                         \
        if (cond) { ++g_passed; }                                                \
        else { ++g_failed; std::printf("  FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond); } \
    } while (0)

#define CHECK_NEAR(a, b, tol)                                                    \
    do {                                                                         \
        const double va_ = (a), vb_ = (b);                                       \
        if (std::fabs(va_ - vb_) <= (tol)) { ++g_passed; }                       \
        else { ++g_failed; std::printf("  FAIL %s:%d  %s=%g  %s=%g (tol %g)\n", __FILE__, __LINE__, #a, va_, #b, vb_, (double)(tol)); } \
    } while (0)

inline int Finish(const char* name) {
    std::printf("%s: %d passed, %d failed\n", name, g_passed, g_failed);
    return g_failed ? 1 : 0;
}
