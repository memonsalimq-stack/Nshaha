// End-to-end on host: fake snapshot + fake transform + fake touch sink, real App/UI/planner/executor.
#include <sys/stat.h>

#include <cstdio>
#include <vector>

#include "app/App.h"
#include "check.h"
#include "imgui.h"

using namespace carrom;

struct FakeSink : TouchSink {
    struct Ev { char kind; float x, y; };
    std::vector<Ev> ev;
    bool Available() const override { return true; }
    void Begin(int, float x, float y) override { ev.push_back({'B', x, y}); }
    void Move(int, float x, float y) override { ev.push_back({'M', x, y}); }
    void End(int, float x, float y) override { ev.push_back({'E', x, y}); }
};

static FrameSnapshot Snap() {
    FrameSnapshot s;
    s.valid = true; s.generation = 7; s.playerTurn = true; s.targetPiece = PieceType::White;
    SnapshotPiece st; st.id = 0; st.type = PieceType::Striker; st.state = PieceState::Default; st.pos = {0, 0};
    SnapshotPiece w; w.id = 1; w.type = PieceType::White; w.state = PieceState::Default; w.pos = {20, 20};
    SnapshotPiece b; b.id = 2; b.type = PieceType::Black; b.state = PieceState::Default; b.pos = {-20, 10};
    s.pieces = {st, w, b};
    return s;
}

static WorldAffine Affine() {
    WorldAffine a; a.ox = 347; a.oy = 768; a.vxx = 9; a.vyy = 9; a.valid = true;
    return a;
}

struct Rig {
    App app;
    FakeSink sink;
    float W = 694.f, H = 1536.f;
    double now = 100.0;
    Rig() {
        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        ImGuiIO& io = ImGui::GetIO();
        io.IniFilename = nullptr;
        io.DisplaySize = ImVec2(W, H);
        io.DeltaTime = 1.f / 60.f;
        ImFontConfig cfg; cfg.SizePixels = 40.f;
        io.Fonts->AddFontDefault(&cfg);
        unsigned char* px; int w, h;
        io.Fonts->GetTexDataAsRGBA32(&px, &w, &h);
        io.Fonts->SetTexID((ImTextureID)1);
        app.Configure("/tmp/carrommod_app_test");
        app.SetTouchSink(&sink);
    }
    ~Rig() { ImGui::DestroyContext(); }
    void Frames(int n) {
        for (int i = 0; i < n; ++i) {
            ImGui::GetIO().MousePos = ImVec2(-100, -100);
            ImGui::NewFrame();
            app.Frame(W, H, 1.f / 60.f, now);
            ImGui::Render();
            now += 1.0 / 60.0;
        }
    }
};

static void TestWithoutOffsets() {
    std::printf("[app: no offsets]\n");
    if (std::system("rm -rf /tmp/carrommod_app_test && mkdir -p /tmp/carrommod_app_test") != 0) std::printf("  (could not reset temp dir)\n");
    Rig r;
    CHECK(!r.app.offsets.HookGameUpdate.set);
    {   // dumps go to a directory inside the app's files dir, created for the user
        struct stat st {};
        CHECK(stat("/tmp/carrommod_app_test/dumps", &st) == 0 && S_ISDIR(st.st_mode));
        CHECK(r.app.ui.dumpDir() == "/tmp/carrommod_app_test/dumps");
    }
    CHECK(r.app.InstallGameHooks() == 0);                   // refuses to hook without an offset
    CHECK(r.app.hooks.records().empty());
    // the offsets template was written for the user to fill in
    FILE* f = std::fopen("/tmp/carrommod_app_test/carrom_offsets.cfg", "r");
    CHECK(f != nullptr);
    if (f) std::fclose(f);
    r.app.settings.autoPlay = true;
    r.app.ui.SetAutoPlaying(true);
    r.Frames(120);                                          // armed but no game state: nothing may happen
    CHECK(r.sink.ev.empty());
    // on the host there is no libgame-CARROM, so the module is reported first; on a device with the
    // module loaded the same bridge reports "offsets missing"
    CHECK(r.app.bridge.StatusText().find("module not found") != std::string::npos);
    CHECK(r.app.offsets.MissingRequired().size() > 5);
}

static void TestAutoplayFires() {
    std::printf("[app: autoplay end to end]\n");
    Rig r;
    r.app.SetSnapshotSource([](FrameSnapshot& s) { s = Snap(); return true; });
    r.app.SetTransformSource([]() { return Affine(); });
    r.app.settings.autoPlay = true;
    r.app.settings.autoPlayMode = 0;
    r.app.ui.SetAutoPlaying(true);

    r.Frames(60 * 8);                                       // 8 simulated seconds
    // exactly one gesture: press, a pull, release
    int b = 0, e = 0, m = 0;
    for (auto& v : r.sink.ev) { b += v.kind == 'B'; e += v.kind == 'E'; m += v.kind == 'M'; }
    CHECK(b >= 1);
    CHECK(e == b);
    CHECK(m > 5);
    CHECK(!r.sink.ev.empty() && r.sink.ev.front().kind == 'B');
    // the press is on the striker's screen position: world (0,0) -> (347, 1536-768)
    CHECK_NEAR(r.sink.ev.front().x, 347.0, 1.0);
    CHECK_NEAR(r.sink.ev.front().y, 768.0, 1.0);
    // shot goes to +x,+y (45 deg): the finger is pulled to the opposite side (left and down on screen)
    CHECK(r.sink.ev[r.sink.ev.size() - 1].x < 347.f);
    CHECK(r.sink.ev[r.sink.ev.size() - 1].y > 768.f);

    // turning autoplay off releases and silences everything
    r.app.ui.SetAutoPlaying(false);
    const size_t n = r.sink.ev.size();
    r.Frames(300);
    CHECK(r.sink.ev.size() == n);
}

static void TestSafetyGates() {
    std::printf("[app: safety gates]\n");
    // armed, state fine, but no transform: must not fire, and must say why
    {
        Rig r;
        r.app.SetSnapshotSource([](FrameSnapshot& s) { s = Snap(); return true; });
        r.app.SetTransformSource([]() { return WorldAffine{}; });
        r.app.settings.autoPlay = true;
        r.app.ui.SetAutoPlaying(true);
        r.Frames(60 * 6);
        CHECK(r.sink.ev.empty());
        CHECK(r.app.autoPlayNote().find("transform") != std::string::npos);
    }
    // only the menu switch on, play button off: nothing fires
    {
        Rig r;
        r.app.SetSnapshotSource([](FrameSnapshot& s) { s = Snap(); return true; });
        r.app.SetTransformSource([]() { return Affine(); });
        r.app.settings.autoPlay = true;
        r.Frames(60 * 6);
        CHECK(r.sink.ev.empty());
    }
    // not my turn: nothing fires
    {
        Rig r;
        r.app.SetSnapshotSource([](FrameSnapshot& s) { s = Snap(); s.playerTurn = false; return true; });
        r.app.SetTransformSource([]() { return Affine(); });
        r.app.settings.autoPlay = true;
        r.app.ui.SetAutoPlaying(true);
        r.Frames(60 * 6);
        CHECK(r.sink.ev.empty());
    }
    // snapshot source failing every frame: no crash, no action
    {
        Rig r;
        r.app.SetSnapshotSource([](FrameSnapshot&) { return false; });
        r.app.settings.autoPlay = true;
        r.app.ui.SetAutoPlaying(true);
        r.Frames(120);
        CHECK(r.sink.ev.empty());
    }
}

static void TestPredictionIsDrawn() {
    std::printf("[app: prediction line]\n");
    Rig r;
    r.app.SetSnapshotSource([](FrameSnapshot& s) { s = Snap(); s.aimAngle = 3.14159265 / 4.0; s.aimPower = 0.8; return true; });
    r.app.SetTransformSource([]() { return Affine(); });
    r.app.settings.predictionLine = true;
    r.Frames(10);
    CHECK(r.app.predLive.scene.piecesCount == 3);
    CHECK(r.app.predLive.scene.pieces[0].positions.size() >= 2);
    r.app.settings.predictionLine = false;
    r.app.predLive.Invalidate();
    r.Frames(5);
    CHECK(r.app.predLive.scene.piecesCount == 0);           // disabled: not even computed
}

int main() {
    TestWithoutOffsets();
    TestAutoplayFires();
    TestSafetyGates();
    TestPredictionIsDrawn();
    return Finish("test_app");
}
