// Pattern/constant scanning tested against THIS process' own real memory — a module found via
// EnumerateModules, with known bytes placed in a real buffer at a real address (no mocking).
#include <cstring>

#include "check.h"
#include "logic/PatternScanner.h"
#include "platform/ModuleEnum.h"

using namespace carrom;

namespace {
// Deliberately NOT static/const, so the compiler can't fold these into immediates that never
// appear in memory as a literal sequence — they must actually be loaded from .data at runtime
// for the scan to find real bytes, the same way a game's own constants live in its binary.
volatile uint8_t g_marker[12] = {0xDE, 0xAD, 0x11, 0x22, 0x33, 0xBE, 0xEF, 0x00, 0x44, 0x55, 0x66, 0x77};
volatile float g_canaryFloat = 2.10f;      // STRIKER_RADIUS, same value the old Carrom source used
volatile double g_canaryDouble = 0.002;    // TIME_PER_TICK, same value the old Carrom source used
uintptr_t P(const void* p) { return (uintptr_t)p; }
} // namespace

static void TestParsePattern() {
    std::printf("[parse pattern]\n");
    std::string err;
    auto p1 = ParsePattern("DE AD ?? 22", &err);
    CHECK(p1.size() == 4 && err.empty());
    CHECK(p1[0].value == 0xDE && !p1[0].wildcard);
    CHECK(p1[2].wildcard);
    CHECK(p1[3].value == 0x22);

    auto p2 = ParsePattern("de ad ? 22");   // lowercase, single '?'
    CHECK(p2.size() == 4 && p2[2].wildcard);

    auto bad = ParsePattern("DE AD ZZ", &err);
    CHECK(bad.empty());
    CHECK(err.find("invalid") != std::string::npos);

    auto empty = ParsePattern("", &err);
    CHECK(empty.empty());
}

static void TestScanBuffer() {
    std::printf("[scan buffer]\n");
    uint8_t buf[6] = {0x11, 0xAA, 0xBB, 0x11, 0xAA, 0xCC};
    auto pat = ParsePattern("11 AA ??");
    auto hits = PatternScanner::ScanBuffer(buf, sizeof(buf), pat);
    CHECK(hits.size() == 2 && hits[0] == 0 && hits[1] == 3);

    auto noHit = PatternScanner::ScanBuffer(buf, sizeof(buf), ParsePattern("FF FF"));
    CHECK(noHit.empty());

    auto capped = PatternScanner::ScanBuffer(buf, sizeof(buf), pat, 1);
    CHECK(capped.size() == 1);

    CHECK(PatternScanner::ScanBuffer(nullptr, 10, pat).empty());
    CHECK(PatternScanner::ScanBuffer(buf, 1, pat).empty());   // buffer shorter than pattern
}

static void TestScanRealModule() {
    std::printf("[scan: real self-process module]\n");
    const auto mods = EnumerateModules();
    const MappedModule* self = nullptr;
    for (const auto& m : mods)
        if (m.name.find("test_pattern_scanner") != std::string::npos) { self = &m; break; }
    CHECK(self != nullptr);
    if (!self) return;

    PatternScanner scanner;
    // the marker bytes really are mapped inside this module's address range
    CHECK(P((const void*)g_marker) >= self->base && P((const void*)g_marker) < self->end);

    auto pat = ParsePattern("DE AD ?? 22 33 BE EF");
    auto hits = scanner.ScanModule(*self, pat, 8);
    bool found = false;
    for (auto addr : hits) if (addr == P((const void*)g_marker)) found = true;
    CHECK(found);

    // a pattern that cannot occur
    auto noPat = ParsePattern("13 37 13 37 13 37 13 37 13 37");
    CHECK(scanner.ScanModule(*self, noPat).empty());

    // an invalid/empty module range never crashes, just returns nothing
    MappedModule empty;
    CHECK(scanner.ScanModule(empty, pat).empty());
}

static void TestFindConstantsRealModule() {
    std::printf("[find float/double constants: real self-process module]\n");
    const auto mods = EnumerateModules();
    const MappedModule* self = nullptr;
    for (const auto& m : mods)
        if (m.name.find("test_pattern_scanner") != std::string::npos) { self = &m; break; }
    CHECK(self != nullptr);
    if (!self) return;

    PatternScanner scanner;
    auto floatHits = scanner.FindFloat(*self, 2.10f);
    bool foundF = false;
    for (auto addr : floatHits) if (addr == P((const void*)&g_canaryFloat)) foundF = true;
    CHECK(foundF);

    auto doubleHits = scanner.FindDouble(*self, 0.002);
    bool foundD = false;
    for (auto addr : doubleHits) if (addr == P((const void*)&g_canaryDouble)) foundD = true;
    CHECK(foundD);

    // "not found" and "tolerance" checks use a NARROW, deterministic range (just the two
    // canaries themselves) rather than the whole multi-megabyte process image: a random made-up
    // value can coincidentally match SOMEWHERE in a large real binary purely by chance (a float
    // has ~7 significant digits, so a handful of accidental hits across megabytes of unrelated
    // code/data is expected, not a bug), so scanning the whole module is not a reliable way to
    // prove a value is absent.
    MappedModule narrow;
    narrow.base = P((const void*)&g_canaryFloat);
    narrow.end = narrow.base + sizeof(g_canaryFloat) + sizeof(g_canaryDouble) + 16;

    CHECK(scanner.FindFloat(narrow, 123456.789f).empty());
    CHECK(scanner.FindFloat(narrow, 2.10f + 0.01f, 1e-5f).empty());   // too far for a tight tolerance

    auto withTol = scanner.FindFloat(narrow, 2.10f + 0.001f, 0.01f);  // close enough for a loose one
    bool foundTol = false;
    for (auto addr : withTol) if (addr == P((const void*)&g_canaryFloat)) foundTol = true;
    CHECK(foundTol);
}

static void TestBufferConstantEdgeCases() {
    std::printf("[find float/double in buffer: edge cases]\n");
    float f = 3.5f;
    uint8_t buf[16] = {0};
    std::memcpy(buf + 4, &f, 4);  // aligned at offset 4
    auto hits = PatternScanner::FindFloatInBuffer(buf, sizeof(buf), 3.5f);
    CHECK(hits.size() == 1 && hits[0] == 4);

    // misaligned occurrence (offset 1, not a multiple of 4) must NOT be reported
    uint8_t buf2[16] = {0};
    std::memcpy(buf2 + 1, &f, 4);
    CHECK(PatternScanner::FindFloatInBuffer(buf2, sizeof(buf2), 3.5f).empty());

    CHECK(PatternScanner::FindFloatInBuffer(nullptr, 10, 1.0f).empty());
    CHECK(PatternScanner::FindDoubleInBuffer(nullptr, 10, 1.0).empty());
    CHECK(PatternScanner::FindFloatInBuffer(buf, 2, 3.5f).empty()); // too short
    CHECK(PatternScanner::FindFloatInBuffer(buf, sizeof(buf), std::nanf("")).empty());
}

int main() {
    TestParsePattern();
    TestScanBuffer();
    TestScanRealModule();
    TestFindConstantsRealModule();
    TestBufferConstantEdgeCases();
    return Finish("test_pattern_scanner");
}
