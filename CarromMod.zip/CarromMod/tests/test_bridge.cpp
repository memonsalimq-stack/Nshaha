// GameBridge test against a FAKE game object graph built in host memory.
// The offsets used here are arbitrary test numbers: they only prove that the pointer-chasing,
// validation and unit handling are correct for whatever offsets the user later supplies.
#include <cstdint>
#include <cstring>

#include "check.h"
#include "config/Offsets.h"
#include "game/GameBridge.h"
#include "platform/Memory.h"

using namespace carrom;

namespace {
template <class T> void Put(uint8_t* base, size_t off, T v) { std::memcpy(base + off, &v, sizeof(T)); }

alignas(16) uint8_t g_gm[0x800], g_rules[0x200], g_board[0x200], g_vs[0x200], g_guide[0x100], g_sm[0x100],
    g_stackObj[0x100], g_state[0x100], g_piecesArr[0x100], g_props[0x100], g_english[0x100], g_classVec[16],
    g_pockets[64], g_piece[4][0x100], g_stackData[16], g_pieceData[8 * 8], g_modulePage[0x400], g_strikerProps[0x100];
uintptr_t P(const void* p) { return (uintptr_t)p; }

// fake world->screen function used by OnGameUpdate: x' = 100 + 10x , y' = 200 + 20y (scaled by scale)
struct Dbl2 { double x, y; };
Dbl2 FakeTransform(uintptr_t, double x, double y) { return {100.0 + 10.0 * x, 200.0 + 20.0 * y}; }
float g_scale = 2.0f;

Offsets MakeOffsets(const ModuleInfo& mod) {
    Offsets o;
    auto set = [](OffsetValue& v, uintptr_t x) { v.value = x; v.set = true; };
    set(o.HookGameUpdate, 0x40);
    set(o.GmRules, 0x10); set(o.GmBoard, 0x18); set(o.GmVisualStriker, 0x20); set(o.GmVisualEnglish, 0x28);
    set(o.GmStateManager, 0x30);
    set(o.SmStack, 0x08); set(o.ArrCount, 0x08); set(o.ArrData, 0x18); set(o.StateId, 0x18);
    set(o.BoardPieces, 0x40); set(o.BoardProps, 0x48); set(o.PropsPockets, 0x68);
    set(o.PiecePos, 0x50); set(o.PieceRadius, 0x98); set(o.PieceType, 0xa0); set(o.PieceState, 0xa4);
    set(o.StrikerGuide, 0x30); set(o.StrikerPower, 0x38); set(o.GuideAimAngle, 0x28);
    set(o.EnglishValue, 0x20);
    set(o.RulesClassifications, 0xC8); set(o.RulesQueenCover, 0x68); set(o.RulesPottedPocket, 0x118);
    set(o.PropsEnglishMul, 0x28); set(o.PropsMaxPower, 0x30);
    set(o.StrikerProps, P(&g_modulePage[0]) - mod.base);
    set(o.TransformFn, P((void*)&FakeTransform) - mod.base);
    set(o.TransformScale, P(&g_scale) - mod.base);
    return o;
}

void BuildWorld(int stateId, int myClass) {
    std::memset(g_gm, 0, sizeof g_gm);
    Put<uintptr_t>(g_gm, 0x10, P(g_rules));
    Put<uintptr_t>(g_gm, 0x18, P(g_board));
    Put<uintptr_t>(g_gm, 0x20, P(g_vs));
    Put<uintptr_t>(g_gm, 0x28, P(g_english));
    Put<uintptr_t>(g_gm, 0x30, P(g_sm));

    Put<uintptr_t>(g_sm, 0x08, P(g_stackObj));
    Put<uintptr_t>(g_stackObj, 0x08, 2);
    Put<uintptr_t>(g_stackObj, 0x18, P(g_stackData));
    Put<uintptr_t>(g_stackData, 0, P(g_state));        // [0] = some other state
    Put<uintptr_t>(g_stackData, 8, P(g_state));        // [1] = top of the stack
    Put<int32_t>(g_state, 0x18, stateId);

    Put<uintptr_t>(g_board, 0x40, P(g_piecesArr));
    Put<uintptr_t>(g_board, 0x48, P(g_props));
    Put<uintptr_t>(g_piecesArr, 0x08, 4);
    Put<uintptr_t>(g_piecesArr, 0x18, P(g_pieceData));
    const double pos[4][2] = {{0.0, -23.5}, {5.0, 3.0}, {-8.0, 10.0}, {12.0, -4.0}};
    const int types[4] = {3, 0, 1, 0};
    for (int i = 0; i < 4; ++i) {
        Put<uintptr_t>(g_pieceData, i * 8, P(g_piece[i]));
        std::memset(g_piece[i], 0, 0x100);
        Put<double>(g_piece[i], 0x50, pos[i][0]);
        Put<double>(g_piece[i], 0x58, pos[i][1]);
        Put<double>(g_piece[i], 0x98, i == 0 ? 2.1 : 1.55);
        Put<int32_t>(g_piece[i], 0xa0, types[i]);
        Put<int32_t>(g_piece[i], 0xa4, 1);
    }
    const double pk[8] = {-34.5, -34.5, 34.5, -34.5, 34.5, 34.5, -34.5, 34.5};
    std::memcpy(g_pockets, pk, sizeof pk);
    Put<uintptr_t>(g_props, 0x68, P(g_pockets));

    Put<uintptr_t>(g_vs, 0x30, P(g_guide));
    Put<double>(g_vs, 0x38, 0.6);
    Put<double>(g_guide, 0x28, 1.2);

    Put<uintptr_t>(g_rules, 0xC8, P(g_classVec));
    Put<int32_t>(g_classVec, 0, myClass);
    Put<int32_t>(g_classVec, 4, myClass == 0 ? 1 : 0);
    Put<uint8_t>(g_rules, 0x68, 1);
    Put<uint32_t>(g_rules, 0x118, 3);

    Put<double>(g_english, 0x20, 0.5);
    Put<double>(g_english, 0x28, -0.25);

    // striker properties live behind a pointer stored at the module "RVA" (first slot of g_modulePage)
    Put<uintptr_t>(g_modulePage, 0, P(g_strikerProps));
    Put<double>(g_strikerProps, 0x28, 2.0);    // english multiplier
    Put<double>(g_strikerProps, 0x30, 150.0);  // max power
}
} // namespace

static void TestReadyPath() {
    std::printf("[bridge ready path]\n");
    ModuleInfo mod;
    mod.found = true; mod.path = "fake"; mod.base = P(&g_modulePage[0]); mod.size = UINTPTR_MAX;
    const Offsets off = MakeOffsets(mod);
    BuildWorld(/*stateId=*/4, /*myClass=*/0);

    GameBridge b;
    b.Configure(mod, off);
    CHECK(b.status() == GameBridge::Status::WaitingForGame);

    FrameSnapshot snap;
    CHECK(!b.BuildSnapshot(snap));         // no game update seen yet: must not read anything
    CHECK(!snap.valid);

    b.OnGameUpdate(P(g_gm));
    CHECK(b.BuildSnapshot(snap));
    CHECK(b.status() == GameBridge::Status::Ready);
    CHECK(snap.valid);
    CHECK(snap.playerTurn);
    CHECK(snap.pieces.size() == 4);
    CHECK(snap.pieces[0].type == PieceType::Striker);
    CHECK_NEAR(snap.pieces[0].pos.x, 0.0, 1e-9);
    CHECK_NEAR(snap.pieces[0].pos.y, -23.5, 1e-9);
    CHECK_NEAR(snap.pieces[0].radius, 2.1, 1e-9);
    CHECK(snap.pieces[2].type == PieceType::Black);
    CHECK(snap.targetPiece == PieceType::White);
    CHECK(snap.queenCoverRequired);
    CHECK(snap.pottedPocketId == 3);
    CHECK_NEAR(snap.aimAngle, 1.2, 1e-9);
    CHECK_NEAR(snap.aimPower, 0.6, 1e-9);
    CHECK_NEAR(snap.maxPower, 150.0, 1e-9);
    CHECK_NEAR(snap.spin.x, 1.0, 1e-9);     // 0.5 * 2.0
    CHECK_NEAR(snap.spin.y, -0.5, 1e-9);    // -0.25 * 2.0
    CHECK_NEAR(snap.pockets[2].x, 34.5, 1e-9);

    // the same table gives the same generation; moving a piece changes it
    FrameSnapshot snap2;
    CHECK(b.BuildSnapshot(snap2));
    CHECK(snap2.generation == snap.generation);
    Put<double>(g_piece[1], 0x50, 6.0);
    CHECK(b.BuildSnapshot(snap2));
    CHECK(snap2.generation != snap.generation);

    // the sampled transform from the (fake) game function
    const WorldAffine a = b.Transform();
    CHECK(a.valid);
    CHECK_NEAR(a.ox, 100.0 * 2.0, 1e-9);
    CHECK_NEAR(a.vxx, 10.0 * 2.0, 1e-9);
    CHECK_NEAR(a.vyy, 20.0 * 2.0, 1e-9);

    // not my turn: classification index flips to the opponent slot
    BuildWorld(/*stateId=*/5, /*myClass=*/0);
    CHECK(b.BuildSnapshot(snap2));
    CHECK(!snap2.playerTurn);
    CHECK(snap2.targetPiece == PieceType::Black);
}

static void TestFailureModes() {
    std::printf("[bridge failure modes]\n");
    ModuleInfo mod;
    mod.found = true; mod.base = P(&g_modulePage[0]); mod.size = UINTPTR_MAX;

    // 1. nothing configured: refuses, and says why
    {
        GameBridge b;
        b.Configure(mod, Offsets{});
        CHECK(b.status() == GameBridge::Status::MissingOffsets);
        CHECK(!b.MissingRequired().empty());
        FrameSnapshot s;
        b.OnGameUpdate(P(g_gm));
        CHECK(!b.BuildSnapshot(s));
        CHECK(b.StatusText().find("offsets missing") != std::string::npos);
    }
    // 2. module missing
    {
        GameBridge b;
        b.Configure(ModuleInfo{}, MakeOffsets(mod));
        CHECK(b.status() == GameBridge::Status::NoModule);
    }
    // 3. garbage pointer in the graph: fails cleanly, no crash
    {
        const Offsets off = MakeOffsets(mod);
        BuildWorld(4, 0);
        Put<uintptr_t>(g_gm, 0x18, 0xdeadbeef00ULL);       // board pointer -> unmapped
        GameBridge b;
        b.Configure(mod, off);
        b.OnGameUpdate(P(g_gm));
        FrameSnapshot s;
        CHECK(!b.BuildSnapshot(s));
        CHECK(b.status() == GameBridge::Status::ReadFailed);
        CHECK(!s.valid);
    }
    // 4. absurd piece count
    {
        const Offsets off = MakeOffsets(mod);
        BuildWorld(4, 0);
        Put<uintptr_t>(g_piecesArr, 0x08, 100000);
        GameBridge b;
        b.Configure(mod, off);
        b.OnGameUpdate(P(g_gm));
        FrameSnapshot s;
        CHECK(!b.BuildSnapshot(s));
    }
    // 5. no striker / two strikers
    {
        const Offsets off = MakeOffsets(mod);
        BuildWorld(4, 0);
        Put<int32_t>(g_piece[0], 0xa0, 0);                  // striker turned into a white piece
        GameBridge b;
        b.Configure(mod, off);
        b.OnGameUpdate(P(g_gm));
        FrameSnapshot s;
        CHECK(!b.BuildSnapshot(s));
    }
    // 6. NaN coordinates are skipped, not propagated
    {
        const Offsets off = MakeOffsets(mod);
        BuildWorld(4, 0);
        Put<double>(g_piece[2], 0x50, std::nan(""));
        GameBridge b;
        b.Configure(mod, off);
        b.OnGameUpdate(P(g_gm));
        FrameSnapshot s;
        CHECK(b.BuildSnapshot(s));
        CHECK(s.pieces.size() == 3);
    }
}

static void TestMemory() {
    std::printf("[safe memory]\n");
    CHECK(mem::Available());
    int v = 0;
    int x = 1234;
    CHECK(mem::Read((uintptr_t)&x, &v));
    CHECK(v == 1234);
    CHECK(!mem::Read(0x10, &v));                  // below the first page
    CHECK(!mem::Read(0xdeadbeef000ULL, &v));      // unmapped
    CHECK(mem::PlausiblePointer(0x7000000000ULL));
    CHECK(!mem::PlausiblePointer(0x1234567));     // misaligned
    CHECK(!mem::PlausiblePointer(0));
}

int main() {
    TestMemory();
    TestReadyPath();
    TestFailureModes();
    return Finish("test_bridge");
}
