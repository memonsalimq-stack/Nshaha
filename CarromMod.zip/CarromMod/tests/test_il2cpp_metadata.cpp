// These tests check the port against hand-computed expectations (not just round-tripping the
// same function), and separately prove the read()/candidate-selection plumbing works correctly
// against buffers built from known-good layouts.
#include <cstring>

#include "check.h"
#include "logic/Il2CppMetadata.h"

using namespace carrom::il2cpp;

static void TestCandidatesFor() {
    std::printf("[CandidatesFor: hand-checked against the smali's switch]\n");
    auto c24 = CandidatesFor(24);
    CHECK(c24.size() == 3);
    CHECK(c24[0] == 24.0 && c24[1] == 24.1 && c24[2] == 24.2);

    auto c27 = CandidatesFor(27);
    CHECK(c27.size() == 3);
    CHECK(c27[0] == 27.0 && c27[1] == 27.1 && c27[2] == 27.2);

    auto c29 = CandidatesFor(29);
    CHECK(c29.size() == 2);
    CHECK(c29[0] == 29.0 && c29[1] == 29.1);

    for (int v : {16, 19, 20, 21, 22, 23, 25, 28, 31}) {
        auto c = CandidatesFor(v);
        CHECK(c.size() == 1 && c[0] == (double)v);
    }
}

static void TestLayoutForMembership() {
    std::printf("[LayoutFor: hand-checked table membership at version boundaries]\n");
    auto has = [](const std::vector<std::string>& v, const char* name) {
        for (auto& s : v) if (s == name) return true;
        return false;
    };

    // base 20 tables are always present, at every version this function accepts
    for (double v : {16.0, 20.0, 24.1, 24.2, 27.0, 29.1}) {
        auto l = LayoutFor(v);
        for (const char* base : {"stringLiteral", "string", "methods", "typeDefinitions"}) CHECK(has(l, base));
    }

    CHECK(has(LayoutFor(24.0), "rgctxEntries"));
    CHECK(has(LayoutFor(24.1), "rgctxEntries"));
    CHECK(!has(LayoutFor(24.2), "rgctxEntries"));   // only v <= 24.1

    CHECK(has(LayoutFor(24.5), "metadataUsageLists"));
    CHECK(!has(LayoutFor(25.0), "metadataUsageLists")); // only v <= 24.5

    CHECK(has(LayoutFor(28.9), "attributesInfo"));
    CHECK(!has(LayoutFor(29.0), "attributesInfo"));
    CHECK(has(LayoutFor(29.0), "attributeData"));        // v >= 29 switches to the other pair
    CHECK(!has(LayoutFor(28.9), "attributeData"));

    CHECK(!has(LayoutFor(18.9), "unresolvedVirtualCallParameterTypes")); // needs v >= 19
    CHECK(has(LayoutFor(19.0), "unresolvedVirtualCallParameterTypes"));
    CHECK(!has(LayoutFor(24.6), "unresolvedVirtualCallParameterTypes")); // and v <= 24.5

    CHECK(!has(LayoutFor(28.9), "unresolvedIndirectCallParameterTypes"));
    CHECK(has(LayoutFor(29.0), "unresolvedIndirectCallParameterTypes"));

    CHECK(!has(LayoutFor(20.9), "windowsRuntimeTypeNames"));
    CHECK(has(LayoutFor(21.0), "windowsRuntimeTypeNames"));

    CHECK(!has(LayoutFor(26.9), "windowsRuntimeStrings"));
    CHECK(has(LayoutFor(27.0), "windowsRuntimeStrings"));

    CHECK(!has(LayoutFor(21.9), "exportedTypeDefinitions"));
    CHECK(has(LayoutFor(22.0), "exportedTypeDefinitions"));
}

namespace {
std::vector<uint8_t> BuildBuffer(int32_t rawVersion, double actualLayoutVersion,
                                 const std::vector<std::pair<int32_t, int32_t>>& values) {
    const auto layout = LayoutFor(actualLayoutVersion);
    const size_t size = 8 + layout.size() * 8;
    std::vector<uint8_t> buf(size, 0);
    uint32_t magic = kMetadataMagic;
    std::memcpy(buf.data(), &magic, 4);
    std::memcpy(buf.data() + 4, &rawVersion, 4);
    for (size_t i = 0; i < layout.size(); ++i) {
        int32_t off = i < values.size() ? values[i].first : (int32_t)(1000 + i);
        int32_t cnt = i < values.size() ? values[i].second : (int32_t)(10 + i);
        std::memcpy(buf.data() + 8 + i * 8, &off, 4);
        std::memcpy(buf.data() + 12 + i * 8, &cnt, 4);
    }
    // the first table's own recorded offset must equal the header size for the selection check
    int32_t headerSize = (int32_t)size;
    std::memcpy(buf.data() + 8, &headerSize, 4);
    return buf;
}
} // namespace

static void TestParseSingleCandidateVersion() {
    std::printf("[parse: a plain, single-candidate version]\n");
    auto buf = BuildBuffer(20, 20.0, {});
    MetadataResult r = ParseMetadataHeader(buf.data(), buf.size());
    CHECK(r.ok);
    CHECK(r.magic == kMetadataMagic);
    CHECK(r.rawVersion == 20);
    CHECK(r.resolvedVersion == 20.0);
    CHECK(r.candidatesTried.size() == 1);
    const auto expected = LayoutFor(20.0);
    CHECK(r.tables.size() == expected.size());
    for (size_t i = 0; i < expected.size(); ++i) CHECK(r.tables[i].name == expected[i]);
    CHECK(r.tables[0].offset == (int32_t)buf.size());   // stringLiteral offset == header size
    CHECK(r.tables[1].count == 11);                     // stringLiteralData's test count value
}

static void TestParseDisambiguatesSubVersion() {
    std::printf("[parse: raw=24 resolves to the sub-version whose layout size actually matches]\n");
    // 24.2's layout is one table SHORTER than 24.0/24.1 (no rgctxEntries): build a buffer sized
    // for 24.2 and confirm the reader picks 24.2, not the first candidate (24.0).
    auto buf = BuildBuffer(24, 24.2, {});
    MetadataResult r = ParseMetadataHeader(buf.data(), buf.size());
    CHECK(r.ok);
    CHECK(r.resolvedVersion == 24.2);
    CHECK(r.candidatesTried.size() == 3);
    bool hasRgctx = false;
    for (auto& t : r.tables) if (t.name == "rgctxEntries") hasRgctx = true;
    CHECK(!hasRgctx);

    // 24.0 and 24.1 produce an IDENTICAL layout (same size): the first matching candidate (24.0)
    // must win, since that's exactly what the ported loop does (try in order, first match wins).
    auto buf2 = BuildBuffer(24, 24.0, {});
    MetadataResult r2 = ParseMetadataHeader(buf2.data(), buf2.size());
    CHECK(r2.ok);
    CHECK(r2.resolvedVersion == 24.0);
}

static void TestRejections() {
    std::printf("[parse: rejects bad magic, bad version range, and unmatched layouts]\n");
    uint8_t badMagic[12] = {1, 2, 3, 4, 20, 0, 0, 0, 0, 0, 0, 0};
    MetadataResult r1 = ParseMetadataHeader(badMagic, sizeof(badMagic));
    CHECK(!r1.ok);
    CHECK(r1.error.find("0xFAB11BAF") != std::string::npos);

    auto buf = BuildBuffer(20, 20.0, {});
    int32_t tooLow = 10;
    std::memcpy(buf.data() + 4, &tooLow, 4);
    MetadataResult r2 = ParseMetadataHeader(buf.data(), buf.size());
    CHECK(!r2.ok);
    CHECK(r2.error.find("unsupported") != std::string::npos);

    int32_t tooHigh = 999;
    std::memcpy(buf.data() + 4, &tooHigh, 4);
    MetadataResult r3 = ParseMetadataHeader(buf.data(), buf.size());
    CHECK(!r3.ok);

    // corrupt the first-table offset so it matches no candidate's computed size
    auto buf2 = BuildBuffer(20, 20.0, {});
    int32_t garbage = 123456;
    std::memcpy(buf2.data() + 8, &garbage, 4);
    MetadataResult r4 = ParseMetadataHeader(buf2.data(), buf2.size());
    CHECK(!r4.ok);
    CHECK(r4.error.find("no known table layout") != std::string::npos);
    CHECK(r4.candidatesTried.size() == 1);

    CHECK(!ParseMetadataHeader(nullptr, 100).ok);
    CHECK(!ParseMetadataHeader(buf.data(), 4).ok);   // too short even for magic+version+peek
}

static void TestFromFile() {
    std::printf("[parse: from a real file on disk]\n");
    auto buf = BuildBuffer(29, 29.1, {});
    const std::string path = "/tmp/carrom_il2cpp_metadata_test.dat";
    std::FILE* f = std::fopen(path.c_str(), "wb");
    std::fwrite(buf.data(), 1, buf.size(), f);
    std::fclose(f);

    MetadataResult r = ParseMetadataHeaderFromFile(path);
    CHECK(r.ok);
    // 29.0 and 29.1 produce an identical layout (same ambiguity as 24.0/24.1): the first
    // candidate in the list (29.0) wins, same as the real tool's try-in-order loop.
    CHECK(r.resolvedVersion == 29.0);
    bool hasIndirect = false;
    for (auto& t : r.tables) if (t.name == "unresolvedIndirectCallParameterTypes") hasIndirect = true;
    CHECK(hasIndirect);

    CHECK(!ParseMetadataHeaderFromFile("/nonexistent/x.dat").ok);
}

int main() {
    TestCandidatesFor();
    TestLayoutForMembership();
    TestParseSingleCandidateVersion();
    TestParseDisambiguatesSubVersion();
    TestRejections();
    TestFromFile();
    return Finish("test_il2cpp_metadata");
}
