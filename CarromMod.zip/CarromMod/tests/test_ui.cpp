// Headless ImGui: runs the real menu code for many frames with simulated mouse input.
// No GL, no game. Proves the UI compiles, never asserts, and that clicks change Settings.
#include <cstdio>

#include "check.h"
#include "imgui.h"
#include "logic/AutoPlayer.h"
#include "logic/OffsetTester.h"
#include "logic/MetadataFinder.h"
#include "logic/PatternScanner.h"
#include "logic/RuntimeDumper.h"
#include "logic/Prediction.h"
#include "ui/PredictionDraw.h"
#include "ui/Ui.h"

using namespace carrom;

static const float W = 694.f, H = 1536.f;

struct Harness {
    Settings settings;
    OffsetTester tester;
    RuntimeDumper dumper;
    PatternScanner scanner;
    MetadataFinder finder;
    ui::Ui ui{settings, tester, dumper, scanner, finder};
    ui::UiStatus status;
    ui::UiOutput last;
    Harness() {
        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        ImGuiIO& io = ImGui::GetIO();
        io.IniFilename = nullptr;
        io.DisplaySize = ImVec2(W, H);
        io.DeltaTime = 1.0f / 60.0f;
        ImFontConfig cfg;
        cfg.SizePixels = 40.f;
        io.Fonts->AddFontDefault(&cfg);
        unsigned char* px; int w, h;
        io.Fonts->GetTexDataAsRGBA32(&px, &w, &h);
        io.Fonts->SetTexID((ImTextureID)1);
        status.bridge = "offsets missing: 33 required keys unset";
        status.module = "not found";
        status.offsetsTotal = Offsets_TotalForTest();
    }
    ~Harness() { ImGui::DestroyContext(); }
    static int Offsets_TotalForTest() { return 36; }

    void Frame(float mx, float my, bool down) {
        ImGuiIO& io = ImGui::GetIO();
        io.MousePos = ImVec2(mx, my);
        io.MouseDown[0] = down;
        ImGui::NewFrame();
        last = ui.Draw(status, W, H);
        ImGui::Render();
    }
    void Click(float x, float y) {
        Frame(x, y, false);   // hover
        Frame(x, y, true);    // press
        Frame(x, y, true);
        Frame(x, y, false);   // release
        Frame(x, y, false);
    }
    void Idle(int n) { for (int i = 0; i < n; ++i) Frame(-100, -100, false); }
};

static void TestRendersAndOpens() {
    std::printf("[ui render + open]\n");
    Harness h;
    h.Idle(3);
    CHECK(!h.ui.menuOpen());
    CHECK(h.last.hitRects.size() >= 2);                  // logo + play button always present
    // tap the floating logo button (default position 48,128 size 100)
    h.Click(98, 178);
    CHECK(h.ui.menuOpen());
    h.Idle(10);
    bool menuRect = false;
    for (const auto& r : h.last.hitRects) if ((r.x1 - r.x0) > 300) menuRect = true;
    CHECK(menuRect);                                     // the open menu reports its rect
    // tap it again: closes
    h.Click(98, 178);
    CHECK(!h.ui.menuOpen());
}

static void TestFunctionsTab() {
    std::printf("[ui functions tab clicks]\n");
    Harness h;
    h.ui.SetMenuOpen(true);
    h.Idle(10);
    const float mx = 108.f + 14.f + 100.f;               // inside a toggle row
    auto row = [&](int i) { return 435.f + 64.f + i * 47.f + 20.f; };

    CHECK(h.settings.predictionLine);
    h.Click(mx, row(0));                                  // Enable Prediction -> off
    CHECK(!h.settings.predictionLine);
    h.Click(mx, row(0));
    CHECK(h.settings.predictionLine);

    CHECK(!h.settings.autoPlay);
    h.Click(mx, row(4));                                  // Auto Play -> on
    CHECK(h.settings.autoPlay);
    h.Idle(2);

    // mode buttons appear now: HUMAN is the second pill at y = menuY + 64 + 5*47 + 27 + 24
    CHECK(h.settings.autoPlayMode == 0);
    const float modeW = ((540.f - 28.f) - 8.f) * 0.5f;      // two pills side by side, 8 px gap
    h.Click(108.f + 14.f + modeW + 8.f + modeW * 0.5f, 435.f + 64.f + 5 * 47.f + 27.f + 24.f);
    CHECK(h.settings.autoPlayMode == 1);
}

static void TestTabsAndSliders() {
    std::printf("[ui tabs and sliders]\n");
    Harness h;
    h.ui.SetMenuOpen(true);
    h.Idle(10);
    const float footerY = 435.f + 560.f - 54.f + 20.f;
    const float tabW5 = 540.f / 5.f;
    h.Click(108.f + tabW5 * 2.f + tabW5 * 0.5f, footerY); // third tab: ESP LINE
    h.Idle(2);
    // style card 2 (Sea Blue Glow) at x = 108+14+ (styleW+gap) ...
    const float contentW = 540.f - 28.f;
    const float styleW = (contentW - 10.f) / 2.f;
    h.Click(108.f + 14.f + styleW + 10.f + 20.f, 435.f + 64.f + 29.f + 30.f);
    CHECK(h.settings.lineStyle == 1);

    // thickness slider: click at 100% of its width -> 10
    const float sliderY = 435.f + 64.f + 29.f + 88.f + 15.f + 24.f + 15.f;
    h.Click(108.f + 14.f + contentW - 1.f, sliderY);
    CHECK(h.settings.lineThickness > 9.0f);
    h.Frame(-100, -100, false);
}

static void TestAutoMatchTab() {
    std::printf("[ui auto match tab]\n");
    Harness h;
    h.ui.SetMenuOpen(true);
    h.Idle(10);
    const float footerY = 435.f + 560.f - 54.f + 20.f;
    const float tabW5 = 540.f / 5.f;
    h.Click(108.f + tabW5 + tabW5 * 0.5f, footerY);       // AUTO MATCH tab
    h.Idle(2);
    // Disc Pool button (second of three)
    const float contentW = 540.f - 28.f;
    const float bw = (contentW - 20.f) / 3.f;
    h.Click(108.f + 14.f + bw + 10.f + bw * 0.5f, 435.f + 64.f + 47.f + 20.f + 30.f + 26.f);
    CHECK(h.settings.queueMode == 1);
    // switching mode keeps the coin index in range
    h.settings.coinIndex = 11;
    h.settings.queueMode = 2;
    h.settings.Clamp();
    CHECK(h.settings.coinIndex <= 8);
    h.Idle(3);
}

static void TestSmallAndLandscapeScreens() {
    std::printf("[ui other screen sizes]\n");
    CHECK_NEAR(ui::Ui::UiScale(694, 1536), 1.0, 1e-6);    // portrait design size
    CHECK(ui::Ui::UiScale(2400, 1080) > 1.0);             // landscape: scaled from the short side
    CHECK(ui::Ui::UiScale(100, 100) >= 0.55f);            // clamped
    // menu stays on screen when the surface is tiny
    Harness h;
    ImGui::GetIO().DisplaySize = ImVec2(300, 500);
    h.ui.SetMenuOpen(true);
    for (int i = 0; i < 5; ++i) {
        ImGui::NewFrame();
        h.last = h.ui.Draw(h.status, 300, 500);
        ImGui::Render();
    }
    for (const auto& r : h.last.hitRects) CHECK(r.x1 <= 300.5f && r.y1 <= 500.5f);
}

static void TestPredictionDraw() {
    std::printf("[prediction drawing]\n");
    Harness h;
    Prediction pred;
    FrameSnapshot s;
    s.valid = true; s.generation = 1; s.playerTurn = true;
    SnapshotPiece st; st.type = PieceType::Striker; st.state = PieceState::Default; st.pos = {0, 0};
    SnapshotPiece w; w.type = PieceType::White; w.state = PieceState::Default; w.pos = {20, 20};
    s.pieces = {st, w};
    CHECK(pred.Run(s, false, PI / 4.0, 1.0));

    ScreenMap unusable; unusable.SetViewport(W, H);
    ScreenMap map; map.SetViewport(W, H);
    WorldAffine a; a.ox = 347; a.oy = 768; a.vxx = 9; a.vyy = 9; a.valid = true;
    map.SetAffine(a);

    ImGui::NewFrame();
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    const int before = dl->VtxBuffer.Size;
    ui::DrawPrediction(dl, pred, unusable, h.settings, W, H, false);
    CHECK(dl->VtxBuffer.Size == before);                  // no transform -> draws nothing
    ui::DrawPrediction(dl, pred, map, h.settings, W, H, false);
    CHECK(dl->VtxBuffer.Size > before);                   // with a transform -> lines appear
    const int mid = dl->VtxBuffer.Size;
    Settings off = h.settings;
    off.strikerPath = false; off.puckPaths = false;
    ui::DrawPrediction(dl, pred, map, off, W, H, false);
    CHECK(dl->VtxBuffer.Size > mid);                      // markers still drawn
    ui::DrawPrediction(nullptr, pred, map, h.settings, W, H, false);   // null list is tolerated
    ImGui::Render();
}

static void TestNoTabOverflowsIntoFooter() {
    std::printf("[ui: no tab or page draws into the footer]\n");
    Harness h;
    h.ui.SetMenuOpen(true);
    h.settings.autoPlay = true;                    // shows the extra mode row on FUNCTIONS
    // worst case for lists: many modules, one selected
    std::vector<MappedModule> mods;
    for (int i = 0; i < 9; ++i) {
        MappedModule m; m.name = "libsomething" + std::to_string(i) + ".so"; m.path = "/data/app/x/lib/arm64/" + m.name;
        m.base = 0x7000000000ULL + i * 0x1000000; m.end = m.base + 0x500000; m.everExecutable = true;
        mods.push_back(m);
    }
    h.ui.TestSetModules(mods, 1);
    const float footerTop = 560.f - 54.f;           // design units (menu is 560 high, footer 54)
    struct Case { int tab, page; const char* name; };
    const Case cases[] = {{0, 0, "FUNCTIONS"}, {1, 0, "AUTO MATCH"}, {2, 0, "ESP LINE"}, {3, 0, "TESTER"},
                          {4, 0, "DUMPER/LIBS"}, {4, 1, "DUMPER/METADATA"}, {4, 2, "DUMPER/SCAN"}};
    for (const auto& c : cases) {
        h.ui.TestSetTab(c.tab, c.page);
        h.Idle(4);
        const float bottom = h.ui.contentBottom();
        if (bottom > footerTop - 2.f) std::printf("    %s bottom=%.1f footer=%.1f\n", c.name, bottom, footerTop);
        CHECK(bottom > 0.f);
        CHECK(bottom <= footerTop - 2.f);
    }
}

int main() {
    TestNoTabOverflowsIntoFooter();
    TestRendersAndOpens();
    TestFunctionsTab();
    TestTabsAndSliders();
    TestAutoMatchTab();
    TestSmallAndLandscapeScreens();
    TestPredictionDraw();
    return Finish("test_ui");
}
