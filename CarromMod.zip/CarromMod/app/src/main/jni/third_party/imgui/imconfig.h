// Dear ImGui build configuration for CarromMod. Defaults, minus the demo/metrics code we never call.
#pragma once
#define IMGUI_DISABLE_DEMO_WINDOWS
#define IMGUI_DISABLE_METRICS_WINDOW
#define IMGUI_DISABLE_OBSOLETE_FUNCTIONS
