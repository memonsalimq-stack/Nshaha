#include "ui/Ui.h"

#define IMGUI_DEFINE_MATH_OPERATORS
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>

#include "imgui_internal.h"

namespace carrom::ui {

using namespace ImGui;

namespace {
const ImU32 UI_GOLD = IM_COL32(255, 215, 0, 255);

float ClampF(float v, float lo, float hi) { return std::min(std::max(v, lo), hi); }

// True if the click that just ended on the last item was a tap, not a drag.
bool WasTap() {
    const ImVec2 d = GetMouseDragDelta(ImGuiMouseButton_Left);
    return IsItemHovered() && IsMouseReleased(ImGuiMouseButton_Left) && (d.x * d.x + d.y * d.y) < 9.0f;
}
} // namespace

float Ui::UiScale(float W, float H) {
    // The game runs in portrait (manifest of 19.6.1), and the old layout was designed for a 694 px
    // wide surface. Scaling from the shorter side equals the old Width/694 in portrait and still
    // keeps the menu on screen if the surface is ever reported landscape.
    return ClampF(std::min(W, H) / 694.0f, 0.55f, 3.0f);
}

UiOutput Ui::Draw(const UiStatus& st, float W, float H) {
    UiOutput out;
    const float s = UiScale(W, H);
    ImGuiIO& io = GetIO();

    if (m_open) m_alpha += (1.0f - m_alpha) * io.DeltaTime * 12.0f;
    else m_alpha = 0.0f;
    if (m_alpha > 1.f) m_alpha = 1.f;

    if (m_alpha > 0.01f) DrawMainMenu(st, s, W, H, out);
    DrawFloatingButton(s, W, H, out);
    DrawPlayButton(s, W, H, out);
    if (st.calculating && m_autoPlaying) DrawCalculating(W, H);
    return out;
}

void Ui::DrawCalculating(float W, float H) {
    SetNextWindowPos(ImVec2(W * 0.5f, H * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    PushStyleColor(ImGuiCol_WindowBg, IM_COL32(18, 18, 18, 255));
    PushStyleColor(ImGuiCol_Border, IM_COL32(220, 30, 30, 255));
    PushStyleVar(ImGuiStyleVar_WindowRounding, 18.0f);
    PushStyleVar(ImGuiStyleVar_WindowBorderSize, 2.0f);
    if (Begin("##CalcOverlay", nullptr,
              ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
                  ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoInputs)) {
        SetWindowFontScale(1.4f);
        TextColored(ImVec4(1.0f, 1.0f, 1.0f, 1.0f), "CALCULATING...");
        SetWindowFontScale(1.0f);
    }
    End();
    PopStyleVar(2);
    PopStyleColor(2);
}

void Ui::DrawMainMenu(const UiStatus& st, float s, float W, float H, UiOutput& out) {
    ImGuiIO& io = GetIO();
    const float winW = std::min(m_s.menuW * s, W);
    const float winH = std::min(m_s.menuH * s, H);
    // keep the menu inside the screen (design units)
    m_s.menuX = ClampF(m_s.menuX, 0.f, std::max(0.f, W / s - m_s.menuW));
    m_s.menuY = ClampF(m_s.menuY, 0.f, std::max(0.f, H / s - m_s.menuH));
    const float px = m_s.menuX * s, py = m_s.menuY * s;

    SetNextWindowSize(ImVec2(winW, winH), ImGuiCond_Always);
    SetNextWindowPos(ImVec2(px, py), ImGuiCond_Always);
    PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0));
    PushStyleVar(ImGuiStyleVar_WindowRounding, 18 * s);
    PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0);
    PushStyleVar(ImGuiStyleVar_Alpha, m_alpha);

    const ImGuiWindowFlags flags = ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar |
                                   ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse |
                                   ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove;
    if (Begin("##MainMenu", &m_open, flags)) {
        ImDrawList* dl = GetWindowDrawList();
        const ImVec2 a = GetWindowPos(), b(a.x + winW, a.y + winH);
        dl->AddRectFilled(a, b, IM_COL32(5, 5, 7, 248), 18 * s);
        dl->AddRect(a, b, IM_COL32(112, 82, 15, 255), 18 * s, 0, 2 * s);
        dl->AddRect(ImVec2(a.x + 3 * s, a.y + 3 * s), ImVec2(b.x - 3 * s, b.y - 3 * s),
                    IM_COL32(235, 195, 70, 210), 15 * s, 0, 1 * s);

        SetCursorPos(ImVec2(0, 0));
        InvisibleButton("##MenuDrag", ImVec2(winW, 48 * s));
        if (IsItemActive() && IsMouseDragging(ImGuiMouseButton_Left, 2.0f)) {
            m_s.menuX += io.MouseDelta.x / s;
            m_s.menuY += io.MouseDelta.y / s;
            out.settingsChanged = true;
        }
        SetCursorPos(ImVec2(0, 0));
        DrawContentArea(st, winW, winH, out);
        out.hitRects.push_back({a.x, a.y, b.x, b.y});
    }
    End();
    PopStyleVar(4);
    PopStyleColor();
}

void Ui::DrawContentArea(const UiStatus& st, float winW, float winH, UiOutput& out) {
    ImDrawList* dl = GetWindowDrawList();
    const ImVec2 wp = GetWindowPos();
    const float s = winW / 540.0f;

    const float headerH = 48.0f * s;
    const float footerH = 54.0f * s;
    const float padX = 14.0f * s;
    const float contentTop = 64.0f * s;
    const float footerY = winH - footerH;
    const float contentW = winW - padX * 2.0f;
    const ImFont* font = GetFont();
    const float textPx = 14.0f * s;
    const float titlePx = 13.0f * s;
    const float tabPx = 14.0f * s;
    const float mutedPx = 13.0f * s;
    bool changed = false;

    auto TextAt = [&](const char* text, ImVec2 pos, ImU32 color, float px) { dl->AddText(font, px, pos, color, text); };
    auto CenterText = [&](const char* text, ImVec2 center, ImU32 color, float px) {
        ImVec2 ts = font->CalcTextSizeA(px, FLT_MAX, 0.0f, text);
        dl->AddText(font, px, ImVec2(center.x - ts.x * 0.5f, center.y - ts.y * 0.5f), color, text);
    };

    dl->AddLine(ImVec2(wp.x + padX, wp.y + headerH), ImVec2(wp.x + winW - padX, wp.y + headerH),
                IM_COL32(90, 72, 18, 180), 1.0f * s);
    {
        char head[160];
        std::snprintf(head, sizeof(head), "%s  |  offsets %d/%d", st.bridge.c_str(), st.offsetsSet, st.offsetsTotal);
        TextAt(head, ImVec2(wp.x + padX, wp.y + 14.0f * s), IM_COL32(255, 215, 0, 255), titlePx);
    }

    float cy = contentTop;
    const float rowH = 40.0f * s;
    const float rowGap = 7.0f * s;
    const float rowR = 7.0f * s;

    auto Toggle = [&](const char* idText, const char* label, bool* value) {
        ImGuiWindow* w = GetCurrentWindow();
        const ImGuiID id = w->GetID(idText);
        const ImVec2 a(wp.x + padX, wp.y + cy);
        const ImVec2 b(a.x + contentW, a.y + rowH);
        const ImRect bb(a, b);
        ItemSize(ImVec2(contentW, rowH));
        if (ItemAdd(bb, id)) {
            bool hovered = false, held = false;
            if (ButtonBehavior(bb, id, &hovered, &held)) { *value = !*value; changed = true; }
            dl->AddRectFilled(a, b, hovered ? IM_COL32(31, 31, 37, 255) : IM_COL32(24, 24, 29, 255), rowR);
            dl->AddRect(a, b, IM_COL32(70, 65, 27, 220), rowR, 0, 1.0f * s);
            const ImVec2 ts = font->CalcTextSizeA(textPx, FLT_MAX, 0.0f, label);
            TextAt(label, ImVec2(a.x + 10.0f * s, a.y + (rowH - ts.y) * 0.5f), IM_COL32(225, 225, 230, 255), textPx);
            const float tw = 46.0f * s, th = 24.0f * s, r = th * 0.5f;
            const ImVec2 ta(b.x - tw - 9.0f * s, a.y + (rowH - th) * 0.5f);
            const ImVec2 tb(ta.x + tw, ta.y + th);
            dl->AddRectFilled(ta, tb, *value ? UI_GOLD : IM_COL32(61, 63, 73, 255), r);
            dl->AddRect(ta, tb, IM_COL32(48, 48, 54, 180), r, 0, 1.0f * s);
            dl->AddCircleFilled(ImVec2(*value ? tb.x - r : ta.x + r, ta.y + r), 8.0f * s, IM_COL32(250, 250, 250, 255));
        }
        cy += rowH + rowGap;
    };

    // A horizontal slider drawn in the old style. Writes into *value.
    auto Slider = [&](const char* id, float* value, float minV, float maxV, float h, float rad) {
        ImGuiWindow* w = GetCurrentWindow();
        const ImGuiID iid = w->GetID(id);
        const ImVec2 a(wp.x + padX, wp.y + cy), b(a.x + contentW, a.y + h);
        const ImRect bb(a, b);
        ItemSize(ImVec2(contentW, h));
        if (ItemAdd(bb, iid)) {
            bool hovered = false, held = false;
            ButtonBehavior(bb, iid, &hovered, &held);
            float t = ClampF((*value - minV) / (maxV - minV), 0.f, 1.f);
            if (held) {
                t = ClampF((GetIO().MousePos.x - bb.Min.x) / bb.GetWidth(), 0.0f, 1.0f);
                *value = minV + t * (maxV - minV);
                changed = true;
            }
            dl->AddRectFilled(a, b, IM_COL32(23, 23, 29, 255), rad * s);
            dl->AddRect(a, b, IM_COL32(55, 53, 62, 220), rad * s, 0, 1.0f * s);
            const float x = a.x + t * bb.GetWidth();
            dl->AddRectFilled(ImVec2(x - 4.0f * s, a.y + 4.0f * s), ImVec2(x + 4.0f * s, b.y - 4.0f * s), UI_GOLD, 4.0f * s);
            char v[24];
            std::snprintf(v, sizeof(v), "%.1f", *value);
            CenterText(v, ImVec2((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f), IM_COL32(205, 205, 210, 255), mutedPx);
        }
    };

    // A row of selectable "pill" buttons. Returns the index that was pressed or -1.
    auto Choice = [&](const char* idPrefix, const char* label, float x, float y, float w, float h, bool selected,
                      float rounding, ImU32 selectedText, ImU32 normalText) -> bool {
        ImGuiWindow* win = GetCurrentWindow();
        const ImGuiID iid = win->GetID((std::string(idPrefix) + label).c_str());
        const ImVec2 a(x, y), b(x + w, y + h);
        const ImRect bb(a, b);
        ItemSize(ImVec2(w, h));
        bool pressed = false;
        if (ItemAdd(bb, iid)) {
            bool hovered = false, held = false;
            pressed = ButtonBehavior(bb, iid, &hovered, &held);
            dl->AddRectFilled(a, b, selected ? UI_GOLD : IM_COL32(22, 22, 27, 255), rounding);
            dl->AddRect(a, b, selected ? IM_COL32(255, 220, 35, 255) : IM_COL32(55, 53, 62, 230), rounding, 0, 1.0f * s);
            CenterText(label, ImVec2((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f), selected ? selectedText : normalText, textPx);
        }
        return pressed;
    };
    const ImU32 darkText = IM_COL32(20, 20, 20, 255), lightText = IM_COL32(215, 215, 220, 255);

    if (m_tab == 0) {
        Toggle("##enablePrediction", "Enable Prediction", &m_s.predictionLine);
        Toggle("##strikerPath", "Show Striker Path", &m_s.strikerPath);
        Toggle("##puckPaths", "Show Puck Paths", &m_s.puckPaths);
        Toggle("##predictionAfterShot", "Prediction After Shot", &m_s.predictionAfterShot);
        Toggle("##autoPlay", "Auto Play", &m_s.autoPlay);

        if (m_s.autoPlay) {
            TextAt("Auto Play Mode", ImVec2(wp.x + padX, wp.y + cy + 1.0f * s), UI_GOLD, textPx);
            cy += 27.0f * s;
            const float modeGap = 8.0f * s;
            const float modeW = (contentW - modeGap) * 0.5f;
            const float modeH = 48.0f * s;
            for (int i = 0; i < 2; ++i) {
                const float x = wp.x + padX + i * (modeW + modeGap);
                if (Choice("##mode", i == 0 ? "FAST" : "HUMAN", x, wp.y + cy, modeW, modeH, m_s.autoPlayMode == i,
                           8.0f * s, darkText, lightText)) {
                    m_s.autoPlayMode = i;
                    changed = true;
                }
            }
            cy += modeH + 9.0f * s;
        }
        Toggle("##cleanTable", "Clean Table", &m_s.cleanTable);

        // status block (new): what the bridge/hook/fire layers are doing
        const float lh = 17.0f * s;
        float sy = footerY - 62.0f * s;
        char line[200];
        std::snprintf(line, sizeof(line), "Module: %s", st.module.c_str());
        TextAt(line, ImVec2(wp.x + padX, wp.y + sy), IM_COL32(150, 150, 158, 255), mutedPx); sy += lh;
        std::snprintf(line, sizeof(line), "Hooks: %d/%d   Fire path: %s", st.hooksInstalled, st.hooksTotal,
                      st.fireAvailable ? "ready" : "not available");
        TextAt(line, ImVec2(wp.x + padX, wp.y + sy), IM_COL32(150, 150, 158, 255), mutedPx); sy += lh;
        if (!st.autoPlayNote.empty())
            TextAt(st.autoPlayNote.c_str(), ImVec2(wp.x + padX, wp.y + sy), IM_COL32(230, 120, 90, 255), mutedPx);
    } else if (m_tab == 1) {
        Toggle("##autoMatchQueue", "Auto Match Queue", &m_s.autoQueue);
        TextAt("Not part of this build: needs lobby hooks. Settings are kept only.",
               ImVec2(wp.x + padX, wp.y + cy - 3.0f * s), IM_COL32(230, 120, 90, 255), mutedPx);
        cy += 20.0f * s;

        TextAt("Select Game Mode", ImVec2(wp.x + padX, wp.y + cy + 1.0f * s), UI_GOLD, textPx);
        cy += 30.0f * s;

        static const char* modes[] = {"Carrom", "Disc Pool", "Freestyle"};
        const float gapX = 10.0f * s;
        const float bw = (contentW - gapX * 2.0f) / 3.0f;
        const float bh = 52.0f * s;
        for (int i = 0; i < 3; i++) {
            if (Choice("##gm", modes[i], wp.x + padX + i * (bw + gapX), wp.y + cy, bw, bh, m_s.queueMode == i, 9.0f * s,
                       darkText, IM_COL32(210, 210, 215, 255))) {
                m_s.queueMode = i;
                m_s.Clamp();
                changed = true;
            }
        }
        cy += bh + 18.0f * s;

        TextAt("Select Coin", ImVec2(wp.x + padX, wp.y + cy + 1.0f * s), UI_GOLD, textPx);
        cy += 27.0f * s;
        static const char* coin12[] = {"200", "500", "2K", "4K", "5K", "11K", "27K", "55K", "140K", "170K", "280K", "580K"};
        static const char* coin9[] = {"200", "500", "2K", "5K", "11K", "55K", "140K", "280K", "580K"};
        const char* const* coins = (m_s.queueMode == 2) ? coin9 : coin12;
        const int coinCount = (m_s.queueMode == 2) ? 9 : 12;
        if (m_s.coinIndex < 0 || m_s.coinIndex >= coinCount) m_s.coinIndex = 0;
        const float gx = 10.0f * s, gy = 5.0f * s;
        const float cw = (contentW - gx * 3.0f) / 4.0f, ch = 41.0f * s;
        for (int i = 0; i < coinCount; i++) {
            const int col = i % 4, row = i / 4;
            if (Choice("##coin", coins[i], wp.x + padX + col * (cw + gx), wp.y + cy + row * (ch + gy), cw, ch,
                       m_s.coinIndex == i, 7.0f * s, darkText, IM_COL32(210, 210, 215, 255))) {
                m_s.coinIndex = i;
                changed = true;
            }
        }
    } else if (m_tab == 2) {
        TextAt("Select ESP Style", ImVec2(wp.x + padX, wp.y + cy + 1.0f * s), UI_GOLD, textPx);
        cy += 29.0f * s;

        const float styleGap = 10.0f * s;
        const float styleW = (contentW - styleGap) * 0.5f;
        const float styleH = 88.0f * s;
        const float previewPad = 10.0f * s;
        const char* styleNames[2] = {"Classic Mode", "Sea Blue Glow"};
        const float opacity = m_s.lineOpacity;

        for (int i = 0; i < 2; ++i) {
            const float x = wp.x + padX + i * (styleW + styleGap);
            const ImVec2 a(x, wp.y + cy), b(x + styleW, wp.y + cy + styleH);
            ImGuiWindow* w = GetCurrentWindow();
            const ImGuiID id = w->GetID(i == 0 ? "##classicLineStyle" : "##blueLineStyle");
            const ImRect bb(a, b);
            ItemSize(ImVec2(styleW, styleH));
            if (ItemAdd(bb, id)) {
                bool hovered = false, held = false;
                if (ButtonBehavior(bb, id, &hovered, &held)) { m_s.lineStyle = i; changed = true; }
                const bool selected = m_s.lineStyle == i;
                dl->AddRectFilled(a, b, IM_COL32(18, 18, 23, 255), 9.0f * s);
                dl->AddRect(a, b, selected ? UI_GOLD : IM_COL32(55, 53, 62, 230), 9.0f * s, 0, selected ? 2.0f * s : 1.0f * s);

                const float left = a.x + previewPad, right = b.x - previewPad;
                const float mid = a.y + 31.0f * s;
                const float span = right - left;
                const float phase = std::fmod(m_lineAnim * 0.12f, 1.0f);
                ImVec2 prev(left, mid + 4.0f * s), ballPos = prev;
                for (int k = 1; k <= 28; ++k) {
                    const float t = (float)k / 28.0f;
                    const float wave = std::sin((t * 3.2f + phase) * 3.14159265f) * 5.0f * s;
                    const ImVec2 cur(left + span * t, mid + wave);
                    const ImU32 c = i == 0 ? IM_COL32(255, 215, 0, (int)(255.0f * opacity))
                                           : IM_COL32(40, 185, 255, (int)(255.0f * opacity));
                    dl->AddLine(prev, cur, c, ImMax(1.5f * s, m_s.lineThickness * 0.35f * s));
                    prev = cur;
                    ballPos = cur;
                }
                const ImU32 ballCol = i == 0 ? IM_COL32(255, 235, 70, (int)(255.0f * opacity))
                                             : IM_COL32(70, 205, 255, (int)(255.0f * opacity));
                dl->AddCircleFilled(ballPos, 4.2f * s, ballCol, 20);
                dl->AddCircle(ballPos, 6.0f * s, IM_COL32(255, 255, 255, (int)(110.0f * opacity)), 20, 1.0f * s);
                CenterText(styleNames[i], ImVec2((a.x + b.x) * 0.5f, b.y - 17.0f * s),
                           selected ? IM_COL32(235, 235, 235, 255) : IM_COL32(185, 185, 190, 255), mutedPx);
            }
        }
        cy += styleH + 15.0f * s;

        TextAt("Line Thickness", ImVec2(wp.x + padX, wp.y + cy + 1.0f * s), IM_COL32(220, 220, 225, 255), textPx);
        cy += 24.0f * s;
        Slider("##refLineThickness", &m_s.lineThickness, 1.0f, 10.0f, 30.0f * s, 7.0f);
        cy += 40.0f * s;

        TextAt("Line Opacity", ImVec2(wp.x + padX, wp.y + cy + 1.0f * s), IM_COL32(220, 220, 225, 255), textPx);
        cy += 24.0f * s;
        Slider("##refLineOpacity", &m_s.lineOpacity, 0.1f, 1.0f, 30.0f * s, 7.0f);
        m_lineAnim += GetIO().DeltaTime * 2.0f;
    } else if (m_tab == 3) {
        DrawTesterTab(st, winW, cy, out);
    } else {
        DrawDumperTab(winW, cy, out);
    }
    if (m_tab <= 2) m_contentBottom = cy / s;

    // footer tabs
    const float tabW = winW / 5.0f;
    auto Tab = [&](const char* id, const char* label, float x, int index) {
        ImGuiWindow* w = GetCurrentWindow();
        const ImGuiID iid = w->GetID(id);
        const ImVec2 a(wp.x + x, wp.y + footerY), b(wp.x + x + tabW, wp.y + winH);
        const ImRect bb(a, b);
        ItemSize(ImVec2(tabW, footerH));
        if (!ItemAdd(bb, iid)) return;
        bool hovered = false, held = false;
        const bool pressed = ButtonBehavior(bb, iid, &hovered, &held);
        const bool selected = m_tab == index;
        if (selected) dl->AddRectFilled(a, b, UI_GOLD, 8.0f * s);
        else if (hovered) dl->AddRectFilled(a, b, IM_COL32(255, 215, 0, 25), 8.0f * s);
        CenterText(label, ImVec2((a.x + b.x) * 0.5f, (a.y + b.y) * 0.5f),
                   selected ? IM_COL32(15, 15, 15, 255) : IM_COL32(220, 220, 225, 255), tabPx);
        if (pressed) m_tab = index;
    };
    Tab("##functionsTab", "FUNCTIONS", 0, 0);
    Tab("##autoMatchTab", "AUTO MATCH", tabW, 1);
    Tab("##espLineTab", "ESP LINE", tabW * 2.0f, 2);
    Tab("##testerTab", "TESTER", tabW * 3.0f, 3);
    Tab("##dumperTab", "DUMPER", tabW * 4.0f, 4);

    if (changed) { m_s.Clamp(); out.settingsChanged = true; }
}

void Ui::DrawFloatingButton(float s, float W, float H, UiOutput& out) {
    ImGuiIO& io = GetIO();
    const float logoSize = m_s.logoBtnSize * s;
    m_s.logoBtnX = ClampF(m_s.logoBtnX, 0.0f, std::max(0.f, W / s - m_s.logoBtnSize));
    m_s.logoBtnY = ClampF(m_s.logoBtnY, 0.0f, std::max(0.f, H / s - m_s.logoBtnSize));
    const float px = m_s.logoBtnX * s, py = m_s.logoBtnY * s;

    SetNextWindowPos(ImVec2(px, py), ImGuiCond_Always);
    SetNextWindowSize(ImVec2(logoSize + 8 * s, logoSize + 8 * s), ImGuiCond_Always);
    PushStyleColor(ImGuiCol_WindowBg, IM_COL32(0, 0, 0, 0));
    PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    if (Begin("##FloatBtn", nullptr,
              ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar |
                  ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings)) {
        ImDrawList* dl = GetWindowDrawList();
        const ImVec2 pos = GetCursorScreenPos();
        InvisibleButton("##FloatBtnHit", ImVec2(logoSize, logoSize));
        if (IsItemActive() && IsMouseDragging(ImGuiMouseButton_Left, 2.0f)) {
            m_s.logoBtnX += io.MouseDelta.x / s;
            m_s.logoBtnY += io.MouseDelta.y / s;
            out.settingsChanged = true;
        } else if (WasTap()) {
            m_open = !m_open;
        }
        if (m_tex.logo) dl->AddImageRounded(m_tex.logo, pos, ImVec2(pos.x + logoSize, pos.y + logoSize), ImVec2(0, 0),
                                            ImVec2(1, 1), IM_COL32_WHITE, logoSize * 0.5f);
        else dl->AddCircleFilled(ImVec2(pos.x + logoSize * 0.5f, pos.y + logoSize * 0.5f), logoSize * 0.5f,
                                 IM_COL32(20, 20, 20, 255));
        out.hitRects.push_back({pos.x, pos.y, pos.x + logoSize, pos.y + logoSize});
    }
    End();
    PopStyleVar();
    PopStyleColor();
}

void Ui::DrawPlayButton(float s, float W, float H, UiOutput& out) {
    ImGuiIO& io = GetIO();
    const float buttonSize = m_s.playBtnSize * s;
    m_s.playBtnX = ClampF(m_s.playBtnX, 0.0f, std::max(0.f, W / s - m_s.playBtnSize));
    m_s.playBtnY = ClampF(m_s.playBtnY, 0.0f, std::max(0.f, H / s - m_s.playBtnSize));
    const float px = m_s.playBtnX * s, py = m_s.playBtnY * s;

    const bool showModes = m_autoPlaying;
    const float modeW = 66.0f * s, modeH = 30.0f * s, verticalGap = 10.0f * s;
    const float modesW = modeW * 2.0f;
    const float windowW = ImMax(buttonSize, modesW);
    const float windowH = buttonSize + 8.0f * s + (showModes ? verticalGap + modeH : 0.0f);

    SetNextWindowSize(ImVec2(windowW, windowH), ImGuiCond_Always);
    SetNextWindowPos(ImVec2(px - (windowW - buttonSize) * 0.5f, py), ImGuiCond_Always);
    PushStyleColor(ImGuiCol_WindowBg, IM_COL32(0, 0, 0, 0));
    PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    if (Begin("##ToggleBtn", nullptr,
              ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar |
                  ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoBackground)) {
        ImDrawList* dl = GetWindowDrawList();
        const float playOffsetX = (windowW - buttonSize) * 0.5f;
        const ImVec2 pos(GetWindowPos().x + playOffsetX, GetWindowPos().y);

        SetCursorScreenPos(pos);
        InvisibleButton("##TglBtnHit", ImVec2(buttonSize, buttonSize));
        if (IsItemActive() && IsMouseDragging(ImGuiMouseButton_Left, 2.0f)) {
            m_s.playBtnX += io.MouseDelta.x / s;
            m_s.playBtnY += io.MouseDelta.y / s;
            out.settingsChanged = true;
        } else if (WasTap()) {
            m_autoPlaying = !m_autoPlaying;
        }

        const ImTextureID tex = m_autoPlaying ? m_tex.playOn : m_tex.playOff;
        if (tex) dl->AddImageRounded(tex, pos, ImVec2(pos.x + buttonSize, pos.y + buttonSize), ImVec2(0, 0), ImVec2(1, 1),
                                     IM_COL32_WHITE, buttonSize * 0.5f);
        else dl->AddCircleFilled(ImVec2(pos.x + buttonSize * 0.5f, pos.y + buttonSize * 0.5f), buttonSize * 0.5f,
                                 m_autoPlaying ? IM_COL32(60, 180, 90, 255) : IM_COL32(120, 40, 40, 255));
        out.hitRects.push_back({pos.x, pos.y, pos.x + buttonSize, pos.y + buttonSize});

        if (showModes) {
            const float bx = GetWindowPos().x + (windowW - modesW) * 0.5f;
            const float by = GetWindowPos().y + buttonSize + verticalGap;
            for (int i = 0; i < 2; ++i) {
                const float x = bx + i * modeW;
                const ImVec2 a(x, by), b(x + modeW, by + modeH);
                const char* label = i == 0 ? "FAST" : "HUMAN";
                const ImGuiID id = GetCurrentWindow()->GetID(i == 0 ? "##attachedFast" : "##attachedHuman");
                const ImRect bb(a, b);
                ItemSize(ImVec2(modeW, modeH));
                if (ItemAdd(bb, id)) {
                    bool hovered = false, held = false;
                    if (ButtonBehavior(bb, id, &hovered, &held)) { m_s.autoPlayMode = i; out.settingsChanged = true; }
                    const bool selected = m_s.autoPlayMode == i;
                    dl->AddRectFilled(a, b, selected ? IM_COL32(190, 158, 35, 255) : IM_COL32(27, 27, 34, 245), 6.0f * s);
                    dl->AddRect(a, b, selected ? IM_COL32(218, 188, 65, 255) : IM_COL32(70, 68, 78, 235), 6.0f * s, 0, 1.0f * s);
                    const ImVec2 ts = GetFont()->CalcTextSizeA(10.0f * s, FLT_MAX, 0.0f, label);
                    dl->AddText(GetFont(), 10.0f * s, ImVec2((a.x + b.x - ts.x) * 0.5f, (a.y + b.y - ts.y) * 0.5f),
                                selected ? IM_COL32(20, 20, 20, 255) : IM_COL32(225, 225, 230, 255), label);
                    out.hitRects.push_back({a.x, a.y, b.x, b.y});
                }
            }
        }
    }
    End();
    PopStyleVar();
    PopStyleColor();
}

} // namespace carrom::ui

namespace carrom::ui {

void Ui::DrawTesterTab(const UiStatus& st, float winW, float cyStart, UiOutput& out) {
    ImDrawList* dl = GetWindowDrawList();
    const ImVec2 wp = GetWindowPos();
    const float s = winW / 540.0f;
    const float padX = 14.0f * s;
    const float contentW = winW - padX * 2.0f;
    float cy = cyStart;
    const ImFont* font = GetFont();
    const float textPx = 13.0f * s, mutedPx = 12.0f * s;

    auto TextAt = [&](const char* text, ImVec2 pos, ImU32 color, float px) { dl->AddText(font, px, pos, color, text); };

    if (!st.module.empty() && st.module != "not found") {
        char head[160];
        std::snprintf(head, sizeof(head), "Module: %s", st.module.c_str());
        TextAt(head, ImVec2(wp.x + padX, wp.y + cy), IM_COL32(150, 150, 158, 255), mutedPx);
    } else {
        TextAt("Module not loaded yet: readings will fail until it is.", ImVec2(wp.x + padX, wp.y + cy),
               IM_COL32(230, 120, 90, 255), mutedPx);
    }
    cy += 20.0f * s;

    // chain input
    SetCursorScreenPos(ImVec2(wp.x + padX, wp.y + cy));
    PushItemWidth(contentW * 0.62f);
    PushStyleColor(ImGuiCol_FrameBg, IM_COL32(22, 22, 27, 255));
    PushStyleColor(ImGuiCol_Text, IM_COL32(230, 230, 235, 255));
    InputText("##chain", m_chainBuf, sizeof(m_chainBuf));
    PopStyleColor(2);
    PopItemWidth();
    SameLine();
    const bool doRead = Button("READ", ImVec2(contentW * 0.16f, 0));
    SameLine();
    const bool doArr = Button("ARR", ImVec2(contentW * 0.16f, 0));
    cy += 30.0f * s;
    TextAt("chain: hex/dec RVA, comma-separated hops (e.g. 0x18,0x8,0x50) dereference each hop",
           ImVec2(wp.x + padX, wp.y + cy), IM_COL32(140, 140, 148, 255), 11.0f * s);
    cy += 18.0f * s;

    static TestResult lastResult;
    static std::vector<TestResult> lastArray;
    static bool haveResult = false;
    if (doRead) { lastResult = m_tester.Read(m_chainBuf); haveResult = true; lastArray.clear(); }
    if (doArr) { lastArray = m_tester.ReadArray(m_chainBuf, m_arrayCount); haveResult = false; }

    if (haveResult) {
        char line[256];
        if (lastResult.ok) {
            std::snprintf(line, sizeof(line), "@%#llx  i32=%d  i64=%lld  f=%.4f  d=%.6f  ptr=%s",
                          (unsigned long long)lastResult.finalAddress, lastResult.asInt32, (long long)lastResult.asInt64,
                          (double)lastResult.asFloat, lastResult.asDouble,
                          lastResult.pointerPlausible ? "plausible" : "unlikely");
            TextAt(line, ImVec2(wp.x + padX, wp.y + cy), IM_COL32(120, 230, 140, 255), textPx);
            cy += 18.0f * s;
            std::snprintf(line, sizeof(line), "hex: %s", lastResult.hexLine.c_str());
            TextAt(line, ImVec2(wp.x + padX, wp.y + cy), IM_COL32(190, 190, 196, 255), mutedPx);
            cy += 16.0f * s;
            std::snprintf(line, sizeof(line), "ascii: %s", lastResult.asAscii.c_str());
            TextAt(line, ImVec2(wp.x + padX, wp.y + cy), IM_COL32(190, 190, 196, 255), mutedPx);
        } else {
            std::snprintf(line, sizeof(line), "error: %s", lastResult.error.c_str());
            TextAt(line, ImVec2(wp.x + padX, wp.y + cy), IM_COL32(230, 120, 90, 255), textPx);
        }
        cy += 22.0f * s;
    } else if (!lastArray.empty()) {
        for (size_t i = 0; i < lastArray.size() && i < 10; ++i) {
            const auto& r = lastArray[i];
            char line[160];
            if (r.ok)
                std::snprintf(line, sizeof(line), "[%zu] @%#llx = %lld (%s)", i, (unsigned long long)r.finalAddress,
                              (long long)r.asInt64, r.pointerPlausible ? "ptr?" : "-");
            else
                std::snprintf(line, sizeof(line), "[%zu] error: %s", i, r.error.c_str());
            TextAt(line, ImVec2(wp.x + padX, wp.y + cy), IM_COL32(190, 210, 230, 255), mutedPx);
            cy += 15.0f * s;
        }
        cy += 6.0f * s;
    }

    // save row
    SetCursorScreenPos(ImVec2(wp.x + padX, wp.y + cy));
    PushItemWidth(contentW * 0.62f);
    PushStyleColor(ImGuiCol_FrameBg, IM_COL32(22, 22, 27, 255));
    PushStyleColor(ImGuiCol_Text, IM_COL32(230, 230, 235, 255));
    InputTextWithHint("##label", "label, e.g. field.gm.rules", m_labelBuf, sizeof(m_labelBuf));
    PopStyleColor(2);
    PopItemWidth();
    SameLine();
    if (Button("SAVE", ImVec2(contentW * 0.32f, 0)) && m_labelBuf[0] != '\0') {
        m_tester.Save(m_labelBuf, m_chainBuf, "raw");
        out.testerChanged = true;
    }
    cy += 32.0f * s;

    TextAt("Saved (tap to re-read into the field above):", ImVec2(wp.x + padX, wp.y + cy), IM_COL32(220, 220, 225, 255),
           textPx);
    cy += 20.0f * s;

    const auto& saved = m_tester.saved();
    const auto live = m_tester.ReadAllSaved();
    for (size_t i = 0; i < saved.size() && i < 8; ++i) {
        const ImVec2 a(wp.x + padX, wp.y + cy), b(a.x + contentW - 34.0f * s, a.y + 22.0f * s);
        ImGuiWindow* win = GetCurrentWindow();
        const ImGuiID id = win->GetID((int)i + 5000);
        const ImRect bb(a, b);
        ItemSize(ImVec2(contentW - 34.0f * s, 22.0f * s));
        if (ItemAdd(bb, id)) {
            bool hovered = false, held = false;
            if (ButtonBehavior(bb, id, &hovered, &held))
                std::snprintf(m_chainBuf, sizeof(m_chainBuf), "%s", saved[i].chain.c_str());
            dl->AddRectFilled(a, b, hovered ? IM_COL32(30, 30, 36, 255) : IM_COL32(20, 20, 25, 255), 5.0f * s);
            char line[200];
            const bool ok = i < live.size() && live[i].ok;
            std::snprintf(line, sizeof(line), "%s = %s  [%s]", saved[i].label.c_str(), saved[i].chain.c_str(),
                          ok ? std::to_string(live[i].asInt64).c_str() : "err");
            TextAt(line, ImVec2(a.x + 6.0f * s, a.y + 3.0f * s), IM_COL32(210, 210, 215, 255), 11.5f * s);
        }
        SetCursorScreenPos(ImVec2(b.x + 4.0f * s, a.y));
        PushID((int)i);
        if (Button("x", ImVec2(28.0f * s, 22.0f * s))) { m_tester.RemoveSaved(i); out.testerChanged = true; }
        PopID();
        cy += 25.0f * s;
    }
    m_contentBottom = cy / s;
}

} // namespace carrom::ui

namespace carrom::ui {

void Ui::DrawDumperTab(float winW, float cyStart, UiOutput& out) {
    ImDrawList* dl = GetWindowDrawList();
    const ImVec2 wp = GetWindowPos();
    const float s = winW / 540.0f;
    const float padX = 14.0f * s;
    const float contentW = winW - padX * 2.0f;
    float cy = cyStart;
    const ImFont* font = GetFont();
    const float mutedPx = 12.0f * s;
    auto TextAt = [&](const char* text, ImVec2 pos, ImU32 color, float px) { dl->AddText(font, px, pos, color, text); };
    auto Muted = [&](const char* t, ImU32 col = IM_COL32(150, 150, 158, 255), float px = 0.f) {
        TextAt(t, ImVec2(wp.x + padX, wp.y + cy), col, px > 0.f ? px : mutedPx);
    };
    auto Input = [&](const char* id, const char* hint, char* buf, size_t cap, float w) {
        SetCursorScreenPos(ImVec2(wp.x + padX, wp.y + cy));
        PushItemWidth(w);
        PushStyleColor(ImGuiCol_FrameBg, IM_COL32(22, 22, 27, 255));
        PushStyleColor(ImGuiCol_Text, IM_COL32(230, 230, 235, 255));
        InputTextWithHint(id, hint, buf, cap);
        PopStyleColor(2);
        PopItemWidth();
    };
    auto Pill = [&](const char* idp, const char* label, bool sel, float x, float w) -> bool {
        ImGuiWindow* win = GetCurrentWindow();
        const ImGuiID id = win->GetID(idp);
        const ImVec2 a(wp.x + x, wp.y + cy), b(a.x + w, a.y + 24.0f * s);
        const ImRect bb(a, b);
        ItemSize(ImVec2(w, 24.0f * s));
        bool pressed = false;
        if (ItemAdd(bb, id)) {
            bool hovered = false, held = false;
            pressed = ButtonBehavior(bb, id, &hovered, &held);
            dl->AddRectFilled(a, b, sel ? IM_COL32(255, 215, 0, 230) : IM_COL32(22, 22, 27, 255), 5.0f * s);
            const ImVec2 ts = font->CalcTextSizeA(10.5f * s, FLT_MAX, 0.0f, label);
            dl->AddText(font, 10.5f * s, ImVec2((a.x + b.x - ts.x) * 0.5f, (a.y + b.y - ts.y) * 0.5f),
                        sel ? IM_COL32(20, 20, 20, 255) : IM_COL32(210, 210, 215, 255), label);
        }
        return pressed;
    };

    // page selector
    {
        const float w = (contentW - 8.0f * s) / 3.0f;
        if (Pill("##pgLibs", "LIBS", m_dumperPage == 0, padX, w)) m_dumperPage = 0;
        if (Pill("##pgMeta", "METADATA", m_dumperPage == 1, padX + w + 4.0f * s, w)) m_dumperPage = 1;
        if (Pill("##pgScan", "SCAN", m_dumperPage == 2, padX + (w + 4.0f * s) * 2.0f, w)) m_dumperPage = 2;
        cy += 30.0f * s;
    }

    const bool haveSel = m_selectedModule >= 0 && m_selectedModule < (int)m_lastSearch.size();

    if (m_dumperPage == 0) {
        // ---------------- LIBS: pick a library, dump it, or dump a raw range ----------------
        Muted("Library name (blank + SCAN = list all)", IM_COL32(220, 220, 225, 255));
        cy += 16.0f * s;
        Input("##libname", "e.g. il2cpp, any name", m_libNameBuf, sizeof(m_libNameBuf), contentW * 0.62f);
        SameLine();
        const bool doSearch = Button("SCAN", ImVec2(contentW * 0.16f, 0));
        SameLine();
        const bool doAuto = Button("AUTO", ImVec2(contentW * 0.16f, 0));
        cy += 29.0f * s;
        if (doSearch) { m_lastSearch = FindModulesContaining(m_libNameBuf); m_selectedModule = -1; }
        if (doAuto) { m_lastSearch = AutoDetectCandidates(); m_selectedModule = -1; }

        if (m_lastSearch.empty()) { Muted("Nothing listed yet."); cy += 16.0f * s; }
        for (size_t i = 0; i < m_lastSearch.size() && i < 4; ++i) {
            const auto& m = m_lastSearch[i];
            const ImVec2 a(wp.x + padX, wp.y + cy), b(a.x + contentW, a.y + 30.0f * s);
            ImGuiWindow* win = GetCurrentWindow();
            const ImGuiID id = win->GetID((int)i + 9000);
            const ImRect bb(a, b);
            ItemSize(ImVec2(contentW, 30.0f * s));
            if (ItemAdd(bb, id)) {
                bool hovered = false, held = false;
                if (ButtonBehavior(bb, id, &hovered, &held)) m_selectedModule = (int)i;
                const bool sel = m_selectedModule == (int)i;
                dl->AddRectFilled(a, b, sel ? IM_COL32(60, 52, 10, 255) : (hovered ? IM_COL32(30, 30, 36, 255) : IM_COL32(20, 20, 25, 255)), 5.0f * s);
                if (sel) dl->AddRect(a, b, IM_COL32(255, 215, 0, 220), 5.0f * s, 0, 1.0f * s);
                char line[200];
                std::snprintf(line, sizeof(line), "%s  @%#llx  (%llu KB)", m.name.c_str(), (unsigned long long)m.base,
                              (unsigned long long)(m.end - m.base) / 1024ULL);
                TextAt(line, ImVec2(a.x + 6.0f * s, a.y + 4.0f * s), IM_COL32(210, 215, 220, 255), 12.0f * s);
                TextAt(m.path.c_str(), ImVec2(a.x + 6.0f * s, a.y + 17.0f * s), IM_COL32(140, 140, 148, 255), 10.0f * s);
            }
            cy += 33.0f * s;
        }
        if (m_lastSearch.size() > 4) {
            char more[96];
            std::snprintf(more, sizeof(more), "...and %zu more (type a more specific name)", m_lastSearch.size() - 4);
            Muted(more, IM_COL32(150, 150, 158, 255), 10.5f * s);
            cy += 14.0f * s;
        }
        cy += 4.0f * s;

        Muted("Output directory", IM_COL32(220, 220, 225, 255));
        cy += 16.0f * s;
        Input("##outdir", "output directory", m_dumpOutDirBuf, sizeof(m_dumpOutDirBuf), contentW);
        cy += 29.0f * s;

        if (Button(haveSel ? "DUMP SELECTED LIBRARY (memory image)" : "SELECT A LIBRARY FIRST", ImVec2(contentW, 28.0f * s)) &&
            haveSel) {
            const auto& m = m_lastSearch[(size_t)m_selectedModule];
            m_lastDump = m_dumper.DumpModule(m, std::string(m_dumpOutDirBuf) + "/" + m.name + ".dump");
            m_haveDump = true;
        }
        cy += 33.0f * s;

        Muted("Raw range (hex start / end) for heap or anonymous memory", IM_COL32(220, 220, 225, 255), 11.0f * s);
        cy += 15.0f * s;
        SetCursorScreenPos(ImVec2(wp.x + padX, wp.y + cy));
        PushStyleColor(ImGuiCol_FrameBg, IM_COL32(22, 22, 27, 255));
        PushStyleColor(ImGuiCol_Text, IM_COL32(230, 230, 235, 255));
        PushItemWidth(contentW * 0.30f);
        InputTextWithHint("##rs", "0x7f00000000", m_rangeStartBuf, sizeof(m_rangeStartBuf));
        SameLine();
        InputTextWithHint("##re", "0x7f00100000", m_rangeEndBuf, sizeof(m_rangeEndBuf));
        PopItemWidth();
        PopStyleColor(2);
        SameLine();
        if (Button("DUMP", ImVec2(contentW * 0.24f, 0))) {
            const uintptr_t a = (uintptr_t)std::strtoull(m_rangeStartBuf, nullptr, 0);
            const uintptr_t b = (uintptr_t)std::strtoull(m_rangeEndBuf, nullptr, 0);
            char name[64];
            std::snprintf(name, sizeof(name), "/range_%llx_%llx.bin", (unsigned long long)a, (unsigned long long)b);
            m_lastDump = m_dumper.DumpRange(a, b, std::string(m_dumpOutDirBuf) + name);
            m_haveDump = true;
        }
        cy += 30.0f * s;

        if (m_haveDump) {
            char line[300];
            if (m_lastDump.ok)
                std::snprintf(line, sizeof(line), "OK: %zu bytes -> %s", m_lastDump.bytesWritten, m_lastDump.outputPath.c_str());
            else
                std::snprintf(line, sizeof(line), "FAILED: %s", m_lastDump.error.c_str());
            Muted(line, m_lastDump.ok ? IM_COL32(120, 230, 140, 255) : IM_COL32(230, 120, 90, 255), 11.0f * s);
            cy += 15.0f * s;
            if (m_lastDump.ok && m_lastDump.pagesSkipped) {
                std::snprintf(line, sizeof(line), "%zu unreadable chunk(s) zero-filled", m_lastDump.pagesSkipped);
                Muted(line, IM_COL32(230, 190, 90, 255), 11.0f * s);
                cy += 14.0f * s;
            }
        }
    } else if (m_dumperPage == 1) {
        // ---------------- METADATA: file check + find the decrypted copy in memory ----------------
        Muted("global-metadata.dat on disk (works if NOT encrypted)", IM_COL32(220, 220, 225, 255), 11.0f * s);
        cy += 15.0f * s;
        Input("##metapath", "/sdcard/.../global-metadata.dat", m_metadataPathBuf, sizeof(m_metadataPathBuf), contentW * 0.72f);
        SameLine();
        if (Button("CHECK", ImVec2(contentW * 0.24f, 0))) {
            m_lastMeta = RuntimeDumper::ReadMetadataHeaderFromFile(m_metadataPathBuf);
            m_haveMeta = true;
        }
        cy += 29.0f * s;
        if (m_haveMeta) {
            char line[220];
            if (m_lastMeta.ok) {
                std::snprintf(line, sizeof(line), "version %.1f, %zu tables:", m_lastMeta.resolvedVersion, m_lastMeta.tables.size());
                Muted(line, IM_COL32(120, 230, 140, 255), 11.0f * s);
                cy += 14.0f * s;
                for (size_t i = 0; i < m_lastMeta.tables.size() && i < 5; ++i) {
                    const auto& t = m_lastMeta.tables[i];
                    std::snprintf(line, sizeof(line), "  %s: off=%d size=%d", t.name.c_str(), t.offset, t.count);
                    Muted(line, IM_COL32(190, 210, 230, 255), 10.5f * s);
                    cy += 13.0f * s;
                }
                if (m_lastMeta.tables.size() > 5) {
                    std::snprintf(line, sizeof(line), "  ...and %zu more", m_lastMeta.tables.size() - 5);
                    Muted(line, IM_COL32(150, 150, 158, 255), 10.5f * s);
                    cy += 13.0f * s;
                }
            } else {
                std::snprintf(line, sizeof(line), "%s", m_lastMeta.error.c_str());
                Muted(line, IM_COL32(230, 120, 90, 255), 11.0f * s);
                cy += 15.0f * s;
            }
        }
        cy += 6.0f * s;

        Muted("Encrypted/protected? Find the decrypted copy in RAM:", IM_COL32(220, 220, 225, 255), 11.0f * s);
        cy += 15.0f * s;
        SetCursorScreenPos(ImVec2(wp.x + padX, wp.y + cy));
        const bool running = m_finder.Running();
        if (Button(running ? "SCANNING... (tap to cancel)" : "FIND METADATA IN MEMORY", ImVec2(contentW, 28.0f * s))) {
            if (running) m_finder.Cancel(); else { m_finder.StartAsync(8); m_selectedFound = -1; m_metaDumpMsg.clear(); }
        }
        cy += 33.0f * s;
        {
            char line[160];
            if (running) std::snprintf(line, sizeof(line), "scanned %zu MB so far...", m_finder.BytesScanned() / (1024 * 1024));
            else std::snprintf(line, sizeof(line), "scanned %zu MB", m_finder.BytesScanned() / (1024 * 1024));
            Muted(line, IM_COL32(150, 150, 158, 255), 10.5f * s);
            cy += 14.0f * s;
        }
        const auto found = m_finder.Results();
        if (!running && found.empty() && m_finder.BytesScanned() > 0) {
            Muted("none found (not decrypted yet? start a match first, then retry)", IM_COL32(230, 190, 90, 255), 10.5f * s);
            cy += 14.0f * s;
        }
        for (size_t i = 0; i < found.size() && i < 3; ++i) {
            const auto& f = found[i];
            const ImVec2 a(wp.x + padX, wp.y + cy), b(a.x + contentW, a.y + 28.0f * s);
            ImGuiWindow* win = GetCurrentWindow();
            const ImGuiID id = win->GetID((int)i + 9500);
            const ImRect bb(a, b);
            ItemSize(ImVec2(contentW, 28.0f * s));
            if (ItemAdd(bb, id)) {
                bool hovered = false, held = false;
                if (ButtonBehavior(bb, id, &hovered, &held)) m_selectedFound = (int)i;
                const bool sel = m_selectedFound == (int)i;
                dl->AddRectFilled(a, b, sel ? IM_COL32(60, 52, 10, 255) : IM_COL32(20, 20, 25, 255), 5.0f * s);
                if (sel) dl->AddRect(a, b, IM_COL32(255, 215, 0, 220), 5.0f * s, 0, 1.0f * s);
                char line[200];
                std::snprintf(line, sizeof(line), "v%.1f  @%#llx  %zu KB", f.version, (unsigned long long)f.address, f.size / 1024);
                TextAt(line, ImVec2(a.x + 6.0f * s, a.y + 3.0f * s), IM_COL32(210, 215, 220, 255), 12.0f * s);
                TextAt(f.region.empty() ? "(anonymous memory)" : f.region.c_str(), ImVec2(a.x + 6.0f * s, a.y + 16.0f * s),
                       IM_COL32(140, 140, 148, 255), 10.0f * s);
            }
            cy += 31.0f * s;
        }
        if (m_selectedFound >= 0 && m_selectedFound < (int)found.size()) {
            if (Button("SAVE SELECTED AS global-metadata.dat", ImVec2(contentW, 26.0f * s))) {
                char name[64];
                std::snprintf(name, sizeof(name), "/global-metadata.%llx.dat", (unsigned long long)found[(size_t)m_selectedFound].address);
                std::string err, note;
                if (MetadataFinder::Dump(found[(size_t)m_selectedFound], std::string(m_dumpOutDirBuf) + name, &err, &note))
                    m_metaDumpMsg = "saved " + std::string(m_dumpOutDirBuf) + name + (note.empty() ? "" : " (" + note + ")");
                else
                    m_metaDumpMsg = "FAILED: " + err;
            }
            cy += 31.0f * s;
        }
        if (!m_metaDumpMsg.empty()) {
            Muted(m_metaDumpMsg.c_str(), IM_COL32(120, 230, 140, 255), 10.5f * s);
            cy += 14.0f * s;
        }
    } else {
        // ---------------- SCAN: pattern / float / double / string in the selected library ----------------
        char sel[160];
        if (haveSel) std::snprintf(sel, sizeof(sel), "Library: %s", m_lastSearch[(size_t)m_selectedModule].name.c_str());
        else std::snprintf(sel, sizeof(sel), "No library selected: pick one on the LIBS page.");
        Muted(sel, haveSel ? IM_COL32(220, 220, 225, 255) : IM_COL32(230, 120, 90, 255));
        cy += 18.0f * s;

        const float w = (contentW - 12.0f * s) / 4.0f;
        const char* labels[4] = {"AOB", "FLOAT", "DOUBLE", "STRING"};
        const char* ids[4] = {"##mP", "##mF", "##mD", "##mS"};
        for (int i = 0; i < 4; ++i)
            if (Pill(ids[i], labels[i], m_scanMode == i, padX + i * (w + 4.0f * s), w)) m_scanMode = i;
        cy += 30.0f * s;

        char* buf = m_scanMode == 0 ? m_patternBuf : m_scanMode == 1 ? m_floatBuf : m_scanMode == 2 ? m_doubleBuf : m_stringBuf;
        const size_t cap = m_scanMode == 0 ? sizeof(m_patternBuf) : m_scanMode == 1 ? sizeof(m_floatBuf) : m_scanMode == 2 ? sizeof(m_doubleBuf) : sizeof(m_stringBuf);
        const char* hint = m_scanMode == 0 ? "DE AD ?? 22 33" : m_scanMode == 1 ? "e.g. 2.10" : m_scanMode == 2 ? "e.g. 0.002" : "text to find (blank = all)";
        Input("##scaninput", hint, buf, cap, contentW * 0.72f);
        SameLine();
        if (Button("FIND", ImVec2(contentW * 0.24f, 0))) {
            m_lastHits.clear();
            m_lastStrings.clear();
            m_scanError.clear();
            m_haveHits = true;
            if (!haveSel) {
                m_scanError = "select a library on the LIBS page first";
            } else {
                const auto& m = m_lastSearch[(size_t)m_selectedModule];
                if (m_scanMode == 0) {
                    std::string err;
                    auto pat = ParsePattern(m_patternBuf, &err);
                    if (!err.empty()) m_scanError = err; else m_lastHits = m_scanner.ScanModule(m, pat, 20);
                } else if (m_scanMode == 1) {
                    m_lastHits = m_scanner.FindFloat(m, (float)std::atof(m_floatBuf));
                } else if (m_scanMode == 2) {
                    m_lastHits = m_scanner.FindDouble(m, std::atof(m_doubleBuf));
                } else {
                    m_lastStrings = FindStrings(m, 6, m_stringBuf, 40);
                }
            }
        }
        cy += 30.0f * s;

        if (m_haveHits) {
            char line[220];
            if (!m_scanError.empty()) {
                std::snprintf(line, sizeof(line), "error: %s", m_scanError.c_str());
                Muted(line, IM_COL32(230, 120, 90, 255), 11.0f * s);
                cy += 16.0f * s;
            } else if (m_scanMode == 3) {
                std::snprintf(line, sizeof(line), "%zu string(s) (offset from base):", m_lastStrings.size());
                Muted(line, IM_COL32(120, 230, 140, 255), 11.0f * s);
                cy += 15.0f * s;
                for (size_t i = 0; i < m_lastStrings.size() && i < 14; ++i) {
                    std::snprintf(line, sizeof(line), "0x%llx  %.52s", (unsigned long long)m_lastStrings[i].offset, m_lastStrings[i].text.c_str());
                    Muted(line, IM_COL32(190, 210, 230, 255), 10.5f * s);
                    cy += 13.0f * s;
                }
            } else if (m_lastHits.empty()) {
                Muted("no match (a lone hit on a generic constant can be a coincidence; confirm", IM_COL32(150, 150, 158, 255), 10.5f * s);
                cy += 13.0f * s;
                Muted("with a byte pattern or a second known constant)", IM_COL32(150, 150, 158, 255), 10.5f * s);
                cy += 14.0f * s;
            } else if (haveSel) {
                const auto& m = m_lastSearch[(size_t)m_selectedModule];
                std::snprintf(line, sizeof(line), "%zu hit(s), offset from %s base:", m_lastHits.size(), m.name.c_str());
                Muted(line, IM_COL32(120, 230, 140, 255), 11.0f * s);
                cy += 15.0f * s;
                for (size_t i = 0; i < m_lastHits.size() && i < 14; ++i) {
                    std::snprintf(line, sizeof(line), "  0x%llx   (abs %#llx)", (unsigned long long)(m_lastHits[i] - m.base),
                                  (unsigned long long)m_lastHits[i]);
                    Muted(line, IM_COL32(190, 210, 230, 255), 10.5f * s);
                    cy += 13.0f * s;
                }
            }
        }
    }
    m_contentBottom = cy / s;
    (void)out;
}

} // namespace carrom::ui
