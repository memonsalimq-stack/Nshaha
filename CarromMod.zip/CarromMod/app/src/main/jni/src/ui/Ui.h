// The menu, ported from the old project's menu.h (gold theme, 3 tabs, floating buttons).
// Pure ImGui: no GL, no game access. State flows in via UiStatus, out via Settings and UiOutput.
#pragma once
#include <cstdio>
#include <string>
#include <vector>

#include "config/Settings.h"
#include "imgui.h"
#include "logic/OffsetTester.h"
#include "logic/MetadataFinder.h"
#include "logic/PatternScanner.h"
#include "logic/StringScanner.h"
#include "logic/RuntimeDumper.h"

namespace carrom::ui {

struct Textures {
    ImTextureID playOn = nullptr;
    ImTextureID playOff = nullptr;
    ImTextureID logo = nullptr;
};

// What the menu shows about the rest of the system.
struct UiStatus {
    std::string bridge;          // GameBridge::StatusText()
    std::string module;          // e.g. "libgame-CARROM...so @0x7f..." or "not found"
    int offsetsSet = 0;
    int offsetsTotal = 0;
    int hooksInstalled = 0;
    int hooksTotal = 0;
    bool fireAvailable = false;  // a touch sink exists
    bool calculating = false;    // autoplay is scanning for a shot
    std::string autoPlayNote;    // last autoplay problem, if any
};

struct HitRect { float x0, y0, x1, y1; };

struct UiOutput {
    bool settingsChanged = false;
    std::vector<HitRect> hitRects;   // screen rects that should swallow touches
    bool testerChanged = false;      // a saved-offset list edit happened this frame (caller should persist)
};

class Ui {
public:
    Ui(Settings& settings, OffsetTester& tester, RuntimeDumper& dumper, PatternScanner& scanner,
       MetadataFinder& finder)
        : m_s(settings), m_tester(tester), m_dumper(dumper), m_scanner(scanner), m_finder(finder) {}

    // Bottom edge of the current tab's content in design units (the footer starts at 506). The
    // tests use this to prove no tab/page draws into the footer.
    float contentBottom() const { return m_contentBottom; }

    // Where dumps are written. The app's own files dir is the only place a game process can
    // always write (it usually has no /sdcard write permission).
    void SetDumpDir(const std::string& dir) {
        std::snprintf(m_dumpOutDirBuf, sizeof(m_dumpOutDirBuf), "%s", dir.c_str());
    }
    std::string dumpDir() const { return m_dumpOutDirBuf; }
    void TestSetTab(int tab, int dumperPage = 0) { m_tab = tab; m_dumperPage = dumperPage; }
    void TestSetModules(std::vector<MappedModule> m, int selected) {
        m_lastSearch = std::move(m);
        m_selectedModule = selected;
    }

    void SetTextures(const Textures& t) { m_tex = t; }

    // Call between NewFrame() and Render().
    UiOutput Draw(const UiStatus& status, float screenW, float screenH);

    bool menuOpen() const { return m_open; }
    void SetMenuOpen(bool o) { m_open = o; }
    bool autoPlaying() const { return m_autoPlaying; }   // the round play button
    void SetAutoPlaying(bool v) { m_autoPlaying = v; }

    // Scale from design units to pixels for a given screen.
    static float UiScale(float screenW, float screenH);

private:
    void DrawMainMenu(const UiStatus& st, float s, float W, float H, UiOutput& out);
    void DrawContentArea(const UiStatus& st, float winW, float winH, UiOutput& out);
    void DrawFloatingButton(float s, float W, float H, UiOutput& out);
    void DrawPlayButton(float s, float W, float H, UiOutput& out);
    void DrawCalculating(float W, float H);
    void DrawTesterTab(const UiStatus& st, float winW, float cyStart, UiOutput& out);
    void DrawDumperTab(float winW, float cyStart, UiOutput& out);

    Settings& m_s;
    OffsetTester& m_tester;
    RuntimeDumper& m_dumper;
    PatternScanner& m_scanner;
    MetadataFinder& m_finder;
    char m_chainBuf[128] = "0x0";
    char m_labelBuf[64] = "";
    int m_arrayCount = 8;
    bool m_showArray = false;

    char m_libNameBuf[96] = "";
    char m_metadataPathBuf[256] = "";
    char m_dumpOutDirBuf[256] = "/data/local/tmp";
    std::vector<MappedModule> m_lastSearch;
    int m_selectedModule = -1;
    char m_patternBuf[160] = "";
    char m_floatBuf[32] = "2.10";
    char m_doubleBuf[32] = "0.002";
    int m_scanMode = 0; // 0=pattern, 1=float, 2=double, 3=string
    char m_stringBuf[64] = "";
    int m_dumperPage = 0; // 0=LIBS, 1=META, 2=SCAN
    char m_rangeStartBuf[24] = "";
    char m_rangeEndBuf[24] = "";
    DumpResult m_lastDump;
    bool m_haveDump = false;
    il2cpp::MetadataResult m_lastMeta;
    bool m_haveMeta = false;
    std::vector<uintptr_t> m_lastHits;
    std::vector<StringHit> m_lastStrings;
    bool m_haveHits = false;
    std::string m_scanError;
    int m_selectedFound = -1;
    std::string m_metaDumpMsg;
    float m_contentBottom = 0.f;
    Textures m_tex;
    bool m_open = false;
    bool m_autoPlaying = false;
    int m_tab = 0;
    float m_alpha = 0.f;
    float m_lineAnim = 0.f;
};

} // namespace carrom::ui
