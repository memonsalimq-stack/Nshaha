// Reads the live game state through the structures described by Offsets.
// Everything here is gated: with unset offsets it reports exactly what is missing and
// never touches game memory.
#pragma once
#include <atomic>
#include <mutex>
#include <string>
#include <vector>

#include "config/Offsets.h"
#include "logic/ScreenMap.h"
#include "logic/Snapshot.h"
#include "platform/Module.h"

namespace carrom {

class GameBridge {
public:
    enum class Status { NoModule, MissingOffsets, NoMemoryAccess, WaitingForGame, Ready, ReadFailed };

    void Configure(const ModuleInfo& module, const Offsets& offsets);

    // Game thread (called from the GameUpdate hook). Cheap; samples the transform if configured.
    void OnGameUpdate(uintptr_t gameManager);

    // Render thread. Fills `out`; returns false if the game state cannot be read right now.
    bool BuildSnapshot(FrameSnapshot& out);

    Status status() const { return m_status.load(); }
    std::string StatusText() const;
    std::vector<std::string> MissingRequired() const { return m_missing; }
    WorldAffine Transform() const;
    uintptr_t gameManager() const { return m_gm.load(); }
    bool HasFreshUpdate() const;

private:
    bool Fail(const std::string& why);

    ModuleInfo m_module;
    Offsets m_off;
    std::vector<std::string> m_missing;

    std::atomic<Status> m_status{Status::NoModule};
    std::atomic<uintptr_t> m_gm{0};
    std::atomic<long long> m_lastUpdateMs{0};

    mutable std::mutex m_mutex;
    std::string m_lastError;
    WorldAffine m_affine;
};

} // namespace carrom
