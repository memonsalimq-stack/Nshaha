// Plays a shot as a finger gesture: press on the striker, pull back, release.
// Port of the old ShotDragger/DragFire timings (press 0.12 s, pull 0.45 s, hold 0.20 s).
#pragma once
#include "game/TouchSink.h"

namespace carrom {

struct ScreenXY { float x = 0.f, y = 0.f; };

class ShotExecutor {
public:
    void SetSink(TouchSink* sink) { m_sink = sink; }
    bool CanFire() const { return m_sink && m_sink->Available(); }
    bool Busy() const { return m_mode != Mode::Idle; }

    // angle: radians in world space (y up); power: 0..1. Screen y points down.
    bool FireDrag(ScreenXY striker, double angle, double power, float screenHeight);
    // A short tap, used to select a pocket when queen cover must be nominated.
    bool Tap(ScreenXY at);

    void Update(float dt);
    // Releases anything still held (focus loss, shutdown).
    void Abort();

private:
    enum class Mode { Idle, Press, Pull, Hold, TapDown };
    static constexpr int kTouchId = 9; // same pointer index the old project used

    TouchSink* m_sink = nullptr;
    Mode m_mode = Mode::Idle;
    float m_t = 0.f;
    ScreenXY m_start, m_release, m_cur;
    bool m_tapOnly = false;
};

} // namespace carrom
