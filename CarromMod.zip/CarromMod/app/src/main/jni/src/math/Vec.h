#pragma once
#include <cmath>

namespace carrom {

struct Vec2d {
    double x = 0.0, y = 0.0;
    constexpr Vec2d() = default;
    constexpr Vec2d(double px, double py) : x(px), y(py) {}
    constexpr Vec2d operator+(const Vec2d& o) const { return {x + o.x, y + o.y}; }
    constexpr Vec2d operator-(const Vec2d& o) const { return {x - o.x, y - o.y}; }
    constexpr Vec2d operator*(double s) const { return {x * s, y * s}; }
    constexpr double square() const { return x * x + y * y; }
    constexpr void nullify() { x = 0.0; y = 0.0; }
    constexpr bool operator==(const Vec2d& o) const { return x == o.x && y == o.y; }
    constexpr bool operator!=(const Vec2d& o) const { return !(*this == o); }
};

struct Vec3d {
    double x = 0.0, y = 0.0, z = 0.0;
    constexpr double square() const { return x * x + y * y + z * z; }
    constexpr void nullify() { x = y = z = 0.0; }
};

using Point2D = Vec2d;

inline bool IsFinite(const Vec2d& v) { return std::isfinite(v.x) && std::isfinite(v.y); }

} // namespace carrom
