#include "config/Settings.h"

#include <algorithm>
#include <cstdlib>
#include <fstream>
#include <sstream>

namespace carrom {

namespace {
template <class T> T Bound(T v, T lo, T hi) { return std::min(std::max(v, lo), hi); }

bool ParseBool(const std::string& v) { return v == "1" || v == "true"; }
} // namespace

void Settings::Clamp() {
    autoPlayMode = Bound(autoPlayMode, 0, 1);
    queueMode = Bound(queueMode, 0, 2);
    coinIndex = Bound(coinIndex, 0, queueMode == 2 ? 8 : 11);
    lineStyle = Bound(lineStyle, 0, 1);
    lineThickness = Bound(lineThickness, 1.0f, 10.0f);
    lineOpacity = Bound(lineOpacity, 0.1f, 1.0f);
    fontPixels = Bound(fontPixels, 10.0f, 80.0f);
    menuW = Bound(menuW, 200.f, 2000.f);
    menuH = Bound(menuH, 200.f, 2000.f);
    playBtnSize = Bound(playBtnSize, 20.f, 400.f);
    logoBtnSize = Bound(logoBtnSize, 20.f, 400.f);
}

std::string Settings::Serialize() const {
    std::ostringstream o;
    auto b = [&](const char* k, bool v) { o << k << '=' << (v ? 1 : 0) << '\n'; };
    auto i = [&](const char* k, int v) { o << k << '=' << v << '\n'; };
    auto f = [&](const char* k, float v) { o << k << '=' << v << '\n'; };
    b("predictionLine", predictionLine);
    b("strikerPath", strikerPath);
    b("puckPaths", puckPaths);
    b("predictionAfterShot", predictionAfterShot);
    i("autoPlayMode", autoPlayMode);
    b("cleanTable", cleanTable);
    b("autoQueue", autoQueue);
    i("queueMode", queueMode);
    i("coinIndex", coinIndex);
    i("lineStyle", lineStyle);
    f("lineThickness", lineThickness);
    f("lineOpacity", lineOpacity);
    f("menuX", menuX); f("menuY", menuY); f("menuW", menuW); f("menuH", menuH);
    f("playBtnX", playBtnX); f("playBtnY", playBtnY); f("playBtnSize", playBtnSize);
    f("logoBtnX", logoBtnX); f("logoBtnY", logoBtnY); f("logoBtnSize", logoBtnSize);
    f("fontPixels", fontPixels);
    b("consumeTouchOverUi", consumeTouchOverUi);
    return o.str();
}

void Settings::Deserialize(const std::string& text) {
    std::istringstream in(text);
    std::string line;
    while (std::getline(in, line)) {
        const size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        const std::string k = line.substr(0, eq);
        const std::string v = line.substr(eq + 1);
        const float fv = (float)std::atof(v.c_str());
        const int iv = std::atoi(v.c_str());
        if (k == "predictionLine") predictionLine = ParseBool(v);
        else if (k == "strikerPath") strikerPath = ParseBool(v);
        else if (k == "puckPaths") puckPaths = ParseBool(v);
        else if (k == "predictionAfterShot") predictionAfterShot = ParseBool(v);
        else if (k == "autoPlayMode") autoPlayMode = iv;
        else if (k == "cleanTable") cleanTable = ParseBool(v);
        else if (k == "autoQueue") autoQueue = ParseBool(v);
        else if (k == "queueMode") queueMode = iv;
        else if (k == "coinIndex") coinIndex = iv;
        else if (k == "lineStyle") lineStyle = iv;
        else if (k == "lineThickness") lineThickness = fv;
        else if (k == "lineOpacity") lineOpacity = fv;
        else if (k == "menuX") menuX = fv;
        else if (k == "menuY") menuY = fv;
        else if (k == "menuW") menuW = fv;
        else if (k == "menuH") menuH = fv;
        else if (k == "playBtnX") playBtnX = fv;
        else if (k == "playBtnY") playBtnY = fv;
        else if (k == "playBtnSize") playBtnSize = fv;
        else if (k == "logoBtnX") logoBtnX = fv;
        else if (k == "logoBtnY") logoBtnY = fv;
        else if (k == "logoBtnSize") logoBtnSize = fv;
        else if (k == "fontPixels") fontPixels = fv;
        else if (k == "consumeTouchOverUi") consumeTouchOverUi = ParseBool(v);
    }
    autoPlay = false; // never start with autoplay armed
    autoQueue = false;
    Clamp();
}

bool Settings::Load(const std::string& path) {
    std::ifstream f(path);
    if (!f.is_open()) return false;
    std::stringstream ss;
    ss << f.rdbuf();
    Deserialize(ss.str());
    return true;
}

bool Settings::Save(const std::string& path) const {
    std::ofstream f(path, std::ios::trunc);
    if (!f.is_open()) return false;
    f << Serialize();
    return f.good();
}

} // namespace carrom
