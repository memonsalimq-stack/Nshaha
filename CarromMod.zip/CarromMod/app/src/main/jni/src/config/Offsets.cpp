#include "config/Offsets.h"

#include <cctype>
#include <cerrno>
#include <cstdlib>
#include <fstream>
#include <sstream>

namespace carrom {

namespace {

std::string Trim(const std::string& s) {
    size_t a = 0, b = s.size();
    while (a < b && std::isspace((unsigned char)s[a])) ++a;
    while (b > a && std::isspace((unsigned char)s[b - 1])) --b;
    return s.substr(a, b - a);
}

bool ParseNumber(const std::string& text, uintptr_t* out) {
    if (text.empty()) return false;
    errno = 0;
    char* end = nullptr;
    const unsigned long long v = std::strtoull(text.c_str(), &end, 0); // base 0: 0x.. hex, else decimal
    if (errno != 0 || end == text.c_str() || *end != '\0') return false;
    *out = (uintptr_t)v;
    return true;
}

// Keys that may stay unset without breaking the bridge.
bool IsOptionalKey(const std::string& k) {
    static const char* kOptional[] = {
        "rva.striker_properties_ptr", "rva.world_transform_fn", "rva.world_transform_scale_float",
        "field.gm.visual_english", "field.board.properties",
        "field.props.pockets", "field.piece.radius", "field.english.value",
        "field.striker_props.english_multiplier", "field.striker_props.max_power",
        "sym.touches_begin", "sym.touches_move", "sym.touches_end"};
    for (const char* o : kOptional)
        if (k == o) return true;
    return false;
}

} // namespace

int Offsets::LoadFromText(const std::string& text, std::vector<std::string>* errors) {
    int applied = 0;
    std::istringstream in(text);
    std::string line;
    int lineNo = 0;
    auto err = [&](const std::string& m) {
        if (errors) errors->push_back("line " + std::to_string(lineNo) + ": " + m);
    };
    while (std::getline(in, line)) {
        ++lineNo;
        const size_t hash = line.find('#');
        if (hash != std::string::npos) line.erase(hash);
        line = Trim(line);
        if (line.empty()) continue;
        const size_t eq = line.find('=');
        if (eq == std::string::npos) { err("missing '='"); continue; }
        const std::string key = Trim(line.substr(0, eq));
        const std::string val = Trim(line.substr(eq + 1));
        if (val.empty()) continue; // template line left blank: stays unset

        bool known = false;
#define X(member, k, kind, doc)                                                   \
        if (key == k) {                                                           \
            known = true;                                                         \
            uintptr_t v = 0;                                                      \
            if (!ParseNumber(val, &v)) err("bad number for " + key + ": " + val); \
            else { member.value = v; member.set = true; ++applied; }              \
        }
        CARROM_NUMERIC_OFFSETS(X)
#undef X
#define X(member, k, doc)                                                         \
        if (key == k) {                                                           \
            known = true;                                                         \
            member.name = val;                                                    \
            member.set = true;                                                    \
            ++applied;                                                            \
        }
        CARROM_SYMBOL_OFFSETS(X)
#undef X
        if (!known) err("unknown key " + key);
    }
    return applied;
}

bool Offsets::LoadFromFile(const std::string& path, std::vector<std::string>* errors) {
    std::ifstream f(path);
    if (!f.is_open()) return false;
    std::stringstream ss;
    ss << f.rdbuf();
    LoadFromText(ss.str(), errors);
    return true;
}

std::string Offsets::TemplateText() {
    std::string t =
        "# carrom_offsets.cfg: fill in values measured on YOUR game build, leave the rest empty.\n"
        "# Numbers: 0x1234 (hex) or 1234 (decimal). Symbols: exact export name.\n"
        "# 'rva' is relative to the base of libgame-CARROM*.so. '(optional)' keys may stay empty.\n\n";
#define X(member, k, kind, doc) t += std::string("# ") + #kind + ": " + doc + "\n" + k + "=\n\n";
    CARROM_NUMERIC_OFFSETS(X)
#undef X
#define X(member, k, doc) t += std::string("# symbol: ") + doc + "\n" + k + "=\n\n";
    CARROM_SYMBOL_OFFSETS(X)
#undef X
    return t;
}

int Offsets::TotalCount() {
    int n = 0;
#define X(member, k, kind, doc) ++n;
    CARROM_NUMERIC_OFFSETS(X)
#undef X
#define X(member, k, doc) ++n;
    CARROM_SYMBOL_OFFSETS(X)
#undef X
    return n;
}

int Offsets::SetCount() const {
    int n = 0;
#define X(member, k, kind, doc) if (member.set) ++n;
    CARROM_NUMERIC_OFFSETS(X)
#undef X
#define X(member, k, doc) if (member.set) ++n;
    CARROM_SYMBOL_OFFSETS(X)
#undef X
    return n;
}

std::vector<std::string> Offsets::MissingRequired() const {
    std::vector<std::string> out;
#define X(member, k, kind, doc) if (!member.set && !IsOptionalKey(k)) out.push_back(k);
    CARROM_NUMERIC_OFFSETS(X)
#undef X
    return out;
}

std::vector<std::string> Offsets::MissingOptional() const {
    std::vector<std::string> out;
#define X(member, k, kind, doc) if (!member.set && IsOptionalKey(k)) out.push_back(k);
    CARROM_NUMERIC_OFFSETS(X)
#undef X
#define X(member, k, doc) if (!member.set) out.push_back(k);
    CARROM_SYMBOL_OFFSETS(X)
#undef X
    return out;
}

} // namespace carrom
