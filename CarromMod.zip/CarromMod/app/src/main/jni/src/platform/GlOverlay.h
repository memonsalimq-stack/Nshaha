// Hooks eglSwapBuffers and draws the ImGui overlay into the game's own GL context. Android only.
#pragma once
#include "platform/Hooks.h"

namespace carrom::gl {

// Returns true if the hook was installed. Safe to call once.
bool InstallEglHook(HookManager& hooks);

} // namespace carrom::gl
