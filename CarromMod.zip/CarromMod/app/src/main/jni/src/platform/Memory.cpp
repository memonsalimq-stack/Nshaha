#include "platform/Memory.h"

#include <sys/syscall.h>
#include <sys/uio.h>
#include <unistd.h>

#include <atomic>
#include <cerrno>

namespace carrom::mem {

namespace {
std::atomic<int> g_state{0}; // 0 unknown, 1 available, -1 unavailable

long SelfRead(uintptr_t address, void* out, size_t size) {
    struct iovec local{out, size};
    struct iovec remote{(void*)address, size};
    return syscall(SYS_process_vm_readv, getpid(), &local, 1UL, &remote, 1UL, 0UL);
}
} // namespace

bool Read(uintptr_t address, void* out, size_t size) {
    if (!out || size == 0) return false;
    if (address < 0x1000) return false;
    if (g_state.load(std::memory_order_relaxed) < 0) return false;
    const long n = SelfRead(address, out, size);
    if (n == (long)size) {
        g_state.store(1, std::memory_order_relaxed);
        return true;
    }
    if (n < 0 && (errno == ENOSYS || errno == EPERM) && g_state.load() == 0) {
        g_state.store(-1, std::memory_order_relaxed);
    }
    return false;
}

std::vector<uint8_t> ReadRange(uintptr_t base, size_t len, size_t* unreadableChunks) {
    std::vector<uint8_t> buf;
    if (unreadableChunks) *unreadableChunks = 0;
    if (len == 0 || len > (size_t(2) << 30)) return buf;
    buf.assign(len, 0);
    constexpr size_t kChunk = 4096;
    for (size_t off = 0; off < len; off += kChunk) {
        const size_t want = len - off < kChunk ? len - off : kChunk;
        if (!Read(base + off, buf.data() + off, want) && unreadableChunks) ++*unreadableChunks;
    }
    return buf;
}

bool Available() {
    int s = g_state.load();
    if (s != 0) return s > 0;
    static volatile int probe = 0x5a5a;
    int v = 0;
    const long n = SelfRead((uintptr_t)&probe, &v, sizeof(v));
    const bool ok = n == (long)sizeof(v) && v == 0x5a5a;
    g_state.store(ok ? 1 : -1);
    return ok;
}

} // namespace carrom::mem
