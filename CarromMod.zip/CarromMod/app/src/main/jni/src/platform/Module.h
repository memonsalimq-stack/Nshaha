// Locates a loaded shared library by name fragment and reports its load bias and size.
#pragma once
#include <cstdint>
#include <string>

namespace carrom {

struct ModuleInfo {
    bool found = false;
    std::string path;
    uintptr_t base = 0; // load bias: RVA + base = runtime address
    uintptr_t size = 0; // end of the highest PT_LOAD segment, relative to base
};

ModuleInfo FindModule(const std::string& nameContains);

} // namespace carrom
