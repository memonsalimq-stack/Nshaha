// JNI helpers. Android only.
#pragma once
#include <jni.h>

namespace carrom {

void SetJavaVM(JavaVM* vm);
JavaVM* GetJavaVM();

// Attaches the calling thread to the VM for the lifetime of the scope if it is not attached yet.
class JniThreadScope {
public:
    JniThreadScope();
    ~JniThreadScope();
    JNIEnv* env() const { return m_env; }
private:
    JNIEnv* m_env = nullptr;
    bool m_attached = false;
};

} // namespace carrom
