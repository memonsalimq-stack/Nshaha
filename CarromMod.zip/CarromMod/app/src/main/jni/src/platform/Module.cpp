#include "platform/Module.h"

#include <link.h>

#include <algorithm>

namespace carrom {

namespace {
struct Query {
    const std::string* needle;
    ModuleInfo result;
};

int Callback(struct dl_phdr_info* info, size_t, void* data) {
    auto* q = static_cast<Query*>(data);
    if (!info->dlpi_name || !*info->dlpi_name) return 0;
    const std::string path = info->dlpi_name;
    if (path.find(*q->needle) == std::string::npos) return 0;

    uintptr_t end = 0;
    for (int i = 0; i < info->dlpi_phnum; ++i) {
        const auto& ph = info->dlpi_phdr[i];
        if (ph.p_type == PT_LOAD) end = std::max<uintptr_t>(end, ph.p_vaddr + ph.p_memsz);
    }
    if (end == 0) return 0;
    q->result.found = true;
    q->result.path = path;
    q->result.base = info->dlpi_addr;
    q->result.size = end;
    return 1; // stop at the first match
}
} // namespace

ModuleInfo FindModule(const std::string& nameContains) {
    Query q{&nameContains, {}};
    dl_iterate_phdr(Callback, &q);
    return q.result;
}

} // namespace carrom
