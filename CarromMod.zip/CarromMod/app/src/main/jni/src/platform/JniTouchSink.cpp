#include "platform/JniTouchSink.h"

#include <dlfcn.h>

#include "platform/Jni.h"
#include "platform/Log.h"

namespace carrom {

bool JniTouchSink::Resolve(const ModuleInfo& module, const Offsets& o) {
    m_begin = m_end = nullptr;
    m_move = nullptr;
    if (!module.found || !o.SymTouchBegin.set || !o.SymTouchMove.set || !o.SymTouchEnd.set) return false;

    // RTLD_NOLOAD: only look inside the already loaded game library, never load anything.
    void* h = dlopen(module.path.c_str(), RTLD_NOW | RTLD_NOLOAD);
    if (!h) { Logf("touch sink: dlopen(NOLOAD) failed for %s", module.path.c_str()); return false; }
    m_begin = (BeginEndFn)dlsym(h, o.SymTouchBegin.name.c_str());
    m_move = (MoveFn)dlsym(h, o.SymTouchMove.name.c_str());
    m_end = (BeginEndFn)dlsym(h, o.SymTouchEnd.name.c_str());
    dlclose(h);
    if (!Available()) {
        Logf("touch sink: symbols not found (begin=%p move=%p end=%p)", (void*)m_begin, (void*)m_move, (void*)m_end);
        m_begin = m_end = nullptr;
        m_move = nullptr;
        return false;
    }
    Logf("touch sink ready");
    return true;
}

void JniTouchSink::Begin(int id, float x, float y) {
    JniThreadScope s;
    if (s.env() && m_begin) m_begin(s.env(), nullptr, id, x, y, JNI_FALSE, JNI_FALSE);
}

void JniTouchSink::End(int id, float x, float y) {
    JniThreadScope s;
    if (s.env() && m_end) m_end(s.env(), nullptr, id, x, y, JNI_FALSE, JNI_FALSE);
}

void JniTouchSink::Move(int id, float x, float y) {
    JniThreadScope s;
    JNIEnv* env = s.env();
    if (!env || !m_move) return;
    jintArray ids = env->NewIntArray(1);
    jfloatArray xs = env->NewFloatArray(1);
    jfloatArray ys = env->NewFloatArray(1);
    if (ids && xs && ys) {
        env->SetIntArrayRegion(ids, 0, 1, &id);
        env->SetFloatArrayRegion(xs, 0, 1, &x);
        env->SetFloatArrayRegion(ys, 0, 1, &y);
        m_move(env, nullptr, ids, xs, ys, JNI_FALSE, JNI_FALSE);
    }
    if (ids) env->DeleteLocalRef(ids);
    if (xs) env->DeleteLocalRef(xs);
    if (ys) env->DeleteLocalRef(ys);
}

} // namespace carrom
