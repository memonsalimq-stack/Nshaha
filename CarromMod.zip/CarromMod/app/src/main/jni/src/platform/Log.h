// Tiny logger: Android logcat + an in-memory ring the menu can show.
#pragma once
#include <cstdarg>
#include <cstdio>
#include <deque>
#include <mutex>
#include <string>
#include <vector>

#ifdef __ANDROID__
#include <android/log.h>
#endif

namespace carrom {

class LogRing {
public:
    static LogRing& Get() { static LogRing r; return r; }
    void Add(const std::string& line) {
        std::lock_guard<std::mutex> lk(m_mutex);
        m_lines.push_back(line);
        while (m_lines.size() > 64) m_lines.pop_front();
    }
    std::vector<std::string> Snapshot() {
        std::lock_guard<std::mutex> lk(m_mutex);
        return {m_lines.begin(), m_lines.end()};
    }
private:
    std::mutex m_mutex;
    std::deque<std::string> m_lines;
};

#if defined(__GNUC__)
__attribute__((format(printf, 1, 2)))
#endif
inline void Logf(const char* fmt, ...) {
    char buf[512];
    va_list ap;
    va_start(ap, fmt);
    std::vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
#ifdef __ANDROID__
    __android_log_print(ANDROID_LOG_INFO, "CarromMod", "%s", buf);
#else
    std::fprintf(stderr, "[CarromMod] %s\n", buf);
#endif
    LogRing::Get().Add(buf);
}

} // namespace carrom
