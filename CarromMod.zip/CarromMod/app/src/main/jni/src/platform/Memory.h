// Fault-tolerant reads of this process' own memory.
// Uses process_vm_readv on our own pid: a bad address returns an error instead of crashing.
#pragma once
#include <cstddef>
#include <cstdint>
#include <vector>

namespace carrom::mem {

// False on any failure, including partial reads.
bool Read(uintptr_t address, void* out, size_t size);

// True once a probe read of our own memory succeeded. False means the kernel/seccomp
// policy refuses process_vm_readv; callers must then refuse to read game memory.
bool Available();

template <class T>
bool Read(uintptr_t address, T* out) { return Read(address, out, sizeof(T)); }

// Reads [base, base+len) in 4 KB chunks into a host buffer. A chunk that cannot be read (hole,
// guard page) is left zero-filled; `unreadableChunks` (optional) counts them. Never throws on a
// bad range: returns a zero-filled buffer of the requested size (or empty if len == 0 or the
// request is absurdly large, > 2 GiB).
std::vector<uint8_t> ReadRange(uintptr_t base, size_t len, size_t* unreadableChunks = nullptr);

// Convenience: returns false if the read failed, otherwise stores the value.
template <class T>
bool ReadAt(uintptr_t base, uintptr_t offset, T* out) {
    if (base > UINTPTR_MAX - offset) return false;
    return Read(base + offset, out, sizeof(T));
}

// Rejects null and obviously non-user-space pointers (arm64 user space is 48 bit).
inline bool PlausiblePointer(uintptr_t p) { return p >= 0x10000 && p < (uintptr_t(1) << 48) && (p & 7) == 0; }

} // namespace carrom::mem
