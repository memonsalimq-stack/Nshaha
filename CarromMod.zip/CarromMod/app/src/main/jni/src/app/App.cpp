#include "app/App.h"

#include <cmath>
#include <sys/stat.h>

#include <fstream>

#include "imgui.h"
#include "platform/Log.h"
#include "ui/PredictionDraw.h"

namespace carrom {

namespace {
using GameUpdateFn = void (*)(uintptr_t self, uintptr_t arg1, double dt);
GameUpdateFn g_origGameUpdate = nullptr;

// ABI: x0 = self, x1 = arg1, d0 = dt (same as the old kill.h hook).
void HookedGameUpdate(uintptr_t self, uintptr_t arg1, double dt) {
    if (g_origGameUpdate) g_origGameUpdate(self, arg1, dt);
    App::Get().OnGameUpdate(self);
}

bool FileExists(const std::string& p) { std::ifstream f(p); return f.good(); }
} // namespace

App& App::Get() { static App app; return app; }

void App::Configure(const std::string& filesDir, const std::string& moduleNameFragment) {
    m_filesDir = filesDir;
    settings.Load(filesDir + "/carrom_settings.ini");

    const std::string dumpDir = filesDir + "/dumps";
    mkdir(dumpDir.c_str(), 0771);          // ok if it already exists
    ui.SetDumpDir(dumpDir);

    const std::string offsetsPath = filesDir + "/carrom_offsets.cfg";
    offsets = Offsets{};
    m_offsetErrors.clear();
    if (FileExists(offsetsPath)) {
        offsets.LoadFromFile(offsetsPath, &m_offsetErrors);
    } else {
        std::ofstream t(offsetsPath);
        if (t.is_open()) {
            t << Offsets::TemplateText();
            Logf("wrote offsets template to %s", offsetsPath.c_str());
        }
    }
    for (const auto& e : m_offsetErrors) Logf("offsets: %s", e.c_str());

    module = FindModule(moduleNameFragment);
    hooks.SetModule(module);
    if (module.found)
        Logf("game module %s base=%#lx size=%#lx", module.path.c_str(), (unsigned long)module.base,
             (unsigned long)module.size);
    else
        Logf("game module '%s' not loaded (yet)", moduleNameFragment.c_str());

    tester.SetModule(module);
    bridge.Configure(module, offsets);
    tester.LoadSavedFromFile(filesDir + "/carrom_tester_saved.tsv");
    m_snapshotSource = [this](FrameSnapshot& s) { return bridge.BuildSnapshot(s); };
    m_transformSource = [this]() { return bridge.Transform(); };
}

bool App::AttachModule(const std::string& fragment) {
    std::lock_guard<std::mutex> lk(m_mutex);
    module = FindModule(fragment);
    hooks.SetModule(module);
    tester.SetModule(module);
    bridge.Configure(module, offsets);
    if (module.found)
        Logf("game module %s base=%#lx size=%#lx", module.path.c_str(), (unsigned long)module.base,
             (unsigned long)module.size);
    return module.found;
}

int App::InstallGameHooks() {
    int installed = 0;
    if (!offsets.HookGameUpdate.set) {
        Logf("hook rva.hook_game_update not set: game state stays unavailable");
        return 0;
    }
    if (hooks.InstallRva("GameUpdate", offsets.HookGameUpdate.value, (void*)&HookedGameUpdate,
                         (void**)&g_origGameUpdate))
        ++installed;
    return installed;
}

void App::SaveSettingsNow() {
    if (m_filesDir.empty()) return;
    settings.Save(m_filesDir + "/carrom_settings.ini");
}

void App::SaveTesterNow() {
    if (m_filesDir.empty()) return;
    tester.SaveSavedToFile(m_filesDir + "/carrom_tester_saved.tsv");
}

ui::UiStatus App::BuildStatus(bool calculating) const {
    ui::UiStatus st;
    st.bridge = bridge.StatusText();
    st.module = module.found ? module.path.substr(module.path.find_last_of('/') + 1) : "not found";
    st.offsetsSet = offsets.SetCount();
    st.offsetsTotal = Offsets::TotalCount();
    st.hooksInstalled = hooks.InstalledCount();
    st.hooksTotal = (int)hooks.records().size();
    st.fireAvailable = executor.CanFire();
    st.calculating = calculating;
    st.autoPlayNote = m_note;
    return st;
}

ui::UiOutput App::Frame(float W, float H, float dt, double now) {
    std::lock_guard<std::mutex> lock(m_mutex);
    screen.SetViewport(W, H);
    const WorldAffine affine = m_transformSource ? m_transformSource() : WorldAffine{};
    if (affine.valid) screen.SetAffine(affine);
    else screen.ClearAffine();

    // ~30 Hz snapshot: every read is a syscall, no need to do it on every frame
    if (now - m_lastSnapTime >= 1.0 / 30.0) {
        m_lastSnapTime = now;
        if (!m_snapshotSource || !m_snapshotSource(m_snap)) m_snap = FrameSnapshot{};
    }

    const bool armed = settings.autoPlay && ui.autoPlaying();
    if (armed != m_armed) {
        m_armed = armed;
        autoplay.SetEnabled(armed);
        if (!armed) executor.Abort();
        m_note.clear();
    }
    autoplay.SetMode(settings.autoPlayMode == 1 ? AutoPlayer::Scan::Slow : AutoPlayer::Scan::Fast);

    executor.Update(dt);
    autoplay.SetExecutorBusy(executor.Busy());

    if (armed && m_snap.valid) {
        const ShotAction a = autoplay.Update(predPlan, m_snap, now);
        if (a.kind == ShotAction::Kind::Fire || a.kind == ShotAction::Kind::Nominate) {
            const auto& striker = m_snap.pieces;
            Vec2d strikerPos;
            for (const auto& p : striker) if (p.type == PieceType::Striker) strikerPos = p.pos;

            if (!executor.CanFire()) {
                m_note = "cannot act: no touch path (set sym.touches_* in offsets)";
                if (a.kind == ShotAction::Kind::Fire) autoplay.NotifyFired(120);
            } else if (!screen.Usable()) {
                m_note = "cannot act: no world->screen transform (set rva.world_transform_*)";
                if (a.kind == ShotAction::Kind::Fire) autoplay.NotifyFired(120);
            } else if (a.kind == ShotAction::Kind::Fire) {
                const ScreenPoint sp = screen.WorldToScreen(strikerPos);
                if (sp.valid && executor.FireDrag({sp.x, sp.y}, a.angle, a.power, H)) {
                    autoplay.NotifyFired(45);
                    m_note.clear();
                }
            } else {
                const int pk = a.pocketIndex;
                if (pk >= 0 && pk < 4) {
                    const ScreenPoint pp = screen.WorldToScreen(m_snap.pockets[pk]);
                    if (pp.valid) executor.Tap({pp.x, pp.y});
                }
            }
        }
    } else if (!armed) {
        m_note.clear();
    }

    // prediction line (live aim, or the planner's suggestion while autoplay is armed)
    if (settings.predictionLine && m_snap.valid && m_snap.playerTurn && screen.Usable()) {
        bool suggested = false;
        if (armed && autoplay.candidate().idx >= 0) {
            predLive.Run(m_snap, false, autoplay.candidate().angle, autoplay.candidate().power, m_snap.spin);
            suggested = true;
        } else {
            predLive.Run(m_snap, false, m_snap.aimAngle, m_snap.aimPower, m_snap.spin);
        }
        ui::DrawPrediction(ImGui::GetBackgroundDrawList(), predLive, screen, settings, W, H, suggested);
    }

    const bool calculating = armed && m_snap.valid && m_snap.playerTurn &&
                             autoplay.state() == AutoPlayer::State::Scanning && autoplay.candidate().idx < 0;
    ui::UiOutput out = ui.Draw(BuildStatus(calculating), W, H);

    if (out.settingsChanged) { m_saveQueued = true; m_saveAt = now + 1.0; }
    if (out.testerChanged) SaveTesterNow();
    if (m_saveQueued && now >= m_saveAt) { m_saveQueued = false; SaveSettingsNow(); }
    return out;
}

} // namespace carrom
