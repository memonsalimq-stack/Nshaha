// World (board units) -> screen (pixels, y down).
//
// Only the transform sampled from the game is supported, same formula as the old project:
//   px = ox + vxx*x + vyx*y ;  py = H - (oy + vxy*x + vyy*y)
// It needs the optional rva.world_transform_* offsets. Without them every point is invalid and
// nothing is drawn or fired: the game is portrait (CarromActivity screenOrientation=portrait in the
// 19.6.1 manifest), and the old 1280x640 landscape reference layout does not describe it, so no
// geometric guess is offered.
#pragma once
#include "math/Vec.h"

namespace carrom {

struct ScreenPoint {
    float x = -9999.f, y = -9999.f;
    bool valid = false;
};

struct WorldAffine {
    double ox = 0, oy = 0;     // screen position of world (0,0), y up
    double vxx = 0, vxy = 0;   // screen delta per world +x
    double vyx = 0, vyy = 0;   // screen delta per world +y
    bool valid = false;
};

class ScreenMap {
public:
    void SetViewport(double w, double h) { m_w = w; m_h = h; }
    void SetAffine(const WorldAffine& a) { m_affine = a; }
    void ClearAffine() { m_affine.valid = false; }

    bool Usable() const { return m_affine.valid && m_h > 0.0; }
    ScreenPoint WorldToScreen(const Vec2d& world) const;
    // Pixels per world unit near the board centre (0 when unusable).
    double PixelsPerUnit() const;

private:
    double m_w = 0, m_h = 0;
    WorldAffine m_affine;
};

} // namespace carrom
