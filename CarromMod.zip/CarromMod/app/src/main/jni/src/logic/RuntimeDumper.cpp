#include "logic/RuntimeDumper.h"

#include <cstdio>
#include <cstring>
#include <vector>

#include "platform/Memory.h"

namespace carrom {

namespace {
constexpr size_t kChunk = 4096;
}

DumpResult RuntimeDumper::DumpModule(const MappedModule& mod, const std::string& outputPath) const {
    return DumpRange(mod.base, mod.end, outputPath);
}

DumpResult RuntimeDumper::DumpRange(uintptr_t start, uintptr_t end, const std::string& outputPath) const {
    MappedModule mod;
    mod.base = start;
    mod.end = end;
    DumpResult r;
    r.base = mod.base;
    r.end = mod.end;
    r.outputPath = outputPath;
    if (mod.base == 0 || mod.end <= mod.base) { r.error = "empty or invalid module range"; return r; }

    std::FILE* out = std::fopen(outputPath.c_str(), "wb");
    if (!out) { r.error = "could not open output file: " + outputPath; return r; }

    std::vector<uint8_t> chunk(kChunk);
    uintptr_t addr = mod.base;
    bool writeFailed = false;
    while (addr < mod.end && !writeFailed) {
        const size_t want = std::min<size_t>(kChunk, mod.end - addr);
        bool readOk = mem::Read(addr, chunk.data(), want);
        if (!readOk) {
            ++r.pagesSkipped;
            std::memset(chunk.data(), 0, want); // keep file layout aligned with the address space
        }
        if (std::fwrite(chunk.data(), 1, want, out) != want) writeFailed = true;
        else r.bytesWritten += want;
        addr += want;
    }
    std::fclose(out);

    if (writeFailed) { r.error = "disk write failed partway through (disk full?)"; return r; }
    r.ok = true;
    if (r.pagesSkipped > 0)
        r.error = std::to_string(r.pagesSkipped) + " chunk(s) were unreadable and were zero-filled";
    return r;
}

} // namespace carrom
