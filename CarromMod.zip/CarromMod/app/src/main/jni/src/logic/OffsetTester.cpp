#include "logic/OffsetTester.h"

#include <cctype>
#include <cerrno>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <sstream>

#include "platform/Memory.h"

namespace carrom {

namespace {
std::string Trim(const std::string& s) {
    size_t a = 0, b = s.size();
    while (a < b && std::isspace((unsigned char)s[a])) ++a;
    while (b > a && std::isspace((unsigned char)s[b - 1])) --b;
    return s.substr(a, b - a);
}

bool ParseHop(const std::string& text, int64_t* out) {
    if (text.empty()) return false;
    errno = 0;
    char* end = nullptr;
    const bool neg = text[0] == '-';
    const char* p = neg ? text.c_str() + 1 : text.c_str();
    const unsigned long long v = std::strtoull(p, &end, 0); // base 0: "0x.." hex, else decimal
    if (errno != 0 || end == p || *end != '\0') return false;
    *out = neg ? -(int64_t)v : (int64_t)v;
    return true;
}
} // namespace

bool ParseChain(const std::string& chain, std::vector<int64_t>* hops) {
    hops->clear();
    std::stringstream ss(chain);
    std::string part;
    while (std::getline(ss, part, ',')) {
        part = Trim(part);
        if (part.empty()) continue;
        int64_t v = 0;
        if (!ParseHop(part, &v)) { hops->clear(); return false; }
        hops->push_back(v);
    }
    return !hops->empty();
}

TestResult OffsetTester::Read(const std::string& chain) const {
    TestResult r;
    if (!m_module.found) { r.error = "module not found"; return r; }

    std::vector<int64_t> hops;
    if (!ParseChain(chain, &hops)) { r.error = "could not parse chain (use e.g. 0x10 or 0x10,0x8)"; return r; }

    // Walk hops: the first hop is relative to module base; each subsequent hop dereferences
    // the address reached so far as a pointer, then adds the next hop to it.
    uintptr_t addr = m_module.base;
    for (size_t i = 0; i < hops.size(); ++i) {
        addr = addr + (uintptr_t)hops[i];
        const bool isLast = i + 1 == hops.size();
        if (!isLast) {
            uintptr_t next = 0;
            if (!mem::Read(addr, &next)) { r.error = "read failed following hop " + std::to_string(i); return r; }
            if (!mem::PlausiblePointer(next)) { r.error = "hop " + std::to_string(i) + " is not a plausible pointer"; return r; }
            addr = next;
        }
    }

    r.finalAddress = addr;
    r.bytesRead = (int)sizeof(r.bytes);
    if (!mem::Read(addr, r.bytes, sizeof(r.bytes))) {
        // fall back to a smaller read: the tail of mapped memory may be shorter than 32 bytes
        r.bytesRead = 8;
        if (!mem::Read(addr, r.bytes, 8)) { r.error = "read failed at final address"; return r; }
    }

    std::memcpy(&r.asInt32, r.bytes, 4);
    std::memcpy(&r.asInt64, r.bytes, 8);
    std::memcpy(&r.asFloat, r.bytes, 4);
    std::memcpy(&r.asDouble, r.bytes, 8);
    r.asPointer = (uintptr_t)r.asInt64;
    r.pointerPlausible = mem::PlausiblePointer(r.asPointer);

    char hex[3 * 32 + 1] = {0};
    char* p = hex;
    for (int i = 0; i < r.bytesRead; ++i) p += std::snprintf(p, 4, "%02X ", r.bytes[i]);
    r.hexLine = hex;

    for (int i = 0; i < r.bytesRead; ++i) {
        const unsigned char c = r.bytes[i];
        r.asAscii += (c >= 32 && c < 127) ? (char)c : '.';
    }
    r.ok = true;
    return r;
}

std::vector<TestResult> OffsetTester::ReadArray(const std::string& chain, int count) const {
    std::vector<TestResult> out;
    if (count <= 0) return out;
    if (count > 64) count = 64;
    const TestResult first = Read(chain);
    if (!first.ok) { out.push_back(first); return out; }
    for (int i = 0; i < count; ++i) {
        TestResult r;
        const uintptr_t addr = first.finalAddress + (uintptr_t)(i * 8);
        r.finalAddress = addr;
        r.bytesRead = 8;
        if (!mem::Read(addr, r.bytes, 8)) { r.error = "read failed"; out.push_back(r); continue; }
        std::memcpy(&r.asInt32, r.bytes, 4);
        std::memcpy(&r.asInt64, r.bytes, 8);
        std::memcpy(&r.asFloat, r.bytes, 4);
        std::memcpy(&r.asDouble, r.bytes, 8);
        r.asPointer = (uintptr_t)r.asInt64;
        r.pointerPlausible = mem::PlausiblePointer(r.asPointer);
        char hex[3 * 8 + 1] = {0};
        char* p = hex;
        for (int b = 0; b < 8; ++b) p += std::snprintf(p, 4, "%02X ", r.bytes[b]);
        r.hexLine = hex;
        for (int b = 0; b < 8; ++b) { const unsigned char c = r.bytes[b]; r.asAscii += (c >= 32 && c < 127) ? (char)c : '.'; }
        r.ok = true;
        out.push_back(r);
    }
    return out;
}

void OffsetTester::Save(const std::string& label, const std::string& chain, const std::string& kind) {
    for (auto& s : m_saved)
        if (s.label == label) { s.chain = chain; s.kind = kind; return; }
    m_saved.push_back({label, chain, kind});
}

void OffsetTester::RemoveSaved(size_t index) {
    if (index < m_saved.size()) m_saved.erase(m_saved.begin() + (long)index);
}

std::vector<TestResult> OffsetTester::ReadAllSaved() const {
    std::vector<TestResult> out;
    out.reserve(m_saved.size());
    for (const auto& s : m_saved) out.push_back(Read(s.chain));
    return out;
}

std::string OffsetTester::ExportSavedAsConfig() const {
    std::string out = "# exported from the in-app offset tester\n";
    for (const auto& s : m_saved) {
        std::vector<int64_t> hops;
        ParseChain(s.chain, &hops);
        out += "# chain=" + s.chain + " kind=" + s.kind + "\n";
        out += s.label + "=" + (hops.empty() ? "0x0" : ("0x" + [&] {
                   char b[20]; std::snprintf(b, sizeof(b), "%llX", (unsigned long long)hops[0]); return std::string(b);
               }())) + "\n";
    }
    return out;
}

bool OffsetTester::LoadSavedFromFile(const std::string& path) {
    std::ifstream f(path);
    if (!f.is_open()) return false;
    m_saved.clear();
    std::string line;
    while (std::getline(f, line)) {
        line = Trim(line);
        if (line.empty() || line[0] == '#') continue;
        const size_t t1 = line.find('\t');
        const size_t t2 = line.find('\t', t1 == std::string::npos ? std::string::npos : t1 + 1);
        if (t1 == std::string::npos || t2 == std::string::npos) continue;
        SavedOffset s;
        s.label = line.substr(0, t1);
        s.chain = line.substr(t1 + 1, t2 - t1 - 1);
        s.kind = line.substr(t2 + 1);
        m_saved.push_back(s);
    }
    return true;
}

bool OffsetTester::SaveSavedToFile(const std::string& path) const {
    std::ofstream f(path, std::ios::trunc);
    if (!f.is_open()) return false;
    f << "# label\\tchain\\tkind\n";
    for (const auto& s : m_saved) f << s.label << '\t' << s.chain << '\t' << s.kind << '\n';
    return f.good();
}

} // namespace carrom
