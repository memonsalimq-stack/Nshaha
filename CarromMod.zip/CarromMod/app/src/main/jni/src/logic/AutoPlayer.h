// Autoplay planner: picks a shot (angle, power, pocket) from a FrameSnapshot.
// Ported from the old project's game/inc/AutoPlay.h (ScanFast/ScanSlow/Shoot/Update).
// It only *plans*. Executing a shot (direct call into the game, or a simulated
// drag) and clicking a pocket for queen nomination are done by the caller.
#pragma once
#include "logic/Prediction.h"
#include "logic/Snapshot.h"

namespace carrom {

struct ShotAction {
    enum class Kind { None, Nominate, Fire };
    Kind kind = Kind::None;
    double angle = 0.0;
    double power = 0.0;
    int pocketIndex = -1;   // pocket to click (Nominate) or targeted pocket (Fire)
    int pieceIdx = -1;      // index in the prediction scene of the targeted piece
    int gamePieceId = -1;   // id on the game side of the targeted piece, -1 unknown
};

class AutoPlayer {
public:
    enum class Scan { Fast, Slow };
    enum class State { Idle, Scanning, Nominating };

    void SetEnabled(bool on) { m_enabled = on; if (on) Reset(); else m_state = State::Idle; }
    bool Enabled() const { return m_enabled; }
    // Which scan a new turn starts with. FAST may still fall back to SLOW on its own.
    void SetMode(Scan s) { m_preferred = s; if (m_state == State::Idle) m_scan = s; }
    void SetScan(Scan s) { m_scan = s; }
    Scan scan() const { return m_scan; }
    State state() const { return m_state; }
    const Candidate& candidate() const { return m_cand; }

    // Forget the current candidate (new turn, shot fired, toggled on).
    void Reset();

    // The executor reports whether it is still busy (e.g. a pocket click is running).
    void SetExecutorBusy(bool busy) { m_busy = busy; }
    // Call after a shot was actually fired: pause planning for this many frames.
    void NotifyFired(int cooldownFrames = 45) { m_cooldown = cooldownFrames; }

    // Run once per rendered frame. `now` is seconds on any monotonic clock.
    ShotAction Update(Prediction& pred, const FrameSnapshot& snap, double now);

    // exposed for tests / UI preview
    bool ScanFast(Prediction& pred, const FrameSnapshot& snap);
    bool ScanSlow(Prediction& pred, const FrameSnapshot& snap, double angleStep);

private:
    ShotAction Shoot(Prediction& pred, const FrameSnapshot& snap, double angle, double power);

    bool m_enabled = false;
    State m_state = State::Idle;
    Scan m_scan = Scan::Fast;
    Scan m_preferred = Scan::Fast;
    Candidate m_cand{};
    Vec2d m_lastFailedStrikerPos{-1000.0, -1000.0};
    int m_cooldown = 0;
    bool m_busy = false;

    int m_nominationFrames = 0;
    bool m_nominationClicked = false;
    double m_pendingAngle = 0.0, m_pendingPower = 0.0;

    double m_lastFastScanTime = -1e9;

    // ScanSlow state
    double m_slowAngle = 0.0;
    bool m_slowScanning = false;
    Vec2d m_slowStrikerPos{-1000.0, -1000.0};
};

double NormalizeAngle(double angle);

} // namespace carrom
