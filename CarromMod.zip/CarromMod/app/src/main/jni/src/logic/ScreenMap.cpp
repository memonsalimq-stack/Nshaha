#include "logic/ScreenMap.h"

#include <cmath>

namespace carrom {

ScreenPoint ScreenMap::WorldToScreen(const Vec2d& w) const {
    ScreenPoint out;
    if (!Usable() || !std::isfinite(w.x) || !std::isfinite(w.y)) return out;
    const double px = m_affine.ox + m_affine.vxx * w.x + m_affine.vyx * w.y;
    const double py = m_h - (m_affine.oy + m_affine.vxy * w.x + m_affine.vyy * w.y);
    if (std::isfinite(px) && std::isfinite(py)) { out.x = (float)px; out.y = (float)py; out.valid = true; }
    return out;
}

double ScreenMap::PixelsPerUnit() const {
    if (!Usable()) return 0.0;
    const ScreenPoint a = WorldToScreen({0, 0}), b = WorldToScreen({1, 0});
    if (!a.valid || !b.valid) return 0.0;
    return std::hypot((double)b.x - a.x, (double)b.y - a.y);
}

} // namespace carrom
