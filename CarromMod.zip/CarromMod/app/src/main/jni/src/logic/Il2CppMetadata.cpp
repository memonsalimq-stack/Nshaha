#include "logic/Il2CppMetadata.h"

#include <cstdio>
#include <cstring>

namespace carrom::il2cpp {

namespace {
int32_t ReadI32(const uint8_t* data, size_t off) {
    int32_t v;
    std::memcpy(&v, data + off, 4);
    return v;
}
} // namespace

// MetadataHeader.smali candidatesFor(int), lines 67-365: a plain switch on the raw version int.
// 24 -> {24.0, 24.1, 24.2}; 27 -> {27.0, 27.1, 27.2}; 29 -> {29.0, 29.1}; anything else -> itself.
std::vector<double> CandidatesFor(int32_t rawVersion) {
    switch (rawVersion) {
        case 24: return {24.0, 24.1, 24.2};
        case 27: return {27.0, 27.1, 27.2};
        case 29: return {29.0, 29.1};
        default: return {(double)rawVersion};
    }
}

// MetadataHeader.smali layoutFor(double), lines 433-914. The base 20 tables are unconditional;
// every table after that is included or not based on the exact comparisons at the smali lines
// noted beside each one (read directly, not inferred).
std::vector<std::string> LayoutFor(double v) {
    std::vector<std::string> t = {
        "stringLiteral", "stringLiteralData", "string", "events", "properties", "methods",
        "parameterDefaultValues", "fieldDefaultValues", "fieldAndParameterDefaultValueData",
        "fieldMarshaledSizes", "parameters", "fields", "genericParameters",
        "genericParameterConstraints", "genericContainers", "nestedTypes", "interfaces",
        "vtableMethods", "interfaceOffsets", "typeDefinitions"};

    if (v <= 24.1) t.push_back("rgctxEntries");               // smali line ~214-216
    t.push_back("images");
    t.push_back("assemblies");

    if (v <= 24.5) {                                           // smali line ~249-253
        t.push_back("metadataUsageLists");
        t.push_back("metadataUsagePairs");
    }
    t.push_back("fieldRefs");
    t.push_back("referencedAssemblies");

    if (v >= 29.0) {                                           // smali line ~295-301 (cond_7)
        t.push_back("attributeData");
        t.push_back("attributeDataRange");
    } else {
        t.push_back("attributesInfo");
        t.push_back("attributeTypes");
    }
    // smali goto_0 (line 322) rejoins here regardless of which branch above was taken.
    if (v >= 19.0 && v <= 24.5) {                               // lines ~325-339
        t.push_back("unresolvedVirtualCallParameterTypes");
        t.push_back("unresolvedVirtualCallParameterRanges");
    }
    if (v >= 29.0) {                                            // lines ~363-369
        t.push_back("unresolvedIndirectCallParameterTypes");
        t.push_back("unresolvedIndirectCallParameterRanges");
    }
    if (v >= 21.0) t.push_back("windowsRuntimeTypeNames");       // lines ~393-399
    if (v >= 27.0) t.push_back("windowsRuntimeStrings");         // lines ~414-420
    if (v >= 22.0) t.push_back("exportedTypeDefinitions");       // lines ~435-441
    return t;
}

MetadataResult ParseMetadataHeader(const uint8_t* data, size_t len) {
    MetadataResult r;
    if (!data || len < 12) { r.error = "buffer too short (need at least 12 bytes)"; return r; }

    r.magic = (uint32_t)ReadI32(data, 0);
    if (r.magic != kMetadataMagic) {
        char buf[96];
        std::snprintf(buf, sizeof(buf), "not global-metadata.dat: magic 0x%08X, expected 0x%08X", r.magic,
                      kMetadataMagic);
        r.error = buf;
        return r;
    }

    r.rawVersion = ReadI32(data, 4);
    if (r.rawVersion < 16 || r.rawVersion > 40) { // smali: if-lt 16 or if-gt 40 -> throw (lines ~1483-1538)
        r.error = "unsupported metadata version: " + std::to_string(r.rawVersion);
        return r;
    }

    const int32_t firstTableOffset = ReadI32(data, 8); // readIntAt(8), a peek: smali lines ~1538-1543
    r.candidatesTried = CandidatesFor(r.rawVersion);

    for (double candidate : r.candidatesTried) {
        const std::vector<std::string> layout = LayoutFor(candidate);
        const int32_t computedSize = 8 + (int32_t)layout.size() * 8; // smali lines ~1799-1807
        if (computedSize != firstTableOffset) continue;              // smali line ~1863 if-ne

        if (len < (size_t)computedSize) {
            r.error = "buffer too short for the matched table layout (need " + std::to_string(computedSize) +
                      " bytes, have " + std::to_string(len) + ")";
            return r;
        }
        r.resolvedVersion = candidate;
        r.tables.reserve(layout.size());
        size_t pos = 8;
        for (const auto& name : layout) {
            MetadataTable tab;
            tab.name = name;
            tab.offset = ReadI32(data, pos);
            tab.count = ReadI32(data, pos + 4);
            pos += 8;
            r.tables.push_back(tab);
        }
        r.ok = true;
        return r;
    }

    r.error = "no known table layout matches this file (first table offset " + std::to_string(firstTableOffset) +
              " did not match any candidate for raw version " + std::to_string(r.rawVersion) +
              "); layoutFor() needs an entry for this build";
    return r;
}

MetadataResult ParseMetadataHeaderFromFile(const std::string& path) {
    std::FILE* f = std::fopen(path.c_str(), "rb");
    if (!f) {
        MetadataResult r;
        r.error = "could not open file: " + path;
        return r;
    }
    // A header is at most 8 + (~35 tables)*8 ~= 300 bytes; 4096 is generous headroom.
    uint8_t buf[4096] = {0};
    const size_t n = std::fread(buf, 1, sizeof(buf), f);
    std::fclose(f);
    return ParseMetadataHeader(buf, n);
}

} // namespace carrom::il2cpp
