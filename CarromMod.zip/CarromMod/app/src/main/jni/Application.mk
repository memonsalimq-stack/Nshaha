APP_ABI := arm64-v8a
APP_STL := c++_static
ifeq ($(NDK_DEBUG),1)
APP_OPTIM := debug
else
APP_OPTIM := release
endif
APP_PIE := true
APP_PLATFORM := android-21
APP_CPPFLAGS := -std=c++20 -frtti -fexceptions
APP_BUILD_SCRIPT := Android.mk
