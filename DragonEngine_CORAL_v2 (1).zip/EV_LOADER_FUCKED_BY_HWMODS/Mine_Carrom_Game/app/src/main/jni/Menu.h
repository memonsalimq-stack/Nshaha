#pragma once
// Dragon Engine | @Memon_salim
#include "name.h"

bool titleValid, headingValid, iconValid, settingsValid, isLeeched;

void setText(JNIEnv *env, jobject obj, const char* text){
    if(!env || !obj || !text || env->ExceptionCheck() || env->PushLocalFrame(8)!=0) return;
    jclass html = (*env).FindClass(OBFUSCATE("android/text/Html"));
    if(!html) {env->PopLocalFrame(nullptr);return;}
    jmethodID fromHtml = (*env).GetStaticMethodID(html, OBFUSCATE("fromHtml"), OBFUSCATE("(Ljava/lang/String;)Landroid/text/Spanned;"));
    if(!fromHtml) {env->PopLocalFrame(nullptr);return;}
    jclass textView = (*env).FindClass(OBFUSCATE("android/widget/TextView"));
    if(!textView || !env->IsInstanceOf(obj,textView)) {env->PopLocalFrame(nullptr);return;}
    jmethodID setText = (*env).GetMethodID(textView, OBFUSCATE("setText"), OBFUSCATE("(Ljava/lang/CharSequence;)V"));
    if(!setText) {env->PopLocalFrame(nullptr);return;}
    jstring jstr = (*env).NewStringUTF(text);
    if(jstr) {
        jobject content=env->CallStaticObjectMethod(html,fromHtml,jstr);
        if(!env->ExceptionCheck()) env->CallVoidMethod(obj,setText,content);
    }
    env->PopLocalFrame(nullptr);
}


void setTitleText(JNIEnv *env, jobject thiz, jobject obj) {
    setText(env, obj, OBFUSCATE("<b>" MOD_NAME "</b>"));

    titleValid = true;
}

void setHeadingText(JNIEnv *env, jobject thiz, jobject obj) {
    // Html.fromHtml supplies inline styling; the Android TextView owns scrolling.
    setText(env, obj, OBFUSCATE("<b><font color=\"#FFC107\">" MOD_NAME "</font> | " MOD_SUBTITLE "</b>"));

    headingValid = true;
}

jstring Icon(JNIEnv *env, jobject thiz) {
    // Logo PNG Base64 
    iconValid = true;
    return env->NewStringUTF(MOD_LOGO_BASE64);
}

jstring AuthorBase64(JNIEnv *env, jobject thiz) {
    return env->NewStringUTF(MOD_AUTHOR_BASE64); 
}

jstring IconWebViewData(JNIEnv *env, jobject thiz) {
    iconValid = true;
    return NULL;
}

jobjectArray settingsList(JNIEnv *env, jobject activityObject) {
    jobjectArray ret;

    const char *features[] = {
            OBFUSCATE("Category_Dragon Engine (@Memon_salim)"),
            OBFUSCATE("RichTextView_<b><marquee scrollamount=\"4\"><p style=\"color:#FFC107; font-size:16px;\">" MOD_MARQUEE_TEXT "</p></marquee></b>"),
            OBFUSCATE("RichTextView_<p style=\"color:#94A3B8; font-size:12px; text-align:center;\"><b>" MOD_CREDIT "</b></p>"),
            OBFUSCATE("ButtonLink_Buy Licence Key (@Memon_salim)_" MOD_BUY_KEY_URL),
            OBFUSCATE("ButtonLink_Join Telegram (Dragon Engine)_" MOD_TELEGRAM_CHANNEL),
            OBFUSCATE("-6_Button_<font color='#FF5252'><b>⬅ Back To Menu</b></font>"),
    };

    int Total_Feature = (sizeof features /
                         sizeof features[0]); //Now you dont have to manually update the number everytime;
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));
    int i;
    for (i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    settingsValid = true;

    return (ret);
}
