package com.easyvictory.mods;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Holds the Firebase license fields for the key that most recently passed
 * {@link FirebaseLicense}, so the ABOUT tab can display them. This is a
 * display cache only: it grants nothing by itself, and the Menu service still
 * requires LicenseGateActivity to have finished successfully before it starts
 * (see MainActivity.Start).
 */
final class LicenseSession {
    private LicenseSession() {}

    static volatile String key = "";
    static volatile String admin = "";
    static volatile long expiresAtMillis = 0L;   // 0 = no expiry (lifetime)
    static volatile int maxDevices = 0;           // 0 = unlimited
    static volatile int deviceCount = 0;

    static void set(String key_, String admin_, long expiresAtMillis_, int maxDevices_, int deviceCount_) {
        key = key_ == null ? "" : key_;
        admin = admin_ == null ? "" : admin_;
        expiresAtMillis = expiresAtMillis_;
        maxDevices = maxDevices_;
        deviceCount = deviceCount_;
    }

    static String expiryText() {
        if (expiresAtMillis <= 0L) return "Lifetime";
        try {
            return new SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.US).format(new Date(expiresAtMillis));
        } catch (Exception ignored) {
            return "unknown";
        }
    }

    static String deviceText() {
        if (maxDevices <= 0) return deviceCount + " / unlimited";
        return deviceCount + " / " + maxDevices;
    }
}
