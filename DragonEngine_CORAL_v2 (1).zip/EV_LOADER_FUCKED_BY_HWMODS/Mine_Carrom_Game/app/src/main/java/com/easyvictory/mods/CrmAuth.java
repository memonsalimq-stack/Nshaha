package com.easyvictory.mods;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLException;

/** Untrusted transport and device proof. Native code owns grants and session crypto. */
public final class CrmAuth {
    private CrmAuth() {}
    private static byte[] failure(String code) { return ("E:" + code).getBytes(StandardCharsets.US_ASCII); }
    private static final long EXCHANGE_NANOS = TimeUnit.SECONDS.toNanos(18);
    // No unbounded task queue or one-new-thread-per-tap. Cancellation is best
    // effort for platform DNS/socket I/O; even if it stalls, the caller returns
    // on its deadline and at most two transport workers can remain occupied.
    private static final ThreadPoolExecutor TRANSPORT = new ThreadPoolExecutor(
        0, 2, 30, TimeUnit.SECONDS, new SynchronousQueue<Runnable>(), task -> {
            Thread thread = new Thread(task, "crm-transport");
            thread.setDaemon(true);
            return thread;
        }, new ThreadPoolExecutor.AbortPolicy());

    private static int remainingTimeout(long started) throws SocketTimeoutException {
        long elapsed = System.nanoTime() - started;
        if (Thread.currentThread().isInterrupted() || elapsed < 0 || elapsed >= EXCHANGE_NANOS)
            throw new SocketTimeoutException("CRM exchange deadline");
        return (int) Math.min(8000, Math.max(1, TimeUnit.NANOSECONDS.toMillis(EXCHANGE_NANOS - elapsed)));
    }

    public static native String nativeGetAuthEndpoint();

    // Background login/renewal worker only. Neither the input nor output contains
    // a plaintext license, session key, TTL or Java-created authorization grant.
    public static byte[] exchange(byte[] request) {
        String endpoint = null;
        try {
            endpoint = nativeGetAuthEndpoint();
        } catch (UnsatisfiedLinkError | Exception ignored) {}
        return exchange(endpoint, request);
    }

    public static byte[] exchange(String endpoint, byte[] request) {
        if (request == null || request.length == 0 || request.length > 8192) return failure("AUTH_REQUEST");
        if (endpoint == null || endpoint.isEmpty()) {
            try {
                endpoint = nativeGetAuthEndpoint();
            } catch (UnsatisfiedLinkError | Exception ignored) {}
        }
        if (endpoint == null || endpoint.isEmpty()) return failure("AUTH_ENDPOINT");
        final String targetEndpoint = endpoint;
        final long started = System.nanoTime();
        final byte[] snapshot = request.clone();
        Future<byte[]> pending = null;
        try {
            pending = TRANSPORT.submit(() -> send(targetEndpoint, snapshot, started));
            long remaining = EXCHANGE_NANOS - (System.nanoTime() - started);
            if (remaining <= 0) return failure("AUTH_TIMEOUT");
            return pending.get(remaining, TimeUnit.NANOSECONDS);
        } catch (TimeoutException failure) {
            return failure("AUTH_TIMEOUT");
        } catch (InterruptedException failure) {
            Thread.currentThread().interrupt();
            return failure("AUTH_TIMEOUT");
        } catch (RejectedExecutionException failure) {
            try {
                return send(targetEndpoint, snapshot, started);
            } catch (Throwable fallback) {
                return ("E:AUTH_ERR:" + fallback.getClass().getSimpleName() + ":" + fallback.getMessage()).getBytes(StandardCharsets.US_ASCII);
            }
        } catch (Throwable failure) {
            return ("E:AUTH_ERR:" + failure.getClass().getSimpleName() + ":" + failure.getMessage()).getBytes(StandardCharsets.US_ASCII);
        } finally {
            if (pending != null) pending.cancel(true);
        }
    }

    private static byte[] send(String endpoint, byte[] request, long started) {
        HttpsURLConnection connection = null;
        try {
            remainingTimeout(started);
            final boolean isJson = request[0] == '{';
            if (isJson) {
                try { request = CrmDeviceKey.authorize(request); }
                catch (java.security.GeneralSecurityException failure) { return failure("AUTH_DEVICE_KEY"); }
                remainingTimeout(started);
            }
            connection = (HttpsURLConnection) new URL(endpoint).openConnection();
            // Default Android certificate-chain and hostname verification stay on.
            // Redirects and legacy/free-mode fallback are deliberately forbidden.
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(remainingTimeout(started));
            connection.setReadTimeout(remainingTimeout(started));
            connection.setUseCaches(false);
            connection.setRequestMethod("POST");
            connection.setDoOutput(true);
            connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36");
            connection.setRequestProperty("Accept", "application/json");
            connection.setRequestProperty("Content-Type", isJson ? "application/json" : "application/x-www-form-urlencoded");
            connection.setFixedLengthStreamingMode(request.length);
            try (OutputStream stream = connection.getOutputStream()) { stream.write(request); }
            connection.setReadTimeout(remainingTimeout(started));
            int status = connection.getResponseCode();
            remainingTimeout(started);
            if (status == 404 || status == 405) return failure("AUTH_ENDPOINT");
            if (status >= 300 && status < 400) return failure("AUTH_REDIRECT");
            if (status == 429) return failure("AUTH_RATE");
            if (status >= 500) return failure("AUTH_SERVER");
            if (status != 200) return failure("AUTH_REJECTED");
            if (connection.getContentLength() > 16384) return failure("AUTH_RESPONSE");
            ByteArrayOutputStream response = new ByteArrayOutputStream();
            try (InputStream stream = connection.getInputStream()) {
                byte[] chunk = new byte[1024];
                int count;
                while (true) {
                    connection.setReadTimeout(remainingTimeout(started));
                    count = stream.read(chunk);
                    remainingTimeout(started);
                    if (count == -1) break;
                    if (response.size() + count > 16384) return failure("AUTH_RESPONSE");
                    response.write(chunk, 0, count);
                }
            }
            return response.size() == 0 ? failure("AUTH_RESPONSE") : response.toByteArray();
        } catch (SocketTimeoutException failure) {
            return failure("AUTH_TIMEOUT");
        } catch (UnknownHostException failure) {
            return failure("AUTH_DNS");
        } catch (SSLException failure) {
            return failure("AUTH_TLS");
        } catch (Throwable failure) {
            return ("E:AUTH_ERR:" + failure.getClass().getSimpleName() + ":" + failure.getMessage()).getBytes(StandardCharsets.US_ASCII);
        } finally {
            if (connection != null) {
                try { connection.disconnect(); } catch (RuntimeException ignored) {}
            }
        }
    }
}
