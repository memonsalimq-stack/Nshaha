# Dragon Engine — Firebase key system

Database: `https://nova-engine-3c69b-default-rtdb.firebaseio.com`
(already compiled into the app via `jni/name.h` -> `FIREBASE_LICENSE_BASE`,
obfuscated and exposed through `FirebaseLicense`/`Main.cpp`.)

## 1. Apply the rules

Firebase Console -> Realtime Database -> **Rules** tab -> paste the contents
of `database.rules.json` (in this same folder) -> Publish.

What these rules actually do:
- Nobody can list `/keys` (no enumeration of every key that exists).
- Reading one key's full record (`/keys/<KEY>`) is allowed to anyone who
  already has that exact 23-character key string — the app needs this to
  show admin/expiry/device count. It is not a secret field store.
- A device can only be added to `/keys/<KEY>/devices/<deviceId>` once; it
  cannot overwrite another device's slot, and it cannot write `admin`,
  `expiresAt`, `maxDevices` or `revoked` at all. Only you, writing from the
  Firebase console or with the project's secret, can set or change those.

This is honest, not bulletproof: anyone who has a valid key can read that
key's record, and a modified APK could ignore the app's own verdict. The
rules are what actually stops a client from registering unlimited devices or
editing its own expiry; nothing client-side can be made unbypassable.

## 2. Create a key manually (until you ask for the admin panel)

Realtime Database -> Data -> `keys` -> add a child node named exactly the key
(for example `5E343-92B79-F3A72-8413E`), with these fields:

```json
{
  "admin": "Memon_salim",
  "createdAt": 1764000000,
  "expiresAt": 1766678399,
  "maxDevices": 2,
  "revoked": false
}
```

- `createdAt`, `expiresAt`: Unix seconds (UTC). `expiresAt: 0` = lifetime key.
- `maxDevices`: 0 = unlimited devices.
- `revoked`: set to `true` to kill a key immediately; leave the record
  otherwise untouched (do not delete it, or a freshly-issued duplicate key
  could reuse the id).
- Do not add a `devices` child yourself — the app creates it the first time
  each device logs in.

## 3. Key format

Every key must look like `5E343-92B79-F3A72-8413E`: four groups of five
uppercase hex characters (`0-9`, `A-F`), joined by dashes, 23 characters
total. `LicenseGateActivity` upper-cases what the person types and
`FirebaseLicense`/`Main.cpp` reject anything else before it ever reaches the
database.

## 4. Multiple admins

There's no separate admin-accounts table yet — "admin" is just a label you
type into each key's record, shown as-is on the ABOUT tab ("Activated by:
..."). When you ask for the key-generation panel, that is where real
per-admin accounts, permissions and an audit trail belong.

## 5. Admin panel (added)

`database.rules.json` is now the admin-aware version: keys are still stored as
`/keys/<KEY>` with `admin, adminUid, createdAt, expiresAt, maxDevices, revoked`,
but only the owner / the creating admin can write them, and the device limit
(`maxDevices`, 0 = unlimited) is enforced by the rules too. Use
`dragon_admin_panel.html` to create keys. Owner bootstrap: enable Email/Password
auth, create a user, then add `/admins/<UID> = {"name":"Memon_salim","owner":true}`
by hand in the console before publishing the rules.

## 6. Prediction colours

The core draws the prediction; `Main.cpp` passes each colour through `RemapCol()`.
Run one match, read the `pred colour #N = 0x........` lines from logcat (tag
libCrash) and fill `PRED_REMAP_FROM` / `PRED_REMAP_TO` in `name.h`.
