//Please don't replace listeners with lambda!
// Created By @GoToHellxD | @HwMods

package com.easyvictory.mods;

import android.app.Activity;
import android.app.Application;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.AlertDialog;
import android.app.Service;
import android.os.Bundle;
import android.content.Context;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.text.Html;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.text.method.DigitsKeyListener;
import android.util.Base64;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;
import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;
import static android.widget.RelativeLayout.ALIGN_PARENT_LEFT;
import static android.widget.RelativeLayout.ALIGN_PARENT_RIGHT;
import android.animation.ValueAnimator;
import android.animation.ArgbEvaluator;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.view.animation.TranslateAnimation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;
import android.view.animation.AlphaAnimation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.MotionEvent;
import android.annotation.TargetApi;

public class Menu extends Service {
    static {
        try { System.loadLibrary("HwMods"); } catch (Throwable ignored) {}
        try { System.loadLibrary("Crash"); } catch (Throwable ignored) {}
    }
    private final List<Runnable> nativeSpinnerRefreshers = new LinkedList<>();
    //********** Here you can easly change the menu appearance **********//

    //region Variable
    public static final String TAG = "Mod_Menu"; //Tag for logcat
    int TEXT_COLOR = EvIcons.TEXT_WHITE;
    int TEXT_COLOR_2 = EvIcons.GOLD;
    int BTN_COLOR = EvIcons.GOLD;
    int SURFACE_COLOR = EvIcons.SURFACE;
    int BORDER_COLOR = EvIcons.BORDER_GOLD;
    int MUTED_COLOR = EvIcons.TEXT_SUBTLE;
    int MENU_BG_COLOR = EvIcons.BG_DARK; //#AARRGGBB
    int MENU_FEATURE_BG_COLOR = Color.parseColor("#00000000"); //#AARRGGBB
    int MENU_WIDTH = 311;
    int MENU_HEIGHT = 350;
    float MENU_CORNER = 28f;
    int ICON_SIZE = 45; //Change both width and height of image
    float ICON_ALPHA = 0.7f; //Transparent
    int ToggleON = EvIcons.GOLD;
    int ToggleOFF = EvIcons.SWITCH_OFF_THUMB;
    int BtnON = Color.parseColor("#FFC107");
    int BtnOFF = Color.parseColor("#4A4A4A");
    int CategoryBG = Color.parseColor("#00000000");
    int SeekBarColor = EvIcons.GOLD;
    int SeekBarProgressColor = EvIcons.GOLD;
    int CheckBoxColor = EvIcons.GOLD;
    int RadioColor = EvIcons.GOLD;
    String NumberTxtColor = "#FFC107";
    //********************************************************************//
    RelativeLayout mCollapsed, mRootContainer;
    private Button floatingQueueButton;
    private Switch queueMenuSwitch;
    private boolean syncingQueueControl;
    LinearLayout mExpanded, patches, mSettings, mCollapse;
    LinearLayout categoryTabs, currentCategory, globalControls;
    final List<LinearLayout> categoryPages = new LinkedList<>();
    final List<Button> categoryButtons = new LinkedList<>();
    int selectedCategory = 0;
    LinearLayout.LayoutParams scrlLLExpanded, scrlLL;
    WindowManager mWindowManager;
    WindowManager.LayoutParams params;
    private boolean autoplaySettingsRestored;
    private boolean appForeground = true;
    ImageView startimage;
    FrameLayout rootFrame;
    ScrollView scrollView;

    FrameLayout instantBrakeFrame;
    TextView instantBrakeBtn;
    WindowManager.LayoutParams brakeParams;

    public static Menu instance;

    boolean stopChecking;

    //initialize methods from the native library
    native void setTitleText(TextView textView);

    native void setHeadingText(TextView textView);

    native String Icon();

    native String IconWebViewData();

    native String[] getFeatureList();
    native String getFeatureStatus(int feature);
    native int getFeatureValue(int feature);

    native String[] settingsList();

    native boolean isGameLibLoaded();

    native String nativeCheckKey(Context context, String userKey);
    native String nativeRenewKey(Context context);
    private volatile boolean crmRenewalEnabled = false;
    private volatile boolean authDestroyed = false;
    // Presentation ordering only; this value never grants native authorization.
    private final java.util.concurrent.atomic.AtomicLong authUiEpoch = new java.util.concurrent.atomic.AtomicLong();
    private java.util.concurrent.ScheduledExecutorService crmRenewal;

    private void renewCrmSession() {
        crmRenewalEnabled = true;
        if (crmRenewal != null || authDestroyed) return;
        crmRenewal = java.util.concurrent.Executors.newSingleThreadScheduledExecutor();
        crmRenewal.scheduleWithFixedDelay(() -> {
            final long uiEpoch = authUiEpoch.get();
            if (authDestroyed || !crmRenewalEnabled) return;
            String result = nativeRenewKey(Menu.this);
            if (authDestroyed) { nativeSetFreeMode(false); return; }
            if (uiEpoch != authUiEpoch.get() || !crmRenewalEnabled) return;
            if (result == null || !result.startsWith("OK|") || !isKeyAuthenticated()) {
                new Handler(android.os.Looper.getMainLooper()).post(() -> {
                    if (!authDestroyed && uiEpoch == authUiEpoch.get() && crmRenewalEnabled) {
                        crmRenewalEnabled = false;
                        authUiEpoch.incrementAndGet();
                        showLoginView();
                        if (statusText != null) {
                            statusText.setTextColor(EvIcons.ERROR_RED);
                            statusText.setText("Session expired or verification failed. Please log in again.");
                        }
                    }
                });
            }
        }, 45, 45, java.util.concurrent.TimeUnit.SECONDS);
    }

    native boolean isKeyAuthenticated();

    native boolean isLoginEnabled();

    native String getExpiryDate();

    native String getModStatus();

    native String getModCredit();

    native String getModName();

    native String getModSubtitle();

    native String getTelegramHandle();

    native String getTelegramUrl();

    native String getBuyKeyUrl();

    native String getFreeKeyUrl();

    native String getLoginTitle();

    native String getLoginBanner();

    native String getStatusBadge();

    native void nativeSetFreeMode(boolean freeMode);
    //endregion

    public static void showInstantBrake(final boolean show) {
        if (instance != null) {
            instance.showInstantBrakeButton(show);
        }
    }

    //When this Class is called the code in this function will be executed
    private TextView menuExpiryText;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        Preferences.context = this;
        Preferences.with(this).resetFeaturesExceptKey();

        // Monitor App Lifecycle to hide/show overlays & dialogs instantly on minimize
        try {
            if (getApplication() != null) {
                getApplication().registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
                    @Override
                    public void onActivityCreated(Activity activity, Bundle savedInstanceState) {}
                    @Override
                    public void onActivityStarted(Activity activity) {}
                    @Override
                    public void onActivityResumed(Activity activity) {
                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                onAppForegroundChanged(true);
                            }
                        });
                    }
                    @Override
                    public void onActivityPaused(Activity activity) {}
                    @Override
                    public void onActivityStopped(Activity activity) {
                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                onAppForegroundChanged(false);
                            }
                        });
                    }
                    @Override
                    public void onActivitySaveInstanceState(Activity activity, Bundle outState) {}
                    @Override
                    public void onActivityDestroyed(Activity activity) {}
                });
            }
        } catch (Exception ignored) {}

        //Create the menu
        initFloating();
        startAnimation();
        //Create a handler for this Class
        final Handler handler = new Handler();
        handler.post(new Runnable() {
            public void run() {
                Thread();
                refreshQueueControls();
                handler.postDelayed(this, 1000);
            }
        });
    }

    //Here we write the code for our Menu
    // Reference: https://www.androidhive.info/2016/11/android-floating-widget-like-facebook-chat-head/
    private void initFloating() {
        rootFrame = new FrameLayout(this); // Global markup
        rootFrame.setOnTouchListener(onTouchListener());
        mRootContainer = new RelativeLayout(this); // Markup on which two markups of the icon and the menu itself will be placed
        mCollapsed = new RelativeLayout(this); // Markup of the icon (when the menu is minimized)
        mCollapsed.setVisibility(View.VISIBLE);
        mCollapsed.setAlpha(ICON_ALPHA);

        //********** The box of the mod menu **********
        mExpanded = new LinearLayout(this); // Menu markup (when the menu is expanded)
        mExpanded.setVisibility(View.GONE);
        mExpanded.setOrientation(LinearLayout.VERTICAL);

        int availableWidth = getResources().getDisplayMetrics().widthPixels - dp(16);
        mExpanded.setLayoutParams(new LinearLayout.LayoutParams(Math.min(dp(MENU_WIDTH), availableWidth), WRAP_CONTENT));
        mExpanded.setBackground(EvIcons.createMenuPanelBackground(this));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            mExpanded.setElevation(dp(12));
        }

        //********** The icon to open mod menu **********
        startimage = new ImageView(this);
        startimage.setLayoutParams(new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT));
        int applyDimension = (int) TypedValue.applyDimension(1, ICON_SIZE, getResources().getDisplayMetrics()); //Icon size
        startimage.getLayoutParams().height = applyDimension;
        startimage.getLayoutParams().width = applyDimension;
        startimage.setScaleType(ImageView.ScaleType.FIT_CENTER);
        try {
            byte[] decode = Base64.decode(Icon(), Base64.DEFAULT);
            android.graphics.Bitmap iconBmp = BitmapFactory.decodeByteArray(decode, 0, decode.length);
            if (iconBmp != null) {
                startimage.setImageBitmap(iconBmp);
            } else {
                android.graphics.drawable.Drawable fallback = EvIcons.evIcon(this, "ev_icon_ev", 0);
                if (fallback != null) startimage.setImageDrawable(fallback);
            }
        } catch (Throwable ignored) {
            android.graphics.drawable.Drawable fallback = EvIcons.evIcon(this, "ev_icon_ev", 0);
            if (fallback != null) startimage.setImageDrawable(fallback);
        }
        ((ViewGroup.MarginLayoutParams) startimage.getLayoutParams()).topMargin = convertDipToPixels(10);
        startimage.setOnTouchListener(onTouchListener());
        startimage.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                mCollapsed.setVisibility(View.GONE);
                mExpanded.setVisibility(View.VISIBLE);
                if (isBrakeBtnAdded && instantBrakeFrame != null) {
                    instantBrakeFrame.setVisibility(View.VISIBLE);
                }
            }
        });

        //********** The icon in Webview to open mod menu **********
        WebView wView = new WebView(this); //Icon size width="50" height="50"
        wView.setLayoutParams(new RelativeLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT));
        int applyDimension2 = (int) TypedValue.applyDimension(1, ICON_SIZE, getResources().getDisplayMetrics()); //Icon size
        wView.getLayoutParams().height = applyDimension2;
        wView.getLayoutParams().width = applyDimension2;
        wView.loadData("<html>" +
                "<head></head>" +
                "<body style=\"margin: 0; padding: 0\">" +
                "<img src=\"" + IconWebViewData() + "\" width=\"" + ICON_SIZE + "\" height=\"" + ICON_SIZE + "\" >" +
                "</body>" +
                "</html>", "text/html", "utf-8");
        wView.setBackgroundColor(0x00000000); //Transparent
        wView.setAlpha(ICON_ALPHA);
        wView.getSettings().setAppCacheEnabled(true);
        wView.setOnTouchListener(onTouchListener());

        //********** Settings (lazy container kept for native command compatibility) **********
        mSettings = new LinearLayout(this);
        mSettings.setOrientation(LinearLayout.VERTICAL);

        //********** Centered Mod Header (Logo + Mod Name + Expiry) **********
        ImageView[] headerLogoRef = new ImageView[1];
        TextView[] headerExpiryRef = new TextView[1];
        LinearLayout evHeader = EvIcons.createHeader(this, Icon(), getModName(), headerLogoRef, headerExpiryRef);
        menuExpiryText = headerExpiryRef[0];
        if (headerLogoRef[0] != null) {
            headerLogoRef[0].setOnTouchListener(onTouchListener());
        }

        //********** Mod menu feature list **********
        scrollView = new ScrollView(this);
        int usableBody = Math.max(dp(96), getResources().getDisplayMetrics().heightPixels - dp(300));
        scrlLL = new LinearLayout.LayoutParams(MATCH_PARENT, Math.min(dp(MENU_HEIGHT), usableBody));
        scrlLLExpanded = new LinearLayout.LayoutParams(MATCH_PARENT, usableBody);
        scrollView.setLayoutParams(Preferences.isExpanded ? scrlLLExpanded : scrlLL);
        scrollView.setBackgroundColor(MENU_FEATURE_BG_COLOR);
        scrollView.setFillViewport(true);
        scrollView.setVerticalScrollBarEnabled(false);
        scrollView.setClipToPadding(false);
        scrollView.setPadding(dp(4), 0, dp(4), dp(4));
        patches = new LinearLayout(this);
        patches.setOrientation(LinearLayout.VERTICAL);
        patches.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        categoryTabs = new LinearLayout(this);
        categoryTabs.setOrientation(LinearLayout.HORIZONTAL);
        categoryTabs.setPadding(dp(4), dp(4), dp(4), dp(4));
        categoryTabs.setVisibility(View.GONE);
        globalControls = new LinearLayout(this);
        globalControls.setOrientation(LinearLayout.VERTICAL);
        globalControls.setPadding(dp(12), 0, dp(12), dp(4));
        globalControls.setVisibility(View.GONE);

        //********** Footer Minimize Square Button (bottom-right, long-press hides icon) **********
        FrameLayout footerLayout = EvIcons.createMinimizeFooter(this,
                new View.OnClickListener() {
                    public void onClick(View view) {
                        mCollapsed.setVisibility(View.VISIBLE);
                        mCollapsed.setAlpha(ICON_ALPHA);
                        mExpanded.setVisibility(View.GONE);
                    }
                },
                new View.OnLongClickListener() {
                    public boolean onLongClick(View view) {
                        mCollapsed.setVisibility(View.VISIBLE);
                        mCollapsed.setAlpha(0);
                        mExpanded.setVisibility(View.GONE);
                        if (isBrakeBtnAdded && instantBrakeFrame != null) {
                            instantBrakeFrame.setVisibility(View.GONE);
                        }
                        Toast.makeText(view.getContext(), "Icon hidden. Remember the hidden icon position", Toast.LENGTH_LONG).show();
                        return true;
                    }
                });

        //********** Params **********
        int iparams = Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O ? 2038 : 2002;
        params = new WindowManager.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, iparams, 8, -3);
        params.gravity = 51;
        params.x = 0;
        params.y = 100;

        //********** Adding view components **********
        rootFrame.addView(mRootContainer);
        mRootContainer.addView(mCollapsed);
        mRootContainer.addView(mExpanded);
        View logo = IconWebViewData() != null ? wView : startimage;
        logo.setId(View.generateViewId());
        RelativeLayout.LayoutParams logoParams = new RelativeLayout.LayoutParams(dp(ICON_SIZE), dp(ICON_SIZE));
        logoParams.addRule(RelativeLayout.CENTER_HORIZONTAL);
        mCollapsed.addView(logo, logoParams);
        floatingQueueButton = new Button(this);
        floatingQueueButton.setAllCaps(false);
        floatingQueueButton.setText("");
        floatingQueueButton.setPadding(0, 0, 0, 0);
        floatingQueueButton.setMinWidth(0);
        floatingQueueButton.setMinimumWidth(0);
        floatingQueueButton.setMinHeight(0);
        floatingQueueButton.setMinimumHeight(0);
        floatingQueueButton.setBackground(null);
        RelativeLayout.LayoutParams queueParams = new RelativeLayout.LayoutParams(dp(36), dp(36));
        queueParams.addRule(RelativeLayout.BELOW, logo.getId());
        queueParams.addRule(RelativeLayout.CENTER_HORIZONTAL);
        queueParams.topMargin = dp(12);
        mCollapsed.addView(floatingQueueButton, queueParams);
        floatingQueueButton.setOnClickListener(v -> {
            if (isLoginEnabled() && !isKeyAuthenticated()) return;
            boolean enable = getFeatureValue(13) == 0;
            if (enable) {
                Preferences.changeFeatureInt("Autoplay", 13, 2);
                Preferences.changeFeatureInt("Clean Table", 16, 1);
                Preferences.changeFeatureInt("Scanner Depth", 14, 5);
                Preferences.changeFeatureInt("Shot Force", 15, 100);
            } else {
                Preferences.changeFeatureInt("Autoplay", 13, 0);
            }
            Preferences.changeFeatureBool("Auto Queue", 19, false);
            refreshQueueControls();
            Toast.makeText(Menu.this, enable ? "Auto Play V2 / Natural on" : "Auto Play off", Toast.LENGTH_SHORT).show();
        });
        refreshQueueControls();

        mExpanded.addView(evHeader);
        mExpanded.addView(globalControls);
        mExpanded.addView(categoryTabs);
        scrollView.addView(patches);
        mExpanded.addView(scrollView);
        mExpanded.addView(footerLayout);
        mWindowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        mWindowManager.addView(rootFrame, params);
        initInstantBrakeButton();

        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            boolean viewLoaded = false;

            @Override
            public void run() {
                //If the save preferences is enabled, it will check if game lib is loaded before starting menu
                if (Preferences.loadPref && !isGameLibLoaded() && !stopChecking) {
                    if (!viewLoaded) {
                        patches.addView(Category("Save preferences was been enabled. Waiting for game lib to be loaded...\n\nForce load menu may not apply mods instantly. You would need to reactivate them again"));
                        patches.addView(Button(-100, "Force load menu"));
                        viewLoaded = true;
                    }
                    handler.postDelayed(this, 600);
                } else {
                    if (!isLoginEnabled() || isKeyAuthenticated()) {
                        showFeaturesView();
                        startExpiryCountdown();
                        updateMenuExpiryText();
                    } else {
                        showLoginView();
                        // Key will be pre-filled in keyInput for convenience without auto-logging in
                    }
                }
            }
        }, 500);
    }

    LinearLayout loginContainer;
    EditText keyInput;
    TextView statusText;
    Button loginBtn, pasteBtn, getKeyBtn, joinTgBtn;

    private void showLoginView() {
        if (categoryTabs != null) categoryTabs.setVisibility(View.GONE);
        if (globalControls != null) globalControls.setVisibility(View.GONE);
        scrollView.removeAllViews();
        if (loginContainer == null) {
            initLoginView();
        }
        scrollView.addView(loginContainer);
    }

    private void restorePreferences() {
        AutoplaySettings.restore(this);
        int[] boolFeatures = {1, 2, 5, 11, 18, 19};
        SharedPreferences prefs = Preferences.getStore(this);
        for (int feat : boolFeatures) {
            boolean defaultVal = (feat == 1 || feat == 2 || feat == 5 || feat == 11 || feat == 18);
            boolean val = (prefs != null && prefs.contains("pref_bool_" + feat))
                    ? prefs.getBoolean("pref_bool_" + feat, defaultVal)
                    : defaultVal;
            Preferences.Changes(this, feat, "feature_" + feat, 0, val, null);
        }
        int[] intFeatures = {14, 15, 16, 20, 22, 27};
        for (int feat : intFeatures) {
            int defaultVal = (feat == 15 ? 60 : (feat == 14 ? 5 : (feat == 27 ? 1 : 0)));
            int val = (prefs != null && prefs.contains("pref_int_" + feat))
                    ? prefs.getInt("pref_int_" + feat, defaultVal)
                    : defaultVal;
            Preferences.Changes(this, feat, "feature_" + feat, val, false, null);
        }
        int apMode = AutoplaySettings.savedInt(this, 13);
        Preferences.Changes(this, 13, "Autoplay", apMode, false, null);
        refreshQueueControls();
        updateAutoplayVisibility();
    }

    private void showFeaturesView() {
        // UX guard only. The independent native execution guards are authoritative.
        if (authDestroyed || (isLoginEnabled() && !isKeyAuthenticated())) { showLoginView(); return; }
        if (!autoplaySettingsRestored) {
            restorePreferences();
            autoplaySettingsRestored = true;
        }
        scrollView.removeAllViews();
        if (patches.getChildCount() == 0) {
            featureList(getFeatureList(), patches);
        }
        scrollView.addView(patches);
        globalControls.setVisibility(View.VISIBLE);
        if (!categoryPages.isEmpty()) {
            categoryTabs.setVisibility(View.VISIBLE);
            selectCategory(selectedCategory);
        }
        updateAutoplayVisibility();
        refreshQueueControls();
    }

    // Generic presentation only: labels, feature IDs, defaults and all game
    // decisions arrive from JNI. Java never scans or chooses a shot/table.
    private void addCategory(String title, LinearLayout parent) {
        final int index = categoryPages.size();
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(8), dp(4), dp(8), dp(8));
        parent.addView(page);
        categoryPages.add(page);
        currentCategory = page;
        Button tab = EvIcons.createTabButton(this, title, index == selectedCategory);
        tab.setOnClickListener(v -> selectCategory(index));
        categoryTabs.addView(tab);
        categoryButtons.add(tab);
        page.setVisibility(index == selectedCategory ? View.VISIBLE : View.GONE);
    }

    private void selectCategory(int index) {
        if (index < 0 || index >= categoryPages.size()) return;
        selectedCategory = index;
        for (int i = 0; i < categoryPages.size(); ++i) {
            categoryPages.get(i).setVisibility(i == index ? View.VISIBLE : View.GONE);
            EvIcons.styleTabButton(this, categoryButtons.get(i), i == index);
        }
        scrollView.scrollTo(0, 0);
        scrollView.post(() -> scrollView.scrollTo(0, 0));
    }

    private void applyButtonTouchEffect(final View view) {
        if (view == null) return;
        view.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_DOWN) {
                    v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start();
                } else if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                    v.animate().scaleX(1.0f).scaleY(1.0f).setDuration(160).setInterpolator(new OvershootInterpolator(2.2f)).start();
                }
                return false;
            }
        });
    }

    private void playShakeAnimation(View view) {
        if (view == null) return;
        TranslateAnimation shake = new TranslateAnimation(0, dp(8), 0, 0);
        shake.setDuration(45);
        shake.setRepeatCount(5);
        shake.setRepeatMode(Animation.REVERSE);
        view.startAnimation(shake);
    }

    private void startTitleGlowAnimation(final TextView title) {
        if (title == null) return;
        ValueAnimator titleGlow = ValueAnimator.ofArgb(
            Color.parseColor("#00E5FF"), // Neon Cyan
            Color.parseColor("#A855F7"), // Purple Glow
            Color.parseColor("#EC4899"), // Hot Pink Glow
            Color.parseColor("#FACC15"), // Gold Glow
            Color.parseColor("#10B981"), // Emerald Glow
            Color.parseColor("#00E5FF")  // Loop
        );
        titleGlow.setDuration(4500);
        titleGlow.setRepeatCount(ValueAnimator.INFINITE);
        titleGlow.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animator) {
                int col = (int) animator.getAnimatedValue();
                title.setTextColor(col);
                title.setShadowLayer(10.0f, 0, 0, col);
            }
        });
        titleGlow.start();
    }

    private void startPulseAnimation(final TextView serverStatus) {
        if (serverStatus == null) return;
        ValueAnimator pulse = ValueAnimator.ofFloat(0.5f, 1.0f);
        pulse.setDuration(1000);
        pulse.setRepeatCount(ValueAnimator.INFINITE);
        pulse.setRepeatMode(ValueAnimator.REVERSE);
        pulse.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                float alpha = (float) animation.getAnimatedValue();
                serverStatus.setAlpha(alpha);
            }
        });
        pulse.start();
    }

    private void initLoginView() {
        EditText[] keyRef = new EditText[1];
        Button[] pasteRef = new Button[1];
        Button[] loginRef = new Button[1];
        TextView[] statusRef = new TextView[1];
        loginContainer = EvIcons.createLoginContainer(
                this,
                "Enter your license key to authenticate.",
                getStatusBadge(),
                getLoginTitle(),
                getLoginBanner(),
                getBuyKeyUrl(),
                getFreeKeyUrl(),
                getTelegramUrl(),
                keyRef, pasteRef, loginRef, statusRef);
        keyInput = keyRef[0];
        pasteBtn = pasteRef[0];
        loginBtn = loginRef[0];
        statusText = statusRef[0];

        String savedKey = CrmKeyStore.read(this);
        // Retire the legacy plaintext cache. It never authorizes a session.
        Preferences.with(this).writeString("HW_LICENSE_KEY", "");
        if (savedKey != null && !savedKey.isEmpty() && keyInput != null) {
            keyInput.setText(savedKey);
        }

        if (loginBtn != null) {
            loginBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    performKeyLogin(false);
                }
            });
        }
    }

    private void performKeyLogin(final boolean isAutoLogin) {
        if (authDestroyed) return;
        final String key = keyInput != null ? keyInput.getText().toString().trim() : CrmKeyStore.read(this);
        if (key == null || key.isEmpty()) {
            playShakeAnimation(loginContainer);
            if (statusText != null) {
                statusText.setTextColor(Color.parseColor("#FF5252"));
                statusText.setText("Please enter a valid license key.");
            }
            if (!isAutoLogin) {
                Toast.makeText(Menu.this, "Please enter a license key", Toast.LENGTH_SHORT).show();
            }
            return;
        }


        final long loginEpoch = authUiEpoch.incrementAndGet();
        crmRenewalEnabled = false;
        nativeSetFreeMode(false); // Cancel in-flight renewals before starting a replacement login.
        if (statusText != null) {
            statusText.setTextColor(EvIcons.GOLD);
            statusText.setText("Connecting to server...");
        }
        if (loginBtn != null) {
            loginBtn.setEnabled(false);
            loginBtn.setText("VERIFYING...");
            loginBtn.setTextColor(EvIcons.TEXT_WHITE);
            loginBtn.setAlpha(0.7f);
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                if (authDestroyed || loginEpoch != authUiEpoch.get()) return;
                final String result = nativeCheckKey(Menu.this, key);
                if (authDestroyed) { nativeSetFreeMode(false); return; }

                new Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
                    @Override
                    public void run() {
                        if (authDestroyed || loginEpoch != authUiEpoch.get()) return;
                        if (loginBtn != null) {
                            loginBtn.setEnabled(true);
                            loginBtn.setText("LOGIN");
                            loginBtn.setTextColor(EvIcons.TEXT_WHITE);
                            loginBtn.setAlpha(1.0f);
                        }

                        if (authDestroyed) { nativeSetFreeMode(false); return; }
                        if (result != null && result.startsWith("OK|") && isKeyAuthenticated()) {
                            String exp = getExpiryDate();
                            if (statusText != null) {
                                statusText.setTextColor(EvIcons.GOLD);
                                statusText.setText("ACCESS GRANTED  •  VIP UNLOCKED\nExpires: " + exp);
                            }
                            Toast.makeText(Menu.this, "Welcome! " + getModName() + " Unlocked (Exp: " + exp + ")", Toast.LENGTH_LONG).show();

                            // Save key for auto-login
                            CrmKeyStore.write(Menu.this, key);
                            renewCrmSession();
                            animateAuthenticatedFeatures();

                        } else {
                            playShakeAnimation(loginContainer);
                            String reason = result != null ? (result.startsWith("ERR|") ? result.substring(4) : result) : "Unknown Error";
                            if (statusText != null) {
                                statusText.setTextColor(EvIcons.ERROR_RED);
                                statusText.setText(reason);
                            }
                            if (isServerBroadcastNotice(reason)) {
                                showVersionDisabledDialog(reason);
                            } else {
                                if (isAutoLogin) {
                                    CrmKeyStore.clear(Menu.this);
                                }
                                if (!isAutoLogin) {
                                    Toast.makeText(Menu.this, reason, Toast.LENGTH_LONG).show();
                                }
                            }
                        }
                    }
                });
            }
        }).start();
    }

    // Keep animation callbacks outside the login closure so an attached
    // Animation cannot retain that closure's plaintext license String.
    private void animateAuthenticatedFeatures() {
        startExpiryCountdown();
        updateMenuExpiryText();
        if (loginContainer == null) { showFeaturesView(); return; }
        AnimationSet fadeOut = new AnimationSet(true);
        fadeOut.addAnimation(new AlphaAnimation(1.0f, 0.0f));
        fadeOut.addAnimation(new ScaleAnimation(1.0f, 0.95f, 1.0f, 0.95f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f));
        fadeOut.setDuration(400);
        final long uiEpoch = authUiEpoch.get();
        fadeOut.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationEnd(Animation animation) {
                if (authDestroyed || uiEpoch != authUiEpoch.get() || !isKeyAuthenticated()) return;
                showFeaturesView();
                if (patches != null) {
                    AnimationSet fadeIn = new AnimationSet(true);
                    fadeIn.addAnimation(new AlphaAnimation(0.0f, 1.0f));
                    fadeIn.addAnimation(new TranslateAnimation(0, 0, dp(15), 0));
                    fadeIn.setDuration(350);
                    fadeIn.setInterpolator(new DecelerateInterpolator());
                    patches.startAnimation(fadeIn);
                }
            }
            @Override public void onAnimationStart(Animation a) {}
            @Override public void onAnimationRepeat(Animation a) {}
        });
        loginContainer.startAnimation(fadeOut);
    }

    private boolean isServerBroadcastNotice(String message) {
        if (message == null || message.trim().isEmpty()) return false;
        final String lower = message.toLowerCase();
        // Routine license, device limit, clock or transport errors must never show update/maintenance dialog
        if (lower.contains("license") || lower.contains("user_key") || lower.contains("device limit") 
                || lower.contains("session expired") || lower.contains("invalid key") 
                || lower.contains("please enter") || lower.contains("not valid for carrom pool")
                || lower.contains("expired, disabled") || lower.contains("login rejected")
                || lower.contains("check automatic date/time") || lower.contains("transport")) {
            return false;
        }
        String tgHandle = getTelegramHandle();
        if (tgHandle == null || tgHandle.isEmpty()) tgHandle = "@HwMods";
        return message.startsWith("MAINTENANCE:") 
                || message.startsWith("UPDATE REQUIRED:") 
                || lower.contains("scheduled maintenance") 
                || (lower.contains("game version") && (lower.contains("disabled") || lower.contains("outdated")))
                || message.contains(tgHandle);
    }

    private AlertDialog versionDisabledDialog = null;
    private void showVersionDisabledDialog(final String message) {
        if (!isServerBroadcastNotice(message)) return;
        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                try {
                    if (versionDisabledDialog != null && versionDisabledDialog.isShowing()) return;
                    AlertDialog.Builder builder = new AlertDialog.Builder(Menu.this);
                    final String lower = message != null ? message.toLowerCase() : "";
                    final boolean isMaint = message.startsWith("MAINTENANCE:") || lower.contains("maintenance");
                    final boolean isUpdate = message.startsWith("UPDATE REQUIRED:") || (lower.contains("game version") && (lower.contains("disabled") || lower.contains("outdated")));
                    if (isMaint) {
                        builder.setTitle("🔧 SERVER MAINTENANCE");
                    } else if (isUpdate) {
                        builder.setTitle("⚠️ UPDATE REQUIRED");
                    } else {
                        builder.setTitle("📢 NOTICE");
                    }
                    String tgHandle = getTelegramHandle();
                    if (tgHandle == null || tgHandle.isEmpty()) tgHandle = "@HwMods";
                    String tgUrlVal = getTelegramUrl();
                    final String tgUrl = (tgUrlVal != null && !tgUrlVal.isEmpty()) ? tgUrlVal : "https://t.me/HwMods";
                    builder.setMessage(message + "\n\nPlease visit Telegram (" + tgHandle + ") for the latest updates.");
                    builder.setCancelable(true);
                    builder.setPositiveButton("JOIN TELEGRAM", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            try {
                                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(tgUrl));
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            } catch (Exception ignored) {}
                        }
                    });
                    builder.setNegativeButton("CLOSE", null);
                    versionDisabledDialog = builder.create();
                    int iparams = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O 
                            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY 
                            : WindowManager.LayoutParams.TYPE_PHONE;
                    if (versionDisabledDialog.getWindow() != null) {
                        versionDisabledDialog.getWindow().setType(iparams);
                    }
                    versionDisabledDialog.show();
                } catch (Exception ignored) {}
            }
        });
    }

    // ============================================================
    //  EXPIRY COUNTDOWN TIMER
    // ============================================================
    Handler countdownHandler;
    Runnable countdownRunnable;

    private void startExpiryCountdown() {
        if (countdownHandler == null) {
            countdownHandler = new Handler(Looper.getMainLooper());
        }
        if (countdownRunnable != null) {
            countdownHandler.removeCallbacks(countdownRunnable);
        }

        countdownRunnable = new Runnable() {
            @Override
            public void run() {
                updateMenuExpiryText();
                countdownHandler.postDelayed(this, 1000);
            }
        };
        countdownHandler.post(countdownRunnable);
    }

    private void stopExpiryCountdown() {
        if (countdownHandler != null && countdownRunnable != null) {
            countdownHandler.removeCallbacks(countdownRunnable);
        }
    }

    private void updateMenuExpiryText() {
        if (menuExpiryText == null) return;
        if (isLoginEnabled() && !isKeyAuthenticated()) {
            menuExpiryText.setText("");
            menuExpiryText.setVisibility(View.GONE);
            return;
        }
        boolean[] expired = new boolean[1];
        menuExpiryText.setText(EvIcons.formatExpiryLabel(getExpiryDate(), expired));
        int color = expired[0] ? EvIcons.ERROR_RED : EvIcons.GOLD;
        menuExpiryText.setTextColor(color);
        menuExpiryText.setShadowLayer(4.0f, 0, 0, expired[0] ? 0x66FF5252 : 0x66FFC107);
        menuExpiryText.setVisibility(View.VISIBLE);
    }

    private boolean isBrakeBtnAdded = false;
    private int currentBrakeSize = 70;

    private void updateBrakeButtonSize(int sizeDp) {
        currentBrakeSize = sizeDp;
        if (brakeParams != null) {
            brakeParams.width = dp(sizeDp);
            brakeParams.height = dp(sizeDp);
        }
        if (instantBrakeBtn != null) {
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(sizeDp), dp(sizeDp));
            instantBrakeBtn.setLayoutParams(lp);
            float textSize = Math.max(8.0f, (float) sizeDp * 0.15f);
            instantBrakeBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, textSize);
        }
        if (isBrakeBtnAdded && instantBrakeFrame != null && mWindowManager != null) {
            try {
                mWindowManager.updateViewLayout(instantBrakeFrame, brakeParams);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void initInstantBrakeButton() {
        if (instantBrakeFrame != null) return;
        instantBrakeFrame = new FrameLayout(this);

        instantBrakeBtn = new TextView(this);
        instantBrakeBtn.setText(Html.fromHtml("<b><font size='4' color='#FFD700'>⚡</font><br/><font color='#FFFFFF' size='2'><b>BRAKE</b></font><br/><font color='#FF5252' size='1'>STOP</font></b>"));
        instantBrakeBtn.setTextColor(Color.WHITE);
        instantBrakeBtn.setTextSize(TypedValue.COMPLEX_UNIT_SP, Math.max(8.0f, (float) currentBrakeSize * 0.15f));
        instantBrakeBtn.setTypeface(null, Typeface.BOLD);
        instantBrakeBtn.setGravity(Gravity.CENTER);
        instantBrakeBtn.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        final GradientDrawable brakeBg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.parseColor("#FF1744"), Color.parseColor("#B71C1C"), Color.parseColor("#210005")}
        );
        brakeBg.setShape(GradientDrawable.OVAL);
        brakeBg.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        brakeBg.setGradientRadius(dp(45));
        brakeBg.setStroke(dp(3), Color.parseColor("#FFFFFF"));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            instantBrakeBtn.setElevation(dp(12));
        }
        instantBrakeBtn.setBackground(brakeBg);

        FrameLayout.LayoutParams btnLp = new FrameLayout.LayoutParams(dp(currentBrakeSize), dp(currentBrakeSize));
        instantBrakeBtn.setLayoutParams(btnLp);

        int iparams = Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O ? 2038 : 2002;
        brakeParams = new WindowManager.LayoutParams(
                dp(currentBrakeSize),
                dp(currentBrakeSize),
                iparams,
                8, // FLAG_NOT_FOCUSABLE
                -3 // PixelFormat.TRANSLUCENT
        );
        brakeParams.gravity = 51; // TOP | START
        brakeParams.x = dp(20);
        brakeParams.y = dp(220);

        instantBrakeBtn.setOnTouchListener(new View.OnTouchListener() {
            private int initialX, initialY;
            private float initialTouchX, initialTouchY;
            private boolean isClick = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = brakeParams.x;
                        initialY = brakeParams.y;
                        initialTouchX = event.getRawX();
                        initialTouchY = event.getRawY();
                        isClick = true;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float diffX = event.getRawX() - initialTouchX;
                        float diffY = event.getRawY() - initialTouchY;
                        if (Math.abs(diffX) > 15 || Math.abs(diffY) > 15) {
                            isClick = false;
                        }
                        brakeParams.x = initialX + (int) diffX;
                        brakeParams.y = initialY + (int) diffY;
                        if (isBrakeBtnAdded && instantBrakeFrame != null && mWindowManager != null) {
                            try {
                                mWindowManager.updateViewLayout(instantBrakeFrame, brakeParams);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (isClick) {
                            v.performClick();
                        }
                        return true;
                }
                return false;
            }
        });

        instantBrakeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Preferences.changeFeatureBool("Instant Emergency Brake Action", 39, true);

                final GradientDrawable tapBg = new GradientDrawable(
                        GradientDrawable.Orientation.TL_BR,
                        new int[]{Color.parseColor("#FFEE58"), Color.parseColor("#FFD600"), Color.parseColor("#FF6F00")}
                );
                tapBg.setShape(GradientDrawable.OVAL);
                tapBg.setGradientType(GradientDrawable.RADIAL_GRADIENT);
                tapBg.setGradientRadius(dp(45));
                tapBg.setStroke(dp(4), Color.WHITE);
                instantBrakeBtn.setBackground(tapBg);
                instantBrakeBtn.setText(Html.fromHtml("<b><font size='4' color='#B71C1C'>🛑</font><br/><font color='#B71C1C' size='2'><b>LOCKED</b></font></b>"));

                new Handler(android.os.Looper.getMainLooper()).postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        instantBrakeBtn.setBackground(brakeBg);
                        instantBrakeBtn.setText(Html.fromHtml("<b><font size='4' color='#FFD700'>⚡</font><br/><font color='#FFFFFF' size='2'><b>BRAKE</b></font><br/><font color='#FF5252' size='1'>STOP</font></b>"));
                    }
                }, 500);
            }
        });

        instantBrakeFrame.addView(instantBrakeBtn);
    }

    public void showInstantBrakeButton(final boolean show) {
        new Handler(android.os.Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                try {
                    if (instantBrakeFrame == null) {
                        initInstantBrakeButton();
                    }
                    if (show) {
                        if (!isBrakeBtnAdded && instantBrakeFrame != null && mWindowManager != null) {
                            mWindowManager.addView(instantBrakeFrame, brakeParams);
                            isBrakeBtnAdded = true;
                            Toast.makeText(getApplicationContext(), "Instant Brake Button Enabled", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        if (isBrakeBtnAdded && instantBrakeFrame != null && mWindowManager != null) {
                            mWindowManager.removeView(instantBrakeFrame);
                            isBrakeBtnAdded = false;
                        }
                    }
                } catch (Exception e) {
                    Log.e(TAG, "Error in showInstantBrakeButton: " + e.getMessage(), e);
                }
            }
        });
    }

    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = mCollapsed;
            final View expandedView = mExpanded;
            private float initialTouchX, initialTouchY;
            private int initialX, initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = motionEvent.getRawX();
                        initialTouchY = motionEvent.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int rawX = (int) (motionEvent.getRawX() - initialTouchX);
                        int rawY = (int) (motionEvent.getRawY() - initialTouchY);
                        mExpanded.setAlpha(1f);
                        mCollapsed.setAlpha(1f);
                        //The check for Xdiff <10 && YDiff< 10 because sometime elements moves a little while clicking.
                        //So that is click event.
                        if (Math.abs(rawX) < 10 && Math.abs(rawY) < 10 && isViewCollapsed()) {
                            //When user clicks on the image view of the collapsed layout,
                            //visibility of the collapsed layout will be changed to "View.GONE"
                            //and expanded view will become visible.
                            try {
                                collapsedView.setVisibility(View.GONE);
                                expandedView.setVisibility(View.VISIBLE);
                            } catch (NullPointerException e) {

                            }
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        mExpanded.setAlpha(1f);
                        mCollapsed.setAlpha(0.5f);
                        //Calculate the X and Y coordinates of the view.
                        params.x = initialX + ((int) (motionEvent.getRawX() - initialTouchX));
                        params.y = initialY + ((int) (motionEvent.getRawY() - initialTouchY));
                        //Update the layout with new X & Y coordinate
                        mWindowManager.updateViewLayout(rootFrame, params);
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        mExpanded.setAlpha(1f);
                        mCollapsed.setAlpha(ICON_ALPHA);
                        return true;
                    default:
                        return false;
                }
            }
        };
    }

    private void featureList(String[] listFT, LinearLayout linearLayout) {
        //Currently looks messy right now. Let me know if you have improvements
        int featNum, subFeat = 0;
        LinearLayout llBak = linearLayout;

        for (int i = 0; i < listFT.length; i++) {
            boolean switchedOn = false;
            //Log.i("featureList", listFT[i]);
            String feature = listFT[i];
            if (feature.contains("True_")) {
                switchedOn = true;
                feature = feature.replaceFirst("True_", "");
            }

            linearLayout = llBak;
            if (feature.startsWith("Global_")) {
                linearLayout = globalControls;
                feature = feature.substring("Global_".length());
            }
            if (feature.startsWith("TabAdd_")) {
                linearLayout = currentCategory != null ? currentCategory : llBak;
                feature = feature.substring("TabAdd_".length());
            }
            if (feature.contains("CollapseAdd_")) {
                //if (collapse != null)
                linearLayout = mCollapse;
                feature = feature.replaceFirst("CollapseAdd_", "");
            }
            String[] str = feature.split("_");

            //Assign feature number
            if (TextUtils.isDigitsOnly(str[0]) || str[0].matches("-[0-9]*")) {
                featNum = Integer.parseInt(str[0]);
                feature = feature.replaceFirst(str[0] + "_", "");
                subFeat++;
            } else {
                //Subtract feature number. We don't want to count ButtonLink, Category, RichTextView and RichWebView
                featNum = i - subFeat;
            }
            String[] strSplit = feature.split("_");
            switch (strSplit[0]) {
                case "Toggle":
                case "TG":
                case "Tg": {
                    View switchView = Switch(featNum, strSplit[1], switchedOn);
                    if (featNum == 5) {
                        autoAimCard = switchView;
                    }
                    linearLayout.addView(switchView);
                    break;
                }
                case "SeekBar":
                case "Slider": {
                    View sbView = SeekBar(featNum, strSplit[1], Integer.parseInt(strSplit[2]), Integer.parseInt(strSplit[3]),
                            strSplit.length > 4 ? Integer.parseInt(strSplit[4]) : null);
                    if (featNum == 15) {
                        shotForceCard = sbView;
                    }
                    linearLayout.addView(sbView);
                    break;
                }
                case "Button":
                    linearLayout.addView(Button(featNum, strSplit[1]));
                    break;
                case "ButtonOnOff":
                    linearLayout.addView(ButtonOnOff(featNum, strSplit[1], switchedOn));
                    break;
                case "Spinner":
                    linearLayout.addView(Spinner(featNum, strSplit[1], strSplit[2]));
                    break;
                case "NativeSpinner": {
                    View nsView = Spinner(featNum, strSplit[1], strSplit[2], true);
                    if (featNum == 16) {
                        cleanTableCard = nsView;
                    }
                    linearLayout.addView(nsView);
                    break;
                }
                case "ChoiceGrid":
                    linearLayout.addView(ChoiceGrid(featNum, strSplit[1], strSplit[2],
                            strSplit.length > 3 ? Integer.parseInt(strSplit[3]) : 0, ""));
                    break;
                case "ColorGrid":
                    linearLayout.addView(ChoiceGrid(featNum, strSplit[1], strSplit[2],
                            Integer.parseInt(strSplit[3]), strSplit[4]));
                    break;
                case "Status":
                    linearLayout.addView(FeatureStatus(featNum, strSplit[1]));
                    break;
                case "InputText":
                    linearLayout.addView(TextField(featNum, strSplit[1], false, 0));
                    break;
                case "InputValue":
                    if (strSplit.length == 3)
                        linearLayout.addView(TextField(featNum, strSplit[2], true, Integer.parseInt(strSplit[1])));
                    if (strSplit.length == 2)
                        linearLayout.addView(TextField(featNum, strSplit[1], true, 0));
                    break;
                case "CheckBox":
                    linearLayout.addView(CheckBox(featNum, strSplit[1], switchedOn));
                    break;
                case "RadioButton":
                    linearLayout.addView(RadioButton(featNum, strSplit[1], strSplit[2]));
                    break;
                case "Collapse":
                    Collapse(linearLayout, strSplit[1]);
                    subFeat++;
                    break;
                case "Tab":
                    addCategory(strSplit[1], linearLayout);
                    subFeat++;
                    break;
                case "ButtonLink":
                    subFeat++;
                    linearLayout.addView(ButtonLink(strSplit[1], strSplit[2]));
                    break;
                case "Text":
                    subFeat++;
                    linearLayout.addView(Text(strSplit[1]));
                    break;
                case "Rainbow":
                    subFeat++;
                    linearLayout.addView(Rainbow(strSplit[1]));
                    break;
                case "Category":
                    subFeat++;
                    linearLayout.addView(Category(strSplit[1]));
                    break;
                case "RichTextView":
                    subFeat++;
                    linearLayout.addView(RichTextView(strSplit[1]));
                    break;
                case "RichWebView":
                    subFeat++;
                    linearLayout.addView(RichWebView(strSplit[1]));
                    break;
            }
        }
    }

    private GradientDrawable cardBackground(int fill, int border) {
        return EvIcons.cardBackground(this, fill, border, 10f, 1);
    }

    private void featureCard(View view) {
        EvIcons.styleFeatureCard(this, view, 52);
    }

    private View Switch(final int featNum, final String featName, boolean swiOn) {
        final Switch switchR = new Switch(this);
        EvIcons.styleSwitchCard(this, switchR, featName);
        boolean isInitiallyOn = Preferences.loadPrefBool(featName, featNum, swiOn);
        if (featNum == 19) {queueMenuSwitch = switchR; isInitiallyOn = getFeatureValue(19) != 0;}
        if (featNum == 5) {autoAimSwitch = switchR;}
        switchR.setChecked(isInitiallyOn);
        if (featNum == 37 && isInitiallyOn) {
            showInstantBrakeButton(true);
        }
        switchR.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton compoundButton, boolean bool) {
                if (featNum == 19 && syncingQueueControl) return;
                Preferences.changeFeatureBool(featName, featNum, bool);
                if (featNum == 19) {
                    if (bool) Preferences.changeFeatureInt("Autoplay", 13, 2);
                    refreshQueueControls();
                }
                switch (featNum) {
                    case 37:
                        showInstantBrakeButton(bool);
                        break;
                    case -1: //Save perferences
                        Preferences.with(switchR.getContext()).writeBoolean(-1, bool);
                        if (bool == false)
                            Preferences.with(switchR.getContext()).clear(); //Clear perferences if switched off
                        break;
                    case -3:
                        Preferences.isExpanded = bool;
                        scrollView.setLayoutParams(bool ? scrlLLExpanded : scrlLL);
                        break;
                }
            }
        });
        return switchR;
    }
    private View Toggle(final int featNum, final String featName, boolean swiOn) {
        final GradientDrawable rm = new GradientDrawable();
        rm.setCornerRadius(50);
        rm.setSize(dp(10),dp(1));
        rm.setAlpha(50);
        rm.setColor(Color.WHITE);      
        
        final  GradientDrawable raunak= new  GradientDrawable();
        raunak.setSize(50,50);
        raunak.setShape(1);
        raunak.setStroke(3,Color.WHITE);
        raunak.setColor(Color.BLACK);
        
        final GradientDrawable raunakm = new GradientDrawable();
        raunakm.setColor(Color.BLACK);
        raunakm.setSize(10,4);
        raunakm.setStroke(3,Color.WHITE);
        raunakm.setCornerRadius(100);
        
        final Switch switchh = new Switch(this);
        switchh.setText(featName);
        switchh.setTextColor(Color.WHITE);
        switchh.setTypeface(null, Typeface.BOLD_ITALIC);
        switchh.setPadding(10, 3, 3, 3);
        switchh.setTextSize(15.0f);
        switchh.setBackgroundColor(Color.TRANSPARENT);
        switchh.setThumbDrawable(raunak);
        switchh.setTrackDrawable(raunakm);
        switchh.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(40)));
        switchh.setTypeface(switchh.getTypeface(), Typeface.NORMAL);
        switchh.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                    if(isChecked) {
                        raunakm.setColor(Color.GREEN);
                        raunak.setColor(Color.GREEN);

                    } else {
                        raunakm.setColor(Color.RED);
                        raunak.setColor(Color.RED);
                    }
                }
            });
        return switchh;
    }
    private View AddToggle(final int featNum, final String featName, boolean swiOn) {
        Switch switchR = new Switch(this);
        switchR.setBackgroundColor(Color.TRANSPARENT);
        switchR.setText(Html.fromHtml("<font face='roboto'>" + featName + "</font>"));
        switchR.setTextColor(Color.parseColor("BLACK"));
        GradientDrawable raunak= new  GradientDrawable();
        raunak.setSize(40,40);
        raunak.setShape(1);
        raunak.setStroke(3,Color.argb(255,15,169,255));
        raunak.setColor(Color.WHITE);
        final GradientDrawable rmods = new GradientDrawable();
        rmods.setColor(Color.RED);
        rmods.setSize(30,4);

        rmods.setColor(Color.parseColor("BLACK"));

        rmods.setCornerRadius(100);
        switchR.setThumbDrawable(raunak);
        switchR.setTrackDrawable(rmods);
        switchR.setTextColor(Color.WHITE);
        switchR.setPadding(10, 3, 3, 3);
        rmods.setColor(Color.RED);


        if(Build.VERSION.SDK_INT >= 21) { switchR.setElevation(100f); }
        switchR.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean checked) {
                    if (checked) {
                        rmods.setColor(Color.GREEN);

                    } else {
                        rmods.setColor(Color.RED);

                    }
                    
                }
            });
        return switchR;
    }
    private View SB(final int featNum, final String featName, final int min, int max) {
        int loadedProg = Preferences.loadPrefInt(featName, featNum);
        int defaultVal = min;
        if (featName.contains("Speed Limit")) {
            defaultVal = 100;
        }
        int currentVal = (loadedProg == 0) ? defaultVal : loadedProg;

        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setPadding(10, 5, 0, 5);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(Gravity.CENTER);

        final TextView textView = new TextView(this);
        String labelText = featName + ": <font color='" + NumberTxtColor + "'>" + currentVal + "</font>";
        if (currentVal == defaultVal) {
            labelText += " <font color='#00FF00'>(Default)</font>";
        }
        textView.setText(Html.fromHtml(labelText));
        textView.setTextColor(TEXT_COLOR_2);

        SeekBar seekBar = new SeekBar(this);
        seekBar.setPadding(25, 10, 35, 10);
        seekBar.setMax(max);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            seekBar.setMin(min); //setMin for Oreo and above
        seekBar.setProgress(currentVal);
        seekBar.getThumb().setColorFilter(SeekBarColor, PorterDuff.Mode.SRC_ATOP);
        seekBar.getProgressDrawable().setColorFilter(SeekBarProgressColor, PorterDuff.Mode.SRC_ATOP);
        final int defValFinal = defaultVal;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                public void onStartTrackingTouch(SeekBar seekBar) {
                }

                public void onStopTrackingTouch(SeekBar seekBar) {
                }

                public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                    int val = i < min ? min : i;
                    if (z) {
                        Preferences.changeFeatureInt(featName, featNum, val);
                    }
                    String displayTxt = featName + ": <font color='" + NumberTxtColor + "'>" + val + "</font>";
                    if (val == defValFinal) {
                        displayTxt += " <font color='#00FF00'>(Default)</font>";
                    }
                    textView.setText(Html.fromHtml(displayTxt));
                }
            });
        linearLayout.addView(textView);
        linearLayout.addView(seekBar);

        return linearLayout;
    }
    
    private View SeekBar(final int featNum, final String featName, final int min, int max, Integer nativeDefault) {
        int loadedProg = Preferences.loadPrefInt(featName, featNum);
        int defaultVal = min;
        if (nativeDefault != null) {
            defaultVal = Math.max(min, Math.min(max, nativeDefault));
        } else if (featName.contains("Speed Limit")) {
            defaultVal = 100;
        } else if (featName.contains("Speed Scale")) {
            defaultVal = 10;
        } else if (featName.contains("Float Brake Button Size")) {
            defaultVal = 70;
        } else if (featName.contains("Camera FOV")) {
            defaultVal = 60;
        } else if (featName.contains("Table Position X") || featName.contains("Table Left-Right")) {
            defaultVal = 50;
        } else if (featName.contains("Table Position Y") || featName.contains("Table Up-Down") || featName.contains("Table Vertical Position")) {
            defaultVal = 50;
        } else if (featName.contains("Table Size") || featName.contains("Bada - Chota") || featName.contains("Table Scale Zoom") || featName.contains("Table Width Stretch")) {
            defaultVal = 100;
        } else if (featName.contains("Goti Circle Size")) {
            defaultVal = 19;
        }
        int currentVal = (loadedProg == 0) ? defaultVal : loadedProg;
        if (loadedProg != 0) {
            Preferences.changeFeatureInt(featName, featNum, currentVal);
        }
        if (featNum == -7 || featName.contains("Float Brake Button Size")) {
            updateBrakeButtonSize(currentVal);
        }

        LinearLayout linearLayout = new LinearLayout(this);
        featureCard(linearLayout);
        linearLayout.setOrientation(LinearLayout.VERTICAL);
        linearLayout.setGravity(Gravity.START);
        linearLayout.setClipChildren(false);
        linearLayout.setClipToPadding(false);

        final TextView textView = new TextView(this);
        textView.setText(EvIcons.formatSeekBarLabel(featName, currentVal, defaultVal));
        textView.setTextColor(EvIcons.GOLD);

        SeekBar seekBar = new SeekBar(this);
        seekBar.setFocusable(false);
        seekBar.setFocusableInTouchMode(false);
        seekBar.setContentDescription(featName);
        seekBar.setMax(Math.max(1, max - min));
        seekBar.setProgress(Math.max(0, currentVal - min));
        EvIcons.styleSeekBar(this, seekBar);
        final int defValFinal = defaultVal;
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                int val = min + i;
                if (z) {
                    Preferences.changeFeatureInt(featName, featNum, val);
                    if (featNum == -7 || featName.contains("Float Brake Button Size")) {
                        updateBrakeButtonSize(val);
                    }
                }
                textView.setText(EvIcons.formatSeekBarLabel(featName, val, defValFinal));
            }
        });
        linearLayout.addView(textView);
        linearLayout.addView(seekBar);

        return linearLayout;
    }

    private View Button(final int featNum, final String featName) {
        final Button button = new Button(this);
        EvIcons.styleFeatureCard(this, button, 52);
        button.setTextColor(EvIcons.GOLD);
        button.setAllCaps(false); //Disable caps to support html
        button.setText(Html.fromHtml("<b>" + featName + "</b>"));
        button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.0f);
        button.setGravity(Gravity.CENTER);
        button.setBackground(EvIcons.cardBackground(this, SURFACE_COLOR, BTN_COLOR, 10f, 1));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            button.setElevation(dp(3));
        }

        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                switch (featNum) {
                    case -11:
                        if (categoryTabs != null) categoryTabs.setVisibility(View.GONE);
                        if (globalControls != null) globalControls.setVisibility(View.GONE);
                        scrollView.removeView(patches);
                        scrollView.addView(mSettings);
                        scrollView.scrollTo(0, 0);
                        break;
                    case -4:
                        Logcat.Save(getApplicationContext());
                        break;
                    case -5:
                        Logcat.Clear(getApplicationContext());
                        break;
                    case -6:
                        scrollView.removeAllViews();
                        if (!isLoginEnabled() || isKeyAuthenticated()) {
                            showFeaturesView();
                        } else {
                            showLoginView();
                        }
                        scrollView.scrollTo(0, 0);
                        break;
                    case -100:
                        stopChecking = true;
                        break;
                }
                Preferences.changeFeatureInt(featName, featNum, 0);
            }
        });

        return button;
    }

    private View ButtonLink(final String featName, final String url) {
        final Button button = new Button(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT);
        layoutParams.setMargins(dp(6), dp(5), dp(6), dp(5));
        button.setLayoutParams(layoutParams);
        button.setAllCaps(false); //Disable caps to support html
        button.setTextColor(Color.WHITE);
        button.setText(Html.fromHtml("<b><font color='#FFFFFF'>✈ " + featName + "</font></b>"));
        button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.0f);

        GradientDrawable tgBg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.parseColor("#0088CC"), Color.parseColor("#005580")}
        );
        tgBg.setCornerRadius(dp(8));
        tgBg.setStroke(dp(1), Color.parseColor("#29B6F6"));
        button.setBackground(tgBg);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            button.setElevation(dp(3));
        }

        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.setData(Uri.parse(url));
                startActivity(intent);
            }
        });
        return button;
    }

    private View ButtonOnOff(final int featNum, String featName, boolean switchedOn) {
        final Button button = new Button(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT);
        layoutParams.setMargins(dp(6), dp(4), dp(6), dp(4));
        button.setLayoutParams(layoutParams);
        button.setTextColor(Color.WHITE);
        button.setAllCaps(false); //Disable caps to support html
        button.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.0f);

        final String finalfeatName = featName.replace("OnOff_", "");
        final boolean[] state = { Preferences.loadPrefBool(featName, featNum, switchedOn) };

        final Runnable updateStyle = new Runnable() {
            @Override
            public void run() {
                GradientDrawable bg = new GradientDrawable(
                        GradientDrawable.Orientation.TL_BR,
                        state[0] ? new int[]{Color.parseColor("#2E7D32"), Color.parseColor("#1B5E20")}
                                 : new int[]{Color.parseColor("#C62828"), Color.parseColor("#8E0000")}
                );
                bg.setCornerRadius(dp(8));
                bg.setStroke(dp(1), state[0] ? Color.parseColor("#81C784") : Color.parseColor("#EF5350"));
                button.setBackground(bg);
                button.setText(Html.fromHtml("<b>" + finalfeatName + ": " + (state[0] ? "<font color='#69F0AE'>ON</font>" : "<font color='#FF5252'>OFF</font>") + "</b>"));
            }
        };
        updateStyle.run();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            button.setElevation(dp(3));
        }

        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                state[0] = !state[0];
                updateStyle.run();
                Preferences.changeFeatureBool(finalfeatName, featNum, state[0]);
            }
        });
        return button;
    }

    private void refreshQueueControls() {
        refreshNativeSpinners();
        final boolean autoplayOn = getFeatureValue(13) != 0;
        final boolean on = getFeatureValue(19) != 0;
        if (floatingQueueButton != null) {
            floatingQueueButton.setVisibility((!isLoginEnabled() || isKeyAuthenticated()) ? View.VISIBLE : View.GONE);
            EvIcons.applyQueueButtonStyle(this, floatingQueueButton, autoplayOn);
        }
        if (queueMenuSwitch != null && queueMenuSwitch.isChecked() != on) {
            syncingQueueControl = true;
            queueMenuSwitch.setChecked(on);
            syncingQueueControl = false;
        }
    }

    private View FeatureStatus(final int feature, final String title) {
        final TextView text = new TextView(this);
        EvIcons.styleStatusCard(this, text);
        text.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        final Handler refreshHandler = new Handler(android.os.Looper.getMainLooper());
        final Runnable refresh = new Runnable() {
            @Override public void run() {
                text.setText(title + ": " + getFeatureStatus(feature));
                refreshHandler.postDelayed(this, 750);
            }
        };
        text.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override public void onViewAttachedToWindow(View v) {refreshHandler.post(refresh);}
            @Override public void onViewDetachedFromWindow(View v) {refreshHandler.removeCallbacks(refresh);}
        });
        text.setText(title + ": " + getFeatureStatus(feature));
        return text;
    }

    // Generic presentation only: IDs, prices and match decisions come from JNI.
    // Item zero is the unselected placeholder; buttons preserve native indices.
    private View ChoiceGrid(final int featNum, final String featName, final String list, final int defaultIndex,
                            final String colourList) {
        final String[] items = list.split(",");
        // Generic presentation tokens supplied by JNI, not game/ring decisions.
        final String[] colours = colourList.isEmpty() ? new String[0] : colourList.split(",");
        final LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        EvIcons.styleFeatureCard(this, card, 52);
        final TextView label = new TextView(this);
        label.setTextColor(EvIcons.TEXT_WHITE);
        label.setTextSize(11.0f);
        label.setPadding(0, 0, 0, dp(4));
        card.addView(label);
        final Button[] buttons = new Button[items.length];
        final int saved = Preferences.loadPrefInt(featName, featNum);
        final int[] selected = {saved > 0 && saved < items.length ? saved :
                Math.max(0, Math.min(defaultIndex, items.length - 1))};
        final Runnable refresh = new Runnable() {
            @Override public void run() {
                label.setText(featName);
                for (int i = 1; i < items.length; ++i) {
                    if (buttons[i] == null) continue;
                    boolean active = i == selected[0];
                    int customAccent = 0;
                    if (i <= colours.length) {
                        try { customAccent = Color.parseColor(colours[i - 1]); }
                        catch (IllegalArgumentException ignored) { }
                    }
                    EvIcons.styleChoiceButton(Menu.this, buttons[i], active, customAccent, items[i], featName);
                }
            }
        };
        LinearLayout row = null;
        final int columns = items.length == 3 || items.length == 5 ? 2 : 3;
        for (int i = 1; i < items.length; ++i) {
            if ((i - 1) % columns == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                card.addView(row, new LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT));
            }
            final int index = i;
            Button button = EvIcons.createChoiceButton(this);
            buttons[i] = button;
            row.addView(button, EvIcons.createChoiceButtonParams(this));
            button.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    selected[0] = index;
                    Preferences.changeFeatureInt(featName, featNum, index);
                    refresh.run();
                }
            });
        }
        refresh.run();
        return card;
    }

    private View shotForceCard = null;
    private View cleanTableCard = null;
    private View autoAimCard = null;
    private Switch autoAimSwitch = null;
    private AlertDialog autoplayWarningDialog = null;
    private android.os.CountDownTimer autoplayWarningTimer = null;
    private static final java.util.Set<Integer> sessionRiskAccepted = new java.util.HashSet<>();

    private void updateAutoplayVisibility() {
        int cleanVal = getFeatureValue(16);
        if (cleanTableCard != null) {
            cleanTableCard.setVisibility(cleanVal >= 0 ? View.VISIBLE : View.GONE);
        }
        if (shotForceCard != null) {
            shotForceCard.setVisibility(View.VISIBLE);
        }
        if (autoAimCard != null) {
            autoAimCard.setVisibility(View.VISIBLE);
        }
    }

    private void showAutoplayRiskWarningDialog(final int targetPosition, final Spinner autoplaySpinner, final int[] trackedPos) {
        if (autoplayWarningDialog != null && autoplayWarningDialog.isShowing()) {
            return;
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable rootBg = new GradientDrawable();
        rootBg.setColor(Color.parseColor("#0B0F19"));
        rootBg.setStroke(dp(2), Color.parseColor("#DC2626"));
        rootBg.setCornerRadius(dp(20));
        root.setBackground(rootBg);
        root.setPadding(dp(20), dp(18), dp(20), dp(18));

        TextView badgeView = new TextView(this);
        badgeView.setText("⚠️  HIGH BAN RISK");
        badgeView.setTextColor(Color.parseColor("#FDA4AF"));
        badgeView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        badgeView.setTypeface(null, Typeface.BOLD);
        badgeView.setGravity(Gravity.CENTER);
        GradientDrawable badgeBg = new GradientDrawable();
        badgeBg.setColor(Color.parseColor("#3B0D14"));
        badgeBg.setStroke(dp(1), Color.parseColor("#E11D48"));
        badgeBg.setCornerRadius(dp(14));
        badgeView.setBackground(badgeBg);
        badgeView.setPadding(dp(14), dp(4), dp(14), dp(4));
        LinearLayout.LayoutParams badgeLp = new LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT);
        badgeLp.gravity = Gravity.CENTER_HORIZONTAL;
        badgeLp.bottomMargin = dp(10);
        badgeView.setLayoutParams(badgeLp);
        root.addView(badgeView);

        TextView titleView = new TextView(this);
        titleView.setText("Risky Autoplay Mode");
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        titleView.setTypeface(null, Typeface.BOLD);
        titleView.setGravity(Gravity.CENTER);
        root.addView(titleView);

        LinearLayout infoBox = new LinearLayout(this);
        infoBox.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable infoBg = new GradientDrawable();
        infoBg.setColor(Color.parseColor("#131927"));
        infoBg.setCornerRadius(dp(12));
        infoBg.setStroke(dp(1), Color.parseColor("#1E293B"));
        infoBox.setBackground(infoBg);
        infoBox.setPadding(dp(14), dp(12), dp(14), dp(12));
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT);
        infoLp.setMargins(0, dp(10), 0, dp(12));
        infoBox.setLayoutParams(infoLp);

        TextView msgView = new TextView(this);
        String targetName = (targetPosition == 1 ? "V1 Fast Autoplay" : "V3 360 Autoplay");
        msgView.setText("You are enabling " + targetName + ".\n\n"
                + "This mode shoots instantly with zero delay. Playing like this makes it very obvious to opponents and can easily get your Miniclip account flagged or banned.\n\n"
                + "💡 Recommended: Use V2 Natural instead. It mimics real human finger drag and safe shot timing.");
        msgView.setTextColor(Color.parseColor("#94A3B8"));
        msgView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        msgView.setLineSpacing(dp(2), 1.15f);
        infoBox.addView(msgView);
        root.addView(infoBox);

        final CheckBox cbNeverShow = new CheckBox(this);
        cbNeverShow.setText("Don't show this warning again");
        cbNeverShow.setTextColor(Color.parseColor("#94A3B8"));
        cbNeverShow.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            ColorStateList cbColors = new ColorStateList(
                    new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                    new int[]{Color.parseColor("#EF4444"), Color.parseColor("#64748B")}
            );
            cbNeverShow.setButtonTintList(cbColors);
        }
        LinearLayout.LayoutParams cbLp = new LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT);
        cbLp.bottomMargin = dp(12);
        cbNeverShow.setLayoutParams(cbLp);
        root.addView(cbNeverShow);

        LinearLayout btnLayout = new LinearLayout(this);
        btnLayout.setOrientation(LinearLayout.VERTICAL);

        Button btnSafe = new Button(this);
        btnSafe.setText("Switch to V2 (Safe Recommended)");
        btnSafe.setTextColor(Color.WHITE);
        btnSafe.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f);
        btnSafe.setTypeface(null, Typeface.BOLD);
        GradientDrawable safeBg = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{Color.parseColor("#10B981"), Color.parseColor("#059669")}
        );
        safeBg.setCornerRadius(dp(10));
        safeBg.setStroke(dp(1), Color.parseColor("#34D399"));
        btnSafe.setBackground(safeBg);
        LinearLayout.LayoutParams safeLp = new LinearLayout.LayoutParams(MATCH_PARENT, dp(44));
        safeLp.setMargins(0, 0, 0, dp(8));
        btnSafe.setLayoutParams(safeLp);

        final Button btnRisky = new Button(this);
        btnRisky.setText("Enable Anyway (5s)");
        btnRisky.setTextColor(Color.parseColor("#64748B"));
        btnRisky.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f);
        btnRisky.setTypeface(null, Typeface.BOLD);
        btnRisky.setEnabled(false);
        btnRisky.setAlpha(0.6f);
        final GradientDrawable riskyBg = new GradientDrawable();
        riskyBg.setColor(Color.parseColor("#1E293B"));
        riskyBg.setCornerRadius(dp(10));
        riskyBg.setStroke(dp(1), Color.parseColor("#334155"));
        btnRisky.setBackground(riskyBg);
        LinearLayout.LayoutParams riskyLp = new LinearLayout.LayoutParams(MATCH_PARENT, dp(44));
        riskyLp.setMargins(0, 0, 0, dp(8));
        btnRisky.setLayoutParams(riskyLp);

        Button btnCancel = new Button(this);
        btnCancel.setText("Cancel");
        btnCancel.setTextColor(Color.parseColor("#94A3B8"));
        btnCancel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        GradientDrawable cancelBg = new GradientDrawable();
        cancelBg.setColor(Color.parseColor("#0F172A"));
        cancelBg.setCornerRadius(dp(10));
        cancelBg.setStroke(dp(1), Color.parseColor("#334155"));
        btnCancel.setBackground(cancelBg);
        LinearLayout.LayoutParams cancelLp = new LinearLayout.LayoutParams(MATCH_PARENT, dp(38));
        btnCancel.setLayoutParams(cancelLp);

        btnLayout.addView(btnSafe);
        btnLayout.addView(btnRisky);
        btnLayout.addView(btnCancel);
        root.addView(btnLayout);

        builder.setView(root);
        autoplayWarningDialog = builder.create();

        if (autoplayWarningDialog.getWindow() != null) {
            autoplayWarningDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                autoplayWarningDialog.getWindow().setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY);
            } else {
                autoplayWarningDialog.getWindow().setType(WindowManager.LayoutParams.TYPE_PHONE);
            }
            try {
                WindowManager.LayoutParams wlp = autoplayWarningDialog.getWindow().getAttributes();
                if (wlp != null) {
                    wlp.width = (int) (getResources().getDisplayMetrics().widthPixels * 0.88f);
                    wlp.gravity = Gravity.CENTER;
                    autoplayWarningDialog.getWindow().setAttributes(wlp);
                }
            } catch (Exception ignored) {}
        }

        autoplayWarningTimer = new android.os.CountDownTimer(5000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                long sec = (millisUntilFinished / 1000) + 1;
                btnRisky.setText("Enable Anyway (" + sec + "s)");
            }

            @Override
            public void onFinish() {
                btnRisky.setText("I Understand & Enable");
                btnRisky.setTextColor(Color.WHITE);
                btnRisky.setEnabled(true);
                btnRisky.setAlpha(1.0f);
                GradientDrawable activeRiskyBg = new GradientDrawable(
                        GradientDrawable.Orientation.TL_BR,
                        new int[]{Color.parseColor("#DC2626"), Color.parseColor("#991B1B")}
                );
                activeRiskyBg.setCornerRadius(dp(10));
                activeRiskyBg.setStroke(dp(1), Color.parseColor("#EF4444"));
                btnRisky.setBackground(activeRiskyBg);
            }
        };

        final int prev = trackedPos[0];

        btnSafe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (autoplayWarningTimer != null) autoplayWarningTimer.cancel();
                trackedPos[0] = 2;
                if (autoplaySpinner != null) autoplaySpinner.setSelection(2);
                Preferences.changeFeatureInt("Autoplay", 13, 2);
                refreshNativeSpinners();
                updateAutoplayVisibility();
                if (autoplayWarningDialog != null) autoplayWarningDialog.dismiss();
            }
        });

        btnRisky.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (autoplayWarningTimer != null) autoplayWarningTimer.cancel();
                sessionRiskAccepted.add(targetPosition);
                if (cbNeverShow.isChecked()) {
                    SharedPreferences prefs = Preferences.getStore(Menu.this);
                    if (prefs != null) {
                        prefs.edit().putBoolean("never_show_autoplay_warning", true).apply();
                    }
                }
                trackedPos[0] = targetPosition;
                if (autoplaySpinner != null) autoplaySpinner.setSelection(targetPosition);
                Preferences.changeFeatureInt("Autoplay", 13, targetPosition);
                refreshNativeSpinners();
                updateAutoplayVisibility();
                if (autoplayWarningDialog != null) autoplayWarningDialog.dismiss();
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (autoplayWarningTimer != null) autoplayWarningTimer.cancel();
                trackedPos[0] = prev;
                if (autoplaySpinner != null) autoplaySpinner.setSelection(prev);
                refreshNativeSpinners();
                updateAutoplayVisibility();
                if (autoplayWarningDialog != null) autoplayWarningDialog.dismiss();
            }
        });

        autoplayWarningDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialog) {
                if (autoplayWarningTimer != null) {
                    autoplayWarningTimer.cancel();
                    autoplayWarningTimer = null;
                }
                autoplayWarningDialog = null;
            }
        });

        try {
            autoplayWarningDialog.show();
            autoplayWarningTimer.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private View Spinner(final int featNum, final String featName, final String list) {
        return Spinner(featNum, featName, list, false);
    }

    private void refreshNativeSpinners() {
        for (Runnable refresh : nativeSpinnerRefreshers) refresh.run();
        updateAutoplayVisibility();
    }

    private View Spinner(final int featNum, final String featName, final String list, final boolean nativeState) {
        final List<String> lists = new LinkedList<>(Arrays.asList(list.split(",")));
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(LinearLayout.VERTICAL);
        EvIcons.styleFeatureCard(this, linearLayout2, 52);
        TextView label = new TextView(this);
        label.setText(featName);
        label.setTextColor(EvIcons.TEXT_MUTED);
        label.setTextSize(12.0f);
        linearLayout2.addView(label);

        final Spinner spinner = new Spinner(this, Spinner.MODE_DROPDOWN);
        spinner.setContentDescription(featName);
        spinner.setAdapter(EvIcons.createSpinnerAdapter(this, lists));
        final int[] currentTrackedPos = new int[]{Math.max(0, Math.min(lists.size() - 1,
                nativeState ? getFeatureValue(featNum) : Preferences.loadPrefInt(featName, featNum)))};
        spinner.setSelection(currentTrackedPos[0]);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                if (featNum == 13 && (position == 1 || position == 3) && position != currentTrackedPos[0]) {
                    SharedPreferences prefs = Preferences.getStore(Menu.this);
                    boolean permanentAccepted = prefs != null && prefs.getBoolean("never_show_autoplay_warning", false);
                    boolean sessionAccepted = sessionRiskAccepted.contains(position);
                    if (!permanentAccepted && !sessionAccepted) {
                        showAutoplayRiskWarningDialog(position, spinner, currentTrackedPos);
                        spinner.setSelection(currentTrackedPos[0]);
                        return;
                    }
                }
                currentTrackedPos[0] = position;

                // Negative JNI state means unavailable. Never replay a stale
                // selection when a dependent control has just been hidden.
                if (!nativeState || (getFeatureValue(featNum) >= 0 &&
                        spinner.getSelectedItemPosition() == position)) {
                    Preferences.changeFeatureInt(featName, featNum, position);
                }
                if (nativeState) refreshNativeSpinners();
                if (featNum == 13) refreshQueueControls();
                updateAutoplayVisibility();
                View selected = parentView.getChildAt(0);
                if (selected instanceof TextView) ((TextView) selected).setTextColor(EvIcons.GOLD);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        EvIcons.attachSpinner(this, linearLayout2, spinner);
        if (nativeState) {
            final LinearLayout card = linearLayout2;
            Runnable refresh = new Runnable() {
                @Override public void run() {
                    int value = getFeatureValue(featNum);
                    card.setVisibility(value < 0 ? View.GONE : View.VISIBLE);
                    int selection = Math.max(0, Math.min(lists.size() - 1, value));
                    if (spinner.getSelectedItemPosition() != selection) {
                        currentTrackedPos[0] = selection;
                        spinner.setSelection(selection);
                    }
                }
            };
            nativeSpinnerRefreshers.add(refresh);
            refresh.run();
        }
        return linearLayout2;
    }

    private View TextField(final int featNum, final String featName, final boolean numOnly, final int maxValue) {
        final EditTextString edittextstring = new EditTextString();
        final EditTextNum edittextnum = new EditTextNum();
        LinearLayout linearLayout = new LinearLayout(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT);
        layoutParams.setMargins(7, 5, 7, 5);

        final Button button = new Button(this);
        if (numOnly) {
            int num = Preferences.loadPrefInt(featName, featNum);
            edittextnum.setNum((num == 0) ? 1 : num);
            button.setText(Html.fromHtml(featName + ": <font color='" + NumberTxtColor + "'>" + ((num == 0) ? 1 : num) + "</font>"));
        } else {
            String string = Preferences.loadPrefString(featName, featNum);
            edittextstring.setString((string == "") ? "" : string);
            button.setText(Html.fromHtml(featName + ": <font color='" + NumberTxtColor + "'>" + string + "</font>"));
        }
        button.setAllCaps(false);
        button.setLayoutParams(layoutParams);
        button.setBackgroundColor(BTN_COLOR);
        button.setTextColor(TEXT_COLOR_2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final AlertDialog alert = new AlertDialog.Builder(getApplicationContext(), 2).create();
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                    Objects.requireNonNull(alert.getWindow()).setType(Build.VERSION.SDK_INT >= 26 ? 2038 : 2002);
                }
                alert.setOnCancelListener(new DialogInterface.OnCancelListener() {
                    public void onCancel(DialogInterface dialog) {
                        InputMethodManager imm = (InputMethodManager) getSystemService(getApplicationContext().INPUT_METHOD_SERVICE);
                        imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
                    }
                });

                //LinearLayout
                LinearLayout linearLayout1 = new LinearLayout(getApplicationContext());
                linearLayout1.setPadding(5, 5, 5, 5);
                linearLayout1.setOrientation(LinearLayout.VERTICAL);
                linearLayout1.setBackgroundColor(MENU_FEATURE_BG_COLOR);

                //TextView
                final TextView TextViewNote = new TextView(getApplicationContext());
                TextViewNote.setText("Tap OK to apply changes. Tap outside to cancel");
                if (maxValue != 0)
                TextViewNote.setText("Tap OK to apply changes. Tap outside to cancel\nMax value: " + maxValue);
                TextViewNote.setTextColor(TEXT_COLOR_2);

                //Edit text
                final EditText edittext = new EditText(getApplicationContext());
                edittext.setMaxLines(1);
                edittext.setWidth(convertDipToPixels(300));
                edittext.setTextColor(TEXT_COLOR_2);
                if (numOnly) {
                    edittext.setInputType(InputType.TYPE_CLASS_NUMBER);
                    edittext.setKeyListener(DigitsKeyListener.getInstance("0123456789-"));
                    InputFilter[] FilterArray = new InputFilter[1];
                    FilterArray[0] = new InputFilter.LengthFilter(10);
                    edittext.setFilters(FilterArray);
                } else {
                    edittext.setText(edittextstring.getString());
                }
                edittext.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                    @Override
                    public void onFocusChange(View v, boolean hasFocus) {
                        InputMethodManager imm = (InputMethodManager) getSystemService(getApplicationContext().INPUT_METHOD_SERVICE);
                        if (hasFocus) {
                            imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);
                        } else {
                            imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
                        }
                    }
                });
                edittext.requestFocus();

                //Button
                Button btndialog = new Button(getApplicationContext());
                btndialog.setBackgroundColor(BTN_COLOR);
                btndialog.setTextColor(TEXT_COLOR_2);
                btndialog.setText("OK");
                btndialog.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (numOnly) {
                            int num;
                            try {
                                num = Integer.parseInt(TextUtils.isEmpty(edittext.getText().toString()) ? "0" : edittext.getText().toString());
                                if (maxValue != 0 &&  num >= maxValue)
                                    num = maxValue;
                            } catch (NumberFormatException ex) {
                                num = 2147483640;
                            }
                            edittextnum.setNum(num);
                            button.setText(Html.fromHtml(featName + ": <font color='" + NumberTxtColor + "'>" + num + "</font>"));
                            alert.dismiss();
                            Preferences.changeFeatureInt(featName, featNum, num);
                        } else {
                            String str = edittext.getText().toString();
                            edittextstring.setString(edittext.getText().toString());
                            button.setText(Html.fromHtml(featName + ": <font color='" + NumberTxtColor + "'>" + str + "</font>"));
                            alert.dismiss();
                            Preferences.changeFeatureString(featName, featNum, str);
                        }
                        edittext.setFocusable(false);
                    }
                });

                linearLayout1.addView(TextViewNote);
                linearLayout1.addView(edittext);
                linearLayout1.addView(btndialog);
                alert.setView(linearLayout1);
                alert.show();
            }
        });

        linearLayout.addView(button);
        return linearLayout;
    }

    private View CheckBox(final int featNum, final String featName, boolean switchedOn) {
        final CheckBox checkBox = new CheckBox(this);
        checkBox.setText(featName);
        checkBox.setTextColor(TEXT_COLOR_2);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
            checkBox.setButtonTintList(ColorStateList.valueOf(CheckBoxColor));
        checkBox.setChecked(Preferences.loadPrefBool(featName, featNum, switchedOn));
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (checkBox.isChecked()) {
                    Preferences.changeFeatureBool(featName, featNum, isChecked);
                } else {
                    Preferences.changeFeatureBool(featName, featNum, isChecked);
                }
            }
        });
        return checkBox;
    }

    private View RadioButton(final int featNum, String featName, final String list) {
        //Credit: LoraZalora
        final List<String> lists = new LinkedList<>(Arrays.asList(list.split(",")));

        final TextView textView = new TextView(this);
        textView.setText(featName + ":");
        textView.setTextColor(TEXT_COLOR_2);

        final RadioGroup radioGroup = new RadioGroup(this);
        radioGroup.setPadding(10, 5, 10, 5);
        radioGroup.setOrientation(LinearLayout.VERTICAL);
        radioGroup.addView(textView);

        for (int i = 0; i < lists.size(); i++) {
            final RadioButton Radioo = new RadioButton(this);
            final String finalfeatName = featName, radioName = lists.get(i);
            View.OnClickListener first_radio_listener = new View.OnClickListener() {
                public void onClick(View v) {
                    textView.setText(Html.fromHtml(finalfeatName + ": <font color='" + NumberTxtColor + "'>" + radioName));
                    Preferences.changeFeatureInt(finalfeatName, featNum, radioGroup.indexOfChild(Radioo));
                }
            };
            System.out.println(lists.get(i));
            Radioo.setText(lists.get(i));
            Radioo.setTextColor(Color.LTGRAY);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
                Radioo.setButtonTintList(ColorStateList.valueOf(RadioColor));
            Radioo.setOnClickListener(first_radio_listener);
            radioGroup.addView(Radioo);
        }

        int index = Preferences.loadPrefInt(featName, featNum);
        if (index > 0) { //Preventing it to get an index less than 1. below 1 = null = crash
            textView.setText(Html.fromHtml(featName + ": <font color='" + NumberTxtColor + "'>" + lists.get(index - 1)));
            ((RadioButton) radioGroup.getChildAt(index)).setChecked(true);
        }

        return radioGroup;
    }

    private void Collapse(LinearLayout linLayout, final String text) {
        LinearLayout.LayoutParams layoutParamsLL = new LinearLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT);
        layoutParamsLL.setMargins(0, 5, 0, 0);

        LinearLayout collapse = new LinearLayout(this);
        collapse.setLayoutParams(layoutParamsLL);
        collapse.setVerticalGravity(16);
        collapse.setOrientation(LinearLayout.VERTICAL);

        final LinearLayout collapseSub = new LinearLayout(this);
        collapseSub.setVerticalGravity(16);
        collapseSub.setPadding(0, 5, 0, 5);
        collapseSub.setOrientation(LinearLayout.VERTICAL);
        collapseSub.setBackgroundColor(Color.parseColor("#222D38"));
        collapseSub.setVisibility(View.GONE);
        mCollapse = collapseSub;

        final TextView textView = new TextView(this);
        textView.setBackgroundColor(CategoryBG);
        textView.setText("▽ " + text + " ▽");
        textView.setGravity(Gravity.CENTER);
        textView.setTextColor(TEXT_COLOR_2);
        textView.setTypeface(null, Typeface.BOLD);
        textView.setPadding(0, 20, 0, 20);
        textView.setOnClickListener(new View.OnClickListener() {
            boolean isChecked;

            @Override
            public void onClick(View v) {

                boolean z = !this.isChecked;
                this.isChecked = z;
                if (z) {
                    collapseSub.setVisibility(View.VISIBLE);
                    textView.setText("△ " + text + " △");
                    return;
                }
                collapseSub.setVisibility(View.GONE);
                textView.setText("▽ " + text + " ▽");
            }
        });
        collapse.addView(textView);
        collapse.addView(collapseSub);
        linLayout.addView(collapse);
    }
    
    //Shake Animation
    ////////////////////////////////////////////////////////////////////////////////////
    int dur1 = 70 + (int)(Math.random() * 30);
    int dur2 = 70 + (int)(Math.random() * 30);
    Animation an = new RotateAnimation(-3, 3, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);

    Animation an2 = new TranslateAnimation(-TranslateAnimation.RELATIVE_TO_SELF,0.02f,
                                           TranslateAnimation.RELATIVE_TO_SELF,0.02f,
                                           -TranslateAnimation.RELATIVE_TO_SELF,0.02f,
                                           TranslateAnimation.RELATIVE_TO_SELF,0.02f);
    
    AnimationSet s = new AnimationSet(false);
    ////////////////////////////////////////////////////////////////////////////////////
    
     ScaleAnimation scale = new ScaleAnimation(0, 1, 0, 1, ScaleAnimation.RELATIVE_TO_SELF, .5f, ScaleAnimation.RELATIVE_TO_SELF, .5f);
   
    
    int secondaryColor;

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private void startAnimation() {
        // Stable contrast; no perpetual border animation while the game scans.
        if (mExpanded != null) mExpanded.setBackground(EvIcons.createMenuPanelBackground(this));
    }
     
    private View Text(String text) {
        TextView textView = new TextView(this);
        textView.setBackgroundColor(CategoryBG);
        textView.setText(Html.fromHtml(text));
        textView.setGravity(Gravity.CENTER);
        textView.setTextColor(TEXT_COLOR_2);
        textView.setTypeface(null, Typeface.BOLD);
        textView.setPadding(0, 5, 0, 5);
        
        scale.setInterpolator(new OvershootInterpolator());
        scale.setDuration(dur2);               
        scale.setRepeatCount(-1);               
        scale.setRepeatMode(Animation.REVERSE);
        textView.startAnimation(scale);
        return textView;
    }
    private View Rainbow(String text) {
        HwMods4 textView = new HwMods4(this);
        textView.setBackgroundColor(CategoryBG);
        textView.setText(Html.fromHtml(text));
        textView.setGravity(Gravity.CENTER);
        textView.setTextColor(TEXT_COLOR_2);
        textView.setTypeface(null, Typeface.BOLD);
        textView.setPadding(0, 5, 0, 5);

        return textView;
    }
    
    private View Category(String text) {
        TextView textView = new TextView(this);
        textView.setBackgroundColor(CategoryBG);
        textView.setText(Html.fromHtml(text));
        textView.setGravity(Gravity.CENTER);
        textView.setTextColor(Color.RED);
        textView.setTypeface(null, Typeface.BOLD);
        textView.setPadding(0, 5, 0, 5);
        
        return textView;
    }

    private View RichTextView(String text) {
        TextView textView = new TextView(this);
        textView.setText(Html.fromHtml(text));
        EvIcons.styleRichHint(this, textView);
        return textView;
    }

    private View RichWebView(String text) {
        WebView wView = new WebView(this);
        wView.loadData(text, "text/html", "utf-8");
        wView.setBackgroundColor(0x00000000); //Transparent
        wView.setPadding(0, 5, 0, 5);
        wView.getSettings().setAppCacheEnabled(false);
        return wView;
    }

    //Override our Start Command so the Service doesnt try to recreate itself when the App is closed
    public int onStartCommand(Intent intent, int i, int i2) {
        return Service.START_NOT_STICKY;
    }

    private boolean isViewCollapsed() {
        return rootFrame == null || mCollapsed.getVisibility() == View.VISIBLE;
    }

    //For our image a little converter
    private int convertDipToPixels(int i) {
        return (int) ((((float) i) * getResources().getDisplayMetrics().density) + 0.5f);
    }

    private int dp(int i) {
        return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }

    //Check if we are still in the game. If now our menu and menu button will dissapear
    private boolean isNotInGame() {
        RunningAppProcessInfo runningAppProcessInfo = new RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(runningAppProcessInfo);
        return runningAppProcessInfo.importance != 100;
    }

    //Destroy our View
    public void onDestroy() {
        authDestroyed = true;
        authUiEpoch.incrementAndGet();
        crmRenewalEnabled = false;
        if (crmRenewal != null) crmRenewal.shutdownNow();
        nativeSetFreeMode(false);
        super.onDestroy();
        instance = null;
        try {
            stopExpiryCountdown();
            if (rootFrame != null && mWindowManager != null) {
                mWindowManager.removeView(rootFrame);
            }
            if (isBrakeBtnAdded && instantBrakeFrame != null && mWindowManager != null) {
                mWindowManager.removeView(instantBrakeFrame);
                isBrakeBtnAdded = false;
            }
            if (autoplayWarningTimer != null) {
                try {
                    autoplayWarningTimer.cancel();
                } catch (Exception ignored) {}
                autoplayWarningTimer = null;
            }
            if (autoplayWarningDialog != null) {
                try {
                    autoplayWarningDialog.dismiss();
                } catch (Exception ignored) {}
                autoplayWarningDialog = null;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error in onDestroy: " + e.getMessage());
        }
    }

    //Same as above so it wont crash in the background and therefore use alot of Battery life
    public void onTaskRemoved(Intent intent) {
        super.onTaskRemoved(intent);
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        stopSelf();
    }

    private void Thread() {
        if (rootFrame == null) {
            return;
        }

        boolean inGame = !isNotInGame();
        onAppForegroundChanged(inGame);
    }

    private void onAppForegroundChanged(boolean inForeground) {
        appForeground = inForeground;
        if (!inForeground) {
            if (rootFrame != null && rootFrame.getVisibility() != View.INVISIBLE) {
                rootFrame.setVisibility(View.INVISIBLE);
            }
            if (instantBrakeFrame != null && instantBrakeFrame.getVisibility() != View.INVISIBLE) {
                instantBrakeFrame.setVisibility(View.INVISIBLE);
            }
            if (autoplayWarningDialog != null && autoplayWarningDialog.isShowing()) {
                try {
                    autoplayWarningDialog.hide();
                } catch (Exception ignored) {}
            }
        } else {
            if (rootFrame != null && rootFrame.getVisibility() != View.VISIBLE) {
                rootFrame.setVisibility(View.VISIBLE);
            }
            if (instantBrakeFrame != null && isBrakeBtnAdded && !isViewCollapsed() && instantBrakeFrame.getVisibility() != View.VISIBLE) {
                instantBrakeFrame.setVisibility(View.VISIBLE);
            }
            if (autoplayWarningDialog != null) {
                try {
                    autoplayWarningDialog.show();
                } catch (Exception ignored) {}
            }
        }
    }

    private class EditTextString {
        private String text;

        public void setString(String s) {
            text = s;
        }

        public String getString() {
            return text;
        }
    }
    private int convertDipToPixels(float f) {
        return (int) ((f * getResources().getDisplayMetrics().density) + 0.5f);
    }
    private class EditTextNum {
        private int val;

        public void setNum(int i) {
            val = i;
        }

        public int getNum() {
            return val;
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
