# Carrom Pool Mod Menu (Public Source)

**Created By @Memon_salim | @Memon_salim**

## Customization (`app/src/main/jni/name.h`)
Edit `app/src/main/jni/name.h` to customize:
- `MOD_LOGIN_ENABLED` (`true` = require panel key login, `false` = direct unlock without login screen)
- `MOD_NAME`, `MOD_SUBTITLE`, `MOD_CREDIT`, `MOD_LOADED_TOAST`
- `MOD_TELEGRAM_HANDLE`, `MOD_TELEGRAM_CHANNEL`, `MOD_BUY_KEY_URL`, `MOD_FREE_KEY_URL`
- `MOD_PANEL_URL`, `MOD_PANEL_GAME`, `MOD_PANEL_SALT`, `MOD_PANEL_PARAM_GAME`, `MOD_PANEL_PARAM_KEY`, `MOD_PANEL_PARAM_SERIAL`, `MOD_PANEL_EXTRA_PARAMS`
- `MOD_LOGO_BASE64` (PNG Base64 logo)

## Architecture
- `app/src/main/jni/prebuilt/arm64-v8a/libHwMods.so`: Prebuilt protected core library (do not rename `libHwMods.so`; filename is verified at runtime).
- `app/src/main/jni/`: Public `ImGui`, `curl`, `And64InlineHook`, `name.h`, `HwModsApi.h`, `Menu.h`, and `Main.cpp` building `libCrash.so`.

## Build
```bash
./gradlew assembleRelease
```
