plugins {
    id("com.android.application")
}

android {
    namespace = "com.carrommod.loader"
    compileSdk = 34
    // ndkVersion is intentionally not pinned: AGP uses its default NDK (r26 for AGP 8.5) and Android
    // Studio offers to install it. Pin one here only if you need a specific NDK.

    defaultConfig {
        applicationId = "com.carrommod.loader"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
        ndk {
            // Only arm64-v8a is supported today: GameBridge/Offsets.h assume AArch64 pointer
            // sizes and the user's target devices are arm64 (see Android.mk's comment).
            abiFilters += listOf("arm64-v8a")
        }
        externalNativeBuild {
            ndkBuild {
                // Same settings as Application.mk, given here too so the build does not depend on
                // how AGP locates Application.mk (it is still used by a plain ndk-build).
                cppFlags += listOf("-std=c++20", "-frtti", "-fexceptions")
                arguments += listOf("APP_STL=c++_static", "APP_PIE=true")
            }
        }
    }

    externalNativeBuild {
        ndkBuild {
            path = file("src/main/jni/Android.mk")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
        debug {
            // ndk-build's own debug/release switch (APP_OPTIM in Application.mk) is driven by
            // NDK_DEBUG, which AGP sets automatically for debug builds.
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    // This module is a build vehicle for libCarromMod.so + the loader class (see ../README.md
    // and ../loader/README.md for what to do with the output) — not an app meant to be launched
    // on its own, so it deliberately declares no launcher activity.
}

dependencies {
}
