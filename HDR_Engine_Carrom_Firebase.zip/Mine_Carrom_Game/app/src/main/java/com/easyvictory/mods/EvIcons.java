package com.easyvictory.mods;

import android.animation.ValueAnimator;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * Shared palette, PNG icon loader (from assets/ev_icons/), and authentic widget styling
 * matching the Easy Victory Carrom overlay across both Menu and CrmExternalMenu.
 */
final class EvIcons {

    static final int BG_DARK = 0xFF121212;
    static final int BG_DARK_2 = 0xFF1A1A1A;
    static final int SURFACE = 0xFF2A2A2A;
    static final int GOLD = 0xFF38BDF8;
    static final int GOLD_BRIGHT = 0xFF38BDF8;
    static final int BORDER_GOLD = 0xFF0EA5E9;
    static final int TEXT_WHITE = 0xFFFFFFFF;
    static final int TEXT_MUTED = 0xFFBDBDBD;
    static final int TEXT_SUBTLE = 0xFFBDBDBD;
    static final int TEXT_ON_GOLD = 0xFF101010;
    static final int SWITCH_OFF_THUMB = 0xFF4A4A4A;
    static final int ERROR_RED = 0xFFFF5252;

    private EvIcons() {
    }

    static int dp(Context context, int value) {
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, value, context.getResources().getDisplayMetrics());
    }

    static float dpF(Context context, float value) {
        return TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, value, context.getResources().getDisplayMetrics());
    }

    static GradientDrawable cardBackground(Context context, int fillColor, int strokeColor) {
        return cardBackground(context, fillColor, strokeColor, 10f, 1);
    }

    static GradientDrawable cardBackground(
            Context context, int fillColor, int strokeColor, float radiusDp, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fillColor);
        d.setCornerRadius(dp(context, Math.round(radiusDp)));
        if (strokeDp > 0) {
            d.setStroke(dp(context, strokeDp), strokeColor);
        }
        return d;
    }

    static GradientDrawable createMenuPanelBackground(Context ctx) {
        GradientDrawable drawable = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{BG_DARK, BG_DARK_2});
        drawable.setCornerRadius(dp(ctx, 28));
        drawable.setStroke(dp(ctx, 2), BORDER_GOLD);
        return drawable;
    }

    /**
     * Decodes a PNG asset from assets/ev_icons/<name>.png.
     * 128x128 row/tab icon sheets are decoded at XXHIGH density (480 dpi -> 42.67dp intrinsic)
     * so they match drawable-xxhdpi scaling identically across all screen densities.
     */
    static Drawable evIconRaw(Context ctx, String name) {
        if (ctx == null || name == null || name.isEmpty()) return null;
        try {
            Resources res = ctx.getResources();
            int resId = res.getIdentifier(name, "drawable", ctx.getPackageName());
            if (resId != 0) {
                Drawable d = res.getDrawable(resId);
                if (d != null) return d.mutate();
            }
        } catch (Throwable ignored) { }

        String[] paths = new String[]{"ev_icons/" + name + ".png", name + ".png"};
        for (String path : paths) {
            try (InputStream is = ctx.getAssets().open(path)) {
                DisplayMetrics dm = ctx.getResources().getDisplayMetrics();
                BitmapFactory.Options opts = new BitmapFactory.Options();
                if (!"ev_icon_ev".equals(name)
                        && !"ev_icon_minus".equals(name)
                        && !name.startsWith("ev_play_")) {
                    opts.inDensity = DisplayMetrics.DENSITY_XXHIGH;
                    opts.inTargetDensity = dm.densityDpi;
                    opts.inScaled = true;
                }
                Bitmap bmp = BitmapFactory.decodeStream(is, null, opts);
                if (bmp != null) {
                    BitmapDrawable bd = new BitmapDrawable(ctx.getResources(), bmp);
                    return bd;
                }
            } catch (Throwable ignored) { }
        }
        return null;
    }

    static Drawable evIcon(Context ctx, String name, int tint) {
        Drawable d = evIconRaw(ctx, name);
        if (d != null && tint != 0) {
            d = d.mutate();
            d.setColorFilter(tint, PorterDuff.Mode.SRC_IN);
        }
        return d;
    }

    static String rowIconName(String featName) {
        if (featName == null) return "ev_icon_gear";
        String low = featName.toLowerCase(Locale.US);
        if (low.contains("auto") && low.contains("queue")) return "ev_icon_layers";
        if (low.contains("colour") || low.contains("color")) return "ev_icon_palette";
        if (low.contains("aim") || low.contains("crosshair")) return "ev_icon_crosshair";
        if (low.contains("autoplay") || low.contains("auto play")) return "ev_icon_play";
        if (low.contains("clean")) return "ev_icon_coins";
        if (low.contains("scanner") || low.contains("depth")) return "ev_icon_search";
        if (low.contains("force") || low.contains("power")) return "ev_icon_bolt";
        if (low.contains("cushion")) return "ev_icon_gear";
        if (low.contains("prediction")) return "ev_icon_dots";
        if (low.contains("pocket") || low.contains("highlight")) return "ev_icon_target";
        if (low.contains("freeze") || low.contains("line")) return "ev_icon_percent";
        if (low.contains("price") || low.contains("table")) return "ev_icon_coins";
        if (low.contains("game") || low.contains("mode")) return "ev_icon_gamepad";
        return "ev_icon_gear";
    }

    static String tabIconName(String title) {
        if (title == null) return "ev_icon_grid";
        String low = title.toLowerCase(Locale.US);
        if (low.contains("visual") || low.contains("vision")) return "ev_icon_eye";
        if (low.contains("play")) return "ev_icon_gamepad";
        if (low.contains("queue")) return "ev_icon_queue";
        return "ev_icon_grid";
    }

    static void applyRowIcon(Context ctx, TextView view, String featName) {
        Drawable d = evIcon(ctx, rowIconName(featName), GOLD);
        if (d != null) {
            view.setCompoundDrawablesWithIntrinsicBounds(d, null, null, null);
            view.setCompoundDrawablePadding(dp(ctx, 10));
        }
    }

    static LinearLayout createHeader(Context ctx, String iconB64, ImageView[] outLogo, TextView[] outExpiry) {
        return createHeader(ctx, iconB64, "EASY VICTORY", outLogo, outExpiry);
    }

    static LinearLayout createHeader(Context ctx, String iconB64, String modTitle, ImageView[] outLogo, TextView[] outExpiry) {
        final String displayTitle = (modTitle != null && !modTitle.trim().isEmpty()) ? modTitle.trim() : "EASY VICTORY";
        LinearLayout headerWrap = new LinearLayout(ctx);
        headerWrap.setOrientation(LinearLayout.VERTICAL);

        RelativeLayout titleBar = new RelativeLayout(ctx);
        titleBar.setPadding(dp(ctx, 16), dp(ctx, 8), dp(ctx, 12), dp(ctx, 8));
        titleBar.setVerticalGravity(Gravity.CENTER_VERTICAL);

        LinearLayout centerGroup = new LinearLayout(ctx);
        centerGroup.setOrientation(LinearLayout.VERTICAL);
        centerGroup.setGravity(Gravity.CENTER);
        RelativeLayout.LayoutParams centerLp = new RelativeLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        centerLp.addRule(RelativeLayout.CENTER_IN_PARENT);
        centerGroup.setLayoutParams(centerLp);

        ImageView logo = new ImageView(ctx);
        boolean logoSet = false;
        if (iconB64 != null && !iconB64.isEmpty()) {
            try {
                byte[] decoded = Base64.decode(iconB64, Base64.DEFAULT);
                Bitmap bmp = BitmapFactory.decodeByteArray(decoded, 0, decoded.length);
                if (bmp != null) {
                    logo.setImageBitmap(bmp);
                    logoSet = true;
                }
            } catch (Exception ignored) { }
        }
        if (!logoSet) {
            Drawable evDrawable = evIcon(ctx, "ev_icon_ev", 0);
            if (evDrawable != null) {
                logo.setImageDrawable(evDrawable);
            }
        }
        logo.setAdjustViewBounds(true);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        logo.setContentDescription(displayTitle + " logo. Drag to move.");
        LinearLayout.LayoutParams logoLp = new LinearLayout.LayoutParams(dp(ctx, 82), dp(ctx, 82));
        logoLp.gravity = Gravity.CENTER_HORIZONTAL;
        centerGroup.addView(logo, logoLp);
        if (outLogo != null && outLogo.length > 0) outLogo[0] = logo;

        TextView brand = new TextView(ctx);
        brand.setText(displayTitle);
        brand.setTextColor(GOLD);
        brand.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20.0f);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        brand.setGravity(Gravity.CENTER);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            brand.setLetterSpacing(0.06f);
        }
        LinearLayout.LayoutParams brandLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        centerGroup.addView(brand, brandLp);

        titleBar.addView(centerGroup);
        headerWrap.addView(titleBar);

        TextView expiry = new TextView(ctx);
        expiry.setText("Expiry");
        expiry.setTextColor(GOLD);
        expiry.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.0f);
        expiry.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        expiry.setGravity(Gravity.CENTER);
        expiry.setPadding(0, dp(ctx, 6), 0, dp(ctx, 2));
        expiry.setShadowLayer(4.0f, 0, 0, GOLD);
        expiry.setVisibility(View.GONE);
        headerWrap.addView(expiry);
        if (outExpiry != null && outExpiry.length > 0) outExpiry[0] = expiry;

        return headerWrap;
    }

    static FrameLayout createMinimizeFooter(
            Context ctx, View.OnClickListener onMinimize, View.OnLongClickListener onHide) {
        FrameLayout footer = new FrameLayout(ctx);
        footer.setPadding(10, 3, 10, dp(ctx, 6));

        FrameLayout.LayoutParams btnLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.END | Gravity.CENTER_VERTICAL);

        Button minBtn = new Button(ctx);
        minBtn.setLayoutParams(btnLp);
        minBtn.setBackground(null);
        minBtn.setText("");
        minBtn.setAllCaps(false);
        minBtn.setMinWidth(0);
        minBtn.setMinimumWidth(0);
        minBtn.setPadding(0, 0, 0, 0);
        Drawable minus = evIcon(ctx, "ev_icon_minus", 0);
        if (minus != null) {
            minus.setBounds(0, 0, dp(ctx, 34), dp(ctx, 34));
            minBtn.setCompoundDrawables(null, minus, null, null);
        }
        minBtn.setMinHeight(dp(ctx, 40));
        minBtn.setContentDescription("Minimize menu. Hold to hide icon.");
        if (onMinimize != null) minBtn.setOnClickListener(onMinimize);
        if (onHide != null) minBtn.setOnLongClickListener(onHide);

        footer.addView(minBtn);
        return footer;
    }

    static void applyQueueButtonStyle(Context context, Button button, boolean autoplayActive) {
        if (button == null || context == null) return;
        Drawable bg = evIcon(context, autoplayActive ? "ev_play_on" : "ev_play_off", 0);
        if (bg != null) {
            button.setBackground(bg);
        }
        button.setContentDescription(autoplayActive ? "Stop Auto Play" : "Auto Play");
    }

    static Button createTabButton(Context ctx, String title, boolean selected) {
        Button tab = new Button(ctx);
        tab.setText(title);
        tab.setContentDescription(title + " features");
        tab.setTextSize(11.0f);
        tab.setAllCaps(false);
        tab.setMinWidth(0);
        tab.setMinimumWidth(0);
        tab.setPadding(dp(ctx, 3), 0, dp(ctx, 3), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(ctx, 40), 1.0f);
        lp.setMargins(dp(ctx, 3), 0, dp(ctx, 3), 0);
        tab.setLayoutParams(lp);
        tab.setTag(tabIconName(title));
        styleTabButton(ctx, tab, selected);
        return tab;
    }

    static void styleTabButton(Context ctx, Button tab, boolean selected) {
        if (tab == null) return;
        tab.setTextColor(selected ? TEXT_ON_GOLD : GOLD);
        tab.setTypeface(Typeface.DEFAULT, selected ? Typeface.BOLD : Typeface.NORMAL);
        tab.setBackground(selected
                ? cardBackground(ctx, GOLD, GOLD, 12f, 1)
                : cardBackground(ctx, SURFACE, BORDER_GOLD, 12f, 1));
        Object tag = tab.getTag();
        if (tag instanceof String) {
            Drawable icon = evIcon(ctx, (String) tag, selected ? TEXT_ON_GOLD : GOLD);
            if (icon != null) {
                tab.setCompoundDrawablesWithIntrinsicBounds(null, icon, null, null);
                tab.setCompoundDrawablePadding(dp(ctx, 4));
            }
        }
        tab.setSelected(selected);
    }

    static void styleFeatureCard(Context ctx, View card, int minHeightDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(ctx, 4), 0, dp(ctx, 4));
        card.setLayoutParams(lp);
        card.setPadding(dp(ctx, 8), dp(ctx, 6), dp(ctx, 8), dp(ctx, 6));
        card.setBackground(cardBackground(ctx, SURFACE, BORDER_GOLD, 10f, 1));
        card.setMinimumHeight(dp(ctx, minHeightDp > 0 ? minHeightDp : 52));
    }

    static void styleSwitchCard(Context ctx, Switch toggle, String featName) {
        styleFeatureCard(ctx, toggle, 52);
        toggle.setTextSize(12.0f);
        toggle.setMinHeight(dp(ctx, 34));
        toggle.setSwitchPadding(dp(ctx, 12));
        toggle.setContentDescription(featName);
        applyRowIcon(ctx, toggle, featName);

        ColorStateList switchColors = new ColorStateList(
                new int[][]{
                        new int[]{-android.R.attr.state_enabled},
                        new int[]{android.R.attr.state_checked},
                        new int[]{}
                },
                new int[]{SWITCH_OFF_THUMB, GOLD, SWITCH_OFF_THUMB});
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            if (toggle.getThumbDrawable() != null) toggle.getThumbDrawable().setTintList(switchColors);
            if (toggle.getTrackDrawable() != null) toggle.getTrackDrawable().setTintList(switchColors);
        }
        toggle.setText(featName);
        toggle.setTextColor(GOLD);
    }

    static void styleStatusCard(Context ctx, TextView status) {
        status.setTextColor(TEXT_MUTED);
        status.setTextSize(12.0f);
        status.setPadding(dp(ctx, 12), dp(ctx, 12), dp(ctx, 12), dp(ctx, 12));
        status.setBackground(cardBackground(ctx, SURFACE, BORDER_GOLD, 10f, 1));
    }

    static void styleRichHint(Context ctx, TextView label) {
        label.setTextColor(TEXT_MUTED);
        label.setTextSize(12.0f);
        label.setPadding(dp(ctx, 8), dp(ctx, 8), dp(ctx, 8), dp(ctx, 12));
    }

    static Button createChoiceButton(Context ctx) {
        Button button = new Button(ctx);
        button.setAllCaps(false);
        button.setTextSize(11.0f);
        button.setTypeface(Typeface.DEFAULT_BOLD);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setPadding(dp(ctx, 3), dp(ctx, 3), dp(ctx, 3), dp(ctx, 3));
        button.setMinHeight(dp(ctx, 28));
        button.setMinimumHeight(dp(ctx, 28));
        return button;
    }

    static LinearLayout.LayoutParams createChoiceButtonParams(Context ctx) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(ctx, 28), 1.0f);
        lp.setMargins(dp(ctx, 2), dp(ctx, 2), dp(ctx, 2), dp(ctx, 2));
        return lp;
    }

    static void styleChoiceButton(Context ctx, Button button, boolean active, int customAccent,
                                  String itemText, String accessiblePrefix) {
        int accent = customAccent != 0 ? customAccent : GOLD;
        int border = customAccent != 0 ? customAccent : BORDER_GOLD;
        int unselectedText = customAccent != 0 ? customAccent : GOLD;
        button.setSelected(active);
        button.setText((active ? "\u2713  " : "") + itemText);
        button.setTextColor(active ? BG_DARK : unselectedText);
        button.setBackground(cardBackground(ctx, active ? accent : BG_DARK, active ? accent : border, 10f, 1));
        button.setContentDescription(accessiblePrefix + ": " + itemText + (active ? ", selected" : ", not selected"));
    }

    static ArrayAdapter<String> createSpinnerAdapter(final Context ctx, final List<String> items) {
        return new ArrayAdapter<String>(ctx, android.R.layout.simple_spinner_item, items) {
            private View buildRow(int position, boolean dropdown) {
                TextView text = new TextView(ctx);
                text.setText(getItem(position));
                text.setTextColor(GOLD);
                text.setTextSize(12.0f);
                text.setGravity(Gravity.CENTER_VERTICAL);
                text.setMinHeight(dp(ctx, 30));
                text.setPadding(dp(ctx, 4), dp(ctx, 8), dp(ctx, 12), dp(ctx, 8));
                if (dropdown) {
                    text.setBackgroundColor(SURFACE);
                }
                return text;
            }

            @Override public View getView(int p, View v, ViewGroup parent) { return buildRow(p, false); }
            @Override public View getDropDownView(int p, View v, ViewGroup parent) { return buildRow(p, true); }
        };
    }

    static void attachSpinner(Context ctx, LinearLayout card, Spinner spinner) {
        spinner.setMinimumHeight(dp(ctx, 30));
        spinner.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        if (spinner.getBackground() != null) {
            spinner.getBackground().setColorFilter(TEXT_MUTED, PorterDuff.Mode.SRC_ATOP);
        }
        spinner.setPopupBackgroundDrawable(cardBackground(ctx, SURFACE, BORDER_GOLD, 10f, 1));
        card.addView(spinner);
    }

    static void styleSeekBar(Context context, SeekBar seekBar) {
        if (seekBar == null) return;
        seekBar.setMinimumHeight(dp(context, 34));
        int p = dp(context, 8);
        seekBar.setPadding(p, p, p, p);
        if (seekBar.getThumb() != null) {
            seekBar.getThumb().setColorFilter(GOLD, PorterDuff.Mode.SRC_ATOP);
        }
        if (seekBar.getProgressDrawable() != null) {
            seekBar.getProgressDrawable().setColorFilter(GOLD, PorterDuff.Mode.SRC_ATOP);
        }
    }

    static String formatSeekBarLabel(String featName, int value, int defaultVal) {
        String formatted;
        String suffix = "";
        if (featName.contains("Speed Scale")) {
            formatted = String.format(Locale.US, "%.1fx", value / 10.0f);
        } else if (featName.contains("Float Brake Button Size")) {
            formatted = String.valueOf(value);
            suffix = " dp";
        } else if (featName.contains("Camera FOV")) {
            formatted = String.valueOf(value);
            suffix = "\u00B0";
        } else if (featName.contains("Table Position") || featName.contains("Table Left-Right")
                || featName.contains("Table Up-Down") || featName.contains("Table Vertical Position")) {
            int offset = (int) ((value - 50) * 2.5f);
            formatted = offset > 0 ? "+" + offset : String.valueOf(offset);
            suffix = " px";
        } else if (featName.contains("Table Size") || featName.contains("Bada - Chota")
                || featName.contains("Table Scale Zoom") || featName.contains("Table Width Stretch")) {
            formatted = String.valueOf(value);
            suffix = "%";
        } else if (featName.contains("Goti Circle Size")) {
            formatted = String.valueOf(value);
            suffix = " px";
        } else if (featName.contains("Speed Limit")) {
            formatted = String.valueOf(value);
        } else {
            formatted = String.valueOf(value);
        }
        return featName + ": " + formatted + suffix + (value == defaultVal ? " (Default)" : "");
    }

    static void applyButtonTouchEffect(View view) {
        if (view == null) return;
        view.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start();
            } else if (event.getAction() == MotionEvent.ACTION_UP || event.getAction() == MotionEvent.ACTION_CANCEL) {
                v.animate().scaleX(1.0f).scaleY(1.0f).setDuration(160)
                        .setInterpolator(new OvershootInterpolator(2.2f)).start();
            }
            return false;
        });
    }

    static void openExternalUrl(Context ctx, String url) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(ctx, "Cannot open link", Toast.LENGTH_SHORT).show();
        }
    }

    static Button createLoginActionButton(Context ctx, String text, boolean filledGold) {
        Button btn = new Button(ctx);
        btn.setText(text);
        btn.setAllCaps(false);
        btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, filledGold ? 11.5f : (text.equals("PASTE") ? 11.0f : 10.5f));
        btn.setTypeface(Typeface.DEFAULT_BOLD);
        btn.setTextColor(filledGold ? TEXT_WHITE : GOLD);
        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(dp(ctx, 6));
        bg.setColor(filledGold ? GOLD : SURFACE);
        bg.setStroke(dp(ctx, 2), GOLD);
        btn.setBackground(bg);
        applyButtonTouchEffect(btn);
        return btn;
    }

    // Login screen links (set by owner). Not taken from the native getters on purpose.
    static final String LINK_YOUTUBE = "https://youtube.com/@narutopp-b8n?si=mEA_fGkvCEhdZ8Xg";
    static final String LINK_ADMIN = "https://resnet-or5cdtts.manus.space/";
    static final String LINK_TELEGRAM = "https://t.me/HDRENGINE";
    static final String LINK_COMPLAIN_BOX = "https://hdrbox-erxpk9cg.manus.space/";

    static LinearLayout createLoginContainer(
            Context ctx,
            String initialStatus,
            EditText[] outKeyInput,
            Button[] outPasteBtn,
            Button[] outLoginBtn,
            TextView[] outStatus) {
        return createLoginContainer(
                ctx,
                initialStatus,
                "SERVER ONLINE  \u2022  CARROM POOL",
                "CAME BACK",
                "CARROM POOL MOD MENU",
                LINK_YOUTUBE,
                LINK_ADMIN,
                LINK_TELEGRAM,
                outKeyInput,
                outPasteBtn,
                outLoginBtn,
                outStatus);
    }

    static LinearLayout createLoginContainer(
            Context ctx,
            String initialStatus,
            String badgeText,
            String loginTitleText,
            String loginBannerText,
            String buyKeyUrl,
            String freeKeyUrl,
            String telegramUrl,
            EditText[] outKeyInput,
            Button[] outPasteBtn,
            Button[] outLoginBtn,
            TextView[] outStatus) {
        final String safeBadge = (badgeText != null && !badgeText.trim().isEmpty()) ? badgeText : "SERVER ONLINE  \u2022  CARROM POOL";
        final String safeTitle = (loginTitleText != null && !loginTitleText.trim().isEmpty()) ? loginTitleText : "CAME BACK";
        final String safeBanner = (loginBannerText != null && !loginBannerText.trim().isEmpty()) ? loginBannerText : "CARROM POOL MOD MENU";
        final String safeBuyUrl = LINK_YOUTUBE;
        final String safeFreeUrl = LINK_ADMIN;
        final String safeTgUrl = LINK_TELEGRAM;
        final String safeComplainUrl = LINK_COMPLAIN_BOX;
        LinearLayout card = new LinearLayout(ctx);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(ctx, 10), dp(ctx, 8), dp(ctx, 10), dp(ctx, 8));

        final GradientDrawable cardBg = new GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{BG_DARK, BG_DARK_2});
        cardBg.setShape(GradientDrawable.RECTANGLE);
        cardBg.setCornerRadius(dp(ctx, 28));
        final int strokeW = dp(ctx, 2);
        cardBg.setStroke(strokeW, BORDER_GOLD);
        card.setBackground(cardBg);

        final ValueAnimator borderAnim = ValueAnimator.ofArgb(
                0x3338BDF8, 0x8838BDF8, 0x8838BDF8, 0x3338BDF8);
        borderAnim.setDuration(3500);
        borderAnim.setRepeatCount(ValueAnimator.INFINITE);
        borderAnim.addUpdateListener(anim -> cardBg.setStroke(strokeW, (int) anim.getAnimatedValue()));

        final TextView serverPill = new TextView(ctx);
        serverPill.setText(safeBadge);
        serverPill.setTextColor(GOLD);
        serverPill.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.0f);
        serverPill.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            serverPill.setLetterSpacing(0.06f);
        }
        serverPill.setGravity(Gravity.CENTER);
        serverPill.setPadding(dp(ctx, 8), dp(ctx, 2), dp(ctx, 8), dp(ctx, 2));
        GradientDrawable pillBg = new GradientDrawable();
        pillBg.setCornerRadius(dp(ctx, 8));
        pillBg.setColor(0x1A38BDF8);
        pillBg.setStroke(dp(ctx, 2), 0x3338BDF8);
        serverPill.setBackground(pillBg);
        LinearLayout.LayoutParams pillLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pillLp.gravity = Gravity.CENTER_HORIZONTAL;
        pillLp.bottomMargin = dp(ctx, 4);
        serverPill.setLayoutParams(pillLp);
        card.addView(serverPill);

        final ValueAnimator pulseAnim = ValueAnimator.ofFloat(1.0f, 0.55f, 1.0f);
        pulseAnim.setDuration(2200);
        pulseAnim.setRepeatCount(ValueAnimator.INFINITE);
        pulseAnim.addUpdateListener(anim -> serverPill.setAlpha((float) anim.getAnimatedValue()));

        final TextView authHeader = new TextView(ctx);
        authHeader.setText(safeTitle);
        authHeader.setTextColor(GOLD);
        authHeader.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f);
        authHeader.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            authHeader.setLetterSpacing(0.1f);
        }
        authHeader.setGravity(Gravity.CENTER);
        authHeader.setPadding(0, 0, 0, dp(ctx, 2));
        card.addView(authHeader);

        final ValueAnimator glowAnim = ValueAnimator.ofArgb(GOLD, 0xFFBAE6FD, GOLD);
        glowAnim.setDuration(3000);
        glowAnim.setRepeatCount(ValueAnimator.INFINITE);
        glowAnim.addUpdateListener(anim -> {
            int col = (int) anim.getAnimatedValue();
            authHeader.setTextColor(col);
            authHeader.setShadowLayer(8.0f, 0, 0, col);
        });

        card.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override
            public void onViewAttachedToWindow(View v) {
                borderAnim.start();
                pulseAnim.start();
                glowAnim.start();
            }

            @Override
            public void onViewDetachedFromWindow(View v) {
                borderAnim.cancel();
                pulseAnim.cancel();
                glowAnim.cancel();
            }
        });
        borderAnim.start();
        pulseAnim.start();
        glowAnim.start();

        TextView subTitle = new TextView(ctx);
        subTitle.setText(safeBanner);
        subTitle.setTextColor(GOLD);
        subTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        subTitle.setTypeface(Typeface.DEFAULT_BOLD);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            subTitle.setLetterSpacing(0.06f);
        }
        subTitle.setGravity(Gravity.CENTER);
        subTitle.setPadding(0, 0, 0, dp(ctx, 6));
        card.addView(subTitle);

        EditText keyInput = new EditText(ctx);
        keyInput.setHint("Enter License Key...");
        keyInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
        keyInput.setFilters(new InputFilter[]{new InputFilter.LengthFilter(64)});
        keyInput.setHintTextColor(TEXT_MUTED);
        keyInput.setTextColor(TEXT_WHITE);
        keyInput.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11.5f);
        keyInput.setSingleLine(true);
        keyInput.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        keyInput.setPadding(dp(ctx, 12), dp(ctx, 8), dp(ctx, 12), dp(ctx, 8));
        final GradientDrawable inputBg = new GradientDrawable();
        inputBg.setShape(GradientDrawable.RECTANGLE);
        inputBg.setCornerRadius(dp(ctx, 8));
        inputBg.setColor(SURFACE);
        inputBg.setStroke(strokeW, BORDER_GOLD);
        keyInput.setBackground(inputBg);
        keyInput.setOnFocusChangeListener((v, hasFocus) ->
                inputBg.setStroke(strokeW, hasFocus ? GOLD : BORDER_GOLD));
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        inputLp.bottomMargin = dp(ctx, 8);
        keyInput.setLayoutParams(inputLp);
        card.addView(keyInput);
        if (outKeyInput != null && outKeyInput.length > 0) outKeyInput[0] = keyInput;

        LinearLayout btnRow = new LinearLayout(ctx);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setGravity(Gravity.CENTER);

        Button pasteBtn = createLoginActionButton(ctx, "PASTE", false);
        LinearLayout.LayoutParams pasteLp = new LinearLayout.LayoutParams(0, dp(ctx, 34), 1.0f);
        pasteLp.rightMargin = dp(ctx, 4);
        pasteBtn.setLayoutParams(pasteLp);
        pasteBtn.setOnClickListener(v -> {
            try {
                ClipboardManager clipboard = (ClipboardManager) ctx.getSystemService(Context.CLIPBOARD_SERVICE);
                if (clipboard != null && clipboard.hasPrimaryClip() && clipboard.getPrimaryClip().getItemCount() > 0) {
                    CharSequence pasteData = clipboard.getPrimaryClip().getItemAt(0).getText();
                    if (pasteData != null) {
                        keyInput.setText(pasteData.toString().trim());
                        Toast.makeText(ctx, "Key pasted from clipboard", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(ctx, "Clipboard is empty", Toast.LENGTH_SHORT).show();
                }
            } catch (Exception e) {
                Toast.makeText(ctx, "Could not access clipboard", Toast.LENGTH_SHORT).show();
            }
        });
        btnRow.addView(pasteBtn);
        if (outPasteBtn != null && outPasteBtn.length > 0) outPasteBtn[0] = pasteBtn;

        Button loginBtn = createLoginActionButton(ctx, "LOGIN", true);
        LinearLayout.LayoutParams loginLp = new LinearLayout.LayoutParams(0, dp(ctx, 34), 1.0f);
        loginLp.leftMargin = dp(ctx, 4);
        loginBtn.setLayoutParams(loginLp);
        btnRow.addView(loginBtn);
        if (outLoginBtn != null && outLoginBtn.length > 0) outLoginBtn[0] = loginBtn;
        card.addView(btnRow);

        Button buyBtn = createLoginActionButton(ctx, "YOUTUBE CHANNEL", false);
        LinearLayout.LayoutParams buyLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 32));
        buyLp.topMargin = dp(ctx, 6);
        buyBtn.setLayoutParams(buyLp);
        buyBtn.setOnClickListener(v -> openExternalUrl(ctx, safeBuyUrl));
        card.addView(buyBtn);

        Button freeBtn = createLoginActionButton(ctx, "ADMIN", false);
        LinearLayout.LayoutParams freeLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 32));
        freeLp.topMargin = dp(ctx, 4);
        freeBtn.setLayoutParams(freeLp);
        freeBtn.setOnClickListener(v -> openExternalUrl(ctx, safeFreeUrl));
        card.addView(freeBtn);

        Button tgBtn = createLoginActionButton(ctx, "JOIN TELEGRAM", false);
        LinearLayout.LayoutParams tgLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 32));
        tgLp.topMargin = dp(ctx, 4);
        tgBtn.setLayoutParams(tgLp);
        tgBtn.setOnClickListener(v -> openExternalUrl(ctx, safeTgUrl));
        card.addView(tgBtn);

        Button complainBtn = createLoginActionButton(ctx, "HDR COMPLAIN BOX", false);
        LinearLayout.LayoutParams complainLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(ctx, 32));
        complainLp.topMargin = dp(ctx, 4);
        complainBtn.setLayoutParams(complainLp);
        complainBtn.setOnClickListener(v -> openExternalUrl(ctx, safeComplainUrl));
        card.addView(complainBtn);

        TextView status = new TextView(ctx);
        status.setText(initialStatus);
        status.setTextColor(TEXT_MUTED);
        status.setTextSize(TypedValue.COMPLEX_UNIT_SP, 9.5f);
        status.setTypeface(Typeface.MONOSPACE);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(ctx, 4), 0, 0);
        if (outStatus != null && outStatus.length > 0) outStatus[0] = status;
        card.addView(status);

        // Credit line (@GoToHellxD | @HwMods)
        TextView creditLine = new TextView(ctx);
        creditLine.setText("Created By @GoToHellxD  \u2022  @HwMods");
        creditLine.setTextColor(0x9938BDF8);
        creditLine.setTextSize(TypedValue.COMPLEX_UNIT_SP, 8.5f);
        creditLine.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        creditLine.setGravity(Gravity.CENTER);
        creditLine.setPadding(0, dp(ctx, 4), 0, dp(ctx, 2));
        card.addView(creditLine);

        return card;
    }

    static String formatExpiryLabel(String rawExp, boolean[] outExpired) {
        if (outExpired != null && outExpired.length > 0) outExpired[0] = false;
        if (rawExp == null || rawExp.trim().isEmpty()) {
            return "Expiry Active";
        }
        String trimmed = rawExp.trim();
        if (trimmed.equalsIgnoreCase("Lifetime")) {
            return "Expiry Lifetime";
        }
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US);
            Date target = sdf.parse(trimmed);
            if (target != null) {
                long diff = target.getTime() - System.currentTimeMillis();
                if (diff <= 0) {
                    if (outExpired != null && outExpired.length > 0) outExpired[0] = true;
                    return "Expiry Expired";
                }
                long sec = (diff / 1000) % 60;
                long min = (diff / (1000 * 60)) % 60;
                long hrs = (diff / (1000 * 60 * 60)) % 24;
                long days = diff / (1000 * 60 * 60 * 24);
                if (days > 0) {
                    return String.format(Locale.US, "Expiry %dd %02dh %02dm %02ds", days, hrs, min, sec);
                }
                return String.format(Locale.US, "Expiry %02dh %02dm %02ds", hrs, min, sec);
            }
        } catch (Exception ignored) { }
        return "Expiry " + trimmed;
    }
}
