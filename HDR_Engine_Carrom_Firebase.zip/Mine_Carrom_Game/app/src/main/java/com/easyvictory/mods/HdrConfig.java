package com.easyvictory.mods;

/**
 * Firebase Realtime Database settings for the HDR Engine key login.
 * FIREBASE_DB_URL is intentionally empty: it must be filled with the real
 * database URL before login can succeed (an empty value makes login fail with
 * a clear message instead of guessing).
 */
final class HdrConfig {
    private HdrConfig() {}

    // Example shape: "https://<project-id>-default-rtdb.firebaseio.com"  (no trailing slash)
    static final String FIREBASE_DB_URL = "";

    // Layout assumed by HdrAuth: /<KEYS_NODE>/<licenseKey> = { active, expiry, device }
    static final String KEYS_NODE = "keys";
    static final String FIELD_ACTIVE = "active";   // boolean, must be true
    static final String FIELD_EXPIRY = "expiry";   // number: epoch seconds (UTC), or the string "Lifetime"
    static final String FIELD_DEVICE = "device";   // string: device id, written on first login

    // true: first login writes the device id, later logins must come from the same device.
    static final boolean BIND_DEVICE = true;

    // Consecutive network failures tolerated by the background re-check before the session is closed.
    static final int MAX_TRANSIENT_FAILURES = 3;
}
