package com.easyvictory.mods;

import android.content.Context;
import android.provider.Settings;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Pattern;
import javax.net.ssl.HttpsURLConnection;
import org.json.JSONObject;

/**
 * License key check against a Firebase Realtime Database over its REST API.
 * Blocking: call from a background thread only. All results are plain strings
 * "OK|<expiry text>" or "ERR|<reason>" so the existing login UI can use them as-is.
 *
 * This is a client-side check. It decides what the UI and the native core are
 * allowed to unlock in this process; it cannot stop someone who patches the APK.
 */
final class HdrAuth {
    private HdrAuth() {}

    private static final Pattern KEY_PATTERN = Pattern.compile("^[^.$#\\[\\]/\\\\\\s\\x00-\\x1f]{4,64}$");
    private static final int MAX_RESPONSE = 16384;
    private static final int TIMEOUT_MS = 8000;

    private static volatile boolean authenticated = false;
    private static volatile String expiryText = "";
    private static volatile String sessionKey = "";
    private static volatile int transientFailures = 0;

    static boolean isAuthenticated() { return authenticated; }
    static String expiryText() { return expiryText; }

    static void reset() {
        authenticated = false;
        expiryText = "";
        sessionKey = "";
        transientFailures = 0;
    }

    /** Full login with the key the user typed. */
    static String verify(Context context, String key) {
        reset();
        Result r = check(context, key == null ? "" : key.trim());
        if (r.ok) {
            authenticated = true;
            expiryText = r.expiry;
            sessionKey = key.trim();
            return "OK|" + r.expiry;
        }
        return "ERR|" + r.reason;
    }

    /** Periodic re-check of the key used for the current session. */
    static String recheck(Context context) {
        final String key = sessionKey;
        if (!authenticated || key.isEmpty()) return "ERR|No active session";
        Result r = check(context, key);
        if (r.ok) {
            transientFailures = 0;
            expiryText = r.expiry;
            return "OK|" + r.expiry;
        }
        if (r.transientFailure && ++transientFailures < HdrConfig.MAX_TRANSIENT_FAILURES) {
            return "OK|" + expiryText;
        }
        reset();
        return "ERR|" + r.reason;
    }

    private static final class Result {
        boolean ok;
        boolean transientFailure;
        String reason = "";
        String expiry = "";
        static Result fail(String reason) { Result r = new Result(); r.reason = reason; return r; }
        static Result network(String reason) { Result r = fail(reason); r.transientFailure = true; return r; }
    }

    private static Result check(Context context, String key) {
        if (!validDbUrl(HdrConfig.FIREBASE_DB_URL))
            return Result.fail("Login is not configured (HdrConfig.FIREBASE_DB_URL).");
        if (key.isEmpty() || !KEY_PATTERN.matcher(key).matches())
            return Result.fail("Invalid key format.");
        final String device = deviceId(context);
        final String base = HdrConfig.FIREBASE_DB_URL + "/" + HdrConfig.KEYS_NODE + "/" + enc(key);
        try {
            Http first = http("GET", base + ".json", null);
            if (first.status != 200) return httpFailure(first.status);
            Result parsed = evaluate(first, device);
            if (parsed != null) return parsed;

            // Device slot is empty: claim it, then read back to detect a concurrent claim.
            if (!HdrConfig.BIND_DEVICE) return accept(first);
            Http put = http("PUT", base + "/" + HdrConfig.FIELD_DEVICE + ".json", JSONObject.quote(device));
            if (put.status != 200) return Result.fail("Could not bind this device to the key.");
            Http again = http("GET", base + ".json", null);
            if (again.status != 200) return httpFailure(again.status);
            Result confirmed = evaluate(again, device);
            if (confirmed == null) return Result.fail("Could not bind this device to the key.");
            return confirmed;
        } catch (java.net.SocketTimeoutException | java.net.UnknownHostException e) {
            return Result.network("Network unavailable. Check your connection.");
        } catch (javax.net.ssl.SSLException e) {
            return Result.network("Secure connection failed. Check date/time and network.");
        } catch (Exception e) {
            return Result.network("Login request failed.");
        }
    }

    /** Returns a final Result, or null when the key is valid but not yet bound to a device. */
    private static Result evaluate(Http response, String device) throws Exception {
        final String body = response.body.trim();
        if (body.isEmpty() || body.equals("null")) return Result.fail("Invalid key.");
        JSONObject node;
        try { node = new JSONObject(body); }
        catch (Exception e) { return Result.fail("Invalid key record."); }

        if (!node.optBoolean(HdrConfig.FIELD_ACTIVE, false)) return Result.fail("Key is disabled.");

        String expiryLabel;
        Object rawExpiry = node.opt(HdrConfig.FIELD_EXPIRY);
        if (rawExpiry instanceof String && ((String) rawExpiry).trim().equalsIgnoreCase("Lifetime")) {
            expiryLabel = "Lifetime";
        } else if (rawExpiry instanceof Number) {
            long expiryMs = ((Number) rawExpiry).longValue() * 1000L;
            long now = response.serverTimeMs > 0 ? response.serverTimeMs : System.currentTimeMillis();
            if (expiryMs <= 0) return Result.fail("Key has no valid expiry.");
            if (now >= expiryMs) return Result.fail("Key expired.");
            expiryLabel = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date(expiryMs));
        } else {
            return Result.fail("Key has no valid expiry.");
        }

        if (HdrConfig.BIND_DEVICE) {
            String bound = node.optString(HdrConfig.FIELD_DEVICE, "");
            if (bound.isEmpty()) return null;
            if (!bound.equals(device)) return Result.fail("Key is already used on another device.");
        }
        Result ok = new Result();
        ok.ok = true;
        ok.expiry = expiryLabel;
        return ok;
    }

    private static Result accept(Http response) throws Exception {
        Result r = evaluate(response, "");
        return r != null ? r : Result.fail("Invalid key record.");
    }

    private static Result httpFailure(int status) {
        if (status == 401 || status == 403) return Result.fail("Server rejected the request (database rules).");
        if (status == 429 || status >= 500) return Result.network("Server busy. Try again.");
        return Result.fail("Server error (" + status + ").");
    }

    private static final class Http {
        int status;
        String body = "";
        long serverTimeMs;
    }

    private static Http http(String method, String url, String jsonBody) throws Exception {
        HttpsURLConnection c = (HttpsURLConnection) new URL(url).openConnection();
        try {
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(TIMEOUT_MS);
            c.setReadTimeout(TIMEOUT_MS);
            c.setUseCaches(false);
            c.setRequestMethod(method);
            c.setRequestProperty("Accept", "application/json");
            if (jsonBody != null) {
                byte[] bytes = jsonBody.getBytes(StandardCharsets.UTF_8);
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                c.setFixedLengthStreamingMode(bytes.length);
                try (OutputStream out = c.getOutputStream()) { out.write(bytes); }
            }
            Http h = new Http();
            h.status = c.getResponseCode();
            h.serverTimeMs = c.getDate();
            InputStream in = h.status >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in != null) {
                try (InputStream stream = in) {
                    ByteArrayOutputStream buf = new ByteArrayOutputStream();
                    byte[] chunk = new byte[1024];
                    int n;
                    while ((n = stream.read(chunk)) != -1) {
                        if (buf.size() + n > MAX_RESPONSE) throw new java.io.IOException("response too large");
                        buf.write(chunk, 0, n);
                    }
                    h.body = new String(buf.toByteArray(), StandardCharsets.UTF_8);
                }
            }
            return h;
        } finally {
            c.disconnect();
        }
    }

    private static boolean validDbUrl(String url) {
        if (url == null || !url.startsWith("https://") || url.endsWith("/")) return false;
        try {
            String host = new URL(url).getHost();
            return host != null && (host.endsWith(".firebaseio.com") || host.endsWith(".firebasedatabase.app"));
        } catch (Exception e) {
            return false;
        }
    }

    private static String enc(String s) throws Exception { return URLEncoder.encode(s, "UTF-8"); }

    private static String deviceId(Context context) {
        String id = null;
        try { id = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID); }
        catch (Exception ignored) {}
        if (id == null || id.isEmpty()) id = "unknown";
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(("hdr-engine|" + id).getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 8; i++) sb.append(String.format(Locale.US, "%02x", d[i] & 255));
            return sb.toString();
        } catch (Exception e) {
            return id;
        }
    }
}
